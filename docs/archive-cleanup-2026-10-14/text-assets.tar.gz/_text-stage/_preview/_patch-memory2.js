/* MEMORY.md 二次压缩：只减不增，凑到 ≤3000。命中数 ≠ 1 即整体放弃。 */
const fs = require('fs');
const P = process.argv[2];
let t = fs.readFileSync(P, 'utf8');
const before = t.length;

const reps = [
  ['（10 步→1 条、28 秒、≤8KB 摘要；09:30 automation 用它）',
   '（9 步→1 条、28 秒、≤8KB 摘要；09:30 automation 用它）'],
  ['- ★ **样式沿用既有基线**；被否决的旧样式归档 `_deprecated/` 并标注勿用',
   '- ★ **样式沿用既有基线**；废弃样式归档 `_deprecated/` 并标注勿用'],
  ['2. 旧 app 手工清理（现 4 个）', '2. 旧 app 手工清理（4 个）'],
  ['改卡片 CSS ⇒ `check-card-rules.js`；★二层实拍需 CDP、**分批跑**',
   '改卡片 CSS ⇒ `check-card-rules.js`；★实拍需 CDP、**分批跑**'],
];

let bad = 0;
for (const [a, b] of reps) {
  const n = t.split(a).length - 1;
  if (n !== 1) { console.log('MISS/AMBIG(' + n + '): ' + a.slice(0, 44)); bad++; continue; }
  t = t.replace(a, b);
  console.log('ok  (' + (b.length - a.length) + '): ' + a.slice(0, 44));
}
if (bad) { console.log('\n✗ 有 ' + bad + ' 条未命中 —— 未写盘'); process.exit(1); }
fs.writeFileSync(P, t);
console.log('\nchars: ' + before + ' -> ' + t.length + '  (limit 3000, headroom ' + (3000 - t.length) + ')');
const crlf = (t.match(/\r\n/g) || []).length, lf = (t.match(/(?<!\r)\n/g) || []).length;
console.log('line endings: CRLF=' + crlf + ' LFonly=' + lf + ' ' + ((crlf > 0 && lf > 0) ? '*** MIXED ***' : 'ok'));
