/* 探针：3DM Mod 详情页 —— 抓接口 + 点下载按钮看真实行为（不入库） */
const { connectBrowser, sleep } = require('../tools/browser');

(async () => {
  const handle = await connectBrowser();
  const browser = handle.browser || handle;
  const page = await browser.newPage();
  await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36');

  const hits = [];
  page.on('response', async (res) => {
    const u = res.url();
    const ct = res.headers()['content-type'] || '';
    if (/json/i.test(ct) && !/\.js(\?|$)/.test(u)) {
      let b = '';
      try { b = (await res.text()).slice(0, 260); } catch (e) { b = '(读不到)'; }
      hits.push({ s: res.status(), u: u.slice(0, 130), b: b.replace(/\s+/g, ' ').slice(0, 230) });
    }
  });
  const navs = [];
  page.on('framenavigated', (f) => { if (f === page.mainFrame()) navs.push(f.url().slice(0, 150)); });

  const t = 'https://mod.3dmgame.com/mod/253263';
  try { await page.goto(t, { waitUntil: 'networkidle2', timeout: 60000 }); } catch (e) { console.log('goto warn:', e.message); }
  await sleep(5000);

  const txt = await page.evaluate(() => document.body.innerText.replace(/\s+/g, ' ').slice(0, 700)).catch(() => '');
  console.log('=== 详情页文本 ===');
  console.log(txt);

  const before = hits.length;
  const btn = await page.evaluate(() => {
    const els = [...document.querySelectorAll('a,button,div,span')];
    const hit = els.find((e) => /下载|获取|立即/.test((e.textContent || '').trim()) && (e.textContent || '').trim().length <= 8);
    if (hit) { hit.click(); return (hit.textContent || '').trim(); }
    return '';
  }).catch(() => '');
  console.log('\n点击按钮:', JSON.stringify(btn));
  await sleep(6000);

  console.log('\n=== 点击后新增 JSON ===');
  for (const h of hits.slice(before)) console.log(h.s, h.u, '\n   →', h.b);
  console.log('\n=== 全部 JSON 接口 ===');
  const seen = new Set();
  for (const h of hits) { if (seen.has(h.u)) continue; seen.add(h.u); console.log(h.s, h.u, '\n   →', h.b.slice(0, 200)); }
  console.log('\n=== 跳转 ===');
  console.log(navs.join('\n'));

  await page.close();
  if (handle.close) await handle.close();
})().catch((e) => { console.error('失败:', e.message); process.exit(1); });
