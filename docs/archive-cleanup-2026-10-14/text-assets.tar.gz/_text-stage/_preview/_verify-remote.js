/* 独立复核：用 GitHub REST API 读远端 refs/heads/main，与本地 HEAD 比。
   与 _push-via-api.js 走不同的代码路径（不共享任何函数/变量）。 */
const https = require('https');
const fs = require('fs');
const { execSync } = require('child_process');

const TOKEN = process.env.GH_TOKEN;
const REPO = 'A13612812330/game-aggregator';

function api(pathname) {
  return new Promise((resolve, reject) => {
    const req = https.request(
      {
        hostname: 'api.github.com',
        path: pathname,
        method: 'GET',
        headers: {
          'User-Agent': 'verify-remote',
          Authorization: 'Bearer ' + TOKEN,
          Accept: 'application/vnd.github+json',
        },
        timeout: 30000,
      },
      (res) => {
        let d = '';
        res.on('data', (c) => (d += c));
        res.on('end', () => {
          let j = null;
          try { j = JSON.parse(d); } catch (e) { /* keep raw */ }
          resolve({ status: res.statusCode, body: j, raw: d });
        });
      }
    );
    req.on('timeout', () => req.destroy(new Error('timeout')));
    req.on('error', reject);
    req.end();
  });
}

(async () => {
  const localHead = execSync('git rev-parse HEAD').toString().trim();
  const localTree = execSync('git show -s --format=%T HEAD').toString().trim();

  const ref = await api(`/repos/${REPO}/git/ref/heads/main`);
  const commit = await api(`/repos/${REPO}/git/commits/${localHead}`);

  const remoteSha = ref.body && ref.body.object ? ref.body.object.sha : null;
  const remoteTree = commit.body && commit.body.tree ? commit.body.tree.sha : null;

  console.log('ref HTTP          :', ref.status);
  console.log('commit HTTP       :', commit.status);
  console.log('remote main (API) :', remoteSha);
  console.log('local HEAD        :', localHead);
  console.log('sha  MATCH        :', remoteSha === localHead ? 'YES ok' : 'NO FAIL');
  console.log('commit tree (API) :', remoteTree);
  console.log('local tree        :', localTree);
  console.log('tree MATCH        :', remoteTree === localTree ? 'YES ok' : 'NO FAIL');
  console.log('commit msg (API)  :', String(commit.body.message || '').split('\n')[0]);

  const ok = remoteSha === localHead && remoteTree === localTree;
  console.log('\nVERDICT           :', ok ? 'REMOTE_IN_SYNC ok' : 'REMOTE_MISMATCH FAIL');
  process.exit(ok ? 0 : 1);
})().catch((e) => {
  console.error('ERR', e.message);
  process.exit(2);
});
