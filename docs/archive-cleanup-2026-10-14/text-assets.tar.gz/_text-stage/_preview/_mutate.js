#!/usr/bin/env node
'use strict';
/* 只做一件事：对 tools/keepalive-8123.vbs 应用/还原一个变异。
   测试由外层 shell 单独跑（沙箱里 node 不能再 spawn node）。
   原始字节存在 _preview/keepalive-8123.vbs.orig，还原走「写回 + 字节校验」。 */
const fs = require('fs');
const crypto = require('crypto');
const F = 'tools/keepalive-8123.vbs';
const BK = '_preview/keepalive-8123.vbs.orig';
const md5 = (b) => crypto.createHash('md5').update(b).digest('hex');

const MUTS = [
  ['把隐藏窗口改回显示（Run 第 2 参数 0 -> 1）', (s) => s.replace('shell.Run cmd, 0, False', 'shell.Run cmd, 1, False')],
  ['去掉「已在监听就退出」快速路径', (s) => s.replace('If PortBusy(PORT) Then WScript.Quit 0', 'If False Then WScript.Quit 0')],
  ['端口改成 8124（与 server.js 不一致）', (s) => s.replace('Const PORT = 8123', 'Const PORT = 8124')],
  ['不再轮询核实端口（WAIT_S -> 0）', (s) => s.replace('Do While n < WAIT_S', 'Do While n < 0')],
  ['去掉失败日志（START FAILED）', (s) => s.replace(/START FAILED/g, 'oops')],
  ['硬编码版本目录（不扫 managed 运行时）', (s) => s.replace('vbase = shell.ExpandEnvironmentStrings("%USERPROFILE%")', 'vbase = "C:\\x\\versions\\22.22.2-6"')],
  ['写死绝对路径（不用 ScriptFullName）', (s) => s.replace('fso.GetParentFolderName(fso.GetParentFolderName(WScript.ScriptFullName))', '"E:\\x"')],
  ['日志落点改掉（keepalive.log -> out.txt）', (s) => s.replace(/keepalive\.log/g, 'out.txt')],
];

const cmd = process.argv[2];
const src = fs.existsSync(BK) ? fs.readFileSync(BK, 'utf8') : '';

if (cmd === 'backup') {
  fs.copyFileSync(F, BK);
  console.log('backup ok  md5=' + md5(fs.readFileSync(F)));
} else if (cmd === 'list') {
  MUTS.forEach((m, i) => console.log(i + '  ' + m[0]));
} else if (cmd === 'count') {
  console.log(MUTS.length);
} else if (cmd === 'apply') {
  const i = Number(process.argv[3]);
  const out = MUTS[i][1](src);
  if (out === src) { console.log('NOOP(变异表达式没命中)'); process.exit(2); }
  fs.writeFileSync(F, out);
  console.log('applied #' + i + '  ' + MUTS[i][0]);
} else if (cmd === 'restore') {
  fs.writeFileSync(F, src);
  // 注意：要比的是**文件内容**，不是路径字符串（这里原来写成 md5(BK)，
  // 于是永远不相等 —— 反证脚本自身也会骗人）。
  const same = md5(fs.readFileSync(F)) === md5(fs.readFileSync(BK));
  console.log(same ? 'restore ok (byte-identical)' : 'RESTORE MISMATCH');
  process.exit(same ? 0 : 1);
} else {
  console.log('usage: backup | list | count | apply <i> | restore');
}
