/* 探针：打开 3DM Mod 站，抓其真实业务接口（不入库） */
const { connectBrowser, sleep } = require('../tools/browser');

(async () => {
  const handle = await connectBrowser();
  const browser = handle.browser || handle;
  const page = await browser.newPage();
  await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36');

  const hits = [];
  page.on('response', async (res) => {
    const u = res.url();
    const ct = (res.headers()['content-type'] || '');
    if (/json/i.test(ct) && !/\.js(\?|$)/.test(u)) {
      let b = '';
      try { b = (await res.text()).slice(0, 300); } catch (e) { b = '(读不到)'; }
      hits.push({ s: res.status(), u: u.slice(0, 140), b: b.replace(/\s+/g, ' ').slice(0, 240) });
    }
  });

  const targets = [
    'https://mod.3dmgame.com/',
    'https://mod.3dmgame.com/list',
  ];
  for (const t of targets) {
    try { await page.goto(t, { waitUntil: 'networkidle2', timeout: 60000 }); } catch (e) { console.log('goto warn:', t, e.message); }
    await sleep(5000);
    const txt = await page.evaluate(() => document.body.innerText.replace(/\s+/g, ' ').slice(0, 400)).catch(() => '');
    console.log('\n### ' + t);
    console.log('可见文本:', txt);
  }

  console.log('\n=== 命中 JSON 接口 ===');
  const seen = new Set();
  for (const h of hits) { if (seen.has(h.u)) continue; seen.add(h.u); console.log(h.s, h.u); console.log('   →', h.b.slice(0, 200)); }

  await page.close();
  if (handle.close) await handle.close();
})().catch((e) => { console.error('失败:', e.message); process.exit(1); });
