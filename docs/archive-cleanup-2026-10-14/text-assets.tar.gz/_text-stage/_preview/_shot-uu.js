/* 实拍：UU 云存档 热门游戏市集 + 存档详情页（不入库） */
const { connectBrowser, sleep } = require('../tools/browser');
const path = require('path');

(async () => {
  const handle = await connectBrowser();
  const browser = handle.browser || handle;
  const page = await browser.newPage();
  await page.setViewport({ width: 1440, height: 1100 });
  await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36');

  const out = path.join(__dirname, '_uu-market.png');
  const out2 = path.join(__dirname, '_uu-detail.png');

  try { await page.goto('https://archive.uu.163.com/app/cloud-archive/hot-games', { waitUntil: 'networkidle2', timeout: 60000 }); } catch (e) { console.log('warn1', e.message); }
  await sleep(5000);
  await page.screenshot({ path: out });
  console.log('已存', out);

  try { await page.goto('https://archive.uu.163.com/app/cloud-archive/675ec8a992ba86eafc953873', { waitUntil: 'networkidle2', timeout: 60000 }); } catch (e) { console.log('warn2', e.message); }
  await sleep(5000);
  await page.screenshot({ path: out2 });
  console.log('已存', out2);

  await page.close();
  if (handle.close) await handle.close();
})().catch((e) => { console.error('失败:', e.message); process.exit(1); });
