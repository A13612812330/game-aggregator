/* 验证：详情页底部「修改器 / Mod」按钮是否真的被隐藏（只读）
 * 对比同一游戏的 /api/mods/match 实际条数
 * 用法：node _preview/_verify-mod-entry.js
 */
const path = require('path');
const http = require('http');
const { connectBrowser, newPage, sleep } = require('../tools/browser');

const BASE = process.env.BASE || 'http://127.0.0.1:8123';
const LIBID = process.env.LIBID || 'xd-7272';

const get = (p) => new Promise((r) => {
  const q = http.get(BASE + p, (res) => { let d = ''; res.on('data', (c) => (d += c)); res.on('end', () => r(d)); });
  q.on('error', () => r('ERR')); q.setTimeout(25000, () => { q.destroy(); r('TO'); });
});

(async () => {
  const m = JSON.parse(await get('/api/mods/match?id=' + encodeURIComponent(LIBID) + '&kind=mod&limit=5'));
  const mf = JSON.parse(await get('/api/mods/match?id=' + encodeURIComponent(LIBID) + '&kind=modifier&limit=5'));
  console.log('后端 /api/mods/match 实际条数： mod=' + (m.count || 0) + '  modifier=' + (mf.count || 0));

  const dl = JSON.parse(await get('/api/download?source=xd&id=' + encodeURIComponent(LIBID)));
  console.log('/api/download(source=xd) ok=' + dl.ok + ' engine=' + dl.engine + ' sections=' + JSON.stringify((dl.sections || []).map((s) => s.key + ':' + (s.count || 0))));

  const { browser, close } = await connectBrowser();
  const page = await newPage(browser);
  await page.setViewport({ width: 1280, height: 940 });
  await page.goto(BASE, { waitUntil: 'networkidle2', timeout: 45000 });
  await sleep(1000);
  await page.evaluate(async (id) => { if (window.openDetailById) await window.openDetailById(id); }, LIBID);
  for (let i = 0; i < 50; i++) {
    const n = await page.evaluate(() => document.querySelectorAll('[data-dlmod-open]').length);
    if (n) break; await sleep(400);
  }
  await sleep(4000);   // 给 /api/download 回填条数留时间

  const st = await page.evaluate(() => {
    const strip = document.getElementById('dlStrip');
    return {
      stripHidden: strip ? strip.hidden : null,
      stripVisible: strip ? strip.getBoundingClientRect().width > 0 : null,
      btns: [...document.querySelectorAll('[data-dlmod-open]')].map((b) => ({
        kind: b.dataset.dlmodOpen,
        hidden: b.hidden,
        visible: b.getBoundingClientRect().width > 0,
        offsetParent: b.offsetParent !== null,
        num: (b.querySelector('i') || {}).textContent,
      })),
      bodyBtnVisible: (() => { const x = document.querySelector('[data-dl-open]'); return x ? x.getBoundingClientRect().width > 0 : null; })(),
    };
  });
  console.log('前端实测：' + JSON.stringify(st, null, 1));
  await close();
})().catch((e) => { console.error('ERR', e.message); process.exit(1); });
