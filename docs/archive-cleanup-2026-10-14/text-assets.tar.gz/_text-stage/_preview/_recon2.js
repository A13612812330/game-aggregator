/* 侦察 2：① .gitignore ② 启动器 ③ report.js 判据 ④ README块 vs docs/versions 等价性 ⑤ CODEX-INDEX 结构 */
const fs = require('fs');
const path = require('path');
const cp = require('child_process');

console.log('===== ① .gitignore =====');
console.log(fs.readFileSync('.gitignore', 'utf8'));

console.log('\n===== ② 启动器 / 发布相关文件 =====');
for (const f of fs.readdirSync('.')) {
  if (/\.(cmd|vbs|ps1|bat)$/i.test(f)) {
    const st = fs.statSync(f);
    console.log('  ' + f.padEnd(34) + st.size + ' B  ' + st.mtime.toISOString().slice(0, 16));
  }
}
console.log('  -- 根目录 _deploy-* / _archived 体积 --');
for (const d of fs.readdirSync('.').filter(n => /^_deploy-|^_archived$/.test(n))) {
  let s = 0, n = 0;
  (function w(p) { for (const e of fs.readdirSync(p, { withFileTypes: true })) { const q = path.join(p, e.name); if (e.isDirectory()) w(q); else { try { s += fs.statSync(q).size; n++; } catch (_) { } } } })(d);
  console.log('  ' + d.padEnd(30) + (s / 1048576).toFixed(1).padStart(8) + ' MB / ' + n + ' files');
}

console.log('\n===== ③ report.js 判据相关行 =====');
const rj = fs.readFileSync('tools/report.js', 'utf8').split(/\r?\n/);
rj.forEach((l, i) => {
  if (/CODEX-INDEX|README\.md|更新日志|spec\/dict|archRule|md5|changelog|logBlock/.test(l)) {
    console.log('  L' + (i + 1) + ': ' + l.trim().slice(0, 120));
  }
});

console.log('\n===== ④ README 版本块 vs docs/versions 等价性 =====');
function blocks(text) {
  const lines = text.split(/\r?\n/);
  const out = [];
  let cur = null;
  lines.forEach((l, i) => {
    const m = /^##\s+(.*?v(\d+\.\d+)\s*增量.*)$/.exec(l.trim());
    if (m) { if (cur) out.push(cur); cur = { ver: 'v' + m[2], title: m[1], from: i + 1, lines: [] }; return; }
    if (cur) {
      if (/^##\s/.test(l.trim()) || /^#\s/.test(l.trim())) { out.push(cur); cur = null; return; }
      cur.lines.push(l);
    }
  });
  if (cur) out.push(cur);
  return out;
}
const norm = (s) => s.replace(/\s+/g, '').replace(/[|*`>#\-]/g, '');
const readme = fs.readFileSync('README.md', 'utf8');
const cidx = fs.readFileSync('CODEX-INDEX.md', 'utf8');
const rb = blocks(readme), cb = blocks(cidx);
console.log('README 版本块:', rb.length, '| CODEX-INDEX 版本块:', cb.length);
console.log('-- 逐版：README块长度 vs docs/versions/vX.Y.md 长度 vs 是否等价 --');
const allV = [...new Set([...rb.map(b => b.ver), ...cb.map(b => b.ver)])].sort((a, b) => {
  const p = (s) => s.slice(1).split('.').map(Number);
  const A = p(a), B = p(b); return A[0] - B[0] || A[1] - B[1];
});
for (const v of allV) {
  const r = rb.find(b => b.ver === v);
  const c = cb.find(b => b.ver === v);
  const vf = 'docs/versions/' + v + '.md';
  let vlen = 0, hasFile = false;
  try { vlen = fs.readFileSync(vf, 'utf8').length; hasFile = true; } catch (_) { }
  const nR = r ? norm(r.lines.join('\n')) : '';
  const nC = c ? norm(c.lines.join('\n')) : '';
  const nV = hasFile ? norm(fs.readFileSync(vf, 'utf8')) : '';
  const sameRC = nR && nC ? (nR === nC ? '块全等' : '块不同') : '(缺一侧)';
  // README 块是否被 versions 文件包含
  let covered = '';
  if (nR && nV) covered = nV.includes(nR.slice(0, 200)) ? 'README块∈versions文件' : (nR.includes(nV.slice(0, 200)) ? 'versions文件∈README块' : '★互不包含');
  console.log('  ' + v.padEnd(7) + ' README块=' + String(nR.length).padStart(6) + '  CIDX块=' + String(nC.length).padStart(6) + '  versions=' + String(nV.length).padStart(6) + '  ' + sameRC + '  ' + covered);
}

console.log('\n===== ⑤ CODEX-INDEX.md 结构 =====');
const cl = cidx.split(/\r?\n/);
console.log('lines', cl.length, '| H1/H2 计数:',
  'H1=' + cl.filter(l => /^#\s/.test(l)).length,
  'H2=' + cl.filter(l => /^##\s/.test(l)).length);
console.log('-- 前 40 行 --');
console.log(cl.slice(0, 40).map((l, i) => '  ' + (i + 1) + '| ' + l.slice(0, 110)).join('\n'));
console.log('-- 末尾 12 行 --');
console.log(cl.slice(-12).map((l, i) => '  | ' + l.slice(0, 110)).join('\n'));

console.log('\n===== ⑥ git 跟踪的 _*/启动器 =====');
console.log(cp.execSync('git ls-files', { encoding: 'utf8' }).split(/\r?\n/).filter(f => /^_|\.(cmd|vbs)$/i.test(f)).join('\n'));
