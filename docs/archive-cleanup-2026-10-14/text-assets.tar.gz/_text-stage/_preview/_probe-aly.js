/* 探针：游侠补丁详情页 —— 点击「本地下载」抓真实网络请求
   判定：真文件直链 / 导流 / 需登录
   用法：node _preview/_probe-aly.js [url] */
const { connectBrowser, sleep } = require('../tools/browser');

const URL_ = process.argv[2] || 'https://patch.ali213.net/showpatch/310835.html';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36';

(async () => {
  const handle = await connectBrowser();
  const browser = handle.browser;
  const page = await browser.newPage();
  await page.setUserAgent(UA);

  const hits = [];
  page.on('request', (r) => {
    const u = r.url();
    if (/\.(zip|rar|7z|torrent|exe)(\?|$)/i.test(u) || /xunlei|baidu|quark|pan\.|downfile|dl\./i.test(u)) {
      hits.push({ m: r.method(), u: u.slice(0, 180), t: r.resourceType() });
    }
  });
  const pops = [];
  browser.on('targetcreated', async (t) => { if (t.type() === 'page') pops.push(t.url()); });

  console.log('打开:', URL_);
  try { await page.goto(URL_, { waitUntil: 'domcontentloaded', timeout: 45000 }); } catch (e) { console.log('goto 警告:', e.message); }
  await sleep(3000);

  const info = await page.evaluate(() => {
    const out = { downUrl: null, els: [], dlSection: '' };
    try { out.downUrl = (typeof downUrl !== 'undefined') ? downUrl : null; } catch (e) {}
    document.querySelectorAll('a,button').forEach((el) => {
      const t = (el.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 26);
      if (/下载|本地|高速|普通|网盘|迅雷|资源地址/.test(t)) {
        out.els.push(t + ' → ' + ((el.getAttribute('href') || el.getAttribute('onclick') || '(无)').slice(0, 100)));
      }
    });
    const sec = document.getElementsByName('001')[0] || document.getElementById('001');
    if (sec && sec.parentElement) out.dlSection = (sec.parentElement.innerText || '').replace(/\s+/g, ' ').slice(0, 400);
    return out;
  });
  console.log('页面 downUrl =', info.downUrl);
  console.log('下载相关元素:');
  for (const e of info.els.slice(0, 10)) console.log('   ·', e);
  console.log('下载区正文:', info.dlSection || '(空)');

  // 点「本地下载」
  const clicked = await page.evaluate(() => {
    const el = [...document.querySelectorAll('a,button')].find((x) => /本地下载/.test(x.textContent || ''));
    if (el) { el.click(); return (el.textContent || '').trim(); }
    return null;
  });
  console.log('已点击:', clicked || '(未找到)');
  await sleep(5000);

  const after = await page.evaluate(() => ({ url: location.href, txt: document.body.innerText.replace(/\s+/g, ' ').slice(0, 260) }));
  console.log('点击后 URL:', after.url);
  console.log('点击后正文:', after.txt);
  console.log('新开窗口:', pops.join(' | ') || '(无)');
  console.log('=== 捕获请求 ===');
  for (const h of hits.slice(0, 15)) console.log('  ', h.m, h.t, h.u);

  await page.close();
  if (handle.close) await handle.close();
})().catch((e) => { console.error('ERR', e.message); process.exit(1); });
