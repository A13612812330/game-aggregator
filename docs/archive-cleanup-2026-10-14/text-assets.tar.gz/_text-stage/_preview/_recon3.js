/* 侦察 3：① README摘要块的信息覆盖度 ② 载荷目录实况 ③ CODEX-INDEX 顶部块范围 */
const fs = require('fs');
const path = require('path');

const norm = (s) => s.replace(/\s+/g, '');
const readme = fs.readFileSync('README.md', 'utf8');
const rl = readme.split(/\r?\n/);

/* ---- 收集 README 版本块 ---- */
function blocks(lines, re) {
  const out = []; let cur = null;
  lines.forEach((l, i) => {
    const m = re.exec(l.trim());
    if (m) { if (cur) out.push(cur); cur = { ver: 'v' + m[1], from: i + 1, lines: [] }; return; }
    if (cur) { if (/^#{1,2}\s/.test(l.trim())) { out.push(cur); cur = null; return; } cur.lines.push(l); }
  });
  if (cur) out.push(cur);
  return out;
}
const rb = blocks(rl, /^##\s+.*?v(\d+\.\d+)\s*增量/);

console.log('===== ① 覆盖率：README 摘要块里的「路径」与「数字」是否都在 docs/versions 全文里 =====');
let missTotal = 0, tokTotal = 0;
const perVer = [];
for (const b of rb) {
  const vf = 'docs/versions/' + b.ver + '.md';
  let full = ''; try { full = norm(fs.readFileSync(vf, 'utf8')); } catch (_) { }
  const body = b.lines.join('\n');
  const paths = [...new Set((body.match(/`[^`\n]{2,80}`/g) || []).map(s => s.slice(1, -1))
    .filter(s => /[\/\\.]|^[a-z-]+\.js$/.test(s) && !/\s/.test(s)))];
  const nums = [...new Set(body.match(/\b\d[\d,]{2,}\b/g) || [])];
  const toks = [...paths, ...nums];
  const miss = toks.filter(t => !full.includes(norm(t)));
  tokTotal += toks.length; missTotal += miss.length;
  perVer.push({ v: b.ver, tok: toks.length, miss: miss.length, sample: miss.slice(0, 4) });
}
perVer.forEach(p => console.log('  ' + p.v.padEnd(7) + ' tokens=' + String(p.tok).padStart(3) + ' missing=' + String(p.miss).padStart(3) + (p.sample.length ? '  e.g. ' + p.sample.join(' , ') : '')));
console.log('  ---- 合计: ' + tokTotal + ' tokens, 缺失 ' + missTotal + ' (' + (tokTotal ? (missTotal * 100 / tokTotal).toFixed(1) : '0') + '%) ----');

/* ---- 未覆盖的 token 全列（判可否安全删） ---- */
console.log('\n-- 全部未覆盖 token（去重）--');
const allMiss = {};
for (const b of rb) {
  const vf = 'docs/versions/' + b.ver + '.md';
  let full = ''; try { full = norm(fs.readFileSync(vf, 'utf8')); } catch (_) { }
  const body = b.lines.join('\n');
  const toks = [...(body.match(/`[^`\n]{2,80}`/g) || []).map(s => s.slice(1, -1)).filter(s => /[\/\\.]/.test(s) && !/\s/.test(s)),
  ...(body.match(/\b\d[\d,]{2,}\b/g) || [])];
  [...new Set(toks)].filter(t => !full.includes(norm(t))).forEach(t => allMiss[t] = (allMiss[t] || 0) + 1);
}
const am = Object.entries(allMiss).sort((a, b) => b[1] - a[1]);
console.log('  ' + (am.length ? am.slice(0, 40).map(([t, n]) => t + '(x' + n + ')').join('  ') : '(无)'));
console.log('  未覆盖 token 种类数:', am.length);

/* ---- ② 工作区根载荷目录 ---- */
console.log('\n===== ② 载荷目录（工作区根）=====');
const UP = 'E:/新建文件夹/WorkBuddy/2026-09-03-16-11-58';
for (const d of fs.readdirSync(UP).filter(n => /^_deploy-/.test(n))) {
  let s = 0, n = 0;
  (function w(p) { for (const e of fs.readdirSync(p, { withFileTypes: true })) { const q = path.join(p, e.name); if (e.isDirectory()) w(q); else { try { s += fs.statSync(q).size; n++; } catch (_) { } } } })(path.join(UP, d));
  console.log('  ' + d.padEnd(26) + (s / 1048576).toFixed(1).padStart(8) + ' MB / ' + String(n).padStart(5) + ' files');
}

/* ---- ③ CODEX-INDEX 顶部块 ---- */
console.log('\n===== ③ CODEX-INDEX.md 引用块边界 =====');
const cl = fs.readFileSync('CODEX-INDEX.md', 'utf8').split(/\r?\n/);
let started = false, lastQuote = -1, firstNonQuote = -1;
cl.forEach((l, i) => {
  if (/^>/.test(l)) { started = true; lastQuote = i; }
  else if (started && firstNonQuote < 0) firstNonQuote = i;
});
console.log('  块结束于 L' + (lastQuote + 1) + '（最后一行引用）；第一个非引用行 L' + (firstNonQuote + 1));
console.log('  引用块内 H2:', cl.slice(0, lastQuote + 1).filter(l => /^>\s*##\s/.test(l)).length);
console.log('  引用块内版本标题:', cl.slice(0, lastQuote + 1).filter(l => /^>\s*##\s.*?v\d+\.\d+\s*增量/.test(l)).map(l => l.trim().replace(/^>\s*##\s*/, '').slice(0, 60)).join(' | '));
console.log('  引用块后剩下', cl.length - lastQuote - 1, '行，示例：');
cl.slice(lastQuote + 1, lastQuote + 8).forEach((l, i) => console.log('    ' + (lastQuote + 2 + i) + '| ' + l.slice(0, 110)));
