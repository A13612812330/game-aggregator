const fs = require('fs');
const p = '.workbuddy/memory/MEMORY.md';
const t = fs.readFileSync(p, 'utf8');
const crlf = (t.match(/\r\n/g) || []).length;
const lf = (t.match(/(?<!\r)\n/g) || []).length;
console.log('chars', t.length, '| limit 3000 | headroom', 3000 - t.length);
console.log('CRLF', crlf, '| LFonly', lf, (crlf > 0 && lf > 0) ? '*** MIXED ***' : 'ok');
const keys = [
  'v10.41 修复未上线',
  '本地 9',
  '39 套 / 2733 条',
  '三实例对照',
  "side:'game'",
  '基础测试数据.xlsx',
  '绝不用 `unpublish`',
  '推送≠上线',
  '每日同步',
  'RE',
];
console.log('--- key items ---');
for (const k of keys) console.log('  ' + (t.includes(k) ? 'OK  ' : 'MISS') + ' ' + k);
console.log('--- 章节完整性（应为 6 个 ##）---');
const heads = t.split(/\r?\n/).filter((l) => /^## /.test(l));
console.log('  count', heads.length, '|', heads.join(' / '));
const rules = t.split(/\r?\n/).filter((l) => /^\d+\. /.test(l));
console.log('--- 列表项总数（铁律30+待办8=38）:', rules.length);
