/* 侦察：① CODEX-INDEX 的引用面 ② README 的重复结构 ③ docs/versions 索引现状 */
const fs = require('fs');
const path = require('path');

const ROOT = process.cwd();
const SKIP = new Set(['node_modules', '.git', '_archived', '_preview', '_deploy-gamehub',
  '_deploy-gamehub-prev', '_deploy-gamehub-old', '.cache']);
const TEXT_EXT = /\.(md|js|json|cmd|vbs|ps1|html|yml|yaml|txt)$/i;

/* ---- ① 全仓检索 "CODEX-INDEX" 引用 ---- */
const hits = [];
function walk(d) {
  for (const e of fs.readdirSync(d, { withFileTypes: true })) {
    if (SKIP.has(e.name)) continue;
    const p = path.join(d, e.name);
    if (e.isDirectory()) { walk(p); continue; }
    if (!TEXT_EXT.test(e.name)) continue;
    let buf;
    try { buf = fs.readFileSync(p); } catch (_) { continue; }
    if (buf.length > 6 * 1024 * 1024) { hits.push({ f: path.relative(ROOT, p), n: 'BIG-SKIP', first: '' }); continue; }
    const t = buf.toString('utf8');
    if (!t.includes('CODEX-INDEX')) continue;
    const lines = t.split(/\r?\n/);
    let n = 0, first = '';
    lines.forEach((l, i) => {
      if (l.includes('CODEX-INDEX')) { n++; if (!first) first = 'L' + (i + 1) + ': ' + l.trim().slice(0, 130); }
    });
    hits.push({ f: path.relative(ROOT, p), n, first });
  }
}
walk(ROOT);
console.log('===== ① CODEX-INDEX 引用面 =====');
console.log('引用文件数:', hits.length);
hits.sort((a, b) => (b.n === 'BIG-SKIP' ? 0 : b.n) - (a.n === 'BIG-SKIP' ? 0 : a.n));
for (const h of hits) console.log('  ' + String(h.n).padStart(4) + '  ' + h.f.padEnd(44) + h.first);

/* ---- ② README 结构：标题 + 偏移重复 ---- */
const rd = fs.readFileSync('README.md', 'utf8');
const rl = rd.split(/\r?\n/);
console.log('\n===== ② README.md =====');
console.log('bytes', Buffer.byteLength(rd), '| lines', rl.length, '| maxLineLen', Math.max(...rl.map(l => l.length)));

function headingsOf(lines) {
  const out = []; let fence = null;
  lines.forEach((raw, i) => {
    const t = raw.trim();
    const f = /^(`{3,}|~{3,})/.exec(t);
    if (f) { const m = f[1][0]; if (fence === null) fence = m; else if (fence === m) fence = null; return; }
    if (fence !== null) return;
    const m = /^(#{1,6})\s+(.+?)\s*$/.exec(t);
    if (m) out.push({ lv: m[1].length, t: m[2], ln: i + 1 });
  });
  return out;
}
const H = headingsOf(rl);
console.log('-- 标题层级计数 --');
const cnt = {};
H.forEach(h => cnt[h.lv] = (cnt[h.lv] || 0) + 1);
console.log('  ' + Object.keys(cnt).sort().map(k => 'H' + k + '=' + cnt[k]).join('  '));
console.log('-- H1 --');
H.filter(h => h.lv === 1).forEach(h => console.log('  L' + h.ln + '  ' + h.t));
console.log('-- H2 (前 60) --');
H.filter(h => h.lv === 2).slice(0, 60).forEach(h => console.log('  L' + String(h.ln).padStart(6) + '  ' + h.t.slice(0, 90)));
console.log('-- H2 总数:', H.filter(h => h.lv === 2).length, ' --');

/* ---- ③ docs/versions 索引 ---- */
console.log('\n===== ③ docs/versions/ =====');
const vf = fs.readdirSync('docs/versions').sort();
console.log('files:', vf.length);
console.log('  ' + vf.join(', '));
