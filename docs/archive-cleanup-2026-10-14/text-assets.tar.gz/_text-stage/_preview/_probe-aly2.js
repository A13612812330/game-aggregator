/* 探针：游侠详情页「点击查找资源地址」→ 抓展开后的真实地址
   用法：node _preview/_probe-aly2.js [url] */
const { connectBrowser, sleep } = require('../tools/browser');

const URL_ = process.argv[2] || 'https://patch.ali213.net/showpatch/313399.html';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36';

(async () => {
  const handle = await connectBrowser();
  const browser = handle.browser;
  const page = await browser.newPage();
  await page.setUserAgent(UA);

  const hits = [];
  page.on('request', (r) => {
    const u = r.url();
    if (/\.(zip|rar|7z|exe|torrent)(\?|$)/i.test(u) || /xunlei|baidu|quark|pan\.|w1z1c|downfile|ali213\.net\/(search|down)/i.test(u)) {
      hits.push({ m: r.method(), u: u.slice(0, 190) });
    }
  });

  console.log('打开:', URL_);
  try { await page.goto(URL_, { waitUntil: 'domcontentloaded', timeout: 45000 }); } catch (e) { console.log('goto 警告:', e.message); }
  await sleep(3000);

  // 先点「本地下载」展开
  await page.evaluate(() => {
    const el = [...document.querySelectorAll('a')].find((x) => /本地下载/.test(x.textContent || ''));
    if (el) el.click();
  });
  await sleep(2000);

  // 再点第一个「点击查找资源地址」
  const r1 = await page.evaluate(() => {
    const el = [...document.querySelectorAll('a')].find((x) => /资源地址/.test(x.textContent || ''));
    if (!el) return '(没找到资源地址按钮)';
    const id = el.id || '';
    el.click();
    return 'clicked id=' + id;
  });
  console.log('点击资源地址:', r1);
  await sleep(5000);

  // 抓展开后的下载区
  const out = await page.evaluate(() => {
    const sec = document.getElementsByName('001')[0];
    const box = sec ? sec.parentElement : document.body;
    const links = [...(box ? box.querySelectorAll('a[href]') : [])].map((a) => (a.textContent || '').trim().slice(0, 20) + ' → ' + a.href).slice(0, 12);
    const modals = [...document.querySelectorAll('[class*=pop],[class*=box],[class*=dialog],[id*=Box]')]
      .filter((e) => e.offsetParent !== null && /下载|地址|网盘|迅雷/.test(e.innerText || ''))
      .slice(0, 3).map((e) => (e.innerText || '').replace(/\s+/g, ' ').slice(0, 300));
    return { links, modals, bodyHas: document.body.innerText.replace(/\s+/g, ' ').slice(0, 200) };
  });
  console.log('下载区链接:'); for (const l of out.links) console.log('   ·', l);
  console.log('弹出层内容:'); for (const m of out.modals) console.log('   ·', m);
  console.log('新窗口/请求:');
  for (const h of hits.slice(0, 14)) console.log('  ', h.m, h.u);

  await page.close();
  if (handle.close) await handle.close();
})().catch((e) => { console.error('ERR', e.message); process.exit(1); });
