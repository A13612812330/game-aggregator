/* 实拍详情抽屉底部的「下载本体 / 修改器 / Mod」动作条（MOD 的入口）
 * 用法：node _preview/_shot-mod-entry.js
 */
const path = require('path');
const { connectBrowser, newPage, sleep } = require('../tools/browser');

const BASE = process.env.BASE || 'http://127.0.0.1:8123';
const LIBID = process.env.LIBID || 'xd-7272';   // 幻兽帕鲁
const OUT = __dirname;

(async () => {
  const { browser, close } = await connectBrowser();
  const page = await newPage(browser);
  await page.setViewport({ width: 1280, height: 940, deviceScaleFactor: 1 });
  await page.goto(BASE, { waitUntil: 'networkidle2', timeout: 45000 });
  await sleep(1200);

  const r = await page.evaluate(async (id) => {
    if (typeof window.openDetailById !== 'function') return 'no-fn';
    await window.openDetailById(id);
    return 'ok';
  }, LIBID);
  if (r !== 'ok') { console.log('打开详情失败:', r); }

  // 等底部动作条渲染（[data-dlmod-open] 是「修改器 / Mod」两个按钮）
  let found = 0;
  for (let i = 0; i < 60; i++) {
    found = await page.evaluate(() => document.querySelectorAll('[data-dlmod-open]').length);
    if (found) break;
    await sleep(400);
  }
  await sleep(800);

  // 把动作条滚进视野
  await page.evaluate(() => {
    const b = document.querySelector('[data-dlmod-open]');
    const bar = b && b.closest('.dl-strip, .d-strip, .ds, section, div');
    if (b) b.scrollIntoView({ block: 'center' });
    if (bar) bar.scrollIntoView({ block: 'center' });
  });
  await sleep(700);
  await page.screenshot({ path: path.join(OUT, '_mod-ui-entry.png') });

  // 特写：动作条本身
  const box = await page.evaluate(() => {
    const b = document.querySelector('[data-dlmod-open]');
    if (!b) return null;
    let n = b;
    for (let i = 0; i < 4 && n.parentElement; i++) n = n.parentElement;
    const r = n.getBoundingClientRect();
    return { x: Math.max(0, r.left - 10), y: Math.max(0, r.top - 10), w: Math.min(1280, r.width + 20), h: Math.min(940, r.height + 20) };
  });
  if (box && box.h > 20) {
    await page.screenshot({ path: path.join(OUT, '_mod-ui-entry-zoom.png'), clip: { x: box.x, y: box.y, width: box.w, height: box.h } });
  }

  const info = await page.evaluate(() => {
    const btns = [...document.querySelectorAll('[data-dlmod-open]')].map((b) => ({
      kind: b.dataset.dlmodOpen, txt: b.textContent.replace(/\s+/g, ' ').trim().slice(0, 40),
      title: (b.dataset.dlmodTitle || '').slice(0, 30), libId: b.dataset.dlmodId || '',
    }));
    const dl = document.querySelector('[data-dl-open]');
    return { btns, hasBodyBtn: !!dl, bodyTxt: dl ? dl.textContent.replace(/\s+/g, ' ').trim().slice(0, 40) : '' };
  });
  console.log(JSON.stringify({ found, zoom: box, ...info }, null, 1));
  await close();
})().catch((e) => { console.error('ERR', e.message); process.exit(1); });
