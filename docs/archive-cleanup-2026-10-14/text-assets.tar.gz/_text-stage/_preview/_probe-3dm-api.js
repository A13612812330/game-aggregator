/* 探针：在浏览器环境内直调 3DM Mod 站 API，找下载直链端点（不入库） */
const { connectBrowser, sleep } = require('../tools/browser');

(async () => {
  const handle = await connectBrowser();
  const browser = handle.browser || handle;
  const page = await browser.newPage();
  await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36');

  try { await page.goto('https://mod.3dmgame.com/', { waitUntil: 'networkidle2', timeout: 60000 }); } catch (e) { console.log('goto warn:', e.message); }
  await sleep(4000);

  const res = await page.evaluate(async () => {
    const out = {};
    const tryGet = async (name, url) => {
      try {
        const r = await fetch(url, { credentials: 'include' });
        const t = await r.text();
        out[name] = { s: r.status, len: t.length, head: t.slice(0, 300) };
      } catch (e) { out[name] = { err: String(e.message || e) }; }
    };
    await tryGet('modList', '/api/home/modList');
    await tryGet('hotMod', '/api/home/hotMod');
    await tryGet('gameList', '/api/game/getList');
    // 下载端点候选
    await tryGet('down1', '/api/mods/down?id=374205');
    await tryGet('down2', '/api/mods/getDownUrl?id=374205');
    await tryGet('down3', '/api/mods/getDown?id=374205');
    await tryGet('down4', '/api/resource/down?id=374205');
    await tryGet('down5', '/api/download?id=374205');
    await tryGet('donwload', '/api/mods/download?id=374205');
    return out;
  });

  for (const [k, v] of Object.entries(res)) {
    console.log('---', k, '---');
    console.log(JSON.stringify(v).slice(0, 420));
  }

  // 找页面里是否已加载的 mod 详情链接形态
  const links = await page.evaluate(() =>
    [...document.querySelectorAll('a[href*="/mod/"], a[href*="/mods/"]')].slice(0, 10).map(a => a.href)
  ).catch(() => []);
  console.log('\n=== mod 详情链接 ===');
  console.log(links.join('\n') || '(无)');

  await page.close();
  if (handle.close) await handle.close();
})().catch((e) => { console.error('失败:', e.message); process.exit(1); });
