/* 就地更新项目 MEMORY.md：逐条替换，命中数 ≠ 1 即报错（防静默失配）。
   ★ 字符预算只剩 30，所以每条都按「近等长」设计：净增目标 ≈ +15。 */
const fs = require('fs');
const P = process.argv[2];
let t = fs.readFileSync(P, 'utf8');
const before = t.length;

const reps = [
  // ① 防线规模：37 套 / 2517 条 → 38 套 / 2703 条
  ['**37 套 / 2517 条**', '**38 套 / 2703 条**'],

  // ② 待办 1：压缩（腾空间）
  ['1. **数据线**：✅ 2-B · ✅ 2-A/2-C 一轮（v10.36）；剩 C 类 **145**（手游）/ **36**（实测库）',
   '1. **数据线**：✅ 2-B · 2-A/2-C 一轮；剩 C 类 145（手游）/ 36（实测库）'],

  // ③ 待办 3：发布现状（本轮最重要的一条）
  ['3. ★发布＝每轮拿授权（已实测：线上前端同版、**服务端停在 v10.35 前**，待授权后覆盖）',
   '3. ★**发布未完成**：v10.39 已授权，被 connector-proxy 故障阻塞（7 次全败）⇒ 重启客户端后重发；载荷已就绪'],

  // ④ 待办 5：口径已解
  ["5. ★ **口径待决**：「未标 DX ⇒ `skip` ⇒ 仍可判『流畅』」（预热自动纠 57 条，口径未改）",
   "5. ✅ **口径已解（v10.39）**：`skip` 拆 `side:'game'`/`'profile'`，影响面 6,585 款"],

  // ⑤ 待办 6：天数
  ['连续 8 日', '连续 9 日'],

  // ⑥ 待办 7：文档副本已清
  ['7. `WORKFLOW.md` 349 行起为前 348 行副本（数字要改两处，待清）；GCM→APK 调研在 `GCM-APK-参考/`',
   '7. ✅ `WORKFLOW.md` 副本已清（752→456 行）；GCM→APK 调研在 `GCM-APK-参考/`'],

  // ⑦ 铁律 7：ls-remote 的真因（代理不通，不是网络不通）
  ['7. 探 GitHub 绝不设 `GIT_TERMINAL_PROMPT=0`；判 push 看 `ls-remote` sha',
   '7. 探 GitHub 绝不设 `GIT_TERMINAL_PROMPT=0`；★`ls-remote` 常报 502（沙箱代理不通，≠网络问题）⇒ 判 push 用 **REST 比 sha/tree**'],
];

let bad = 0;
for (const [a, b] of reps) {
  const n = t.split(a).length - 1;
  if (n !== 1) { console.log('MISS/AMBIG(' + n + '): ' + a.slice(0, 46)); bad++; continue; }
  t = t.replace(a, b);
  console.log('ok  (' + (b.length - a.length >= 0 ? '+' : '') + (b.length - a.length) + '): ' + a.slice(0, 46));
}
if (bad) { console.log('\n✗ 有 ' + bad + ' 条未命中 —— 未写盘'); process.exit(1); }
fs.writeFileSync(P, t);
console.log('\nchars: ' + before + ' -> ' + t.length + ' (limit 3000, headroom ' + (3000 - t.length) + ')');
const crlf = (t.match(/\r\n/g) || []).length, lf = (t.match(/(?<!\r)\n/g) || []).length;
console.log('line endings: CRLF=' + crlf + ' LFonly=' + lf + ' ' + ((crlf > 0 && lf > 0) ? '*** MIXED ***' : 'ok'));
