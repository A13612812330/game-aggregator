$ErrorActionPreference = 'Stop'
$root = 'E:\新建文件夹\WorkBuddy\2026-09-03-16-11-58\game-aggregator'
$log  = Join-Path $root '_preview\_install-keepalive.log'
function W($m) { $m | Out-File -Append -Encoding UTF8 $log }
Remove-Item $log -ErrorAction SilentlyContinue

try {
  $hostExe = Join-Path ([Environment]::SystemDirectory) 'wscript.exe'
  $vbs     = Join-Path $root 'tools\keepalive-8123.vbs'
  W "host exists : $(Test-Path $hostExe)  ($hostExe)"
  W "vbs  exists : $(Test-Path $vbs)"

  $name   = 'GameHub 8123 keepalive'
  $action = New-ScheduledTaskAction -Execute $hostExe -Argument ('"' + $vbs + '"') -WorkingDirectory $root

  # time trigger + per-minute repetition (logon triggers do NOT repeat - see skill)
  $trigger = New-ScheduledTaskTrigger -Daily -At 00:00
  $rep = (New-ScheduledTaskTrigger -Once -At (Get-Date).Date `
      -RepetitionInterval (New-TimeSpan -Minutes 1) `
      -RepetitionDuration (New-TimeSpan -Days 3650)).Repetition
  $rep.StopAtDurationEnd = $false
  $trigger.Repetition = $rep

  $settings = New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew `
    -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable `
    -ExecutionTimeLimit ([TimeSpan]::Zero)

  $existing = Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue
  if ($existing) {
    W "task already exists -> updating (Action, then Trigger separately)"
    Set-ScheduledTask -TaskName $name -Action $action | Out-Null
    Set-ScheduledTask -TaskName $name -Trigger $trigger | Out-Null
    W "updated"
  } else {
    Register-ScheduledTask -TaskName $name -Action $action -Trigger $trigger `
      -Settings $settings -Description 'Silent keepalive for the GameHub aggregator (port 8123).' | Out-Null
    W "registered"
  }

  $t = Get-ScheduledTask -TaskName $name
  $i = Get-ScheduledTaskInfo -TaskName $name
  W "State        = $($t.State)"
  W "NextRunTime  = $($i.NextRunTime)"
  W "LastRunTime  = $($i.LastRunTime)"
  W "Action       = $($t.Actions[0].Execute) $($t.Actions[0].Arguments)"
  W "Interval     = $($t.Triggers[0].Repetition.Interval)"
  W "DONE"
} catch {
  W "ERROR: $($_.Exception.Message)"
  W "TYPE : $($_.Exception.GetType().FullName)"
}
