$root = 'E:\新建文件夹\WorkBuddy\2026-09-03-16-11-58\game-aggregator'
$log  = Join-Path $root '_preview\_kill.txt'
function W($m) { $m | Out-File -Append -Encoding UTF8 $log }
Remove-Item $log -ErrorAction SilentlyContinue
try {
  $c = Get-NetTCPConnection -LocalPort 8123 -State Listen -ErrorAction Stop
  $pid0 = $c.OwningProcess
  W "before  : pid=$pid0"
  Stop-Process -Id $pid0 -Force -ErrorAction Stop
  W "killed  : pid=$pid0"
  Start-Sleep -Seconds 2
  $c2 = Get-NetTCPConnection -LocalPort 8123 -State Listen -ErrorAction SilentlyContinue
  if ($c2) { W "after   : still listening pid=$($c2.OwningProcess)" }
  else     { W "after   : PORT 8123 IS FREE" }
} catch {
  W "ERROR: $($_.Exception.Message)"
}
