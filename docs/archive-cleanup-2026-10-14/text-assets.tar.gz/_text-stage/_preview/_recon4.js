/* 侦察 4：改动波及面 —— 谁在守 server.js 端口 / 启动器 / README / CODEX-INDEX */
const fs = require('fs');
const path = require('path');

const TOOLS = fs.readdirSync('tools').filter(f => f.endsWith('.js'));
const KW = [
  ['EADDRINUSE', /EADDRINUSE/],
  ['port-shift', /port\s*\+\s*1|尝试 \$\{port|triesLeft/],
  ['启动器', /启动聚合站|stop-gamehub|\.vbs|launcher/i],
  ['CODEX-INDEX', /CODEX-INDEX/],
  ['README 版本块', /README\.md/],
];
console.log('===== tools/*.js 中命中关键字的文件 =====');
for (const f of TOOLS) {
  let t; try { t = fs.readFileSync('tools/' + f, 'utf8'); } catch (_) { continue; }
  const hit = KW.filter(([, re]) => re.test(t)).map(([n]) => n);
  if (hit.length) {
    const lines = t.split(/\r?\n/);
    console.log('\n--- tools/' + f + '  [' + hit.join(', ') + ']  (' + lines.length + ' 行)');
    lines.forEach((l, i) => {
      if (KW.some(([, re]) => re.test(l))) console.log('    L' + (i + 1) + ': ' + l.trim().slice(0, 130));
    });
  }
}

console.log('\n===== run-all.js 的 SUITES =====');
const ra = fs.readFileSync('tools/run-all.js', 'utf8');
const block = ra.slice(ra.indexOf('SUITES'), ra.indexOf('SUITES') + 3000);
console.log(block.split(/\r?\n/).slice(0, 60).join('\n'));

console.log('\n===== test-report.js 的判据清单 =====');
const tr = fs.readFileSync('tools/test-report.js', 'utf8').split(/\r?\n/);
tr.forEach((l, i) => { if (/ok\(|fail\(|test\(|assert/.test(l)) console.log('  L' + (i + 1) + ': ' + l.trim().slice(0, 140)); });

console.log('\n===== test-doc-structure.js 中 README / CODEX 相关 =====');
const td = fs.readFileSync('tools/test-doc-structure.js', 'utf8').split(/\r?\n/);
td.forEach((l, i) => { if (/README|CODEX|EXCEPTION|H1_EXCEPT|expect|assert/i.test(l)) console.log('  L' + (i + 1) + ': ' + l.trim().slice(0, 140)); });
