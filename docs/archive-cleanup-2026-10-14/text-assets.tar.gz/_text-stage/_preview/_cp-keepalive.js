#!/usr/bin/env node
'use strict';
/* 反证：把 tools/keepalive-8123.vbs 的每个被守护行为逐个打坏，
   断言 tools/test-launcher.js 必须变红。还原用「写回原文 + 字节校验」，
   不用删除（沙箱对累计删除有护栏）。 */
const fs = require('fs');
const cp = require('child_process');
const crypto = require('crypto');

const F = 'tools/keepalive-8123.vbs';
const orig = fs.readFileSync(F, 'utf8');
const md5 = (s) => crypto.createHash('md5').update(s).digest('hex');
const run = () => {
  // 沙箱里 spawnSync 报 EBUSY；run-all.js 用的就是 execFileSync，跟它保持一致。
  // 断言失败时子进程 exit 1，输出在 error.stdout 里，必须一并取回。
  try {
    return cp.execFileSync(process.execPath, ['tools/test-launcher.js'], { encoding: 'utf8', maxBuffer: 1 << 24 }) || '';
  } catch (e) {
    return (e.stdout || '') + (e.stderr || '');
  }
};
const score = (out) => (out.match(/通过 \d+\s*\/\s*\d+/) || ['(无汇总行)'])[0];

const base = score(run());
console.log('基线：' + base);

const muts = [
  ['把隐藏窗口改回显示（0 -> 1）', (s) => s.replace('shell.Run cmd, 0, False', 'shell.Run cmd, 1, False')],
  ['去掉「已在监听就退出」快速路径', (s) => s.replace('If PortBusy(PORT) Then WScript.Quit 0', 'If False Then WScript.Quit 0')],
  ['端口改成 8124（与 server.js 不一致）', (s) => s.replace('Const PORT = 8123', 'Const PORT = 8124')],
  ['不再轮询核实端口', (s) => s.replace('Do While n < WAIT_S', 'Do While n < 0')],
  ['去掉失败日志', (s) => s.replace('START FAILED', 'oops')],
  ['硬编码版本目录', (s) => s.replace('vbase = shell.ExpandEnvironmentStrings("%USERPROFILE%")', 'vbase = "C:\\x\\versions\\22.22.2-6"')],
  ['把 netstat 探测改回 WshShell Exec（可见 cmd 窗回归）', (s) => s.replace('shell.Run "cmd.exe /c netstat -ano -p tcp > """ & tmp & """", 0, True', 'Set fh = shell.Exec("cmd.exe /c netstat -ano -p tcp")')],
];

let caught = 0;
try {
  for (const [name, fn] of muts) {
    const m = fn(orig);
    if (m === orig) { console.log('  [!!] 变异未生效（表达式没命中）：' + name); continue; }
    fs.writeFileSync(F, m);
    const line = score(run());
    const hit = line !== base;
    if (hit) caught++;
    console.log('  ' + (hit ? '[OK] 抓住' : '[!!] 漏过') + '  ' + name + '  ->  ' + line);
  }
} finally {
  fs.writeFileSync(F, orig);
  const back = md5(fs.readFileSync(F, 'utf8')) === md5(orig);
  console.log('\n还原：' + (back ? '字节一致 [OK]' : '不一致 [!!]'));
  console.log('反证结果：' + caught + ' / ' + muts.length + ' 个变异被抓住');
}
