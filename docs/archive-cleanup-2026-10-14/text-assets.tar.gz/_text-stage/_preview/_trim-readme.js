#!/usr/bin/env node
'use strict';
/* 收敛 README 「更新日志」节里最旧的一版摘要块（v10.38），保持「只留最近 5 版」。
   按行处理：split('\n') 会保留 CRLF 里的 \r，join 回去行尾不变。 */
const fs = require('fs');
const F = 'README.md';
const raw = fs.readFileSync(F, 'utf8');
const lines = raw.split('\n');

const start = lines.findIndex((l) => l.startsWith('### \u2605 v10.38 \u589e\u91cf'));
if (start < 0) { console.log('MISS: 未找到 v10.38 块标题'); process.exit(1); }

let end = -1;
for (let i = start + 1; i < lines.length; i++) {
  const t = lines[i].trim();
  if (t === '---' || lines[i].startsWith('<sub>')) { end = i; break; }
}
if (end < 0) { console.log('MISS: 未找到结束边界'); process.exit(1); }

const before = lines.length;
lines.splice(start, end - start);
fs.writeFileSync(F, lines.join('\n'));
console.log('删除 ' + (before - lines.length) + ' 行（第 ' + (start + 1) + ' ~ ' + end + ' 行，1-based）');
console.log('新行数 ' + lines.length + '（原 ' + before + '）');
