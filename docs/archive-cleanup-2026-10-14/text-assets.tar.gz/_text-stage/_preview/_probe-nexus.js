/* 探针：用真实浏览器打开 NexusMods 存档搜索页，判断可否访问 + 链接形态（不入库） */
const { connectBrowser, sleep } = require('../tools/browser');

(async () => {
  const handle = await connectBrowser();
  const browser = handle.browser || handle;
  const page = await browser.newPage();
  await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36');

  const target = process.argv[2] || 'https://www.nexusmods.com/mods?keyword=save&sort=endorsements&page=5';
  let status = 0;
  page.on('response', (r) => { if (r.url() === target) status = r.status(); });

  try { await page.goto(target, { waitUntil: 'domcontentloaded', timeout: 60000 }); } catch (e) { console.log('goto 警告:', e.message); }
  await sleep(9000);

  const title = await page.title().catch(() => '');
  const txt = await page.evaluate(() => document.body.innerText.replace(/\s+/g, ' ').slice(0, 900)).catch(() => '');
  const links = await page.evaluate(() =>
    [...document.querySelectorAll('a[href*="/mods/"]')].slice(0, 12).map(a => a.href)
  ).catch(() => []);

  console.log('HTTP', status, '| 标题:', title);
  console.log('=== 页面文本(前900) ===');
  console.log(txt);
  console.log('=== mod 链接样例 ===');
  console.log(links.join('\n') || '(无)');

  await page.close();
  if (handle.close) await handle.close();
})().catch((e) => { console.error('探针失败:', e.message); process.exit(1); });
