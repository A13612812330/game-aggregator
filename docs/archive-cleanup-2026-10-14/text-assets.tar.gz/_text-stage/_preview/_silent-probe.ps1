$ErrorActionPreference = 'Stop'
$root = 'E:\新建文件夹\WorkBuddy\2026-09-03-16-11-58\game-aggregator'
$log  = Join-Path $root '_preview\_silent-probe.log'
function W($m) { $m | Out-File -Append -Encoding UTF8 $log }
Remove-Item $log -ErrorAction SilentlyContinue

Add-Type -TypeDefinition @'
using System;using System.Collections.Generic;using System.Text;using System.Runtime.InteropServices;
public class WinMon {
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  public delegate bool EnumProc(IntPtr h, IntPtr p);
  public static List<string> Visible() { var l = new List<string>();
    EnumWindows((h, p) => { if (IsWindowVisible(h)) { var sb = new StringBuilder(256); GetClassName(h, sb, 256);
      if (sb.ToString() == "ConsoleWindowClass") l.Add(h.ToInt64().ToString("X")); } return true; }, IntPtr.Zero);
    return l; }
}
'@ -Language CSharp

$name = 'GameHub 8123 keepalive'
$before = (Get-ScheduledTaskInfo -TaskName $name).LastRunTime
W "sample window: 80s @ 400ms"
W "LastRunTime before sampling: $before"

$samples = New-Object System.Collections.Generic.List[int]
$end = (Get-Date).AddSeconds(80)
while ((Get-Date) -lt $end) {
  $samples.Add([WinMon]::Visible().Count)
  Start-Sleep -Milliseconds 400
}

$min = ($samples | Measure-Object -Minimum).Minimum
$max = ($samples | Measure-Object -Maximum).Maximum
$i   = Get-ScheduledTaskInfo -TaskName $name
W "samples      : $($samples.Count)"
W "visible consoles  min=$min  max=$max   (expect 0 / 0)"
W "LastRunTime after : $($i.LastRunTime)   (must be inside the 80s window)"
W "NextRunTime       : $($i.NextRunTime)"
W "LastTaskResult    : $($i.LastTaskResult)  (wscript always returns 0 - not proof)"
W "DONE"
