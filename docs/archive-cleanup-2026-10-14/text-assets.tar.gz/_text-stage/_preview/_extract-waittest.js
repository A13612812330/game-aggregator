/* 从真实的 启动聚合站.cmd 里抠出「2b) 等端口释放」那一整段，做隔离实跑。
   —— 不复制改写逻辑，而是**逐字抽取**，这样测的就是真代码的语法与分支。
   只把等待上限 20 调成 2（否则失败分支要等 20 秒），并把 pause 保留（运行时用 < /dev/null 喂掉）。 */
const fs = require('fs');
const path = require('path');

const SRC = fs.readFileSync('启动聚合站.cmd', 'utf8');
const L = SRC.split(/\r?\n/);
const i0 = L.findIndex((l) => /2b\) wait until the port is really free/.test(l));
const i1 = L.findIndex((l) => l.trim() === ':FREEOK');
if (i0 < 0 || i1 < 0) { console.error('★ 抽不到代码块（起点/终点锚点失配）'); process.exit(1); }
const block = L.slice(i0 - 1, i1 + 1).join('\r\n').replace('GEQ 20', 'GEQ 2');
console.log('抽出 ' + (i1 - i0 + 2) + ' 行，起点 L' + i0 + ' 终点 L' + i1);

const out = [
  '@echo off',
  'setlocal EnableExtensions',
  'set "PORT=%~1"',
  block,
  'echo [TEST] REACHED_FREEOK',
  'exit /b 0',
].join('\r\n') + '\r\n';

fs.mkdirSync('_preview', { recursive: true });
fs.writeFileSync('_preview/_waittest.cmd', out, 'utf8');
console.log('已写 _preview/_waittest.cmd（' + Buffer.byteLength(out) + ' B）');
