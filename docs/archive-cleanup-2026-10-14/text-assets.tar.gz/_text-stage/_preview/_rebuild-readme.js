/* v10.42 文档收敛（1/2）：备份 + 重建 README.md
 *
 * README 现状：L1..L2009 = 34 个版本摘要块（v10.41 → v10.1，往上长）；
 *             L2010 = `---`；L2011.. = 项目说明（唯一的 H1）。
 * 目标：项目说明前置；版本摘要只留最近 4 版（v10.41..v10.38）作为「最近改了什么」，
 *       其余交给 docs/versions/（全文）——同一内容不再写两处。
 *
 * ★ 字节安全：文档是 CRLF，一律 Buffer 读 + split(/\r?\n/) + join('\r\n')，
 *   只拼接完整行，绝不做字符串级改写（按字符串改写会换掉整个文件行尾）。
 */
const fs = require('fs');
const path = require('path');

const ROOT = process.cwd();
const SRC = path.join(ROOT, 'README.md');
const KEEP_TOP = 4;                       // 保留最近 4 版（v10.42 稍后插入，合计 5）

const buf = fs.readFileSync(SRC);
const eol = buf.includes('\r\n') ? '\r\n' : '\n';
const L = buf.toString('utf8').split(/\r?\n/);
console.log('EOL =', eol === '\r\n' ? 'CRLF' : 'LF', '| lines =', L.length);

/* ---- 定位项目说明起点（唯一的 H1，排除围栏代码块内的 `# x`）---- */
function firstRealH1(lines) {
  let fence = null;
  for (let i = 0; i < lines.length; i++) {
    const t = lines[i].trim();
    const f = /^(`{3,}|~{3,})/.exec(t);
    if (f) { const m = f[1][0]; if (fence === null) fence = m; else if (fence === m) fence = null; continue; }
    if (fence !== null) continue;
    if (/^#\s+\S/.test(t)) return i;
  }
  return -1;
}
const h1 = firstRealH1(L);
console.log('项目说明 H1 在第', h1 + 1, '行:', JSON.stringify(L[h1].slice(0, 60)));
if (h1 < 0) { console.error('★ 找不到项目说明 H1，拒绝继续'); process.exit(1); }

/* ---- 切出项目说明（去掉前面的 `---` 与空行）---- */
let docStart = h1;
while (docStart > 0 && (L[docStart - 1].trim() === '' || L[docStart - 1].trim() === '---')) docStart--;
const projectDoc = L.slice(h1);

/* ---- 从上半段抽出版本块（plain `## ... vX.Y 增量`）---- */
function blocks(lines) {
  const out = []; let cur = null;
  lines.forEach((l, i) => {
    const m = /^##\s+(.*?v(\d+\.\d+)\s*增量.*?)\s*$/.exec(l.trim());
    if (m) { if (cur) out.push(cur); cur = { ver: 'v' + m[2], from: i, lines: [l] }; return; }
    if (cur) {
      const t = l.trim();
      if (/^#{1,2}\s/.test(t)) { out.push(cur); cur = null; return; }   // 遇到下一个 H1/H2 就收口
      cur.lines.push(l);
    }
  });
  if (cur) out.push(cur);
  return out;
}
const all = blocks(L.slice(0, h1));
console.log('上半段版本块:', all.length, '→', all.map(b => b.ver).join(' '));
const keep = all.slice(0, KEEP_TOP);
const drop = all.slice(KEEP_TOP);
console.log('保留:', keep.map(b => b.ver).join(' '), '| 收敛:', drop.length, '个（', drop[drop.length - 1].ver, '→', drop[0].ver, '）');

/* ---- 组装新 README ---- */
/* 块体自带 `---` 分隔与尾部空行 ⇒ 用单个 eol 拼接，避免出现双空行 */
const demote = (arr) => arr.map(b => {
  const ls = b.lines.map((l, i) => (i === 0 ? '#' + l : l));
  while (ls.length && ls[ls.length - 1].trim() === '') ls.pop();
  return ls.join(eol);
}).join(eol + eol);
const lines = [];
lines.push(...projectDoc);
while (lines.length && lines[lines.length - 1].trim() === '') lines.pop();
lines.push('');
lines.push('---');
lines.push('');
lines.push('## 更新日志');
lines.push('');
lines.push('> **版本记录分两层写，同一内容不写两遍**（v10.42 文档收敛，2026-09-28）：');
lines.push('>');
lines.push('> | 想看什么 | 去哪看 |');
lines.push('> |---|---|');
lines.push('> | **最近改了什么**（5 版摘要，30 秒读完） | 就是本节，往下翻 |');
lines.push('> | **某一版的完整说明**（改了什么 / 真实对照数据 / 踩过的坑 / 验证结果） | [`docs/versions/v10.N.md`](docs/versions/) |');
lines.push('> | **全部版本一览**（一行一版） | [`docs/versions/README.md`](docs/versions/README.md) |');
lines.push('>');
lines.push('> ⚠️ 更早 ' + drop.length + ' 版（' + drop[drop.length - 1].ver + ' → ' + drop[0].ver + '）的**摘要已从 README 收敛**：');
lines.push('> 它们和 `docs/versions/v10.N.md` 是同一批内容的两次书写，并存只会各自漂移。');
lines.push('> 需要旧摘要原本可走 `git show <sha>:README.md`，或本地归档 `_archived/README-v10.41-版本块全量.md`。');
lines.push('');
lines.push('<!-- V1042-BLOCK -->');
lines.push('');
lines.push(demote(keep));
lines.push('');
lines.push('---');
lines.push('');
lines.push('<sub>更早 ' + drop.length + ' 版（' + drop[drop.length - 1].ver + ' → ' + drop[0].ver + '）的摘要已收敛，完整说明见 `docs/versions/`。</sub>');
lines.push('');
const out = lines.join(eol)
  /* 保留块里唯一一处会变死链的旧文档引用（v10.39 块的最后一行）：
     指向已移除的 CODEX-INDEX.md ⇒ 改为指向现行版本索引。 */
  .replace('> 本文件与 `CODEX-INDEX.md` 同步。', '> 本文件与版本索引（`docs/versions/`）同步。');

/* ---- 自检：不许丢东西 ---- */
const problems = [];
if (!/^#\s+GameHub/.test(lines[0])) problems.push('首行不是项目说明 H1');
if ((out.match(/^#\s+\S/gm) || []).length !== 1) problems.push('H1 数量 != 1');
for (const b of keep) if (!out.includes('### ' + b.lines[0].replace(/^##\s+/, ''))) problems.push('保留块丢失: ' + b.ver);
const docOnly = projectDoc.join(eol);
for (const needle of ['## 页面形态', '## 数据与源站', '## API', '## 目录结构', '## 注意']) {
  if (!out.includes(needle)) problems.push('项目说明章节丢失: ' + needle);
}
console.log('\n--- 自检 ---');
console.log(problems.length ? problems.map(p => '  ★ ' + p).join('\n') : '  全部通过');
console.log('新版 bytes:', Buffer.byteLength(out, 'utf8'), '（原', Buffer.byteLength(buf, 'utf8'), '）');
console.log('新版 lines:', lines.length, '（原', L.length, '）');
console.log('残留 CODEX-INDEX 提及:', (out.match(/CODEX-INDEX/g) || []).length);
console.log('残留 CODEX-DONE 提及:', (out.match(/CODEX-DONE/g) || []).length);

if (process.argv.includes('--write')) {
  if (problems.length) { console.error('\n★ 自检未过，拒绝写入'); process.exit(1); }
  const A = path.join(ROOT, '_archived');
  fs.mkdirSync(A, { recursive: true });
  for (const [from, to] of [['README.md', 'README-v10.41-版本块全量.md'], ['CODEX-INDEX.md', 'CODEX-INDEX-v10.41.md']]) {
    const src = path.join(ROOT, from);
    if (fs.existsSync(src)) {
      const dst = path.join(A, to);
      if (fs.existsSync(dst)) console.log('归档已存在，跳过:', to);
      else { fs.copyFileSync(src, dst); console.log('已归档:', to, fs.statSync(dst).size + ' B'); }
    }
  }
  fs.writeFileSync(SRC, out, 'utf8');
  console.log('\n★ README.md 已写入');
} else {
  console.log('\n（未加 --write，仅预览）');
  console.log('\n--- 新 README 前 60 行 ---');
  console.log(lines.slice(0, 60).join('\n'));
  console.log('\n--- 更新日志节起始处（约 800 行附近）---');
  const idx = lines.findIndex(l => l.startsWith('## 更新日志'));
  console.log(lines.slice(idx - 4, idx + 24).join('\n'));
}
