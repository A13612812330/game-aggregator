// 只读：提取前端模块与服务端接口分组（供总览表使用）
const fs = require('fs');
const s = fs.readFileSync('public/index.html', 'utf8');
console.log('index.html 字节:', s.length);
const uniq = (a) => [...new Set(a)];

const h = uniq([...s.matchAll(/<h[123][^>]*>([^<]{2,30})<\/h[123]>/g)].map((m) => m[1].trim())).filter(Boolean);
console.log('H 标题:', h.slice(0, 40).join(' | ') || '(无)');

const tabs = uniq([...s.matchAll(/data-tab="([a-z0-9_-]+)"[^>]*>([^<]{0,14})/g)].map((m) => m[1] + ':' + m[2].trim()));
console.log('data-tab:', tabs.join(' | ') || '(无)');

const views = uniq([...s.matchAll(/data-view="([a-z0-9_-]+)"/g)].map((m) => m[1]));
console.log('data-view:', views.join(' | ') || '(无)');

// 主要 UI 文本（导航/按钮）
const navText = uniq([...s.matchAll(/class="[^"]*(?:nav-item|tab-btn|chip|seg-btn)[^"]*"[^>]*>\s*([^<]{2,14})/g)].map((m) => m[1].trim()));
console.log('导航文案:', navText.slice(0, 30).join(' | ') || '(无)');

// 服务端接口分组
const srv = fs.readFileSync('server.js', 'utf8');
const groups = {};
for (const m of srv.matchAll(/app\.(?:get|post)\('\/api\/([a-z0-9_-]+)/g)) {
  groups[m[1]] = (groups[m[1]] || 0) + 1;
}
console.log('接口分组:', Object.entries(groups).map(([k, v]) => k + '(' + v + ')').join(' '));
