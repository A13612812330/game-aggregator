/* v10.42 文档收敛（2/2）：把「活文档」里指向 CODEX-INDEX.md 的引路语改到 docs/versions/
 *
 * 原则：
 *   · 只改**活文档**（指路用）。docs/versions/v*.md 是历史留档，原样不动。
 *   · 逐条报告命中数；命中 0 ⇒ 报错退出（防静默失配）。
 *   · 替换串**不含换行** ⇒ 只在行内做字节替换，绝不改变文件行尾。
 */
const fs = require('fs');

const PATCHES = [
  {
    file: 'WORKFLOW.md',
    from: '> 版本索引看 `CODEX-INDEX.md`，本文只讲「**做什么、按什么顺序做、哪里会炸**」。',
    to: '> 版本索引看 **`docs/versions/README.md`**（2026-09-28 起唯一索引；`CODEX-INDEX.md` 已移除，\n> 原因见 [v10.42](docs/versions/v10.42.md)），本文只讲「**做什么、按什么顺序做、哪里会炸**」。',
  },
  {
    file: 'PITFALLS.md',
    from: '> **这份文件的定位**：`WORKFLOW.md` 是「按什么顺序做」，`CODEX-INDEX.md` 是「哪版做了什么」，',
    to: '> **这份文件的定位**：`WORKFLOW.md` 是「按什么顺序做」，`docs/versions/` 是「哪版做了什么」，',
  },
  {
    file: 'HANDOFF.md',
    from: '> | 当前版本 / 各版做了什么 | **`CODEX-INDEX.md`**（索引，最新置顶）+ `docs/versions/vX.Y.md`（逐版完整说明） |',
    to: '> | 当前版本 / 各版做了什么 | **`docs/versions/`**（`README.md` 是索引、`vX.Y.md` 是逐版完整说明） |',
  },
  {
    file: 'CODEX-HANDOFF.md',
    from: '> | 当前版本 / 各版做了什么 | **`CODEX-INDEX.md`**（索引，最新置顶）+ `docs/versions/vX.Y.md`（逐版完整说明） |',
    to: '> | 当前版本 / 各版做了什么 | **`docs/versions/`**（`README.md` 是索引、`vX.Y.md` 是逐版完整说明） |',
  },
  {
    file: 'DESIGN.md',
    from: '> 当前版本与逐版说明见 **`CODEX-INDEX.md`** + **`docs/versions/vX.Y.md`**；',
    to: '> 当前版本与逐版说明见 **`docs/versions/README.md`**（索引）+ **`docs/versions/vX.Y.md`**（逐版）；',
  },
  {
    file: 'docs/versions/README.md',
    from: '| **更新索引** | 新版写好后，在下面的表里补一行；同时同步 `README.md` 与 `CODEX-INDEX.md` 的版本块 |',
    to: '| **更新索引** | 新版写好后，在下面的表里补一行；并在 `README.md` 的「更新日志」节换上前一版摘要（只留最近 5 版） |',
  },
];

let bad = 0;
for (const p of PATCHES) {
  let t;
  try { t = fs.readFileSync(p.file, 'utf8'); } catch (e) { console.log('★ 读不到 ' + p.file); bad++; continue; }
  const n = t.split(p.from).length - 1;
  if (n !== 1) { console.log((n === 0 ? '★ MISS ' : '★ 重复×' + n + ' ') + p.file + '  ← ' + JSON.stringify(p.from.slice(0, 60))); bad++; continue; }
  fs.writeFileSync(p.file, t.replace(p.from, p.to), 'utf8');
  const after = fs.readFileSync(p.file, 'utf8');
  const crlf = (after.match(/\r\n/g) || []).length, lf = (after.match(/(?<!\r)\n/g) || []).length;
  const mixed = crlf > 0 && lf > 0;
  console.log('OK  ' + p.file.padEnd(26) + ' 1 处  | CRLF=' + crlf + ' 裸LF=' + lf + (mixed ? '  ★★ MIXED' : ''));
  if (mixed) bad++;
}
console.log(bad ? '\n★ 有 ' + bad + ' 个问题' : '\n全部替换成功');
process.exit(bad ? 1 : 0);
