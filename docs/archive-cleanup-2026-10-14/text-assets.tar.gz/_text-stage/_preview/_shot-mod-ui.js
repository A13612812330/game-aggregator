/* 实拍前端 MOD 显示链路（只读，不改任何项目文件）
 * ① 详情抽屉底部的「下载本体 / 修改器 / Mod」动作条
 * ② 点 Mod 后弹出的机地社区帖列表
 * 用法：node _preview/_shot-mod-ui.js
 */
const path = require('path');
const fs = require('fs');
const { connectBrowser, newPage, sleep } = require('../tools/browser');

const BASE = process.env.BASE || 'http://127.0.0.1:8123';
const GAME = process.env.GAME || '幻兽帕鲁';
const OUT = path.join(__dirname);
const shot = (p, f) => p.screenshot({ path: path.join(OUT, f) });

(async () => {
  const { browser, close } = await connectBrowser();
  const page = await newPage(browser);
  await page.setViewport({ width: 1280, height: 940, deviceScaleFactor: 1 });

  await page.goto(BASE, { waitUntil: 'networkidle2', timeout: 45000 });
  await sleep(1200);

  // 直接唤起 mod 弹窗（等同用户点底部「Mod」按钮后的效果）
  await page.evaluate((g) => {
    if (typeof window.openModList !== 'function') return 'no-fn';
    return window.openModList({ kind: 'mod', title: g, id: '' });
  }, GAME);

  // 等列表渲染出来（等到有 .d-dl-it 或空态）
  const got = await (async () => {
    for (let i = 0; i < 60; i++) {
      const n = await page.evaluate(() => {
        const b = document.querySelector('#dlBody');
        if (!b) return -1;
        if (b.querySelector('.d-dl-it')) return b.querySelectorAll('.d-dl-it').length;
        if (b.querySelector('.dlpop-empty')) return -2;
        return 0;
      });
      if (n !== 0) return n;
      await sleep(400);
    }
    return 0;
  })();

  await sleep(600);
  await shot(page, '_mod-ui-popup.png');

  const info = await page.evaluate(() => {
    const box = document.querySelector('.dlpop-box');
    const t = document.querySelector('#dlTitle');
    const s = document.querySelector('#dlSub');
    const f = document.querySelector('#dlFoot');
    const body = document.querySelector('#dlBody');
    const note = body && body.querySelector('.dl-note');
    const first = body && body.querySelector('.d-dl-it');
    const r = box ? box.getBoundingClientRect() : null;
    return {
      title: t ? t.textContent : '',
      sub: s ? s.textContent : '',
      note: note ? note.textContent.trim().slice(0, 120) : '',
      foot: f ? f.textContent.trim().slice(0, 200) : '',
      rows: body ? body.querySelectorAll('.d-dl-it').length : 0,
      firstRow: first ? first.textContent.replace(/\s+/g, ' ').trim().slice(0, 140) : '',
      popRect: r ? `${Math.round(r.width)}x${Math.round(r.height)} @ ${Math.round(r.left)},${Math.round(r.top)}` : '',
      visible: box ? (box.getBoundingClientRect().width > 0) : false,
    };
  });

  console.log(JSON.stringify({ got, ...info }, null, 1));
  await close();
})().catch((e) => { console.error('ERR', e.message); process.exit(1); });
