#!/usr/bin/env node
'use strict';
// 只读：对比 HEAD 与工作区中被修改的 data/*.json，输出字段级差异
const { execSync } = require('child_process');
const fs = require('fs');

const files = execSync('git diff --name-only', { encoding: 'utf8' })
  .trim().split('\n').filter(Boolean);

function walk(a, b, p, out) {
  if (Array.isArray(a) || Array.isArray(b)) {
    const la = Array.isArray(a) ? a.length : '(不是数组)';
    const lb = Array.isArray(b) ? b.length : '(不是数组)';
    if (la !== lb) out.push(`  ${p || '(根)'} 数组长度 ${la} -> ${lb}`);
    return;
  }
  if (b && typeof b === 'object') {
    const keys = new Set([...Object.keys(a || {}), ...Object.keys(b)]);
    for (const k of keys) {
      const x = a ? a[k] : undefined, y = b[k];
      if (JSON.stringify(x) !== JSON.stringify(y)) {
        if (y && typeof y === 'object' && x && typeof x === 'object') walk(x, y, p + '.' + k, out);
        else out.push(`  ${p}.${k}: ${JSON.stringify(x)} -> ${JSON.stringify(y)}`);
      }
    }
  }
}

for (const f of files) {
  let old = '';
  try { old = execSync(`git show HEAD:${f}`, { encoding: 'utf8', maxBuffer: 1 << 30 }); } catch (e) { old = '(HEAD 无此文件)'; }
  const cur = fs.readFileSync(f, 'utf8');
  console.log(`\n### ${f}   字节 ${old.length} -> ${cur.length}`);
  let o = null, c = null;
  try { o = JSON.parse(old); } catch (e) { }
  try { c = JSON.parse(cur); } catch (e) { }
  if (o === null || c === null) {
    console.log((o === null && old.length > 60) ? '  (非 JSON：纯文本文件)' : '  (解析失败)');
    continue;
  }
  const out = [];
  walk(o, c, '', out);
  console.log(out.length ? out.slice(0, 12).join('\n') : '  (结构完全相同)');
  if (out.length > 12) console.log(`  ...另有 ${out.length - 12} 处差异`);
}
