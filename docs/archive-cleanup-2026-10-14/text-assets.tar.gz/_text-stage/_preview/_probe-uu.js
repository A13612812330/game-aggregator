/* 探针：打开 UU 云存档 hot-games 页，抓真实 XHR/接口（不入库） */
const { connectBrowser, sleep } = require('../tools/browser');

(async () => {
  const handle = await connectBrowser();
  const browser = handle.browser || handle;
  const page = await browser.newPage();
  await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36');

  const hits = [];
  page.on('response', async (res) => {
    const u = res.url();
    const ct = (res.headers()['content-type'] || '');
    if (/json|javascript/i.test(ct) && !/\.js(\?|$)/.test(u)) {
      let body = '';
      try { body = (await res.text()).slice(0, 400); } catch (e) { body = '(读不到)'; }
      hits.push({ status: res.status(), u: u.slice(0, 160), body: body.replace(/\s+/g, ' ').slice(0, 260) });
    } else if (/api|archive|cloud|save/i.test(u) && !/\.(css|png|jpg|jpeg|webp|svg|woff2?|ico)(\?|$)/i.test(u)) {
      hits.push({ status: res.status(), u: u.slice(0, 160), body: '(非 json)' });
    }
  });

  const target = process.argv[2] || 'https://archive.uu.163.com/app/cloud-archive/hot-games';
  try { await page.goto(target, { waitUntil: 'networkidle2', timeout: 60000 }); } catch (e) { console.log('goto 警告:', e.message); }
  await sleep(6000);

  // 页面可见文本
  const txt = await page.evaluate(() => document.body.innerText.replace(/\s+/g, ' ').slice(0, 1200)).catch(() => '(取不到)');
  const links = await page.evaluate(() => [...document.querySelectorAll('a[href]')].slice(0, 30).map(a => a.href)).catch(() => []);

  console.log('=== 命中接口/请求 ===');
  const seen = new Set();
  for (const h of hits) { if (seen.has(h.u)) continue; seen.add(h.u); console.log(h.status, h.u); if (h.body !== '(非 json)') console.log('    →', h.body.slice(0, 200)); }
  console.log('\n=== 页面可见文本(前1200) ===');
  console.log(txt);
  console.log('\n=== 页面链接(前30) ===');
  console.log(links.join('\n'));

  await page.close();
  if (handle.close) await handle.close();
})().catch((e) => { console.error('探针失败:', e.message); process.exit(1); });
