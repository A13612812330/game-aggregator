/* 探针：UU 详情页点「转存/下载」，抓所有 XHR 与跳转（不入库） */
const { connectBrowser, sleep } = require('../tools/browser');

(async () => {
  const handle = await connectBrowser();
  const browser = handle.browser || handle;
  const page = await browser.newPage();
  await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36');

  const reqs = [];
  page.on('request', (r) => {
    const u = r.url();
    if (!/\.(css|png|jpg|jpeg|webp|svg|woff2?|ico|gif)(\?|$)/i.test(u) && !/\.js(\?|$)/.test(u)) {
      reqs.push({ m: r.method(), u: u.slice(0, 150), post: (r.postData() || '').slice(0, 160) });
    }
  });
  const navs = [];
  page.on('framenavigated', (f) => { if (f === page.mainFrame()) navs.push(f.url().slice(0, 140)); });

  const t = 'https://archive.uu.163.com/app/cloud-archive/675ec8a992ba86eafc953873';
  try { await page.goto(t, { waitUntil: 'networkidle2', timeout: 60000 }); } catch (e) { console.log('goto warn:', e.message); }
  await sleep(5000);

  // 找「转存」按钮并点击
  const before = reqs.length;
  const clicked = await page.evaluate(() => {
    const els = [...document.querySelectorAll('div,button,a,span')];
    const hit = els.find((e) => /转存|下载/.test((e.textContent || '').trim()) && (e.textContent || '').trim().length <= 6);
    if (hit) { hit.click(); return (hit.textContent || '').trim(); }
    return '';
  }).catch(() => '');
  console.log('点击的按钮文案:', JSON.stringify(clicked));
  await sleep(5000);

  const after = await page.evaluate(() => {
    const pop = document.querySelector('.popup, .dialog, [class*=Popup], [class*=popup], [class*=dialog]');
    return pop ? pop.innerText.replace(/\s+/g, ' ').slice(0, 400) : '(未检测到弹窗)';
  }).catch(() => '');

  console.log('\n=== 点击后新增请求 ===');
  for (const r of reqs.slice(before)) console.log(r.m, r.u, r.post ? ('| body: ' + r.post) : '');
  console.log('\n=== 全部请求(去重) ===');
  const seen = new Set();
  for (const r of reqs) { const k = r.m + r.u; if (!seen.has(k)) { seen.add(k); console.log(r.m, r.u); } }
  console.log('\n=== 弹窗/新增文案 ===');
  console.log(after);
  console.log('\n=== 主框架跳转记录 ===');
  console.log(navs.join('\n'));

  await page.close();
  if (handle.close) await handle.close();
})().catch((e) => { console.error('失败:', e.message); process.exit(1); });
