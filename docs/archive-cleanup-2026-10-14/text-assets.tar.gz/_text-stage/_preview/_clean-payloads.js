/* v10.42 优化 1：清理旧发布载荷（工作区根 _deploy-gamehub-old / -prev，约 160MB）
 *
 * ★ 为什么可以删：它们是 `tools/_build-deploy-payload.js` 的产物 —— **可重建**，
 *   而且各自都是完整副本（80MB × 3 份 = 240MB 纯冗余）。
 * ★ 安全前置：
 *   ① 只认**白名单里的确切名字**，不做通配、不递归找「名字像的」；
 *   ② 删之前先验身份（必须是目录 + 含 server.js + 含 data/ + 含 package.json），
 *      身份不符就跳过并报错 —— 防止名字被复用后误删真东西；
 *   ③ **绝不碰** 在用的 `_deploy-gamehub`（发布时要用）；
 *   ④ 删完复核：路径不存在 + 剩余体积对得上。
 */
const fs = require('fs');
const path = require('path');

const WS = 'E:/新建文件夹/WorkBuddy/2026-09-03-16-11-58';
const KEEP = '_deploy-gamehub';                       // ★ 在用载荷，绝不删
const TARGETS = ['_deploy-gamehub-old', '_deploy-gamehub-prev'];

function stat(d) {
  let s = 0, n = 0;
  (function w(p) {
    for (const e of fs.readdirSync(p, { withFileTypes: true })) {
      const q = path.join(p, e.name);
      if (e.isDirectory()) w(q);
      else { try { s += fs.statSync(q).size; n++; } catch (_) { } }
    }
  })(d);
  return { s, n };
}

function listDeploy() {
  return fs.readdirSync(WS).filter((n) => n.startsWith('_deploy-')).map((n) => {
    const p = path.join(WS, n);
    const r = fs.statSync(p).isDirectory() ? stat(p) : { s: fs.statSync(p).size, n: 1 };
    return n + '  ' + (r.s / 1048576).toFixed(1) + ' MB / ' + r.n + ' files';
  });
}

console.log('=== 清理前 ===');
listDeploy().forEach((l) => console.log('  ' + l));

for (const name of TARGETS) {
  const p = path.join(WS, name);
  if (!fs.existsSync(p)) { console.log('\n[' + name + '] 不存在，跳过'); continue; }
  /* 身份校验：不符合「发布载荷」的特征就拒绝删 */
  const isDir = fs.statSync(p).isDirectory();
  const marks = ['server.js', 'package.json', 'data', 'public'].filter((m) => fs.existsSync(path.join(p, m)));
  if (!isDir || marks.length < 4) {
    console.log('\n★ [' + name + '] 身份不符（isDir=' + isDir + ' 特征=' + marks.join(',') + '）⇒ 拒绝删除');
    continue;
  }
  const before = stat(p);
  console.log('\n[' + name + '] 身份校验通过（' + marks.join(' + ') + '）· ' + (before.s / 1048576).toFixed(1) + ' MB / ' + before.n + ' files');
  try {
    fs.rmSync(p, { recursive: true, force: true });
    console.log('  已删除 · 复核 exists=' + fs.existsSync(p));
  } catch (e) {
    console.log('  ★ 删除失败: ' + e.code + ' ' + String(e.message).slice(0, 120));
  }
}

console.log('\n=== 清理后 ===');
listDeploy().forEach((l) => console.log('  ' + l));
console.log('\n（' + KEEP + ' 是在用载荷，必须保留）');
