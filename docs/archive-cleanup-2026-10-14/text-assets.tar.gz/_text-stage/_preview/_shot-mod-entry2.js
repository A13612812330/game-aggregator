/* 实拍详情抽屉底部的「下载本体 / 修改器 / Mod」动作条 —— 修正滚动容器
 * 用法：node _preview/_shot-mod-entry2.js
 */
const path = require('path');
const { connectBrowser, newPage, sleep } = require('../tools/browser');

const BASE = process.env.BASE || 'http://127.0.0.1:8123';
const LIBID = process.env.LIBID || 'xd-7272';
const OUT = __dirname;

(async () => {
  const { browser, close } = await connectBrowser();
  const page = await newPage(browser);
  await page.setViewport({ width: 1280, height: 940, deviceScaleFactor: 1 });
  await page.goto(BASE, { waitUntil: 'networkidle2', timeout: 45000 });
  await sleep(1200);

  await page.evaluate(async (id) => { await window.openDetailById(id); }, LIBID);
  for (let i = 0; i < 60; i++) {
    const n = await page.evaluate(() => document.querySelectorAll('[data-dlmod-open]').length);
    if (n) break;
    await sleep(400);
  }
  // 等动作条条数回填（v10.25 setDlCounts），最多 8 秒
  let counts = '';
  for (let i = 0; i < 40; i++) {
    counts = await page.evaluate(() => [...document.querySelectorAll('[data-dlmod-open]')].map((b) => b.textContent.replace(/\s+/g, '')).join(' | '));
    if (!/0$/.test(counts.split(' | ')[0] || '')) break;
    await sleep(200);
  }

  // ★ 找真正的滚动容器（抽屉内部），写 scrollTop 后等两帧再读 rect（防陈旧布局）
  await page.evaluate(() => {
    const btn = document.querySelector('[data-dlmod-open]');
    let n = btn;
    while (n && n !== document.body) {
      const st = getComputedStyle(n);
      if (/(auto|scroll)/.test(st.overflowY) && n.scrollHeight > n.clientHeight + 40) {
        n.scrollTop = n.scrollHeight;
        return;
      }
      n = n.parentElement;
    }
    window.scrollTo(0, document.body.scrollHeight);
  });
  await sleep(500);
  await page.evaluate(() => {
    const btn = document.querySelector('[data-dlmod-open]');
    if (btn) btn.scrollIntoView({ block: 'center' });
  });
  await sleep(700);
  await page.screenshot({ path: path.join(OUT, '_mod-ui-entry2.png') });

  const box = await page.evaluate(() => {
    const btn = document.querySelector('[data-dlmod-open]');
    if (!btn) return null;
    const strip = btn.parentElement && btn.parentElement.parentElement ? btn.parentElement.parentElement : btn.parentElement;
    const r = strip.getBoundingClientRect();
    return { x: Math.max(0, r.left - 8), y: Math.max(0, r.top - 8), w: r.width + 16, h: r.height + 16 };
  });
  if (box && box.h > 20 && box.y + box.h <= 940) {
    await page.screenshot({ path: path.join(OUT, '_mod-ui-entry2-zoom.png'), clip: box });
  }

  const info = await page.evaluate(() => ({
    btns: [...document.querySelectorAll('[data-dlmod-open]')].map((b) => b.textContent.replace(/\s+/g, ' ').trim()),
    body: (document.querySelector('[data-dl-open]') || {}).textContent,
    stripText: (() => { const b = document.querySelector('[data-dlmod-open]'); if (!b) return ''; const p = b.parentElement.parentElement; return p.textContent.replace(/\s+/g, ' ').trim().slice(0, 200); })(),
  }));
  console.log(JSON.stringify({ counts, zoom: box, ...info }, null, 1));
  await close();
})().catch((e) => { console.error('ERR', e.message); process.exit(1); });
