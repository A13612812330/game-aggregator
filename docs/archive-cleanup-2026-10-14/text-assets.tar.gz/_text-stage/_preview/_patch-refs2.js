/* v10.42 收尾：修掉「指向已移除 CODEX-INDEX.md」的 5 处过期引用（行级替换，保持原行尾）。
 * 背景：文档结构闸新增的「活引用」判据命中这 5 行 —— 全是真发现，不是误报。
 * 做法：把文件按行拆开、精确匹配**整行**、替换后按原 EOL 重组 ——
 *      不在字符串里塞换行（那会把 CRLF 文件混进裸 LF，v10.42 已踩过一次）。
 */
const fs = require('fs');

const PATCHES = [
  {
    file: 'WORKFLOW.md',
    old: 'CODEX-INDEX.md            ← 版本索引（最新置顶，只加一段摘要）',
    next: [],
  },
  {
    file: 'WORKFLOW.md',
    old: '| `CODEX-INDEX.md` | **版本索引**，最新置顶，含工程约定 | 每版 |',
    next: ['| `docs/versions/README.md` | **版本索引**（唯一：一行一版 + 一句话要点） | 每版 |'],
  },
  {
    file: 'WORKFLOW.md',
    old: '| `docs/versions/vX.Y.md` | **逐版完整说明**（**39 份**，v10.1 → v10.39） | 每版 |',
    next: ['| `docs/versions/vX.Y.md` | **逐版完整说明**（**42 份**，v10.1 → v10.42） | 每版 |'],
  },
  {
    file: 'HANDOFF.md',
    old: '> 引用前先到 `CODEX-INDEX.md` 确认。',
    next: ['> 引用前先到 `docs/versions/README.md`（版本索引）确认。'],
  },
  {
    file: 'HANDOFF.md',
    old: '| `CODEX-INDEX.md` | ★★ **交付物清单 + Codex 派发索引**（含首轮引导句、11 条派发句、推荐派发顺序） |',
    next: ['| `docs/versions/` | ★★ **版本索引（`README.md`）+ 逐版完整说明（`v10.N.md`）** —— v10.42 起取代 `CODEX-INDEX.md` |'],
  },
  {
    file: 'CODEX-HANDOFF.md',
    old: '> 例如它列的剩余任务，在 `CODEX-INDEX.md` 的 v10.19 条目里已逐条核实过（36 条只余 2 条）。',
    next: ['> 例如它列的剩余任务，在 `docs/versions/v10.19.md` 里已逐条核实过（36 条只余 2 条）。'],
  },
];

let bad = 0;
for (const p of PATCHES) {
  const buf = fs.readFileSync(p.file);
  const eol = buf.includes('\r\n') ? '\r\n' : '\n';
  const L = buf.toString('utf8').split(/\r?\n/);
  const hits = L.map((l, i) => (l === p.old ? i : -1)).filter((i) => i >= 0);
  if (hits.length !== 1) {
    console.log('★ ' + (hits.length === 0 ? 'MISS' : '重复×' + hits.length) + '  ' + p.file + '  ← ' + JSON.stringify(p.old.slice(0, 56)));
    bad++; continue;
  }
  L.splice(hits[0], 1, ...p.next);
  fs.writeFileSync(p.file, L.join(eol), 'utf8');
  const a = fs.readFileSync(p.file, 'utf8');
  const crlf = (a.match(/\r\n/g) || []).length, lf = (a.match(/(?<!\r)\n/g) || []).length;
  const mixed = crlf > 0 && lf > 0;
  console.log('OK   ' + p.file.padEnd(18) + ' L' + (hits[0] + 1) + ' → ' + (p.next.length ? p.next[0].slice(0, 60) : '(删除该行)') +
    '  | CRLF=' + crlf + ' 裸LF=' + lf + (mixed ? '  ★★ MIXED' : ''));
  if (mixed) bad++;
}
console.log(bad ? '\n★ ' + bad + ' 个问题' : '\n全部替换成功');
process.exit(bad ? 1 : 0);
