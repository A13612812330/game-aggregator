/* tools/_diag-detail.js — 详情抽屉现状体检（临时诊断脚本）
 * 打开首页详情抽屉，dump 每个 block 的存在性与高度，并整幅截图。
 */
const puppeteer = require('puppeteer-core');
const fs = require('fs');
const path = require('path');
const EDGE = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const BASE = 'http://127.0.0.1:8123';
const OUT = path.join(__dirname, '..', '_preview');
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

const CASES = [
  { name: '赛博朋克2077', id: 'xd-5828' },
  { name: '幻世录 重制版', id: 'xd-15924' },
];

(async () => {
  if (!fs.existsSync(OUT)) fs.mkdirSync(OUT, { recursive: true });
  const browser = await puppeteer.launch({
    executablePath: EDGE, headless: 'new',
    args: ['--no-sandbox', '--window-size=1440,1100'],
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1440, height: 1100 });
  page.on('pageerror', (e) => console.log('  [页面 JS 报错]', e.message));
  page.on('console', (m) => { if (m.type() === 'error') console.log('  [console.error]', m.text().slice(0, 200)); });

  await page.goto(BASE + '/', { waitUntil: 'networkidle2', timeout: 60000 });
  await wait(2500);

  for (const c of CASES) {
    console.log('\n=== ' + c.name + ' (' + c.id + ') ===');
    const ok = await page.evaluate(async (id) => {
      if (typeof openDetailById !== 'function') return 'openDetailById 未定义';
      try { await openDetailById(id, ''); } catch (e) { return 'ERR ' + e.message; }
      await new Promise((r) => setTimeout(r, 4500));
      return 'ok';
    }, c.id);
    if (ok !== 'ok') { console.log('  ❌', ok); continue; }

    const info = await page.evaluate(() => {
      const body = document.getElementById('drawerBody');
      const hero = body.querySelector('.d-hero');
      const heroImg = hero ? hero.querySelector('img') : null;
      const heroRect = hero ? hero.getBoundingClientRect() : null;
      const imgRect = heroImg ? heroImg.getBoundingClientRect() : null;
      const blocks = [...body.querySelectorAll('.block, .d-blk')].map((b) => {
        const h4 = b.querySelector('h4');
        return {
          t: h4 ? h4.textContent.replace(/\s+/g, ' ').trim() : (b.className + ' (无标题)'),
          h: Math.round(b.getBoundingClientRect().height),
          empty: b.textContent.replace(/\s+/g, '').length < 3,
        };
      });
      return {
        heroH: heroRect ? Math.round(heroRect.height) : null,
        heroW: heroRect ? Math.round(heroRect.width) : null,
        imgH: imgRect ? Math.round(imgRect.height) : null,
        imgW: imgRect ? Math.round(imgRect.width) : null,
        imgNatural: heroImg ? (heroImg.naturalWidth + 'x' + heroImg.naturalHeight) : '',
        imgSrc: heroImg ? heroImg.currentSrc.slice(0, 120) : '',
        hasBhSlot: !!body.querySelector('#bhSlot .d-blk'),
        hasTrSlot: !!body.querySelector('#trBlock .d-blk'),
        hasSvSlot: !!body.querySelector('#svBlock .d-blk'),
        hasCross: !!body.querySelector('#crossSrc .block'),
        hasRel: !!body.querySelector('#relSlot .rel, #relSlot .block, #relSlot > *'),
        hasDl: !!body.querySelector('#dlSlot > *'),
        shots: body.querySelectorAll('.shots img').length,
        kvRows: [...body.querySelectorAll('.kv .it')].map((x) => x.querySelector('.k').textContent + '=' + x.querySelector('.v').textContent),
        blocks,
        bodyH: Math.round(body.scrollHeight),
      };
    });
    console.log('  hero 高 ' + info.heroH + 'px ｜ img 高 ' + info.imgH + 'px (自然尺寸 ' + info.imgNatural + ')');
    console.log('  img src: ' + info.imgSrc);
    console.log('  kv: ' + info.kvRows.join(' | '));
    console.log('  槽位: bh=' + info.hasBhSlot + ' tr=' + info.hasTrSlot + ' sv=' + info.hasSvSlot +
      ' cross=' + info.hasCross + ' rel=' + info.hasRel + ' dl=' + info.hasDl + ' shots=' + info.shots);
    console.log('  blocks:');
    info.blocks.forEach((b) => console.log('    - ' + b.t + '  [' + b.h + 'px]' + (b.empty ? '  ⚠️空' : '')));
    console.log('  抽屉总高 ' + info.bodyH + 'px');

    await page.screenshot({ path: path.join(OUT, '_diag-detail-' + c.id + '.png'), fullPage: false });
    // 仅 hero 区
    const heroClip = await page.evaluate(() => {
      const h = document.querySelector('#drawerBody .d-hero');
      if (!h) return null;
      const r = h.getBoundingClientRect();
      return { x: r.left, y: r.top, width: r.width, height: r.height };
    });
    if (heroClip) await page.screenshot({ path: path.join(OUT, '_diag-hero-' + c.id + '.png'), clip: heroClip });
    await page.evaluate(() => { if (typeof closeDetail === 'function') closeDetail(); });
    await wait(800);
  }

  await browser.close();
  console.log('\n截图见 _preview/_diag-detail-*.png');
})().catch((e) => { console.error('失败:', e.message); process.exit(1); });
