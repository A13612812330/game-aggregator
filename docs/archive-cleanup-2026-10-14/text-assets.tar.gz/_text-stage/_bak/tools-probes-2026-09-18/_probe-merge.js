/* tools/_probe-merge.js —— 临时：验证「机型清单漏机型」的根因与修复效果
 *
 * 根因假设：机型清单取的是 `bannerhub.json` 的 `dv` 字段，而该字段是**上游聚合页的 6 格摘要**
 *   （全库 dv 长度分布 1~6，最大就是 6）→ 结构性最多只能显示 6 台。
 *   全量机型在 `data/bhparams.json`（逐条配置的 device）里，写法也更规范
 *   （摘要 `MTN NX3` vs 逐条 `HONOR MTN-NX3`）。
 *
 * 本探针做三件事：
 *   ① 证明 dv 的上限就是 6
 *   ② 把 dv 与 bhparams 全量 device 按「归一键」合并，算能多出几台
 *   ③ 对合并后的每一步机型跑 devicemarket.resolve，看译名覆盖率
 * 用完即删。
 */
const fs = require('fs');
const path = require('path');
const D = path.join(__dirname, '..', 'data');
const bh = JSON.parse(fs.readFileSync(path.join(D, 'bannerhub.json'), 'utf8'));
const bp = JSON.parse(fs.readFileSync(path.join(D, 'bhparams.json'), 'utf8'));
const dmk = require('../data/devicemarket');

const TARGET = 'ULTIMATE_MARVEL_VS__CAPCOM_3';

/** 归一键：剥掉全是字母的品牌前缀、去掉空格与连字符，用于把两种写法对齐 */
function devKey(s) {
  let t = String(s || '').trim();
  // 去掉重复分隔符
  const base = t.toUpperCase().replace(/[\s\-_()（）]/g, '');
  return base;
}

/** 更「完整」的那个：带空格且带连字符的优先（HONOR MTN-NX3 > MTN NX3） */
function better(a, b) {
  const sc = (s) => (s.match(/[A-Za-z]/g) || []).length * 2 + (s.match(/[-\s]/g) || []).length;
  return sc(a) >= sc(b) ? a : b;
}

console.log('① dv 上限验证');
const lens = (bh.games || []).map((x) => (x.dv || []).length);
console.log(`   条数=${lens.length}  最大=${Math.max(...lens)}  等于 6 的条数=${lens.filter((n) => n === 6).length}`);
const hit6 = (bh.games || []).filter((x) => (x.dv || []).length === 6);
console.log(`   dv 满 6 格（很可能被截断）的游戏：${hit6.length} 款，例如：${hit6.slice(0, 3).map((x) => x.p || x.k).join(' / ')}`);

console.log('\n② 目标游戏：dv 摘要 vs bhparams 全量');
const src = (bh.games || []).find((x) => String(x.k || '') === TARGET || (x.bk || []).includes(TARGET) || String(x.p || '').includes('终极漫画'));
console.log(`   bannerhub 命中: ${src ? (src.p || src.k) + ' dv=' + JSON.stringify(src.dv) : '(未命中，用上游键直查)'}`);

const raw = bp[TARGET];
const arr = Array.isArray(raw) ? raw : ((raw && (raw.items || raw.list)) || []);
console.log(`   bhparams[${TARGET}] 条数=${arr.length}`);

const norm = new Map(); // key -> 展示串
const add = (s) => {
  const v = String(s || '').trim(); if (!v) return;
  const k = devKey(v);
  norm.set(k, norm.has(k) ? better(norm.get(k), v) : v);
};
// 摘要里的（脏）
const dvList = src ? (src.dv || []) : [];
dvList.forEach(add);
// 逐条配置里的（规范）
arr.forEach((x) => add(x.device || x.model || ''));

console.log(`\n   摘要 ${dvList.length} 台 → 合并后 ${norm.size} 台`);
const merged = [...norm.values()];
console.log('   合并结果：');
merged.forEach((v) => {
  const r = dmk.resolve(v);
  console.log(`     ${v.padEnd(22)} → ${(r.display || v).padEnd(26)} resolved=${r.resolved} via=${r.via}`);
});

console.log('\n③ 译名覆盖率对比');
const cov = (list) => {
  const rs = list.map((v) => dmk.resolve(v));
  return `${rs.filter((r) => r.resolved).length}/${rs.length} = ${((rs.filter((r) => r.resolved).length / rs.length) * 100).toFixed(0)}%`;
};
console.log(`   仅 dv 摘要 : ${cov(dvList)}`);
console.log(`   合并后     : ${cov(merged)}`);

console.log('\n④ 摘要有、逐条没有（说明摘要不是子集，两边得并）');
const A = new Set(dvList.map(devKey));
const B = new Set(arr.map((x) => devKey(x.device || x.model || '')));
console.log('   仅摘要:', dvList.filter((v) => !B.has(devKey(v))).join(' | ') || '无');
console.log('   仅逐条:', [...new Set(arr.map((x) => String(x.device || '').trim()))].filter((v) => !A.has(devKey(v))).join(' | ') || '无');
