const https = require('https');
const tests = [
  'https://store.steampowered.com/api/appdetails?appids=4030150&l=schinese&filters=basic,pc_requirements',
  'https://store.steampowered.com/api/appdetails?appids=4030150&l=schinese',
];
function get(u) {
  return new Promise((res, rej) => {
    https.get(u, { headers: { 'User-Agent': 'Mozilla/5.0' } }, (r) => {
      let s = '';
      r.on('data', (c) => (s += c));
      r.on('end', () => res(s));
    }).on('error', rej);
  });
}
(async () => {
  for (const u of tests) {
    const d = await get(u);
    process.stdout.write('--- ' + u.slice(55) + ' len=' + d.length + '\n');
    try {
      const j = JSON.parse(d)['4030150'];
      process.stdout.write('    success=' + j.success + ' isArr=' + Array.isArray(j.data) + '\n');
      if (!Array.isArray(j.data)) process.stdout.write('    pc_req=' + JSON.stringify(j.data.pc_requirements).slice(0, 160) + '\n');
    } catch (e) {
      process.stdout.write('    parse fail: ' + d.slice(0, 120) + '\n');
    }
  }
})();
