/* 探针：本地库全量字段健壮性体检（v10.8） */
const fs = require('fs');
const path = require('path');
const gamesDb = require('../data/gamesDb');
const { normDate, dateTs } = require('../shared');

gamesDb.load();
const all = gamesDb.all();
const { sizeGb } = gamesDb;

const issues = {};
const add = (k, item, extra) => {
  if (!issues[k]) issues[k] = { n: 0, samples: [] };
  issues[k].n++;
  if (issues[k].samples.length < 5) issues[k].samples.push((item.title || item.id) + (extra ? ' — ' + extra : ''));
};

const byUrl = new Map();
const byTitle = new Map();
for (const g of all) {
  /* 标识 */
  if (!g.id) add('无 id', g);
  if (!g.title || !String(g.title).trim()) add('标题为空', g);
  if (!g.url) add('无 url', g);
  if (g.source !== 'xdgamer' && g.source !== 'jidi') add('source 异常', g, String(g.source));

  /* url 合法性与 host */
  if (g.url) {
    let u = null;
    try { u = new URL(g.url); } catch (e) { add('url 不可解析', g, g.url); }
    if (u) {
      const h = u.hostname.replace(/^www\./, '');
      if (!['xdgame.com', 'xdgamer.com', 'jidiyouxi.com'].includes(h)) add('url host 不在白名单', g, h);
      const okDetail = /\/game\/\d+\.html/.test(u.pathname) || /\/topic\/detail\/\d+/.test(u.pathname);
      if (!okDetail) add('url 非详情页形态', g, u.pathname);
    }
    if (byUrl.has(g.url)) add('url 重复', g, g.url);
    byUrl.set(g.url, g);
  }

  /* 日期 */
  if (g.dateLabel && !/^\d{4}-\d{2}-\d{2}$/.test(g.dateLabel)) add('dateLabel 非 ISO', g, String(g.dateLabel));
  if (g.dateLabel && !normDate(g.dateLabel)) add('dateLabel 非法日期', g, String(g.dateLabel));
  const ts = Number(g.updatedTs);
  if (g.updatedTs != null && (!Number.isFinite(ts) || ts <= 0)) add('updatedTs 非法', g, String(g.updatedTs));
  if (g.updatedTs && ts > Date.now() + 86400e3) add('updatedTs 在未来', g, new Date(ts).toISOString().slice(0, 10));
  if (g.publishTs != null && !Number.isFinite(Number(g.publishTs))) add('publishTs 非法', g, String(g.publishTs));
  if (g.dateLabel && g.updatedTs && ts > 0) {
    const days = (ts - dateTs(g.dateLabel)) / 86400e3;
    /* 只有「收录时间**早于**发布日期 6 年以上」才可疑（时间倒挂）；
       updatedTs 比日期**晚**很多是正常的 —— 老游戏新收录（如钢铁雄心IV：2016 发行 / 2026 收录）。 */
    if (days < -365 * 6) add('updatedTs 早于发布日期 6 年以上（时间倒挂）', g, `${g.dateLabel} vs ${new Date(ts).toISOString().slice(0, 10)}`);
  }

  /* 评分 / 容量 */
  if (g.score != null) {
    const s = Number(g.score);
    if (!Number.isFinite(s)) add('score 非数字', g, String(g.score));
    else if (s < 0 || s > 10) add('score 越界(0-10)', g, String(s));
  }
  if (g.size != null && String(g.size).trim() !== '') {
    if (sizeGb(g.size) == null) add('size 无法解析', g, String(g.size));
    else if (sizeGb(g.size) > 2000) add('size 超过 2TB（可疑）', g, String(g.size));
  }

  /* 封面：只看「是否绝对 URL」。
     ⚠️ 不能按扩展名判 —— 机地 CDN 是 `https://img2.52jidi.com/topic/cover/id/{id}/sz/src`，
     没有扩展名，但实测 Content-Type 是 image/jpeg，是**有效图片**（曾据此误报 23 条）。 */
  if (g.cover) {
    if (!/^https?:\/\//.test(g.cover)) add('cover 非绝对 URL', g, g.cover.slice(0, 50));
  } else add('无封面', g);

  /* 类型 */
  if (!Array.isArray(g.genres) || !g.genres.length) add('genres 为空', g);
  else if ((g.genres || []).some((t) => /^\d+(\.\d+)?\s*(GB|MB|TB)$/i.test(String(t)))) add('genres 混入容量串', g, JSON.stringify(g.genres));

  /* 标题重复（同名前 12 字） */
  const tk = String(g.title || '').slice(0, 12).toLowerCase();
  if (tk) {
    if (!byTitle.has(tk)) byTitle.set(tk, []);
    byTitle.get(tk).push(g);
  }
}
for (const [tk, list] of byTitle) {
  if (list.length > 1) {
    const urls = new Set(list.map((x) => x.url));
    if (urls.size > 1) add('标题近似但 URL 不同', list[0], list.map((x) => x.id).slice(0, 3).join(','));
  }
}

console.log(`=== 本地库体检（共 ${all.length} 条）===\n`);
const order = Object.entries(issues).sort((a, b) => b[1].n - a[1].n);
if (!order.length) console.log('未发现问题');
for (const [k, v] of order) {
  console.log(`【${k}】${v.n} 条`);
  v.samples.forEach((s) => console.log('    · ' + s));
}
console.log('\n=== 来源分布 ===');
const src = {};
for (const g of all) src[g.source] = (src[g.source] || 0) + 1;
console.log(src);
