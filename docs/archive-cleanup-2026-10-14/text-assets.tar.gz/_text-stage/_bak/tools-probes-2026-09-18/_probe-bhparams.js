/* 临时：采样若干社区配置，统计 settings 键集合，用于写解析器 */
const fs = require('fs');
const path = require('path');
const files = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'data', 'bannerhub-files.json'), 'utf8'));
const BASE = 'https://raw.githubusercontent.com/The412Banner/bannerhub-game-configs/main/configs/';

(async () => {
  const keys = ['Pro_Evolution_Soccer_2013', 'Grand_Theft_Auto_V_Legacy', 'Cuphead', 'Elden_Ring'];
  const counter = {};
  const samples = [];
  for (const k of keys) {
    const list = (files[k] || []).slice().sort((a, b) => b[2] - a[2]).slice(0, 3);
    for (const [phone, gpu, ts, file] of list) {
      const url = BASE + encodeURIComponent(k) + '/' + encodeURIComponent(file);
      try {
        const r = await fetch(url, { signal: AbortSignal.timeout(12000) });
        if (!r.ok) { console.log('HTTP', r.status, url); continue; }
        const j = await r.json();
        samples.push({ k, url, j });
        for (const kk of Object.keys(j.settings || {})) counter[kk] = (counter[kk] || 0) + 1;
      } catch (e) { console.log('ERR', e.message, url); }
    }
  }
  console.log('采样成功', samples.length, '份');
  console.log('settings 键出现次数：');
  Object.entries(counter).sort((a, b) => b[1] - a[1]).forEach(([k, n]) => console.log('  ', n, k));
  const s = samples[0];
  if (s) {
    console.log('\n样本1 meta:', JSON.stringify(s.j.meta));
    console.log('样本1 关键值:');
    for (const [k, v] of Object.entries(s.j.settings)) {
      console.log('  ', k, '=', String(v).slice(0, 200));
    }
    fs.writeFileSync(path.join(__dirname, '_sample-cfg.json'), JSON.stringify(s.j, null, 1));
  }
})();
