/* tools/_probe-fix.js —— 临时：验证 v10.17「机型清单列不全」修复效果
 * 跑法：node tools/_probe-fix.js
 * 用完即删。
 */
const D = require('path').join(__dirname, '..', 'data');
const HOST = 'http://localhost:8123';

const cases = [
  ['终极漫画英雄vs卡普空3', 'ULTIMATE_MARVEL_VS__CAPCOM_3'],
  ['看门狗', ''],
  ['GTA V', ''],
];

(async () => {
  for (const [t, k] of cases) {
    const r = await fetch(`${HOST}/api/mobilehub/match?t=${encodeURIComponent(t)}`).then((x) => x.json());
    if (!r.hit) { console.log(`\n【${t}】未命中`); continue; }
    const h = r.hit;
    console.log(`\n【${h.name || t}】`);
    console.log(`  机型：摘要 ${h.devicesSummaryCnt} 台 → 合并后 ${h.devicesCnt} 台` + (h.devicesAdded.length ? `（新增 ${h.devicesAdded.length}：${h.devicesAdded.join(' | ')}）` : ''));
    console.log(`  ${h.devices.join(' | ')}`);
  }

  console.log('\n=== 译名显示质量抽查（含本轮两处修复）===');
  const dmk = require(D + '/devicemarket');
  for (const m of ['MTN NX3', 'HONOR MTN-NX3', 'Xiaomi 21091116UC', 'Xiaomi 25053PC47G', 'BRP NX3', 'samsung SM-A057M', 'motorola moto g24', 'ITEL itel S666LN', 'moto g(20)']) {
    const r = dmk.resolve(m);
    console.log(`  ${m.padEnd(20)} → ${String(r.display).padEnd(30)} resolved=${r.resolved} via=${r.via}`);
  }
})().catch((e) => { console.error('失败：', e.message); process.exit(1); });
