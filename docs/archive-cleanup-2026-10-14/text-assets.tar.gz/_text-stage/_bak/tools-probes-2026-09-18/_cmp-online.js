/* tools/_cmp-online.js —— 临时：对比「线上已发布页面」与「本地最新源码」
 * 用途：用户在线上看到的界面还是旧的（机型显示内部代号 / 机型没列全），
 *       先判定是「线上没重新发布」还是「本地代码真的没改到」。
 * 用完即删。 */
const fs = require('fs');
const path = require('path');

const HOST = 'https://36aa37e911e6447eb86eb187240daff2.app.workbuddy.host';
const OUT = path.join(__dirname, '..', '_online');

const KEYS = [
  ['d-devlist', '机型清单两列（v10.15）'],
  ['hasDetailUrl', '跨源按钮闸门（v10.15）'],
  ['bhRecSlot', '本站实测记录槽位（v10.15）'],
  ['sm-foot', '搜索弹窗按键条（v10.15）'],
  ['d-tg gcm', '「本站实测 N 条」标签'],
  ['上游共汇总', '机型清单 more 行'],
  ['bhHwSlot', '硬件参数槽位（v10.16）'],
  ['toggleDevHardware', '点击展开硬件（v10.16）'],
  ['data-hw', '译名查询键（v10.16）'],
  ['d-hw', '硬件面板样式（v10.16）'],
  ['/api/pc/records', '实测记录端点（v10.15）'],
  ['/api/device/hardware', 'kalvo 硬件端点（v10.16）'],
];

async function grab(url, file) {
  const r = await fetch(url);
  const t = await r.text();
  fs.writeFileSync(path.join(OUT, file), t);
  return { status: r.status, text: t };
}

(async () => {
  fs.mkdirSync(OUT, { recursive: true });
  const local = fs.readFileSync(path.join(__dirname, '..', 'public', 'index.html'), 'utf8');
  const localEmu = fs.readFileSync(path.join(__dirname, '..', 'public', 'emulator.html'), 'utf8');

  const o = await grab(HOST + '/', 'index.html');
  let oe = null;
  try { oe = await grab(HOST + '/emulator.html', 'emulator.html'); } catch (e) { oe = { status: 'ERR', text: '' }; }

  console.log(`线上 index.html    HTTP ${o.status}  ${(o.text.length / 1024).toFixed(0)}KB`);
  console.log(`线上 emulator.html HTTP ${oe.status}  ${(oe.text.length / 1024).toFixed(0)}KB`);
  console.log(`本地 index.html    ${(local.length / 1024).toFixed(0)}KB`);
  console.log(`本地 emulator.html ${(localEmu.length / 1024).toFixed(0)}KB\n`);

  console.log('特征'.padEnd(26) + '本地 index  线上 index   线上 emu');
  console.log('-'.repeat(64));
  for (const [k, label] of KEYS) {
    const f = (s) => (s.includes(k) ? '有' : '无');
    console.log(label.padEnd(24) + '  ' + f(local).padEnd(10) + '  ' + f(o.text).padEnd(10) + '  ' + f(oe.text));
  }

  // 线上机型清单那一段长什么样
  const i = o.text.indexOf('上游共汇总');
  if (i > 0) {
    console.log('\n--- 线上「机型清单」渲染代码（more 行前后） ---');
    console.log(o.text.slice(Math.max(0, i - 900), i + 60));
  }
  const j = o.text.indexOf("d-devlist");
  if (j < 0) console.log('\n线上 **没有** `.d-devlist` —— 说明线上还是 v10.14 的平铺 chips 版式。');
})().catch((e) => { console.error('失败：', e.message); process.exit(1); });
