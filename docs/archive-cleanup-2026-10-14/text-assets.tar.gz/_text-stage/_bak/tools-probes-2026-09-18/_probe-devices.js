/* tools/_probe-devices.js —— 临时：查一款游戏的「机型是否列全」
 * 用户在详情页看到「6 款机型 · 5 种 GPU + 上游汇总了 6 款机型，共 25 套配置」，
 * 怀疑机型没列全。这里把三条数据链路各自的机型集合都打出来对比：
 *   ① /api/mobilehub/match 的 hit.devices（详情页机型清单用的）
 *   ② /api/bh/params 返回的逐条配置里的 device（社区配置原始机型，可能被 limit 截断）
 *   ③ 社区库原始 JSON 里该游戏的全部 device
 * 用完即删。
 */
const KEY = process.argv[2] || 'ULTIMATE_MARVEL_VS__CAPCOM_3';
const T = process.argv[3] || '终极漫画英雄vs卡普空3';
const HOST = 'http://localhost:8123';

const norm = (s) => String(s || '').trim();
const uniq = (a) => [...new Set(a.filter(Boolean))];

(async () => {
  // ① 详情页机型清单的数据源
  const m = await fetch(`${HOST}/api/mobilehub/match?t=${encodeURIComponent(T)}`).then((r) => r.json());
  const h = m.hit || {};
  console.log('① /api/mobilehub/match');
  console.log(`   configs=${h.configs}  records=${h.records}  devicesCnt=${h.devicesCnt}`);
  console.log(`   devices(${(h.devices || []).length}) = ${(h.devices || []).join(' | ')}`);
  console.log(`   gpus(${(h.gpus || []).length})    = ${(h.gpus || []).join(' | ')}`);

  // ② 逐条社区配置（详情页只取 limit=3，这里取 200 看全量）
  const p = await fetch(`${HOST}/api/bh/params?k=${encodeURIComponent(KEY)}&limit=200`).then((r) => r.json());
  const items = p.items || [];
  const devs2 = uniq(items.map((x) => norm(x.device)));
  console.log('\n② /api/bh/params?limit=200');
  console.log(`   items=${items.length}  不同 device=${devs2.length}`);
  console.log(`   ${devs2.join(' | ')}`);

  // ③ 原始 JSON：该 key（含前后可能带反斜杠的变体）
  const bp = require('../data/bhparams.json');
  const keys = Object.keys(bp).filter((k) => k.replace(/\\+$/, '') === KEY);
  console.log('\n③ data/bhparams.json 原始键');
  console.log(`   命中键: ${keys.map((k) => JSON.stringify(k)).join(', ') || '(无)'}`);
  for (const k of keys) {
    const rec = bp[k];
    const arr = Array.isArray(rec) ? rec : (rec.items || rec.list || []);
    const devs3 = uniq(arr.map((x) => norm(x.device || x.model)));
    console.log(`   ${k}: 条数=${arr.length} 不同 device=${devs3.length}`);
    console.log(`   ${devs3.join(' | ')}`);
  }

  // 差异
  const A = new Set(h.devices || []);
  const B = new Set([...devs2, ...(keys.flatMap((k) => {
    const rec = bp[k];
    const arr = Array.isArray(rec) ? rec : (rec.items || rec.list || []);
    return arr.map((x) => norm(x.device || x.model));
  }))]);
  const miss = [...B].filter((x) => !A.has(x));
  const extra = [...A].filter((x) => !B.has(x));
  console.log('\n④ 差异');
  console.log(`   原始有、清单没有（漏列）: ${miss.length ? miss.join(' | ') : '无'}`);
  console.log(`   清单有、原始没有        : ${extra.length ? extra.join(' | ') : '无'}`);
})().catch((e) => { console.error('失败：', e.message); process.exit(1); });
