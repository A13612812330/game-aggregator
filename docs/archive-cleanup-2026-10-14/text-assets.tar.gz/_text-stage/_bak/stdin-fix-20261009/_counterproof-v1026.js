/* 反证：把 v10.26 的四个关键行为逐个打坏，断言必须变红。
 * 用法：node tools/_counterproof-v1026.js     （跑完自动还原，无论成败）
 */
const fs = require('fs');
const { execFileSync } = require('child_process');
const path = require('path');

const ROOT = path.join(__dirname, '..');
/* ★ 相对 ROOT（项目根）：本脚本在 tools/ 下，测试也在 tools/ 下 ——
   这里曾误写成裸文件名，于是 execFileSync 找不到文件、runTest 静默返回空串，
   结果是**六条反证全部「没变红」**：看起来像断言全假，其实是脚本自己跑不起来。
   凡是「子进程跑测试再看输出」的脚本，都要先确认子进程真的跑起来了。 */
const TEST = 'tools/test-v1026-jidiposts.js';

const CASES = [
  {
    name: '① tagsOf 只读顶层 resource_tag（gi.resource_tag 那一支去掉）',
    file: 'fetchers/jidiPosts.js',
    from: "  const raw = (Array.isArray(p && p.resource_tag) ? p.resource_tag : null)\n"
      + "    || (Array.isArray(gi.resource_tag) ? gi.resource_tag : []);",
    to: "  const raw = (Array.isArray(p && p.resource_tag) ? p.resource_tag : []);",
    expect: '标签取自 game_info',
  },
  {
    name: '② coverOf 不认 JSON 字符串形态（imgs 解析分支去掉）',
    file: 'fetchers/jidiPosts.js',
    from: "  let imgs = p && p.imgs;\n"
      + "  if (typeof imgs === 'string') {\n"
      + "    try { imgs = JSON.parse(imgs); } catch { imgs = null; }\n"
      + "  }",
    to: "  let imgs = p && p.imgs;",
    expect: 'imgs 是 JSON 字符串',
  },
  {
    name: '③ sortPosts 去掉「有标题优先」',
    file: 'fetchers/jidiPosts.js',
    from: "    const at = a.title ? 1 : 0;\n    const bt = b.title ? 1 : 0;\n    if (at !== bt) return bt - at;\n",
    to: '',
    expect: '无标题帖沉底',
  },
  {
    name: '④ SECTIONS 的 resourceType 改成 4（本体）',
    file: 'fetchers/jidiPosts.js',
    from: "{ key: 'body', name: '本体', folderId: 7, resourceType: 1 }",
    to: "{ key: 'body', name: '本体', folderId: 7, resourceType: 4 }",
    expect: '三个专区的 resource_type',
  },
  {
    /* ★ v10.29：判据从「全页有 `' 帖'`」收窄到 countLabel 那条赋值语句之后，
       打坏点也必须跟着收窄 —— 否则打的是别处的「帖」，断言照样绿（假反证）。 */
    name: '⑤ 专区徽标单位从「帖」改回「条」（帖与地址混用）',
    file: 'public/index.html',
    from: "    countLabel: (cur.count || cur.items.length) + ' 帖',",
    to: "    countLabel: (cur.count || cur.items.length) + ' 条',",
    expect: '徽标写「N 帖」',
  },
  {
    /* ★ v10.29：`.dl-secs` 的规则行已随 tab 化删除，原打坏点（删掉那行）不可能再命中。
       改成**把叠放规则塞回来** —— 正面打「一次只画一个分区」这条语义：
       规则一旦回来，就说明有人把 tab 改回了「三块纵向叠着」（= 用户要消掉的
       「本体下面还压着 Mod / 修改器」）。目标断言是逐行匹配的 `deadDlCss.length === 0`。 */
    name: '⑥ 把 .dl-secs（三专区纵向叠放）的规则塞回来',
    file: 'public/index.html',
    from: '  .dl-sec>.sh{',
    to: '  .dl-secs{display:flex;flex-direction:column;gap:13px}\n  .dl-sec>.sh{',
    expect: 'v10.29 已删 .dl-secs',
  },
];

function runTest() {
  try {
    return execFileSync(process.execPath, [TEST], { cwd: ROOT, encoding: 'utf8', stdio: 'pipe' });
  } catch (e) {
    return (e.stdout || '') + (e.stderr || '');
  }
}

/** ★ 子进程真的跑起来了才算数：没有汇总行 = 脚本本身失败，
 *  绝不能被当成「断言没变红」（那会把「工具坏了」误判成「断言是假绿」）。 */
function ranOk(out) {
  return /通过 \d+\/\d+/.test(String(out));
}

function lineFor(out, kw) {
  const l = String(out).split(/\r?\n/).find((x) => x.includes(kw));
  return l ? l.trim() : '(未找到该断言行)';
}

let bad = 0;
for (const c of CASES) {
  const p = path.join(ROOT, c.file);
  const orig = fs.readFileSync(p, 'utf8');
  if (!orig.includes(c.from)) {
    console.log('⚠️  ' + c.name + '\n     找不到要替换的原文，反证无效（文件可能与测试不同步）');
    bad++;
    continue;
  }
  try {
    fs.writeFileSync(p, orig.replace(c.from, c.to), 'utf8');
    const out = runTest();
    if (!ranOk(out)) {
      console.log('❌ 测试没跑起来（拿不到汇总行）  ' + c.name);
      console.log('     前 200 字：' + String(out).slice(0, 200).replace(/\s+/g, ' '));
      bad++;
      continue;
    }
    const line = lineFor(out, c.expect);
    const isFail = /× FAIL/.test(line);
    const summary = (out.match(/通过 \d+\/\d+（失败 \d+）/) || ['(无汇总)'])[0];
    console.log((isFail ? '✅ 变红' : '❌ 没变红') + '  ' + c.name);
    console.log('     ' + line);
    console.log('     ' + summary);
    if (!isFail) bad++;
  } finally {
    fs.writeFileSync(p, orig, 'utf8');       // ★ 无论成败都还原
  }
}

console.log('\n============================');
console.log(bad ? ('❌ ' + bad + ' 条反证未变红（断言是假绿）') : '✅ 全部反证通过：打坏即变红');
console.log('已还原全部文件');
console.log('============================');
process.exit(bad ? 1 : 0);
