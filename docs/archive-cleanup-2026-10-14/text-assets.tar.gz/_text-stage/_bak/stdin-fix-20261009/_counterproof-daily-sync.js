/**
 * tools/_counterproof-daily-sync.js —— 对 tools/test-daily-sync.js 做反证（变异测试）
 *
 * ⚠️ 本文件供**手工/收尾**运行，**不登记 run-all**（它自己会跑套件，登记会套娃）。
 *
 * 目的：证明 test-daily-sync.js 的断言不是「假断言」。
 *   做法 = 故意把 daily-sync.js 改坏（每条只改一处、且保证**仍可加载**），
 *   然后跑套件。套件**必须变红**；仍全绿 ⇒ 那条断言守不住东西。
 *
 * ★ 判定要区分三种结果（v10.36 的教训）：
 *   · 有 `× FAIL`                ⇒ 真抓住了
 *   · 无 FAIL 但退出码非 0       ⇒ **崩了**（SyntaxError 等），不算抓住，必须报出来
 *   · 退出码 0                   ⇒ 假断言（最坏，必须修）
 *   ★ 前置：未变异的基线**必须先跑通**，否则「红了」可能只是副本环境问题。
 */
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const ROOT = path.join(__dirname, '..');
const CF = path.join(ROOT, '_cf138');          // 反证工作副本（test-shared-destructure 已排除 ^_cf\d*$）
const SRC_FILE = path.join(ROOT, 'tools', 'daily-sync.js');
const TEST_FILE = path.join(ROOT, 'tools', 'test-daily-sync.js');

const ORIG = fs.readFileSync(SRC_FILE, 'utf8');
const TEST = fs.readFileSync(TEST_FILE, 'utf8');

/** 每条变异：只改一处，from 必须**恰好命中一次**，且改完能加载。 */
const MUTATIONS = [
  { name: '① planStep 去掉 --dry 拦截', from:
    "  if (o.dry && def && def.write) return { run: false, kind: 'dry', reason: '--dry（该步有写副作用，未执行）' };",
    to:
    "  if (o.dry && def && def.write && false) return { run: false, kind: 'dry', reason: 'x' };" },
  { name: '② saves 漏标 write（该步 --dry 下会真跑）', from:
    "  { key: 'saves', label: '云存档', fn: stepSaves, write: true },",
    to:
    "  { key: 'saves', label: '云存档', fn: stepSaves, write: false }," },
  { name: '③ isTaskDone 忽略 done 字段', from:
    '  if (!t) return true;\n  return !!t.done;',
    to:
    '  if (!t) return true;\n  return true;' },
  { name: '④ isTaskDone 把 done=0 误判为已完成', from:
    '  return !!t.done;',
    to:
    '  return t.done !== undefined;' },
  { name: '⑤ fmtDelta 不再跳过「无变化」', from:
    "  if (!d) return '';",
    to:
    "  if (false) return '';" },
  { name: '⑥ decideStatus 去掉「关键失败优先」', from:
    "  if (list.some((r) => r.critical && r.status === 'fail')) return 'DAILY_FAIL';",
    to:
    "  if (false) return 'DAILY_FAIL';" },
  { name: '⑦ decideStatus 把 blocked 也算失败', from:
    "  if (list.some((r) => r.status === 'fail')) return 'DAILY_PARTIAL';",
    to:
    "  if (list.some((r) => r.status === 'fail' || r.status === 'blocked')) return 'DAILY_PARTIAL';" },
  { name: '⑧ padLabel 改成截断', from:
    "  return str + ' '.repeat(Math.max(0, width - dispWidth(str)));",
    to:
    '  return str.slice(0, width);' },
  { name: '⑨ 摘要里塞原始输出（行数爆）', from:
    "    lines.push(String(i + 1) + '. ' + padLabel(r.label, 16) + (icon[r.status] || '?') + ' ' + (r.detail || ''));",
    to:
    "    for (let k = 0; k < 5; k++) lines.push(String(i + 1) + '. ' + (r.detail || '') + ' raw#' + k);" },
  { name: '⑩ 分源条数改读错层级（顶层没有该键）', from:
    '  const bs = (lib && lib.bySource) || {};',
    to:
    '  const bs = lib;' },
  { name: '⑪ 塞回写死的 node 目录 22.22.2-2', from:
    "const ROOT = path.join(__dirname, '..');",
    to:
    "const ROOT = path.join(__dirname, '..');\nconst LEGACY_NODE = '22.22.2-2';" },
  { name: '⑫ 写死用户名 komo', from:
    "    path.join(os.homedir(), '.workbuddy', 'binaries', 'python', 'envs', 'default', 'Scripts', 'python.exe'),",
    to:
    "    'C:/Users/komo/.workbuddy/binaries/python/envs/default/Scripts/python.exe'," },
  { name: '⑬ 去掉 require.main 保护（require 即跑全流程）', from:
    'if (require.main === module) {',
    to:
    'if (false) {' },
  { name: '⑭ 去掉 AbortController（HTTP 无超时）', from:
    '  const ctl = new AbortController();',
    to:
    '  const ctl = { signal: undefined };' },
  { name: '⑮ parseArgs 的 --skip 解析坏掉', from:
    "      for (const k of a.slice(7).split(',')) if (k.trim()) skip.add(k.trim());",
    to:
    "      for (const k of a.slice(7).split(',')) if (k.trim()) skip.add(k.trim() + 'x');" },
  { name: '⑯ tally 不统计 blocked', from:
    '    if (out[r.status] != null) out[r.status] += 1;',
    to:
    "    if (out[r.status] != null && r.status !== 'blocked') out[r.status] += 1;" },
];

function runSuite(dir) {
  const r = spawnSync(process.execPath, ['tools/test-daily-sync.js'], {
    cwd: dir, encoding: 'utf8', timeout: 180000,
  });
  const out = String(r.stdout || '') + String(r.stderr || '');
  return { status: r.status, out, nFail: (out.match(/× FAIL/g) || []).length };
}

// ---- 建副本 ----
fs.rmSync(CF, { recursive: true, force: true });
fs.mkdirSync(path.join(CF, 'tools'), { recursive: true });
fs.writeFileSync(path.join(CF, 'tools', 'test-daily-sync.js'), TEST);

// ---- 前置：未变异基线必须先全绿 ----
fs.writeFileSync(path.join(CF, 'tools', 'daily-sync.js'), ORIG);
const base = runSuite(CF);
console.log('=== 前置检查：未变异基线 ===');
console.log('  退出码 ' + base.status + ' · FAIL ' + base.nFail + ' 条 · ' +
  (base.status === 0 && base.nFail === 0 ? '✅ 基线全绿，反证有意义' : '★★ 基线就不绿，反证无效（先修副本环境）'));
if (base.status !== 0 || base.nFail !== 0) {
  console.log('\n基线输出片段：\n' + base.out.split('\n').slice(-12).join('\n'));
  process.exit(1);
}

// ---- 逐条变异 ----
console.log('\n=== 变异测试（每条都应让套件变红）===');
const results = [];
for (const m of MUTATIONS) {
  const hits = ORIG.split(m.from).length - 1;
  if (hits !== 1) {
    results.push({ name: m.name, verdict: '★ 锚点未命中（' + hits + ' 处）—— 变异没生效，结论不可信' });
    console.log('  ??   ' + m.name + ' —— 锚点命中 ' + hits + ' 处');
    continue;
  }
  fs.writeFileSync(path.join(CF, 'tools', 'daily-sync.js'), ORIG.replace(m.from, m.to));
  const r = runSuite(CF);
  let verdict;
  if (r.nFail > 0 && /× FAIL/.test(r.out)) verdict = '✅ 已抓住（' + r.nFail + ' 条 FAIL）';
  else if (r.status !== 0) verdict = '★ 崩了（无 FAIL 输出）—— 不算抓住';
  else verdict = '★★ 假断言：改坏了仍全绿';
  results.push({ name: m.name, verdict });
  console.log('  ' + (verdict.startsWith('✅') ? ' ' : '') + verdict.padEnd(26) + ' ' + m.name);
}

// ---- 收尾 ----
fs.rmSync(CF, { recursive: true, force: true });

const caught = results.filter((r) => r.verdict.startsWith('✅')).length;
const bad = results.filter((r) => !r.verdict.startsWith('✅'));
console.log('\n============================');
console.log('  反证合规 ' + caught + ' / ' + MUTATIONS.length);
if (bad.length) {
  console.log('  ★ 以下变异未被抓住，对应断言形同虚设：');
  for (const b of bad) console.log('    · ' + b.name + ' —— ' + b.verdict);
}
console.log('============================');
process.exit(bad.length ? 1 : 0);
