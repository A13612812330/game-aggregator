/* 反证：把 v10.29「预览下移 / 灯箱翻页 / 定位条 / 下载弹窗分区 tab / 修改器+云存档同行」
 * 的关键行为逐个打坏，对应断言必须变红。
 * 用法：node tools/_counterproof-v1029.js   （跑完自动还原，无论成败）
 *
 * ★ 每条都挑**同一个语义**打坏，而不是「随便删一行」：
 *   反证的价值在于证明「这条断言真的在守那个行为」。删一行无关代码让它变红，
 *   只能说明测试会挂，说明不了它在守什么。
 *
 * ★ 本版重点反证两类最容易假绿的判据：
 *   ① **反向断言**（「某死代码不许回来」）—— 字符串判据会命中解释性注释，
 *      必须证明打在「规则行 / 属性产出」上才真的会红（见 ⑫ 与文件内注释）。
 *   ② **「常量 + 用法」成对**的判据 —— 例如「行数上限 5」，
 *      只改常量、或只改用法，都必须能红（见 ⑧）。
 */
const fs = require('fs');
const { execFileSync } = require('child_process');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const TEST = 'tools/test-v1029-detail.js';

const CASES = [
  {
    /* ⚠️ 打坏方式必须是「真的挪回去」，不能写成「把 mark 整行替换掉」——
       后者会让 `indexOf` 返回 -1，而 -1 比任何下标都小，
       位置判据会**照样 PASS**（第一次跑就是栽在这，用例被判成「没变红」）。
       这条用例现在把 `${shotsHtml}` 插到介绍块**之前**，两边标记都还在。 */
    name: '① 预览挪回封面之后（v10.28 的位置，用户本轮明确要改掉）',
    file: 'public/index.html',
    from: '${descHtml}${versionHtml}\n      <!-- ③ 游戏预览',
    to: '${descHtml}${shotsHtml}${versionHtml}\n      <!-- ③ 游戏预览',
    expect: '游戏预览在**版本介绍之后**',
  },
  {
    name: '② 灯箱箭头改成 relative（flex column 里会被排成两行、把图挤扁）',
    file: 'public/index.html',
    from: '.gal-lb-nav{position:absolute;top:50%',
    to: '.gal-lb-nav{position:relative;top:50%',
    expect: '必须是 absolute',
  },
  {
    /* ⚠️ expect 关键字不能取「半透明」—— 段落标题行 `=== ② 灯箱左右切换（半透明图标）===`
       也含这三个字，lineFor 取的是**第一个**包含关键字的行，会命中标题而不是判据行，
       于是「明明红了」被判成「没变红」。关键字要取**只可能出现在断言名里**的串。 */
    name: '③ 箭头不透明了（用户要的是「透明度较高的图标」）',
    file: 'public/index.html',
    from: 'opacity:.55;transition:opacity .18s,background .18s}',
    to: 'opacity:1;transition:opacity .18s,background .18s}',
    expect: '透明度较高的图标',
  },
  {
    name: '④ 键盘左键各写一遍取模（与点击那条分叉，边界处理迟早不一致）',
    file: 'public/index.html',
    from: "else if (e.key === 'ArrowLeft') { galLbStep(-1); e.stopPropagation(); }",
    to: "else if (e.key === 'ArrowLeft') { galLbI = (galLbI - 1 + galLbImgs.length) % galLbImgs.length; galLbPaint(); e.stopPropagation(); }",
    expect: '键盘左右与点击走',
  },
  {
    name: '⑤ 定位条去掉「评分参数」（用户反馈「好像没更新」的根因）',
    file: 'public/index.html',
    from: "  { k: 'kv', nm: '评分参数', sel: ['#drawerBody .d-body > .kv'] },\n",
    to: '',
    expect: 'D_RAIL 里有「评分参数」',
  },
  {
    /* ★ 新打坏点：把定位条的排序键改回「视口 rect.top」。
       这条不是纸上的担忧 —— 实测 XD 源（博德之门3）的「下载」正是被它排到了第 3 位：
       `.d-dock` 里的 `#dlStrip` 是 position:sticky，rect.top 反映的是吸附位置。 */
    name: '⑤-b 定位条排序键改回视口 rect.top（sticky 元素会排错位）',
    file: 'public/index.html',
    from: '  found.sort((a, b) => (a.el.compareDocumentPosition(b.el) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1));',
    to: '  const _base = dr.getBoundingClientRect().top;\n  found.sort((a, b) => (a.el.getBoundingClientRect().top - _base) - (b.el.getBoundingClientRect().top - _base));',
    expect: '反向断言：排序那一行',
  },
  {
    name: '⑥ 下载弹窗退回「遍历全部分区各画一块」（本体下面又压着 Mod / 修改器）',
    file: 'public/index.html',
    from: '  const panel = dlBlock({',
    to: '  v.secs.map(() => 0);\n  const panel = dlBlock({',
    expect: '不再遍历全部分区',
  },
  {
    name: '⑦ 切分区不归零滚动位置（看到的是新分区中段，像「这块只有这么几条」）',
    file: 'public/index.html',
    from: "  const b = $('#dlBody');\n  if (b) b.scrollTop = 0;",
    to: "  const b = $('#dlBody');",
    expect: '滚动位置归零',
  },
  {
    name: '⑧ 修改器行数上限退回 8（卡头摘要与「最多 5 行」当场对不上）',
    file: 'public/index.html',
    from: 'const MAXTR = 5;',
    to: 'const MAXTR = 8;',
    expect: '修改器行数上限 = 5',
  },
  {
    name: '⑨ 云存档写死「注册表 2 条」（额度不共享，1 条路径 + 5 条注册表会白空 2 行）',
    file: 'public/index.html',
    from: 'const rTake = Math.min(regs.length, MAXROWS - pTake);',
    to: 'const rTake = Math.min(regs.length, 2);',
    expect: '注册表吃',
  },
  {
    name: '⑩ 更多按钮挪回正文流末位（用户要的是「卡片右上角」）',
    file: 'public/index.html',
    from: '${items.length} 个来源</span>${more}</h4>',
    to: '${items.length} 个来源</span></h4>${more}',
    expect: '按钮在 **h4 卡头里**',
  },
  {
    name: '⑪ .d-pair 退回 block（两块又上下堆，不再是「同行」）',
    file: 'public/index.html',
    from: '.d-pair{display:grid;grid-template-columns:1fr 1fr',
    to: '.d-pair{display:block;grid-template-columns:1fr 1fr',
    expect: '.d-pair 改成 grid',
  },
  {
    name: '⑫ syncPair 只在成功路径调用（提前 return 的路径不再收单列）',
    file: 'public/index.html',
    from: '} catch (e) {} finally { syncPair(); }\n}\n\n/* 💾',
    to: '} catch (e) {}\n}\n\n/* 💾',
    expect: '两个加载函数都在 finally 里调',
  },
  {
    name: '⑬ 卡片更多按钮自造一套机制（不再共用 data-full 委托 → 弹窗侧要改两处）',
    file: 'public/index.html',
    from: '\'<button type="button" class="d-more-hd" data-full="\'',
    to: '\'<button type="button" class="d-more-hd" data-more="\'',
    expect: '共用 data-full 委托',
  },
  {
    name: '⑭ 派生页漂移：emulator.html 的灯箱翻页函数被改名（主源改了没重建）',
    file: 'public/emulator.html',
    from: 'function galLbStep(d) {',
    to: 'function galLbStepX(d) {',
    expect: 'emulator.html 已同步灯箱翻页',
  },
];

function runTest() {
  try {
    return execFileSync(process.execPath, [TEST], { cwd: ROOT, encoding: 'utf8', stdio: 'pipe' });
  } catch (e) {
    return (e.stdout || '') + (e.stderr || '');
  }
}

/** ★ 子进程真的跑起来了才算数：没有汇总行 = 脚本本身失败 ——
 *  绝不能被当成「断言没变红」（那会把「工具坏了」误判成「断言是假绿」）。 */
function ranOk(out) {
  return /通过 \d+\/\d+/.test(String(out));
}

function lineFor(out, kw) {
  const l = String(out).split(/\r?\n/).find((x) => x.includes(kw));
  return l ? l.trim() : '(未找到该断言行)';
}

let bad = 0;
const skipped = [];
for (const c of CASES) {
  const p = path.join(ROOT, c.file);
  const orig = fs.readFileSync(p, 'utf8');
  const hits = orig.split(c.from).length - 1;
  if (hits === 0) {
    console.log('⚠️  ' + c.name + '\n     找不到要替换的原文，反证无效（文件可能与测试不同步）');
    bad++;
    continue;
  }
  if (hits > 1) skipped.push(c.name + '（原文出现 ' + hits + ' 次，只替换了第 1 处）');
  try {
    fs.writeFileSync(p, orig.replace(c.from, c.to), 'utf8');
    const out = runTest();
    if (!ranOk(out)) {
      console.log('❌ 测试没跑起来（拿不到汇总行）  ' + c.name);
      console.log('     前 200 字：' + String(out).slice(0, 200).replace(/\s+/g, ' '));
      bad++;
      continue;
    }
    const line = lineFor(out, c.expect);
    const isFail = /× FAIL/.test(line);
    const summary = (out.match(/通过 \d+\/\d+（失败 \d+）/) || ['(无汇总)'])[0];
    console.log((isFail ? '✅ 变红' : '❌ 没变红') + '  ' + c.name);
    console.log('     ' + line);
    console.log('     ' + summary);
    if (!isFail) bad++;
  } finally {
    fs.writeFileSync(p, orig, 'utf8');       // ★ 无论成败都还原
  }
}

if (skipped.length) {
  console.log('\n⚠️ 以下条目的原文在文件里出现多次，替换的是第 1 处，判据可能没落在同一段代码上：');
  for (const s of skipped) console.log('   · ' + s);
}

console.log('\n============================');
console.log(bad ? ('❌ ' + bad + ' 条反证未变红（断言是假绿）') : '✅ 全部反证通过：打坏即变红');
console.log('已还原全部文件');
console.log('============================');
process.exit(bad ? 1 : 0);
