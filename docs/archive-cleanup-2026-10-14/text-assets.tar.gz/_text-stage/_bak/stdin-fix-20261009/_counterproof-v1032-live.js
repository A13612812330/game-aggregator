#!/usr/bin/env node
/* tools/_counterproof-v1032-live.js —— v10.32 **浏览器层**断言反证（打坏 → 必须变红）
 *
 * 为什么必须做：`preview-v1032.js` 报 57/57 ✅ 只说明「这一次量到的数符合期望」，
 * 不说明这些断言**真的能抓到回归**。这两条尤其可疑：
 *   · ① 「合并成一项」—— 如果断言写的是 `names.length === 8`，那么把两项换回
 *     三项、四项…… 只要不巧凑到 8 就照样绿；所以断言必须**点名**项名。
 *     这里就用「退回两项」来证明它抓得住。
 *   · ② 「不被遮挡」—— `gap >= 0` 是唯一能抓到「余量算少了」的判据。
 *     退回旧的 `- 14` 之后，目标顶会落进小条底下（gap 变负），必须变红。
 *
 * 做法（⚠️ 会**临时改写 public/index.html**，严格 try/finally 还原）：
 *   1. 备份 → _preview/_cf-live-1032.bak（记 md5）
 *   2. 单点变异 → 写回 → 跑 preview-v1032.js（SAMPLE_TAG 限 1 个样本，省一半时间）
 *   3. finally 从备份还原，并核对 md5
 *   4. 判「变红」= 退出码非零 **且** 期望关键词出现在 ❌ 行
 *      （只看退出码会把「撞红了别的断言」误判成通过）
 *
 * 运行：node tools/_counterproof-v1032-live.js   （需 8123 服务在跑）
 */
const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const crypto = require('crypto');

const ROOT = path.join(__dirname, '..');
const IDX = path.join(ROOT, 'public', 'index.html');
const BAK = path.join(ROOT, '_preview', '_cf-live-1032.bak');

const MUTS = [
  {
    id: '① 定位条退回「修改器」「云存档」两项',
    /* 期望点名「不再有单独的『修改器』项」—— 这条断言是逐字匹配项名，
       不是数项数，所以一定能抓到。 */
    expect: '不再有单独的「修改器」项',
    f: (src) => src.replace(
      "{ k: 'trsv', nm: '修改器/云存档', sel: ['#trSvSlot'] },",
      "{ k: 'tr', nm: '修改器', sel: ['#trBlock'] },\n  { k: 'sv', nm: '云存档', sel: ['#svBlock'] },"),
  },
  {
    id: '② 跳转余量退回旧的 -14（不减小条高）',
    /* 旧行为 = 只留 14px 余量。等价于把 cover 恒置 0（gap 随之回落到 else 分支的 14）。
       ⇒ 目标顶会落进小条（62px）底下，`gap` 变负 ⇒ 「未被小条遮挡」必红。 */
    expect: '跳转后未被小条遮挡',
    f: (src) => src.replace('const cover = raw >= heroH ? miniH : 0;', 'const cover = 0;'),
  },
  {
    id: '④ 底部文案某一行的文字加长（两块不再同高）',
    /* ★ 这一条是「④ 三行骨架」的实拍层反证。
       只加长**一行**的文字 ⇒ 它在 306px / 286px 下都会自己折成两行 ⇒ 那一侧变成 4 行、
       hint 高从 59.9 涨到 77.3 ⇒ 同时踩红两条**互相独立**的断言（行数 + 等高）。
       ⚠️ 为什么不能靠静态层替它：「文字写长了会折行」是**布局**后果，
          `<br>` 条数照旧是 2 ⇒ 静态断言全绿。这正是需要实拍的那一半。 */
    expect: ['两块底部文案都是**三行**', '两块文案块**等高**'],
    f: (src) => src.replace('（与主程序 .exe 同级）。',
      '（与主程序 .exe 同级）之后，再重新启动游戏让修改生效。'),
  },
];

const md5 = (f) => crypto.createHash('md5').update(fs.readFileSync(f)).digest('hex');

let ok = 0, bad = 0;
const orig = fs.readFileSync(IDX);
const origMd5 = md5(IDX);
fs.writeFileSync(BAK, orig);
console.log('已备份 public/index.html（md5 ' + origMd5.slice(0, 10) + '…）\n');

try {
  for (const m of MUTS) {
    const mut = m.f(orig.toString('utf8'));
    if (mut === orig.toString('utf8')) {
      bad++;
      console.log('× ' + m.id + '\n   → 变异**未生效**（源码里没找到要替换的串，锚点写错了？）\n');
      continue;
    }
    /* 变异产物先过语法闸：语法都不合法的那种「红」不算数（见 counterproof-assertions skill） */
    fs.writeFileSync(IDX, mut);
    const syn = cp.spawnSync(process.execPath, ['tools/check-inline-syntax.js', 'public/index.html'],
      { cwd: ROOT, encoding: 'utf8' });
    if (syn.status !== 0) {
      bad++;
      console.log('× ' + m.id + '\n   → 变异后内联脚本语法就不合法了，这种红不算数：\n     ' +
        (syn.stdout || '').trim().split('\n').slice(0, 2).join('\n     ') + '\n');
      continue;
    }
    const r = cp.spawnSync(process.execPath, ['tools/preview-v1032.js'], {
      cwd: ROOT, encoding: 'utf8', timeout: 900000,
      env: { ...process.env, SAMPLE_TAG: '692' },
    });
    const out = (r.stdout || '') + (r.stderr || '');
    const fails = out.split('\n').filter((l) => /❌/.test(l));
    const keys = Array.isArray(m.expect) ? m.expect : [m.expect];
    const hitAll = keys.every((k) => fails.some((l) => l.includes(k)));
    if (r.status !== 0 && hitAll) {
      ok++;
      console.log('✅ ' + m.id + '\n   → 退出码 ' + r.status + ' · ❌ ' + fails.length + ' 条 · 命中「' + keys.join(' + ') + '」');
      fails.slice(0, 2).forEach((l) => console.log('       ' + l.trim()));
      console.log('');
    } else if (r.status !== 0) {
      bad++;
      console.log('× ' + m.id + '\n   → 变红了但**不是期望那条**（关键词「' + keys.join(' + ') + '」未出现）');
      fails.slice(0, 3).forEach((l) => console.log('       ' + l.trim()));
      console.log('');
    } else {
      bad++;
      console.log('× ' + m.id + '\n   → ⚠️ **打坏了却全绿**：这条断言形同虚设\n');
    }
    fs.writeFileSync(IDX, orig);   // 每条之间先还原，避免变异叠加
  }
} finally {
  fs.writeFileSync(IDX, orig);
  const after = md5(IDX);
  const same = after === origMd5;
  console.log('已还原 public/index.html：md5 ' + after.slice(0, 10) + '… ' +
    (same ? '与备份**一致** ✅' : '⚠️ 与备份**不一致**，请手工核对！'));
  if (!same) bad++;
}

console.log('\n============================');
console.log('  反证合规 ' + ok + '/' + MUTS.length + '（异常 ' + bad + '）');
console.log('============================');
process.exit(bad ? 1 : 0);
