#!/usr/bin/env node
/* tools/_counterproof-v1034.js —— v10.34（2-B 解包字段校准）静态层的**反证**
 *
 * 做法：把被守护的文件复制到 `_cf134/`（test-v1034.js 的 ROOT 由 __dirname
 * 推导 ⇒ 自动指向副本，隔离干净），单点变异后跑套件。
 *
 * 判据 = **退出码非零 且 指定断言名出现在 FAIL 行**。
 *   · 只看退出码不够：语法错 / 崩溃也非零，那不是「断言抓住了」；
 *   · 只看断言名不够：它可能本来就红。
 *   ⇒ 另加两条前置：基准（无变异）必须全绿；变异必须**真的改到了内容**。
 *
 * ⚠️ 覆盖 `_cf134/` 下的副本，**不动**项目正本。
 */
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const ROOT = path.join(__dirname, '..');
const CF = path.join(ROOT, '_cf134');
/* spec-dict.js 依赖 ./gpu-tier（自带、不 require 别的文件）；
   test-v1034 还会读 server.js 与 public/unpack.html（⑥ 那几条接口断言）。 */
const FILES = [
  'tools/test-v1034.js',
  'data/spec-dict.js',
  'data/spec-match.js',
  'data/gpu-tier.js',
  'server.js',
  'public/unpack.html',
];

const ARCH_LINE = /group: 'arch'/;
const CPU_LINE = /group: 'cpu'/;

const MUT = [
  {
    id: '① 把 arch 规则挪回 cpu 之后（顺序退回旧写法 ⇒ cpuabi 成死词）',
    file: 'data/spec-dict.js',
    expect: 'KEY_RULES 里 arch 排在 cpu 之前',
    f: (s) => {
      const lines = s.split('\n');
      const ai = lines.findIndex((l) => ARCH_LINE.test(l));
      if (ai < 0) return s;
      const [a] = lines.splice(ai, 1);
      const ci = lines.findIndex((l) => CPU_LINE.test(l));
      lines.splice(ci + 1, 0, a);
      return lines.join('\n');
    },
  },
  {
    /* ⚠️ 第一版这条变异只删 `cpuabi` —— **打不红**，因为 arch 的 kws 里还有更窄的
       `abi`（`'cpuabi'.includes('abi')`）把结果兜住了。实现在这里是「两层防」，
       所以变异必须把两层一起拿掉才算真的回到旧行为。
       ⚠️ 第二版又栽在**逗号**上：替换成空串会让数组变成 `'architecture' '指令集'`
       ⇒ SyntaxError ⇒ 套件崩、一行 FAIL 都没打印 ⇒ 工具只看到「没有任何 FAIL 行」。
       ⇒ 替换成 `,` 而不是空串。 */
    id: '① 从 arch 关键词里删掉 abi / cpuabi（两层一起拿掉，arch 通道彻底失效）',
    file: 'data/spec-dict.js',
    expect: 'cpu_abi 归',
    f: (s) => s.replace(", 'abi', 'cpuabi',", ','),
  },
  {
    /* ⚠️ 第一版只把 `v` 那行退回无条件 `dxOf(raw)` —— 也**打不红**：
       后面 `if (kind0)` 分支仍把 vulkan 键归成 vulkan（`v` 算出来了却没人用）。
       真正的「旧写法」是「没有 kind0 这层」，所以变异要整体退回。 */
    id: '② 图形接口整体退回旧写法（无 kind0 层 + 无条件 dxOf ⇒ Vulkan 1.3 冒充 DX 1.3）',
    file: 'data/spec-dict.js',
    expect: 'VULKAN_VERSION:"1.3" 不再被认成',
    f: (s) => s.replace(
      "    const kind0 = /vulkan/.test(kp) ? 'vulkan' : /metal/.test(kp) ? 'metal'\n" +
      "      : /opengl|opengles|gles/.test(kp) ? 'opengl' : '';\n" +
      "    const dxish = /dx|directx|d3d|graphicsapi|apiversion|接口/.test(kp) || /directx|d3d/i.test(raw);\n" +
      '    const v = kind0 ? null : (dxish ? dxOf(raw) : null);',
      "    const kind0 = '';\n    const v = dxOf(raw);"),
  },
  {
    id: '② dxish 恒 false（把真 DX 一起打死 ⇒ 正向断言必须红）',
    file: 'data/spec-dict.js',
    expect: 'DX_VERSION:"11" → dx 11',
    f: (s) => s.replace('const dxish = /dx|directx|d3d|graphicsapi|apiversion|接口/.test(kp) || /directx|d3d/i.test(raw);',
      'const dxish = false;'),
  },
  {
    id: '③ 从 storage 关键词里删掉 space（要求档存储丢失）',
    file: 'data/spec-dict.js',
    expect: 'minRequirements.space 进',
    f: (s) => s.replace("'可用空间', '空间', 'space'],", "'可用空间', '空间'],"),
  },
  {
    id: '③ 删掉规则级排除项（namespace 被算成已识别 ⇒ 识别率虚高）',
    file: 'data/spec-dict.js',
    expect: 'namespace 这个键不许归到存储',
    f: (s) => s.replace(",\n    not: /namespace|workspace|keyspace/ },", ' },'),
  },
  {
    id: '④ nameOf 退化成「device.* 不钻进去」',
    file: 'data/spec-dict.js',
    expect: 'device.model（嵌套）能取到机型',
    f: (s) => s.replace("        const s = pick(vv, DEVICE.concat(['name']));", "        const s = '';"),
  },
  {
    id: '④ nameOf 的 DEVICE 名单里删掉中文「机型」',
    file: 'data/spec-dict.js',
    expect: '中文键「机型」能取到机型',
    f: (s) => s.replace("const DEVICE = ['机型',", 'const DEVICE = ['),
  },
  {
    id: '④ nameOf 的 GAME 名单里删掉 game（顶层字符串取名退化）',
    file: 'data/spec-dict.js',
    expect: '不退化：顶层 game',
    f: (s) => s.replace("const GAME = ['gamename', 'game', 'title', 'appname', '游戏名'];",
      "const GAME = ['gamename', 'title', 'appname', '游戏名'];"),
  },
  {
    /* ⚠️ 这条断言的口径**在 v10.35 被用户决策改掉了**（原判 fail ⇒ 现判 unknown）。
       本变异随之改成「**把口径偷偷退回 fail**」—— 那正是现在需要被拦住的方向。
       完整口径断言与反证见 tools/test-v1035.js / tools/_counterproof-v1035.js。 */
    id: '⑤ cmpArch 把「ARM 缺转译层」改回 fail（v10.35 口径被偷偷退回）',
    file: 'data/spec-match.js',
    expect: 'ARM 且兼容层里没有 x86 转译层',
    f: (s) => s.replace("const ARCH_NO_TR = 'unknown';", "const ARCH_NO_TR = 'fail';"),
  },
  {
    id: '⑥ 词典版本号退回 v10.20（内容改了却不报版本）',
    file: 'data/spec-dict.js',
    expect: '词典版本号已随内容',
    f: (s) => s.replace("DICT_VERSION: 'v10.34',", "DICT_VERSION: 'v10.20',"),
  },
  {
    id: '⑥ 接口被牵连：analyze 不再走 specDict.extract',
    file: 'server.js',
    expect: '/api/spec/analyze 仍走 specDict.extract',
    f: (s) => s.replace('ex = specDict.extract(raw);', "ex = { ok: true, records: [] };"),
  },
];

function cp(src, dst) {
  fs.mkdirSync(path.dirname(dst), { recursive: true });
  fs.copyFileSync(src, dst);
}
function buildBase() {
  for (const f of FILES) cp(path.join(ROOT, f), path.join(CF, f));
}
function runSuite() {
  try {
    return { code: 0, out: execFileSync(process.execPath, [path.join(CF, 'tools', 'test-v1034.js')],
      { encoding: 'utf8', cwd: CF, timeout: 120000 }) };
  } catch (e) {
    return { code: e.status || 1, out: String(e.stdout || '') + String(e.stderr || '') };
  }
}
/* ★★ 「套件崩了」与「断言没抓住」必须分开（v10.34 反证当场学到，v10.35 补上）：
   断言里写 `prof(x).api.find(...).v`，实现被打坏后是 `undefined.v` ⇒ TypeError 直接崩，
   套件**一行 FAIL 都没打印** ⇒ 本工具只看「有没有 FAIL 行」⇒ 会得出「打坏了也没红」，
   于是差点去「修」一条本来正确的断言。
   判据多一条「有没有跑完」（汇总行 `通过 n / m`）：崩了就没有这一行。 */
const RAN_OK = /通过 \d+\/\d+/;

console.log('\n=== 反证 v10.34：基准（无变异）必须全绿 ===');
buildBase();
const base = runSuite();
if (base.code !== 0 || !RAN_OK.test(base.out)) {
  console.log('  × 基准就是红的（或没跑完），反证无意义。输出尾部：\n' + base.out.slice(-1400));
  process.exit(1);
}
console.log('  PASS  基准全绿  — ' + ((base.out.match(RAN_OK) || [])[0] || '') + '\n');

console.log('=== 逐条变异（期望：退出码非零 **且** 指定断言出现在 FAIL 行） ===\n');
let good = 0, bad = 0, unv = 0;
for (const m of MUT) {
  const src = fs.readFileSync(path.join(ROOT, m.file), 'utf8');
  const mut = m.f(src);
  const dst = path.join(CF, m.file);
  if (mut === src) {
    bad += 1;
    console.log('  × [' + m.id + '] 变异**未生效**（替换串没匹配上 ' + m.file + '）—— 这条不算合规\n');
    continue;
  }
  fs.writeFileSync(dst, mut, 'utf8');
  const r = runSuite();
  fs.copyFileSync(path.join(ROOT, m.file), dst);   // 立刻还原副本

  const lines = r.out.split(/\r?\n/);
  const hit = lines.find((l) => l.includes('× FAIL') && l.includes(m.expect)) || '';
  if (!RAN_OK.test(r.out)) {
    unv += 1;
    console.log('  ? UNVERIFIED  ' + m.id);
    console.log('        └ 套件**未跑完**（没有汇总行）⇒ 这次变异什么都没验到，不许算合规');
    console.log('        └ 输出尾部：' + r.out.slice(-300).replace(/\s+/g, ' '));
  } else if (r.code !== 0 && hit) {
    good += 1; console.log('  PASS  ' + m.id + '\n        └ 变红于：' + hit.trim());
  } else {
    bad += 1;
    console.log('  × FAIL  ' + m.id);
    console.log('        └ 期望断言含「' + m.expect + '」；实际退出码=' + r.code + (hit ? '' : '（该断言未变红）'));
    if (!hit) {
      const anyFail = lines.filter((l) => l.includes('× FAIL')).slice(0, 3);
      console.log('        └ 实际红的是：' + (anyFail.join(' | ') || '(没有任何 FAIL 行 —— 套件跑完了却全绿 ⇒ 真·假绿)'));
    }
  }
  console.log('');
}

console.log('=== 反证结果 ===');
console.log('  合规 ' + good + ' / ' + MUT.length +
  (bad ? '   ★ 不合规 ' + bad + ' 条（打不红）' : '') +
  (unv ? '   ★ 不可判定 ' + unv + ' 条（套件崩了，等于没验）' : '') + '\n');
process.exit(bad || unv ? 1 : 0);
