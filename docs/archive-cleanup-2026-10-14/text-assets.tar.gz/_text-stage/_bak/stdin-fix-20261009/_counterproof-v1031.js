#!/usr/bin/env node
/* tools/_counterproof-v1031.js —— v10.31 断言反证（打坏 → 必须变红）
 *
 * ★ 为什么必须有：`test-v1031.js` 首跑就是 65/65 全绿 —— 这**恰恰是最可疑的状态**。
 *   本项目踩过的假绿形态（见 counterproof-assertions 技能）：
 *     · `ruleOf()` 取不到规则体时返回空串，而 `!/transform:/.test('')` 恒真 ⇒
 *       选择器一改名，所有反向断言集体静默变绿；
 *     · 锚点写太宽（裸写 `/align-items:stretch/`）⇒ 改成 start 也照样命中别处；
 *     · 断言名 over-claim（说测「等高」实际只测了常量名）。
 *   所以每个「守住某机制」的断言，都要**故意打坏那个机制**，看它是否真的翻红。
 *
 * 做法：把 public/ + tools/test-v1031.js 复制到 `_cf131/`（ROOT 由 __dirname 推导，
 * 所以复制过去就自动改指向副本），在副本上做**单点变异**，逐条跑并核对
 * 「退出码非零」+「指定断言名出现在 FAIL 行」。
 * ⚠️ 判「变红」不能只看退出码：一个变异可能碰巧撞红别的断言（假阳性保护）。
 *    所以每个变异都登记**期望翻红的断言关键词**，必须真的命中。
 *
 * 产出：逐变异 PASS/FAIL 清单 + 汇总。全部「如预期变红」才算反证通过。
 */
const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const ROOT = path.join(__dirname, '..');
const TMP = path.join(ROOT, '_cf131');

/* 变异表：mutate(file, src) 返回新内容；expect = 期望出现在 FAIL 行里的关键词 */
const MUTS = [
  {
    id: '①a 小条改回 transition',
    expect: '小条不留 transition',
    f: (src) => src.replace('.d-mini{position:sticky;top:0;', '.d-mini{position:sticky;top:0;transition:all .2s;'),
  },
  {
    id: '①b 小条改回位移',
    expect: '小条不再做位移',
    f: (src) => src.replace('.d-mini{position:sticky;top:0;', '.d-mini{position:sticky;top:0;transform:translateY(-102%);'),
  },
  {
    id: '①c 隐藏改用 height 而非 visibility',
    expect: '靠 visibility 隐藏',
    f: (src) => src.replace('opacity:0;visibility:hidden;pointer-events:none}', 'opacity:0;height:0;pointer-events:none}'),
  },
  {
    id: '①d 阈值改回早阈值（−62+12）',
    expect: '不再出现「offsetHeight − 62」',
    f: (src) => src.replace('hero.offsetHeight)', 'hero.offsetHeight - 62 + 12)'),
  },
  {
    id: '①e 上侧阈值写 `>` 而非 `>=`',
    expect: '写 `>` 会把',
    f: (src) => src.replace('if (!cur && y >= on) next = true;', 'if (!cur && y > on) next = true;'),
  },
  {
    id: '①f 高度与负 margin 不一致',
    expect: '高度与负 margin 同值',
    f: (src) => src.replace('height:62px;margin-bottom:-62px;', 'height:62px;margin-bottom:-70px;'),
  },

  {
    id: '②a cover 优先级翻回 d.cover 优先',
    expect: '库内封面优先',
    f: (src) => src.replace("const cover = fb.cover || d.cover || '';", "const cover = d.cover || (fb && fb.cover) || '';"),
  },
  {
    id: '②b 小条缩略图另取 d.cover',
    expect: '小条模板里不出现独立的 d.cover',
    f: (src) => src.replace('<img src="${esc(cover)}" alt="" onerror="this.remove()"></span>', '<img src="${esc(d.cover)}" alt="" onerror="this.remove()"></span>'),
  },

  {
    id: '③a .d-pair 退回 align-items:start',
    expect: '两卡**等高**',
    f: (src) => src.replace('.d-pair{display:grid;grid-template-columns:1fr 1fr;gap:12px;align-items:stretch}',
      '.d-pair{display:grid;grid-template-columns:1fr 1fr;gap:12px;align-items:start}'),
  },
  {
    id: '③b 删掉 .d-rows 的 min-height',
    expect: '真的引用**这两个变量',
    f: (src) => src.replace(/\.d-rows\{min-height:[^}]*\}/, '.d-rows{}'),
  },
  {
    id: '③c --d-rows 改成 3（"固定五个"失守）',
    expect: '--d-rows = 5',
    f: (src) => src.replace('--d-rows:5;', '--d-rows:3;'),
  },
  {
    id: '③d 修改器模板不再套 .d-rows',
    expect: '修改器模板真的套了 .d-rows',
    f: (src) => src.replace('<div class="d-rows">${rows}</div>', '<div>${rows}</div>'),
  },
  {
    id: '③e 删掉 .d-hint2 的 margin-top:auto',
    expect: '提示沉到卡底',
    f: (src) => src.replace('.d-pair .d-hint2{margin-top:auto}', '.d-pair .d-hint2{}'),
  },

  {
    id: '④a contain 改回 cover',
    expect: '同类游戏卡不再用 cover',
    f: (src) => src.replace('aspect-ratio:var(--th-ar);object-fit:contain;', 'aspect-ratio:var(--th-ar);object-fit:cover;'),
  },
  {
    id: '④b slice 退回裸 8',
    expect: '真的引用 REL_SHOW',
    f: (src) => src.replace('.slice(0, REL_SHOW);', '.slice(0, 8);'),
  },
  {
    id: '④c REL_SHOW 改成 6',
    expect: '新增 REL_SHOW = 8',
    f: (src) => src.replace('const REL_SHOW = 8;', 'const REL_SHOW = 6;'),
  },
  {
    id: '④d limit 退回 8（取数不再多于展示）',
    expect: '取数 > 展示数',
    f: (src) => src.replace("const qs = 'limit=12'", "const qs = 'limit=8'"),
  },
  {
    id: '④e 图片槽改回硬编码定高',
    expect: '没有硬编码 px 高度',
    f: (src) => src.replace('display:block;width:100%;height:auto;aspect-ratio:var(--th-ar);object-fit:contain;',
      'display:block;width:100%;height:56px;aspect-ratio:var(--th-ar);object-fit:contain;'),
  },

  {
    id: '⑤ 派生页未重建（emulator.html 缺行槽位变量）',
    page: 'emulator.html',
    expect: 'emulator.html 已同步行槽位变量',
    f: (src) => src.replace(/--d-row-h\s*:[^;]*;/, ''),
  },
];

/* ---------- 准备副本 ---------- */
fs.rmSync(TMP, { recursive: true, force: true });
fs.mkdirSync(path.join(TMP, 'tools'), { recursive: true });
fs.mkdirSync(path.join(TMP, 'public'), { recursive: true });
for (const f of ['index.html', 'emulator.html', 'unpack.html']) {
  fs.copyFileSync(path.join(ROOT, 'public', f), path.join(TMP, 'public', f));
}
fs.copyFileSync(path.join(__dirname, 'test-v1031.js'), path.join(TMP, 'tools', 'test-v1031.js'));

const ORIG = {};
for (const f of ['index.html', 'emulator.html', 'unpack.html']) {
  ORIG[f] = fs.readFileSync(path.join(TMP, 'public', f), 'utf8');
}

/* ---------- 基准：未变异必须绿 ---------- */
console.log('v10.31 断言反证（打坏 → 必须变红）\n');
console.log('【基准】无变异');
{
  const r = cp.spawnSync(process.execPath, [path.join(TMP, 'tools', 'test-v1031.js')], { encoding: 'utf8' });
  const tail = (r.stdout || '').split('\n').filter((l) => /通过 \d+/.test(l)).join(' ');
  if (r.status === 0) console.log(`  ✅ 未变异为绿（${tail}）—— 变异前的基线成立`);
  else { console.log(`  × 未变异就是红的！后面所有"变红"都不算数。\n${r.stdout}`); process.exit(1); }
}

/* ---------- 逐条变异 ---------- */
let good = 0, bad = 0;
console.log('');
for (const m of MUTS) {
  const file = m.page || 'index.html';
  const fp = path.join(TMP, 'public', file);
  const mutated = m.f(ORIG[file]);
  if (mutated === ORIG[file]) {
    console.log(`  × ${m.id}\n      ⚠️ 变异没生效（找不到要替换的源码）⇒ 这条反证无效，必须修脚本`);
    bad++;
    continue;
  }
  fs.writeFileSync(fp, mutated);
  const r = cp.spawnSync(process.execPath, [path.join(TMP, 'tools', 'test-v1031.js')], { encoding: 'utf8' });
  fs.writeFileSync(fp, ORIG[file]);

  const out = (r.stdout || '') + (r.stderr || '');
  const fails = out.split('\n').filter((l) => /× FAIL/.test(l));
  const hit = fails.some((l) => l.includes(m.expect));
  if (r.status !== 0 && hit) {
    good++;
    console.log(`  ✅ ${m.id}\n     → 退出码 ${r.status} · FAIL ${fails.length} 条 · 命中「${m.expect}」`);
  } else if (r.status !== 0 && !hit) {
    bad++;
    console.log(`  × ${m.id}\n     → 变红了但**不是期望的那条**（期望关键词「${m.expect}」没出现）\n` +
      fails.slice(0, 4).map((l) => '       ' + l.trim()).join('\n'));
  } else {
    bad++;
    console.log(`  × ${m.id}\n     → ★ 打坏了却**照样全绿** ⇒ 假绿！这条机制目前没有真守卫`);
  }
}

fs.rmSync(TMP, { recursive: true, force: true });

console.log('\n============================');
console.log(`  反证：合规 ${good} / ${MUTS.length}（无效或假绿 ${bad}）`);
console.log('============================');
if (bad) {
  console.log('⇒ 逐条修 test-v1031.js 的锚点/断言，再复跑本脚本。');
  process.exit(1);
}
console.log('✅ 每条机制的断言都经得起「打坏必红」。');
