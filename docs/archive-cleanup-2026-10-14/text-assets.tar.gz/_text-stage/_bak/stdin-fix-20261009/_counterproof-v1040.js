#!/usr/bin/env node
/* _counterproof-v1040.js —— v10.40 反证：文档结构闸新增的 6 条守卫
 *
 * 用途：证明这 6 条新判据**真的在守行为**。判据坏了却不变红 = 假断言，比没写还危险。
 *
 * 本轮守的是「日志搬家」这件事的完整性：
 *   ① 根目录回潮出现 CODEX-DONE-*.md
 *   ② docs/versions 下出现 CODEX-DONE-*.md
 *   ③ 全仓残留 `CODEX-DONE-v<版本>.md` 活引用
 *   ④ docs/versions 版本号缺号
 *   ⑤ 某份日志的 H1 与文件名版本号不符
 *   ⑥ md 相对链接失效
 *   ⑦（闸自身）把 ③ 的正则打坏 ⇒ 注入的活引用必须**不再被抓住**（证明 ③ 是唯一的把关者）
 *
 * 手法（沿用 v10.38/v10.39 约定）：
 *   ① 每个变异前先跑**未变异基线**，必须 exit=0 且 0 FAIL；
 *   ② 按**字节**备份被改的文件；③ 跑闸；④ 无论成败都还原；⑤ 末位 md5 校验还原成功。
 *
 * 判定：
 *   有 FAIL            ⇒ ✅ 已抓住
 *   无 FAIL 且退出码≠0 ⇒ ⚠️ 崩了（不算抓住）
 *   无 FAIL 且退出码=0 ⇒ ★★ 假断言
 *   基线不为绿          ⇒ 该变异组作废
 *
 * tools/_* 已在 .gitignore，本文件不入库。跑完可删。
 */
'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawnSync } = require('child_process');

const ROOT = path.join(__dirname, '..');
const GATE = path.join(ROOT, 'tools', 'test-doc-structure.js');
const LOGD = path.join(ROOT, 'docs', 'versions');
const md5 = (b) => crypto.createHash('md5').update(b).digest('hex');

const snap = (p) => ({ path: p, buf: fs.readFileSync(p) });
const restore = (s) => fs.writeFileSync(s.path, s.buf);
const deltas = (...parts) => Buffer.concat(parts.map((p) => (Buffer.isBuffer(p) ? p : Buffer.from(p, 'utf8'))));

function runGate() {
  const r = spawnSync(process.execPath, [GATE], { cwd: ROOT, encoding: 'utf8', maxBuffer: 1 << 26 });
  const out = (r.stdout || '') + (r.stderr || '');
  return {
    code: r.status,
    fails: (out.match(/^\s*FAIL\s/gm) || []).length,
    out,
    pass: (() => { const m = /通过\s+(\d+)\/(\d+)/.exec(out); return m ? +m[1] : -1; })(),
    total: (() => { const m = /通过\s+(\d+)\/(\d+)/.exec(out); return m ? +m[2] : -1; })(),
  };
}

/* 被改文件留底 */
const KEEP = {
  readme: path.join(ROOT, 'README.md'),
  gate: GATE,
  log20: path.join(LOGD, 'v10.20.md'),
  log30: path.join(LOGD, 'v10.30.md'),
};
const base = {};
for (const [k, p] of Object.entries(KEEP)) base[k] = snap(p);
const baseMd5 = Object.fromEntries(Object.entries(base).map(([k, s]) => [k, md5(s.buf)]));
function restoreAll() { for (const s of Object.values(base)) restore(s); }
function verifyRestored() {
  const bad = [];
  for (const [k, s] of Object.entries(base)) if (md5(fs.readFileSync(s.path)) !== baseMd5[k]) bad.push(k);
  return bad;
}
/* 变异期间新建/改名的额外产物，逐组清理 */
let extra = [];
function cleanExtra() {
  for (const f of extra) { try { fs.rmSync(f, { force: true }); } catch (e) { /* ignore */ } }
  extra = [];
}

/* ================= 变异清单 ================= */
const VARIANTS = [
  {
    name: '① 在**根目录**新建 CODEX-DONE-v10.99.md（旧命名回潮）',
    apply: () => {
      const p = path.join(ROOT, 'CODEX-DONE-v10.99.md');
      fs.writeFileSync(p, '# v10.99 —— 回潮测试\n\n这是一份不该出现在根目录的旧命名日志。\n');
      extra.push(p);
      return { doc: 'CODEX-DONE-v10.99.md（根目录）', target: p };
    },
    expect: '「根目录无 CODEX-DONE-*.md」必须红',
    selfCheck: (info) => ({ ok: fs.existsSync(info.target), note: '根目录该文件已建立=' + fs.existsSync(info.target) }),
  },
  {
    name: '② 在 docs/versions/ 里新建 CODEX-DONE-v10.98.md（只搬不改名）',
    apply: () => {
      const p = path.join(LOGD, 'CODEX-DONE-v10.98.md');
      fs.writeFileSync(p, '# v10.98 —— 只搬不改名\n\n模拟「文件挪进来了但前缀没去掉」。\n');
      extra.push(p);
      return { doc: 'docs/versions/CODEX-DONE-v10.98.md', target: p };
    },
    expect: '「docs/versions 下无 CODEX-DONE-*.md」必须红',
    selfCheck: (info) => ({ ok: fs.existsSync(info.target), note: '目标文件已建立=' + fs.existsSync(info.target) }),
  },
  {
    name: '③ 在 README.md 末尾写回一行 `CODEX-DONE-v10.39.md` 活引用',
    apply: () => {
      const p = KEEP.readme;
      const cur = fs.readFileSync(p);
      fs.writeFileSync(p, deltas(cur, '\r\n', '> 迁移回潮测试：完整说明见 `CODEX-DONE-v10.39.md`。', '\r\n'));
      return { doc: 'README.md', target: p };
    },
    expect: '「无 CODEX-DONE-v<版本>.md 活引用」必须红',
    selfCheck: (info) => ({
      ok: /`CODEX-DONE-v10\.39\.md`/.test(fs.readFileSync(info.target, 'utf8')),
      note: 'README 已含该活引用',
    }),
  },
  {
    name: '④ 把 docs/versions/v10.20.md 改名 ⇒ 制造版本号缺号',
    apply: () => {
      const from = KEEP.log20;
      const to = path.join(LOGD, '_v10.20.md.off');
      fs.renameSync(from, to);
      extra.push(to);
      return { doc: 'docs/versions/v10.20.md → 临时改名', from, to };
    },
    /* 注：索引里的 [v10.20](v10.20.md) 同时会失效 ⇒ 断言⑥**连带**变红，属预期 */
    expect: '「版本号连续」必须红（索引链接断裂会连带触发 ⑥，属预期）',
    selfCheck: (info) => ({ ok: !fs.existsSync(info.from) && fs.existsSync(info.to), note: '原文件已不在，改名件在位' }),
  },
  {
    name: '⑤ 把 docs/versions/v10.30.md 的 H1 改成 v10.29（复制模板忘改版本号）',
    apply: () => {
      const p = KEEP.log30;
      const s = fs.readFileSync(p, 'utf8');
      const out = s.replace(/^# v10\.30/, '# v10.29');
      fs.writeFileSync(p, Buffer.from(out, 'utf8'));
      return { doc: 'docs/versions/v10.30.md', target: p };
    },
    expect: '「每份日志的 H1 与文件名版本号一致」必须红',
    selfCheck: (info) => ({
      ok: /^# v10\.29/m.test(fs.readFileSync(info.target, 'utf8')),
      note: 'H1 已改成 v10.29',
    }),
  },
  {
    name: '⑥ 在 README.md 里加一个指向不存在文件的相对链接',
    apply: () => {
      const p = KEEP.readme;
      const cur = fs.readFileSync(p);
      fs.writeFileSync(p, deltas(cur, '\r\n', '> 断链测试：[v10.404](docs/versions/v10.404.md)。', '\r\n'));
      return { doc: 'README.md', target: p };
    },
    expect: '「md 相对链接全部可解析」必须红',
    selfCheck: (info) => ({
      ok: /\]\(docs\/versions\/v10\.404\.md\)/.test(fs.readFileSync(info.target, 'utf8')),
      note: 'README 已含断链',
    }),
  },

  /* ---- 把 ③ 的判据本身打坏：证明它真的是唯一把关者 ---- */
  {
    name: '⑦ 把闸里 ③ 的正则改成永不匹配 + 注入活引用 ⇒ 期望**不再红**（证明 ③ 在起作用）',
    apply: () => {
      const s = fs.readFileSync(GATE, 'utf8');
      const from = 'const RE_LIVE_REF = /`CODEX-DONE-v\\d+\\.\\d+\\.md`/;';
      if (s.split(from).length - 1 !== 1) return { doc: null, reason: 'RE_LIVE_REF 常量没找到唯一位置' };
      fs.writeFileSync(GATE, Buffer.from(s.replace(from, 'const RE_LIVE_REF = /$^/;'), 'utf8'));
      const p = KEEP.readme;
      fs.writeFileSync(p, deltas(fs.readFileSync(p), '\r\n', '> 判据负载测试：见 `CODEX-DONE-v10.39.md`。', '\r\n'));
      return { doc: 'README.md + test-doc-structure.js', target: p };
    },
    expectRed: false,
    expect: '★ 期望**全绿** ⇒ 证明「活引用」这条判据是它在把关；若仍红 ⇒ 说明是别的判据顺手兜住的',
    selfCheck: (info) => {
      const g = fs.readFileSync(GATE, 'utf8').includes('const RE_LIVE_REF = /$^/;');
      const r = /`CODEX-DONE-v10\.39\.md`/.test(fs.readFileSync(info.target, 'utf8'));
      return { ok: g && r, note: '闸正则已打坏=' + g + ' · 活引用已注入=' + r };
    },
  },
];

/* ================= 执行 ================= */
const results = [];
console.log('=== v10.40 反证：文档结构闸（v10.40 新增 6 条守卫）===');
console.log('基线自检中（未变异必须先绿）…');
restoreAll(); cleanExtra();
const b0 = runGate();
console.log('  未变异基线：exit=' + b0.code + ' · ' + b0.pass + '/' + b0.total + ' · FAIL=' + b0.fails);
const BASE_GREEN = b0.code === 0 && b0.fails === 0;
console.log('  ⇒ ' + (BASE_GREEN ? '✅ 基线为绿，变异判定有效' : '⚠️ 基线不为绿 ⇒ 所有变异组作废'));
console.log('');

for (const v of VARIANTS) {
  restoreAll(); cleanExtra();
  let info;
  try { info = v.apply(); } catch (e) { info = { doc: null, reason: e.message }; }
  if (info && info.doc === null) {
    results.push({ name: v.name, verdict: '作废', note: info.reason });
    console.log('⊘ ' + v.name + '\n   作废：' + info.reason + '\n');
    restoreAll(); cleanExtra();
    continue;
  }
  const check = v.selfCheck ? v.selfCheck(info) : { ok: true, note: '（无自检）' };
  if (!check.ok) {
    results.push({ name: v.name, verdict: '作废', note: '变异未按设计生效：' + check.note });
    console.log('⊘ ' + v.name + '\n   ★ 作废：变异未按设计生效 —— ' + check.note + '\n');
    restoreAll(); cleanExtra();
    continue;
  }
  const r = runGate();
  const expectRed = v.expectRed !== false;
  let verdict, note = '';
  if (!BASE_GREEN) { verdict = '作废'; note = '基线不为绿'; }
  else if (expectRed && r.fails > 0) { verdict = '已抓住'; note = 'FAIL×' + r.fails + '（' + r.pass + '/' + r.total + '）'; }
  else if (expectRed && r.code !== 0) { verdict = '崩了(不算)'; note = 'exit=' + r.code + ' 但 0 条 FAIL'; }
  else if (expectRed) { verdict = '★★假断言'; note = 'exit=0 且 0 条 FAIL'; }
  else if (r.fails === 0 && r.code === 0) { verdict = '已抓住'; note = '按预期「不再被抓住」⇒ 该判据确实是把关者'; }
  else { verdict = '★未达预期'; note = '期望全绿，实测 FAIL×' + r.fails; }
  results.push({ name: v.name, verdict, note, expect: v.expect });
  console.log((verdict === '已抓住' ? '✅ ' : verdict.startsWith('★') ? '★★ ' : '⚠️ ') + v.name);
  console.log('   施加于：' + info.doc);
  console.log('   变异自检：' + check.note);
  console.log('   期望：' + v.expect);
  console.log('   实测：' + verdict + ' · ' + note);
  const fl = (r.out.match(/^\s*FAIL\s+.*$/gm) || []).slice(0, 4).map((s) => s.trim().slice(0, 140));
  if (fl.length) console.log('   抓住的断言：\n     ' + fl.join('\n     '));
  console.log('');
  restoreAll(); cleanExtra();
}

/* ---------- 还原校验 ---------- */
const badRestore = verifyRestored();
const leftover = fs.readdirSync(ROOT).filter((f) => /^CODEX-DONE-/.test(f))
  .concat(fs.readdirSync(LOGD).filter((f) => /^CODEX-DONE-|^_v10\./.test(f)));
console.log('=== 还原校验 ===');
for (const [k, s] of Object.entries(base)) {
  const now = md5(fs.readFileSync(s.path));
  console.log('  ' + (now === baseMd5[k] ? '✓' : '✗') + '  ' + k + '  ' + baseMd5[k].slice(0, 8) + ' → ' + now.slice(0, 8));
}
console.log('  残余变异产物：' + (leftover.length ? '★ ' + leftover.join(', ') : '无'));

console.log('');
console.log('=== 汇总 ===');
const by = {};
for (const r of results) by[r.verdict] = (by[r.verdict] || 0) + 1;
console.log('  ' + results.length + ' 组：' + Object.entries(by).map(([k, v]) => k + ' ' + v).join(' · '));
const bad = results.filter((r) => r.verdict !== '已抓住');
if (bad.length) {
  console.log('');
  console.log('--- 有问题的组 ---');
  for (const r of bad) console.log('  · [' + r.verdict + '] ' + r.name + ' —— ' + r.note);
}
console.log('');
console.log('====');
console.log('合规 ' + results.filter((r) => r.verdict === '已抓住').length + '/' + results.length +
  '（假断言 ' + (by['★★假断言'] || 0) + ' · 崩了 ' + (by['崩了(不算)'] || 0) +
  ' · 作废 ' + (by['作废'] || 0) + ' · 未达预期 ' + (by['★未达预期'] || 0) + '）');
console.log('还原：' + (badRestore.length ? '★ 失败 ' + badRestore.join(',') : '按字节还原成功') +
  ' · 净化：' + (leftover.length ? '★ 有残留' : 'ok'));
process.exit(bad.length || badRestore.length || leftover.length ? 1 : 0);
