#!/usr/bin/env node
/* tools/_counterproof-v1035.js —— v10.35「arch 口径」静态层的**反证**
 *
 * 做法：把被守护的文件复制到 `_cf135/`（套件的 ROOT 由 __dirname 推导 ⇒ 自动指向副本），
 *   单点变异后跑 `tools/test-v1035.js`。
 *
 * 判据 = **退出码非零 且 指定断言名出现在 FAIL 行**。
 *   · 只看退出码不够：语法错 / 崩溃也非零，那不是「断言抓住了」；
 *   · 只看断言名不够：它可能本来就红。
 *   ⇒ 另加两条前置：基准（无变异）必须全绿；变异必须**真的改到了内容**。
 *
 * ★★ 本版新增一条（v10.34 反证当场学到的）：**把「套件崩了」与「断言没抓住」分开报**。
 *   实测踩到 —— 断言写成 `prof(x).api.find(a=>a.kind==='dx').v`，实现被打坏后是
 *   `undefined.v` ⇒ **TypeError 直接崩**，套件一行 FAIL 都没打印 ⇒ 本工具只看「有没有 FAIL 行」
 *   ⇒ 得出「打坏了也没红」= 假绿 ⇒ 差点去「修」一条本来正确的断言。
 *   现在判据多一条「有没有跑完」（汇总行 `通过 n / m`）：
 *     跑完 + 无 FAIL  ⇒ 真·假绿（打不红）
 *     没跑完/无汇总行  ⇒ **UNVERIFIED（不可判定）**，既不算合规、也不算假绿，必须修。
 *
 * ⚠️ 覆盖 `_cf135/` 下的副本，**不动**项目正本。
 */
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const ROOT = path.join(__dirname, '..');
const CF = path.join(ROOT, '_cf135');
/* test-v1035 会跑 `specMatch.index()` 做全库影响面统计 ⇒ 副本里必须有 spec-req.json
   （spec-match.js 用 `path.join(__dirname,'spec-req.json')` 定位，跟着副本走）。 */
const FILES = [
  'tools/test-v1035.js',
  'data/spec-match.js',
  'data/spec-dict.js',
  'data/gpu-tier.js',
  'data/spec-req.json',
  'server.js',
];

const MUT = [
  {
    /* ⚠️ 变异必须打在**唯一来源**上：`ARCH_NO_TR` 常量同时驱动 cmpArch 的行为与
       dictInfo().archRule 的自述 ⇒ 改它两处一起变，一致性断言不会替我们兜住。
       （这正是 v10.34 学到的「第二层守卫会兜住单点替换」的反面用法：把唯一来源改坏。） */
    id: '① 口径被悄悄收回：ARM 缺转译层改回 fail（v10.35 决策被退回）',
    file: 'data/spec-match.js',
    expect: '画像 G：cpu_abi=ARM + 无 box64',
    f: (s) => s.replace("const ARCH_NO_TR = 'unknown';", "const ARCH_NO_TR = 'fail';"),
  },
  {
    /* ★ 专打「自述与实现漂移」：接口自述说 fail、实现返回 unknown ⇒
       一致性断言必须红（否则 `curl /api/spec/dict` 这个线上判据本身不可信）。 */
    id: '⑥ arch 口径自述与实现漂移（archRule 写死 fail，实现仍 unknown）',
    file: 'data/spec-match.js',
    expect: '自述「未提及转译层」的 state == cmpArch 实际返回值',
    f: (s) => s.replace('noTranslatorInfo: ARCH_NO_TR,', "noTranslatorInfo: 'fail',"),
  },
  {
    id: '② 「显式声明不可用 ⇒ fail」这一层被拿掉（连明确不支持也放过）',
    file: 'data/spec-match.js',
    expect: 'box64 显式写成「off」',
    f: (s) => s.replace('if (TR_OFF.test(raw)) {', 'if (false) {'),
  },
  {
    id: '② TR_OFF 少认中文（无 / 禁用 不再算「明确不支持」）',
    file: 'data/spec-match.js',
    expect: 'box64 显式写成「无」',
    f: (s) => s.replace('|无|禁用|关闭|不支持|不可用)$/i;', ')$/i;'),
  },
  {
    /* ★ 空值 ≠ 禁用：导出物里「键在值空」极常见，那是没填，不是不支持。 */
    id: '② 把「空值」也当成禁用（空值 ⇒ fail）',
    file: 'data/spec-match.js',
    expect: 'box64 值为空串',
    f: (s) => s.replace(
      "    const raw = String((profile.layer[tr] || {}).raw || '').trim();",
      "    const raw = String((profile.layer[tr] || {}).raw || '').trim() || 'off';"),
  },
  {
    id: '③ 既有分支被牵连：无架构且无 ARM 专用层时不再 skip',
    file: 'data/spec-match.js',
    expect: '既没标架构、又没有 ARM 专用层',
    f: (s) => s.replace(
      "return { dim: 'arch', state: 'skip', note: '配置未涉及指令集架构（按无关维度跳过）' };",
      "return { dim: 'arch', state: 'unknown', note: '配置未涉及指令集架构（按无关维度跳过）' };"),
  },
  {
    id: '③ 既有分支被牵连：x86 也被判 unknown（可直接执行的能力丢了）',
    file: 'data/spec-match.js',
    expect: 'x86_64 可直接执行',
    f: (s) => s.replace(
      "if (/x86|amd64|x64|i[3-6]86/.test(a)) return { dim: 'arch', state: 'ok', note: 'x86 架构可直接执行 Windows 程序' };",
      "if (/x86|amd64|x64|i[3-6]86/.test(a)) return { dim: 'arch', state: 'unknown', note: 'x86 架构可直接执行 Windows 程序' };"),
  },
  {
    id: '③ 既有分支被牵连：没标架构但有 turnip 不再提示补 arch',
    file: 'data/spec-match.js',
    expect: '没标架构但有 turnip',
    f: (s) => s.replace(
      "      return { dim: 'arch', state: 'unknown', note: '出现 ' + armish",
      "      return { dim: 'arch', state: 'skip', note: '出现 ' + armish"),
  },
  {
    id: '⑤ 转译层识别失效（tr 恒 null）⇒ 参考组 H 全库不再 arch ok',
    file: 'data/spec-match.js',
    expect: '参考组 H',
    f: (s) => s.replace(
      'const tr = Object.keys(profile.layer || {}).find((k) => X86_TRANSLATORS.some((w) => k.includes(w)));',
      'const tr = null;'),
  },
  {
    id: '⑥ 接口被牵连：server.js 不再走 specMatch.analyze',
    file: 'server.js',
    expect: '/api/spec/analyze 仍走 specMatch.analyze',
    f: (s) => s.replace(/specMatch\.analyze\(/g, 'specMatch.analyzeX('),
  },
];

function cp(src, dst) {
  fs.mkdirSync(path.dirname(dst), { recursive: true });
  fs.copyFileSync(src, dst);
}
function buildBase() {
  for (const f of FILES) cp(path.join(ROOT, f), path.join(CF, f));
}
function runSuite() {
  try {
    return { code: 0, out: execFileSync(process.execPath, [path.join(CF, 'tools', 'test-v1035.js')],
      { encoding: 'utf8', cwd: CF, timeout: 180000 }) };
  } catch (e) {
    return { code: e.status || 1, out: String(e.stdout || '') + String(e.stderr || '') };
  }
}
/* ★ 判「跑完」看汇总行。崩了 / 语法错 / 提前 return 都不会有这一行。 */
const RAN_OK = /通过 \d+\/\d+/;

console.log('\n=== 反证 v10.35：基准（无变异）必须全绿 ===');
buildBase();
const base = runSuite();
if (base.code !== 0 || !RAN_OK.test(base.out)) {
  console.log('  × 基准就是红的（或没跑完），反证无意义。输出尾部：\n' + base.out.slice(-1400));
  process.exit(1);
}
console.log('  PASS  基准全绿  — ' + (base.out.match(/通过 \d+\/\d+/) || [])[0] + '\n');

console.log('=== 逐条变异（期望：退出码非零 **且** 指定断言出现在 FAIL 行） ===\n');
let good = 0, bad = 0, unv = 0;
for (const m of MUT) {
  const src = fs.readFileSync(path.join(ROOT, m.file), 'utf8');
  const mut = m.f(src);
  const dst = path.join(CF, m.file);
  if (mut === src) {
    bad += 1;
    console.log('  × [' + m.id + '] 变异**未生效**（替换串没匹配上 ' + m.file + '）—— 这条不算合规\n');
    continue;
  }
  fs.writeFileSync(dst, mut, 'utf8');
  const r = runSuite();
  fs.copyFileSync(path.join(ROOT, m.file), dst);   // 立刻还原副本

  const lines = r.out.split(/\r?\n/);
  const hit = lines.find((l) => l.includes('× FAIL') && l.includes(m.expect)) || '';
  if (!RAN_OK.test(r.out)) {
    /* ★★ 没跑完 = 什么都没验到。既不能算合规，也不能判「假绿」。 */
    unv += 1;
    console.log('  ? UNVERIFIED  ' + m.id);
    console.log('        └ 套件**未跑完**（没有汇总行）⇒ 这次变异什么都没验到，不许算合规');
    console.log('        └ 输出尾部：' + r.out.slice(-300).replace(/\s+/g, ' '));
  } else if (r.code !== 0 && hit) {
    good += 1;
    console.log('  PASS  ' + m.id + '\n        └ 变红于：' + hit.trim());
  } else {
    bad += 1;
    console.log('  × FAIL  ' + m.id);
    console.log('        └ 期望断言含「' + m.expect + '」；实际退出码=' + r.code + (hit ? '' : '（该断言未变红）'));
    if (!hit) {
      const anyFail = lines.filter((l) => l.includes('× FAIL')).slice(0, 3);
      console.log('        └ 实际红的是：' + (anyFail.join(' | ') || '(没有任何 FAIL 行 —— 套件跑完了却全绿 ⇒ 真·假绿)'));
    }
  }
  console.log('');
}

console.log('=== 反证结果 ===');
console.log('  合规 ' + good + ' / ' + MUT.length +
  (bad ? '   ★ 不合规 ' + bad + ' 条（打不红）' : '') +
  (unv ? '   ★ 不可判定 ' + unv + ' 条（套件崩了，等于没验）' : '') + '\n');
process.exit(bad || unv ? 1 : 0);
