#!/usr/bin/env node
/* 落盘式语法闸：把 HTML 里的 <script> 段抽出来交给 `node --check`（带行号） */
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const root = path.join(__dirname, '..');
const files = process.argv.slice(2).length ? process.argv.slice(2)
  : ['public/index.html', 'public/emulator.html', 'public/unpack.html'];

let bad = 0;
for (const rel of files) {
  const f = path.join(root, rel);
  if (!fs.existsSync(f)) { console.log(rel + ' → 不存在'); continue; }
  const s = fs.readFileSync(f, 'utf8');
  const lines = s.split(/\r?\n/);
  const re = /<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/g;
  let m, i = 0;
  while ((m = re.exec(s))) {
    i++;
    /* 该 script 段起始行号（用于把 --check 的行号换算回 HTML 行号） */
    const startLine = s.slice(0, m.index).split('\n').length;
    const body = m[1];
    const tmp = path.join(root, '_syntax-probe.js');
    fs.writeFileSync(tmp, body, 'utf8');
    try {
      execFileSync(process.execPath, ['--check', tmp], { stdio: 'pipe' });
      console.log(rel + ' script#' + i + ' ✅ 语法通过（' + body.length + ' 字符，起始 HTML 行 ' + startLine + '）');
    } catch (e) {
      bad++;
      const msg = (e.stderr ? e.stderr.toString() : e.message);
      console.log(rel + ' script#' + i + ' ❌ 语法错误：');
      const mm = msg.match(/_syntax-probe\.js:(\d+)/);
      if (mm) {
        const ln = +mm[1];
        console.log('   → HTML 第 ' + (startLine + ln - 1) + ' 行附近');
        for (let k = Math.max(0, ln - 4); k < Math.min(lines.length, ln + 3); k++) {
          console.log('     ' + String(k + 1).padStart(5) + ' | ' + lines[k].slice(0, 150));
        }
      }
      console.log('   ' + msg.split('\n').slice(0, 6).join('\n   '));
    }
    fs.unlinkSync(tmp);
  }
  console.log(rel + ' → ' + i + ' 段 script，共 ' + lines.length + ' 行');
}
process.exit(bad ? 1 : 0);
