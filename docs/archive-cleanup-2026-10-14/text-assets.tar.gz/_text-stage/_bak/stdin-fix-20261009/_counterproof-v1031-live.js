#!/usr/bin/env node
/* tools/_counterproof-v1031-live.js —— v10.31 **浏览器层**断言反证（打坏 → 必须变红）
 *
 * `_counterproof-v1031.js` 只反证了静态层（改源码字符串 → test-v1031.js 变红）。
 * 但 ①「忽大忽小」这条的**决定性证据**在实拍层：两个游戏名同屏、抖动次数、
 * naturalWidth —— 静态层永远看不见「浏览器实际排出来什么样」。
 * 所以实拍层的断言同样必须反证，否则 `preview-v1031.js` 里那些 ✅ 可能只是
 * 「量了个不相干的数」。
 *
 * 做法（⚠️ 会**临时改写 public/index.html**，必须严格 try/finally 还原）：
 *   1. 备份 public/index.html → _preview/_cf-live-index.bak（并记 md5）
 *   2. 单点变异 → 写回 → 跑 `preview-v1031.js`（SAMPLE_TAG 限定 1 个样本，省一半时间）
 *   3. 无论成败，finally 从备份还原，并**核对 md5 与备份一致**
 *   4. 判「变红」= 退出码非零 **且** 期望断言名出现在 ❌ 行（只看退出码会把
 *      「撞红别的断言」误判成通过）
 *
 * 运行：node tools/_counterproof-v1031-live.js   （需 8123 服务在跑）
 */
const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const crypto = require('crypto');

const ROOT = path.join(__dirname, '..');
const IDX = path.join(ROOT, 'public', 'index.html');
const BAK = path.join(ROOT, '_preview', '_cf-live-index.bak');

const MUTS = [
  {
    id: '①a 小条加回「位移 + 过渡」',
    expect: '小条 transform 为 none',
    f: (src) => src.replace('.d-mini{position:sticky;top:0;z-index:7;',
      '.d-mini{position:sticky;top:0;z-index:7;transform:translateY(-102%);transition:transform .26s ease;'),
  },
  {
    id: '①b 阈值退回早阈值（大图高 − 62 + 12 = 200）',
    /* 旧阈值会**同时**踩红两条：41 点扫描出现「同屏」，且首激活时大标题还没走完
       （实测阈值 200 时大标题底还有 +36px）。 */
    expect: ['无「大标题与小条同屏」', '首激活时大标题**已完全离开视口**'],
    f: (src) => src.replace('const on = Math.max(60, hero.offsetHeight);', 'const on = Math.max(60, hero.offsetHeight - 62 + 12);'),
  },
  {
    id: '①c 阈值推迟 40px（晚于大图离开 ⇒ 露出空档）',
    /* 这一条专门守「阈值 ≈ 大图高」那条断言：晚激活**不会**造成同屏，
       所以只有 `阈值首次激活 ≈ 大图高（同档；跟随 offsetHeight）` 能抓到它。 */
    expect: '阈值首次激活 ≈ 大图高',
    f: (src) => src.replace('const on = Math.max(60, hero.offsetHeight);', 'const on = Math.max(60, hero.offsetHeight + 40);'),
  },
  {
    id: '② cover 退回 d.cover 优先（顶图糊成方图）',
    /* ⚠️ 期望关键词不能写「顶图与列表封面同一张」—— 大图与小条缩略图**共用同一个
       `cover` 变量**，所以把优先级翻回去，两者**依然相等**（一起变成 128×128）。
       真正能抓住它的是**像素尺寸**那条断言（natural=128x128 < 400）。 */
    expect: '顶图像素不是 XD',
    f: (src) => src.replace("const cover = fb.cover || d.cover || '';", "const cover = d.cover || (fb && fb.cover) || '';"),
  },
  {
    id: '③ .d-pair 退回 align-items:start（两卡不等高）',
    expect: '两块**高度相等**',
    f: (src) => src.replace('gap:12px;align-items:stretch}', 'gap:12px;align-items:start}'),
  },
  {
    /* ⚠️ 这里**不能**用「退回裸 8」当变异：实测证明 `slice(0, 8)` 与 `slice(0, REL_SHOW)`
       在本样本上**结果完全一样（都是 8 张）** —— 因为 `limit=12` 取回来的条数
       过滤后仍 ≥8。也就是说：真正决定「张数是 8 还是 5~7」的是 **`limit` 比展示数大**，
       而 `REL_SHOW` 只是「8 这个数字只写一处」的可维护性问题（那一条由**静态层**守）。
       ⇒ 实拍层要验的是**可观测张数**：写死 6 必然只有 6 张。 */
    id: '④a 展示数写死 6（可观测张数应掉到 6）',
    expect: '同分类显示 8 张',
    f: (src) => src.replace('.slice(0, REL_SHOW);', '.slice(0, 6);'),
  },
  {
    id: '④b limit 退回 6（取数不再多于展示数）',
    expect: '同分类显示 8 张',
    f: (src) => src.replace("const qs = 'limit=12'", "const qs = 'limit=6'"),
  },
  {
    id: '④c contain 退回 cover',
    expect: 'object-fit 全为 contain',
    f: (src) => src.replace('aspect-ratio:var(--th-ar);object-fit:contain;', 'aspect-ratio:var(--th-ar);object-fit:cover;'),
  },
];

const sha = (p) => crypto.createHash('md5').update(fs.readFileSync(p)).digest('hex');

if (!fs.existsSync(path.join(ROOT, '_preview'))) fs.mkdirSync(path.join(ROOT, '_preview'), { recursive: true });
const ORIG = fs.readFileSync(IDX, 'utf8');
const ORIG_MD5 = sha(IDX);
fs.writeFileSync(BAK, ORIG);
console.log('v10.31 实拍层断言反证（打坏 → 必须变红）');
console.log(`  已备份 public/index.html → _preview/_cf-live-index.bak（md5 ${ORIG_MD5}）\n`);

let good = 0, bad = 0, restored = false;
try {
  for (const m of MUTS) {
    const mutated = m.f(ORIG);
    if (mutated === ORIG) { console.log(`  × ${m.id}\n      ⚠️ 变异没生效 ⇒ 这条反证无效`); bad++; continue; }
    fs.writeFileSync(IDX, mutated);
    const r = cp.spawnSync(process.execPath, [path.join(__dirname, 'preview-v1031.js')], {
      encoding: 'utf8', timeout: 240000, env: { ...process.env, SAMPLE_TAG: '692' },
    });
    const out = (r.stdout || '') + (r.stderr || '');
    const fails = out.split('\n').filter((l) => /❌/.test(l));
    /* `expect` 可用字符串或**字符串数组**（数组要求每条关键词都出现在 FAIL 行里 —— 更严：
       同一个变异常常同时踩红多条断言，用数组能一次证明「这几条都真的在守」）。 */
    const keys = Array.isArray(m.expect) ? m.expect : [m.expect];
    const hit = keys.every((k) => fails.some((l) => l.includes(k)));
    if (r.status !== 0 && hit) {
      good++;
      console.log(`  ✅ ${m.id}\n     → 退出码 ${r.status} · ❌ ${fails.length} 条 · 命中「${keys.join(' + ')}」`);
    } else if (r.status !== 0 && !hit) {
      bad++;
      console.log(`  × ${m.id}\n     → 变红了但**不是期望那条**（关键词「${keys.join(' + ')}」未全部出现）\n` +
        fails.slice(0, 3).map((l) => '       ' + l.trim()).join('\n'));
    } else {
      bad++;
      console.log(`  × ${m.id}\n     → ★ 打坏了却**照样全绿** ⇒ 实拍层这条没有真守卫`);
    }
    fs.writeFileSync(IDX, ORIG); // 每条之间先还原，避免变异叠加
  }
} finally {
  fs.writeFileSync(IDX, fs.readFileSync(BAK));
  restored = sha(IDX) === ORIG_MD5;
  fs.rmSync(BAK, { force: true });
}
console.log(`\n  还原检查：public/index.html md5 ${restored ? '与备份一致 ✅' : '**不一致 ✗ 必须手工恢复！**'}`);
if (!restored) process.exit(2);

console.log('\n============================');
console.log(`  实拍层反证：合规 ${good} / ${MUTS.length}（无效或假绿 ${bad}）`);
console.log('============================');
process.exit(bad ? 1 : 0);
