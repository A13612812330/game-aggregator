/* 反证：把 v10.28「详情页重排 / 置顶 / 固定底栏 / 三专区预览」的关键行为逐个打坏，
 * 对应断言必须变红。用法：node tools/_counterproof-v1028.js   （跑完自动还原，无论成败）
 *
 * ★ 每条都挑**同一个语义**打坏，而不是「随便删一行」：
 *   反证的价值在于证明「这条断言真的在守那个行为」。删一行无关代码让它变红，
 *   只能说明测试会挂，说明不了它在守什么。
 *
 * ★ 为什么必须做：本版新增的多数断言是「顺序 / 层级 / 归属」类 ——
 *   这类判据最容易写成恒真（例如「游戏预览在配置要求之前」，一旦标记被删，
 *   indexOf 返回 -1，-1 < 任何下标 ⇒ 照样绿）。不逐条反证一遍，等于没有防线。
 */
const fs = require('fs');
const { execFileSync } = require('child_process');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const TEST = 'tools/test-v1028-detail.js';

const CASES = [
  {
    name: '① 版式顺序打乱：游戏介绍 / 版本介绍对调',
    file: 'public/index.html',
    from: '${descHtml}${versionHtml}',
    to: '${versionHtml}${descHtml}',
    expect: '十四块标记',
  },
  {
    name: '② 灯箱层级退回 90（又被详情抽屉原样盖住）',
    file: 'public/index.html',
    from: '.gal-lb{position:fixed;inset:0;z-index:140;',
    to: '.gal-lb{position:fixed;inset:0;z-index:90;',
    expect: '灯箱层级必须',
  },
  {
    name: '②-b 灯箱 ✕ 的关闭分支被去掉（回到 v10.28 之前：点 ✕ 没反应，只能按 Esc）',
    file: 'public/index.html',
    from: "if (e.target === galLbEl || (e.target.closest && e.target.closest('.gal-lb-x'))) { galLbClose(); return; }",
    to: 'if (e.target === galLbEl) { galLbClose(); return; }',
    expect: '点右上角 ✕ 有对应的关闭分支',
  },
  {
    name: '③ 固定底栏改回普通流（不再贴底）',
    file: 'public/index.html',
    from: '.d-dock{position:sticky;bottom:0;',
    to: '.d-dock{position:relative;bottom:0;',
    expect: '.d-dock 是 sticky',
  },
  {
    name: '④ 把底栏挪进 .d-body（sticky 会被 padding-bottom 垫起一条白缝）',
    file: 'public/index.html',
    from: '    </div>\n    <!-- ⑩ 操作按钮组',
    to: '    <!-- ⑩ 操作按钮组',
    expect: '在 .d-body **之外**',
  },
  {
    name: '⑤ 机型默认数量退回 24（一屏半的按钮墙）',
    file: 'public/index.html',
    from: 'const DL_DEV_SHOW = 5;',
    to: 'const DL_DEV_SHOW = 24;',
    expect: '默认展示 5 台机型',
  },
  {
    name: '⑥ 「更多」入口缩进成 if 块内（无机型但有实测的游戏连入口都没有）',
    file: 'public/index.html',
    from: '    }\n\n    /* ★ v10.28：「其余机型',
    to: '      }\n\n    /* ★ v10.28：「其余机型',
    expect: '「更多」入口在 if',
  },
  {
    name: '⑦ 专区固定序打坏：Mod 排到本体前面（跟着服务端顺序走）',
    file: 'public/index.html',
    from: "  const order = ['body', 'mod', 'modifier'];",
    to: "  const order = ['mod', 'body', 'modifier'];",
    expect: '固定序「本体',
  },
  {
    name: '⑧ 丢掉 real 过滤（用户会点到一个空地址）',
    file: 'public/index.html',
    from: "  const items = ((j && j.items) || []).filter((i) => i && i.real);",
    to: "  const items = ((j && j.items) || []).filter((i) => i);",
    expect: '没有 real 的条目被过滤',
  },
  {
    name: '⑨ 弹窗每页退回 30（用户要的是每页 10 帖）',
    file: 'public/index.html',
    from: 'const DF_PAGE = 10;',
    to: 'const DF_PAGE = 30;',
    expect: '弹窗每页 10 帖',
  },
  {
    name: '⑩ 派生页漂移：emulator.html 的底栏节点被改名（主源改了没重建）',
    file: 'public/emulator.html',
    from: '<div class="d-dock">',
    to: '<div class="d-dock-x">',
    expect: 'emulator.html 已同步固定底栏',
  },
];

function runTest() {
  try {
    return execFileSync(process.execPath, [TEST], { cwd: ROOT, encoding: 'utf8', stdio: 'pipe' });
  } catch (e) {
    return (e.stdout || '') + (e.stderr || '');
  }
}

/** ★ 子进程真的跑起来了才算数：没有汇总行 = 脚本本身失败 ——
 *  绝不能被当成「断言没变红」（那会把「工具坏了」误判成「断言是假绿」）。 */
function ranOk(out) {
  return /通过 \d+\/\d+/.test(String(out));
}

function lineFor(out, kw) {
  const l = String(out).split(/\r?\n/).find((x) => x.includes(kw));
  return l ? l.trim() : '(未找到该断言行)';
}

let bad = 0;
const skipped = [];
for (const c of CASES) {
  const p = path.join(ROOT, c.file);
  const orig = fs.readFileSync(p, 'utf8');
  const hits = orig.split(c.from).length - 1;
  if (hits === 0) {
    console.log('⚠️  ' + c.name + '\n     找不到要替换的原文，反证无效（文件可能与测试不同步）');
    bad++;
    continue;
  }
  if (hits > 1) skipped.push(c.name + '（原文出现 ' + hits + ' 次，只替换了第 1 处）');
  try {
    fs.writeFileSync(p, orig.replace(c.from, c.to), 'utf8');
    const out = runTest();
    if (!ranOk(out)) {
      console.log('❌ 测试没跑起来（拿不到汇总行）  ' + c.name);
      console.log('     前 200 字：' + String(out).slice(0, 200).replace(/\s+/g, ' '));
      bad++;
      continue;
    }
    const line = lineFor(out, c.expect);
    const isFail = /× FAIL/.test(line);
    const summary = (out.match(/通过 \d+\/\d+（失败 \d+）/) || ['(无汇总)'])[0];
    console.log((isFail ? '✅ 变红' : '❌ 没变红') + '  ' + c.name);
    console.log('     ' + line);
    console.log('     ' + summary);
    if (!isFail) bad++;
  } finally {
    fs.writeFileSync(p, orig, 'utf8');       // ★ 无论成败都还原
  }
}

if (skipped.length) {
  console.log('\n⚠️ 以下条目的原文在文件里出现多次，替换的是第 1 处，判据可能没落在同一段代码上：');
  for (const s of skipped) console.log('   · ' + s);
}

console.log('\n============================');
console.log(bad ? ('❌ ' + bad + ' 条反证未变红（断言是假绿）') : '✅ 全部反证通过：打坏即变红');
console.log('已还原全部文件');
console.log('============================');
process.exit(bad ? 1 : 0);
