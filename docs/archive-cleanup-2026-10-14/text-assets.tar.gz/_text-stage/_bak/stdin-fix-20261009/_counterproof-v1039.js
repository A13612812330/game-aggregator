#!/usr/bin/env node
/* _counterproof-v1039.js —— v10.39 反证：文档结构闸（tools/test-doc-structure.js）
 *
 * 用途：证明这条新防线**真的在守行为**，而不是「守了个寂寞」。
 *   判据坏了却不变红 = 假断言，比没写还危险 —— 它让人以为已经守住了。
 *
 * ★ 本轮的特别之处：被守对象是**文档**（不是代码），所以变异施加在 `.md` 上，
 *   并且第一组变异用**真实事故数据回放**（v10.36 那个 752 行污染版还在 `_archived/` 里），
 *   比合成变异更有说服力 —— 它证明「这条闸当年就能抓到那次事故」。
 *
 * 手法（沿用 v10.38 约定）：
 *   ① 每个变异前先跑**未变异基线**，必须 exit=0 且 0 FAIL（否则后面的判定没有意义）；
 *   ② 按**字节**备份被改的文件；③ 跑闸；④ 无论成败都还原；⑤ 末位 md5 校验还原成功。
 *
 * 四种判定：
 *   有 FAIL            ⇒ ✅ 已抓住
 *   无 FAIL 且退出码≠0 ⇒ ⚠️ 崩了（变异体让闸自己炸了）—— **不算抓住**
 *   无 FAIL 且退出码=0 ⇒ ★★ 假断言
 *   基线不为绿          ⇒ 该变异组**作废**（前置失败，不算数）
 *
 * tools/_* 已在 .gitignore，本文件不入库。跑完可删。
 */
'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawnSync } = require('child_process');

const ROOT = path.join(__dirname, '..');
const GATE = path.join(ROOT, 'tools', 'test-doc-structure.js');
const md5 = (b) => crypto.createHash('md5').update(b).digest('hex');

/* 按字节读入并留底 —— ★ 必须是字节：文档是 CRLF，按字符串改写会把整个文件的行尾换掉 */
const snap = (p) => ({ path: p, buf: fs.readFileSync(p) });
const restore = (s) => fs.writeFileSync(s.path, s.buf);
const deltas = (...parts) => Buffer.concat(parts.map((p) => (Buffer.isBuffer(p) ? p : Buffer.from(p, 'utf8'))));
const BOM = '\uFEFF';

function runGate() {
  const r = spawnSync(process.execPath, [GATE], { cwd: ROOT, encoding: 'utf8', maxBuffer: 1 << 26 });
  const out = (r.stdout || '') + (r.stderr || '');
  const fails = (out.match(/^\s*FAIL\s/gm) || []).length;
  const last = /通过\s+(\d+)\/(\d+)/.exec(out);
  return { code: r.status, fails, out, pass: last ? +last[1] : -1, total: last ? +last[2] : -1 };
}

/* 围栏感知的一级标题计数（与闸实现同口径 —— 自检不沿用同口径就会自欺） */
function countH1(text) {
  let fence = null, n = 0;
  for (const raw of text.split(/\r?\n/)) {
    const t = raw.trim();
    const f = /^(`{3,}|~{3,})/.exec(t);
    if (f) { const m = f[1][0]; if (fence === null) fence = m; else if (fence === m) fence = null; continue; }
    if (fence !== null) continue;
    if (/^#\s+\S/.test(t)) n++;
  }
  return n;
}

/* ================= 变异清单 =================
 * kind: 'file' 施加在文档上；'gate' 施加在闸自己身上（验判据本身在起作用） */
const DOC_HEAD_LINES = (p, n) => fs.readFileSync(p, 'utf8').split(/\r?\n/).slice(0, n).join('\r\n');

const VARIANTS = [
  /* ---- 第一组：真实事故回放 ---- */
  {
    name: '① ★ 真实事故回放：把 v10.36 那个 752 行污染版 WORKFLOW.md 放回去',
    kind: 'file',
    apply: () => {
      const broken = fs.readFileSync(path.join(ROOT, '_archived', 'WORKFLOW-v10.38-duplicated.md'));
      const good = fs.readFileSync(path.join(ROOT, 'WORKFLOW.md'));
      fs.writeFileSync(path.join(ROOT, 'WORKFLOW.md'), broken);
      return { doc: 'WORKFLOW.md', beforeBytes: good.length, afterBytes: broken.length, target: path.join(ROOT, 'WORKFLOW.md') };
    },
    expect: '当年那次事故若跑过本闸 ⇒ 必须在「偏移重复」与「标题路径」上变红',
    selfCheck: (info) => {
      const n = fs.readFileSync(info.target, 'utf8').split(/\r?\n/).length;
      return { ok: n === 752, note: '行数 ' + n + '（期望 752，事故版原样）' };
    },
  },

  /* ---- 第二组：合成变异（换个文件、换个位置，证明判据不是为单个文件调的）---- */
  {
    name: '② 把 ROADMAP.md 的**前 200 行**整段追加到它自己末尾（模拟「局部大段副本」）',
    kind: 'file',
    apply: () => {
      const p = path.join(ROOT, 'ROADMAP.md');
      const head = DOC_HEAD_LINES(p, 200);
      const cur = fs.readFileSync(p);
      fs.writeFileSync(p, deltas(cur, '\r\n', head, '\r\n'));
      return { doc: 'ROADMAP.md', target: p, needle: head.split(/\r?\n/)[12] };
    },
    expect: '「整段副本」必须红（证明判据不只在 WORKFLOW.md 上生效）',
    selfCheck: (info) => {
      const ls = fs.readFileSync(info.target, 'utf8').split(/\r?\n/);
      const c = ls.filter((l) => l.trim() === info.needle.trim()).length;
      return { ok: c === 2, note: '取样行「' + info.needle.trim().slice(0, 24) + '…」出现 ' + c + ' 次（期望 2）' };
    },
  },
  {
    name: '③ 把 PITFALLS.md 的**中间 150 行**插回它自己的前半部分（插在中途，不是末尾）',
    kind: 'file',
    apply: () => {
      const p = path.join(ROOT, 'PITFALLS.md');
      const lines = fs.readFileSync(p, 'utf8').split(/\r?\n/);
      const block = lines.slice(150, 300);
      const at = [...lines.slice(0, 60), ...block, ...lines.slice(60)].join('\r\n');
      fs.writeFileSync(p, Buffer.from(at, 'utf8'));
      return { doc: 'PITFALLS.md', target: p, needle: block[5] };
    },
    expect: '「整段副本」必须红 —— ★ 副本被插在**文档中间**时也要抓得到（标题不会被复制）',
    selfCheck: (info) => {
      const ls = fs.readFileSync(info.target, 'utf8').split(/\r?\n/);
      const c = ls.filter((l) => l.trim() === info.needle.trim()).length;
      return { ok: c === 2, note: '取样行出现 ' + c + ' 次（期望 2）· 文件 ' + ls.length + ' 行' };
    },
  },
  {
    name: '④ 删掉 ROADMAP.md 的一级标题（0 个 H1）',
    kind: 'file',
    apply: () => {
      const p = path.join(ROOT, 'ROADMAP.md');
      const s = fs.readFileSync(p, 'utf8');
      fs.writeFileSync(p, Buffer.from(s.replace(/^# GameHub 功能全景与路线图\r?\n/, ''), 'utf8'));
      return { doc: 'ROADMAP.md', target: p };
    },
    expect: '「一级标题恰好 1 个」必须红（0 个也是不合格）',
    selfCheck: (info) => {
      /* ★ 自检必须**围栏感知**：本脚本首版这里用了朴素 `/^#\s+\S/`，
       *   把 ```bash 块里的 `# 重建派生页` 也数成标题 ⇒ 报到「6 个」⇒ 自检自己误判。
       *   与闸实现同一口径才不会自欺。 */
      const n = countH1(fs.readFileSync(info.target, 'utf8'));
      return { ok: n === 0, note: '围栏外一级标题 ' + n + ' 个（期望 0）' };
    },
  },
  {
    name: '⑤ 在 README.md 的**同一父节下**再加一个同名子节（标题路径重复）',
    kind: 'file',
    apply: () => {
      const p = path.join(ROOT, 'README.md');
      const lines = fs.readFileSync(p, 'utf8').split(/\r?\n/);
      /* 找一个 `## ` 父节，在它管辖范围内插一个与它下辖 `### ` 同名的子节 */
      let pi = -1, sub = '';
      for (let i = 0; i < lines.length; i++) {
        if (/^##\s+\S/.test(lines[i])) {
          for (let j = i + 1; j < Math.min(i + 80, lines.length); j++) {
            if (/^###\s+\S/.test(lines[j])) { pi = i; sub = lines[j]; break; }
            if (/^##\s+\S/.test(lines[j])) break;
          }
        }
        if (pi >= 0) break;
      }
      if (pi < 0 || !sub) return { doc: null, reason: 'README.md 里找不到可用的「## 父节 + ### 子节」组合' };
      /* ★★ 这里曾漏写展开运算符 `...`（写成 lines.slice(pi+1)），
       *    结果「剩余全部行」被当成**一个数组元素** join 进去 ⇒ README 被整体搞乱，
       *    闸确实变红了，但红的是一级标题（0 个）、**不是我预期打到的那条判据**。
       *    ⇒ 「变异把它弄坏了」不等于「变异按设计弄坏了它」。已补自检（见 selfCheck）。 */
      const out = [...lines.slice(0, pi + 1), '', sub, '', ...lines.slice(pi + 1)].join('\r\n');
      fs.writeFileSync(p, Buffer.from(out, 'utf8'));
      return { doc: 'README.md', inserted: sub, target: p, needle: sub };
    },
    expect: '「标题路径无重复」必须红（★ 同名子节挂不同父节是合法的，同父才算重复）',
    /* 自检：插进去的那一行必须**恰好出现 2 次**，且行数只 +3 */
    selfCheck: (info) => {
      const ls = fs.readFileSync(info.target, 'utf8').split(/\r?\n/);
      const c = ls.filter((l) => l.trim() === info.needle.trim()).length;
      return { ok: c === 2, note: '插入行出现 ' + c + ' 次（期望 2）· 文件 ' + ls.length + ' 行' };
    },
  },

  /* ---- 第三组：把判据本身打坏，证明「闸真的靠这条判据在工作」---- */
  {
    name: '⑥ 把闸的偏移门槛改成 1.01（永不触发）—— 此时真实事故回放必须「不再被抓住」',
    kind: 'gate',
    apply: () => {
      const s = fs.readFileSync(GATE, 'utf8');
      const from = 'const MAX_COPY_RATIO = 0.6;';
      if (s.split(from).length - 1 !== 1) return { doc: null, reason: '门槛常量没找到唯一位置' };
      fs.writeFileSync(GATE, Buffer.from(s.replace(from, 'const MAX_COPY_RATIO = 1.01;'), 'utf8'));
      const wf = path.join(ROOT, 'WORKFLOW.md');
      fs.writeFileSync(wf, fs.readFileSync(path.join(ROOT, '_archived', 'WORKFLOW-v10.38-duplicated.md')));
      return { doc: 'WORKFLOW.md + test-doc-structure.js', wf, gate: GATE };
    },
    expect: '★ 期望仍是「红」但**由标题路径判据兜住** ⇒ 证明两条判据有分工；若全绿 ⇒ 说明标题判据是空的',
    selfCheck: (info) => {
      const g = fs.readFileSync(info.gate, 'utf8').includes('MAX_COPY_RATIO = 1.01;');
      const n = fs.readFileSync(info.wf, 'utf8').split(/\r?\n/).length;
      return { ok: g && n === 752, note: '门槛已改成 1.01=' + g + ' · WORKFLOW ' + n + ' 行' };
    },
  },
];

/* ================= 执行 ================= */
const results = [];
const KEEP = {
  workflow: path.join(ROOT, 'WORKFLOW.md'),
  road: path.join(ROOT, 'ROADMAP.md'),
  pit: path.join(ROOT, 'PITFALLS.md'),
  readme: path.join(ROOT, 'README.md'),
  gate: GATE,
};
const base = {};
for (const [k, p] of Object.entries(KEEP)) base[k] = snap(p);
const baseMd5 = Object.fromEntries(Object.entries(base).map(([k, s]) => [k, md5(s.buf)]));

function restoreAll() { for (const s of Object.values(base)) restore(s); }

function verifyRestored() {
  const bad = [];
  for (const [k, s] of Object.entries(base)) {
    const now = md5(fs.readFileSync(s.path));
    if (now !== baseMd5[k]) bad.push(k);
  }
  return bad;
}

console.log('=== v10.39 反证：文档结构闸 ===');
console.log('基线自检中（未变异必须先绿）…');
restoreAll();
const b0 = runGate();
console.log('  未变异基线：exit=' + b0.code + ' · ' + b0.pass + '/' + b0.total + ' · FAIL=' + b0.fails);
const BASE_GREEN = b0.code === 0 && b0.fails === 0;
console.log('  ⇒ ' + (BASE_GREEN ? '✅ 基线为绿，变异判定有效' : '⚠️ 基线不为绿 ⇒ 所有变异组作废'));
console.log('');

for (const v of VARIANTS) {
  restoreAll();
  const info = v.apply();
  if (info && info.doc === null) {
    results.push({ name: v.name, verdict: '作废', note: info.reason });
    console.log('⊘ ' + v.name + '\n   作废：' + info.reason + '\n');
    restoreAll();
    continue;
  }
  /* ★ 变异自检（v10.39 实测教训）：变异必须**按设计**生效，否则红/绿都说明不了问题。
   *   本脚本首版 ⑤ 漏写展开运算符 `...`，把 README 整体搞乱 ⇒ 闸确实红了，
   *   但红的是「一级标题 0 个」而不是我预期要打的那条判据 ⇒ **变异把它弄坏 ≠ 按设计弄坏它**。 */
  const check = v.selfCheck ? v.selfCheck(info) : { ok: true, note: '（该变异无自检）' };
  if (!check.ok) {
    results.push({ name: v.name, verdict: '作废', note: '变异未按设计生效：' + check.note });
    console.log('⊘ ' + v.name + '\n   ★ 作废：变异未按设计生效 —— ' + check.note + '\n');
    restoreAll();
    continue;
  }
  const r = runGate();
  let verdict, note = '';
  if (!BASE_GREEN) { verdict = '作废'; note = '基线不为绿'; }
  else if (r.fails > 0) { verdict = '已抓住'; note = 'FAIL×' + r.fails + '（' + r.pass + '/' + r.total + '）'; }
  else if (r.code !== 0) { verdict = '崩了(不算)'; note = 'exit=' + r.code + ' 但 0 条 FAIL'; }
  else { verdict = '★★假断言'; note = 'exit=0 且 0 条 FAIL'; }
  results.push({ name: v.name, verdict, note, expect: v.expect });
  console.log((verdict === '已抓住' ? '✅ ' : verdict.startsWith('★') ? '★★ ' : '⚠️ ') + v.name);
  console.log('   施加于：' + info.doc +
    (info.beforeBytes ? '（' + info.beforeBytes + 'B → ' + info.afterBytes + 'B）' : '') +
    (info.inserted ? '（插入：' + info.inserted.trim() + '）' : ''));
  console.log('   变异自检：' + check.note);
  console.log('   期望：' + v.expect);
  console.log('   实测：' + verdict + ' · ' + note);
  const fails = (r.out.match(/^\s*FAIL\s+.*$/gm) || []).slice(0, 4).map((s) => s.trim().slice(0, 150));
  if (fails.length) console.log('   抓住的断言：\n     ' + fails.join('\n     '));
  console.log('');
  restoreAll();
}

/* ---------- 还原校验 ---------- */
const badRestore = verifyRestored();
console.log('=== 还原校验 ===');
for (const [k, s] of Object.entries(base)) {
  const now = md5(fs.readFileSync(s.path));
  console.log('  ' + k.padEnd(9) + (now === baseMd5[k] ? '✅ md5 一致 ' + now.slice(0, 12) : '❌ 不一致！'));
}
console.log(badRestore.length ? '★★ 还原失败：' + badRestore.join(', ') : '✅ 全部文件已按字节还原');

/* ---------- 汇总 ---------- */
console.log('');
console.log('====');
const caught = results.filter((r) => r.verdict === '已抓住').length;
const fake = results.filter((r) => r.verdict === '★★假断言').length;
const crashed = results.filter((r) => r.verdict === '崩了(不算)').length;
const voided = results.filter((r) => r.verdict === '作废').length;
console.log('反证 ' + caught + '/' + (results.length - voided) + ' 已抓住' +
  '（假断言 ' + fake + ' · 崩了 ' + crashed + ' · 作废 ' + voided + '）');
for (const r of results) console.log('  [' + r.verdict + '] ' + r.name);
if (fake || crashed) {
  console.log('');
  console.log('★ 注意：第五组（⑥）的期望是「仍红，但由标题路径判据兜住」——');
  console.log('  若它显示「★★假断言」，说明偏移判据是唯一在场的判据，标题判据没起作用（需补强）。');
}
process.exit(fake || crashed || badRestore.length ? 1 : 0);
