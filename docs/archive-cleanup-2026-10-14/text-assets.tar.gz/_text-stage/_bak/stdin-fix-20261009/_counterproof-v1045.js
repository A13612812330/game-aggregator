/* 反证（v10.45）：把本轮**新加的护栏**逐条打坏，对应断言必须变红。
 *
 * 为什么必须做：断言全绿也可能是**假绿** —— 护栏写歪了、或者根本没走到被守护的分支时，
 * 它照样打印 ✅。判据只有一个：把被守护的行为**故意打坏**，对应断言必须变红。
 *
 * ★★ 关于「崩了 ≠ 抓住了」（本项目踩过）：
 *   变异如果直接把文件搞成语法错误，套件会因为「加载失败」而**集体翻红**，
 *   看起来像抓到了，实际什么也没证明。本脚本的对策是**逐条指定必须出现的失败文案**：
 *   语法崩掉时那条**具体**的断言文案不会出现 ⇒ 本脚本自己判 UNVERIFIED 并退出非零。
 *   （对纯模块文件另有 `node --check` 前置自检。）
 *
 * ★ 还原用 `writeFileSync(原名, 原文)`，**不用 unlink / 改名挪开** ——
 *   沙箱里有「累计删除」护栏，`unlinkSync` 会被拦下，反而把原文件留在被破坏状态。
 *
 * 运行：node tools/_counterproof-v1045.js
 * 依赖：8123 服务在跑（第 7 例是 jsdom + 真页面）
 */
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const ROOT = path.join(__dirname, '..');
const abs = (p) => path.join(ROOT, p);
const read = (p) => fs.readFileSync(abs(p), 'utf8');
const write = (p, s) => fs.writeFileSync(abs(p), s);

/* 各套件的失败行格式实测是**三套**（×/❌/FAIL），这里统一识别。
 * ⚠️ 不要写成只认某一种：那会让另外两套的失败**读成成功**（反证自己变成假绿）。 */
const FAIL_LINE = /(^\s*❌)|(^\s*×)|(FAIL)/;

const CASES = [
  {
    nm: '① 底部入口重新带 hidden（旧实现把入口与 dlSecs 绑死 = 用户看不到 Mod/存档的根因）',
    file: 'public/index.html',
    good: '<div class="dl-strip" id="dlStrip">',
    bad: '<div class="dl-strip" id="dlStrip" hidden>',
    suite: 'test-v1028-detail.js',
    expect: ['底部动作条不许自带 hidden'],
  },
  {
    nm: '② setDlCounts 复活（它的唯一职责就是「按 dlSecs 定按钮显隐 + 条数」）',
    file: 'public/index.html',
    good: 'const DL_UNI = [',
    bad: 'function setDlCounts() { return 1; }\nconst DL_UNI = [',
    suite: 'test-download.js',
    expect: ['setDlCounts'],
  },
  {
    nm: '③ 四模块顺序打乱（把「修改器」提到「Mod」前面）',
    file: 'public/index.html',
    good: "  { k: 'mod', nm: 'Mod', ic: '🧩' },\n  { k: 'modifier', nm: '修改器', ic: '🛠' },",
    bad: "  { k: 'modifier', nm: '修改器', ic: '🛠' },\n  { k: 'mod', nm: 'Mod', ic: '🧩' },",
    suite: 'test-download.js',
    expect: ['顺序'],
  },
  {
    nm: '④ 广告站过滤删掉（回到「只滤站内链」，52leiqu 会重新混进「其他」）',
    file: 'shared.js',
    good: 'if (INTERNAL_HOST_RE.test(host) || JUNK_HOST_RE.test(host)) continue;',
    bad: 'if (INTERNAL_HOST_RE.test(host)) continue;',
    check: 'shared.js',
    suite: 'test-download.js',
    expect: ['抽取阶段就丢掉广告链'],
  },
  {
    nm: '⑤ 存档按钮不再把 tab:\'save\' 递出去（落点退回默认的「本体」）',
    file: 'tools/resource-sections.js',
    good: "tab: 'save',",
    bad: "tab: 'body',",
    check: 'tools/resource-sections.js',
    suite: 'test-emulator-structure.js',
    expect: ["tab:'save'"],
  },
  {
    nm: '⑥ 空态徽标退回 over-claim（不管什么原因都写「需登录源站」）',
    file: 'public/index.html',
    good: "${needAuth ? '需登录源站' : '无可用地址'}",
    bad: "需登录源站",
    suite: 'test-related-dl.js',
    expect: ['徽标跟着真实原因走'],
  },
  {
    nm: '⑦ 存档卡面重新铺路径（用户明确要求「不在卡片中显示位置」）',
    file: 'public/resources.html',
    good: "+ '<div class=\"tgs\">' + cloudTags + '</div>'",
    bad: "+ '<div class=\"tgs\">' + cloudTags + '</div>' + '<div class=\"paths\"><span class=\"p\"><span>x</span></span></div>'",
    suite: 'test-resource-page.js',
    expect: ['存档卡面已不再铺路径'],
  },
  {
    nm: '⑧ 广告站串漏进渲染层（断言「任何渲染层都不许出现广告站」必须抓住）',
    file: 'public/index.html',
    good: '<div class="dlmod" id="dlModTabs" hidden></div>',
    bad: '<div class="dlmod" id="dlModTabs" hidden data-ad="https://52leiqu.com/problemTutorial"></div>',
    suite: 'test-download.js',
    expect: ['广告站串不许出现在任何'],
  },
];

/* ---------- 前置自检：锚点必须唯一，否则反证无效（改错地方 = 什么都没证） ---------- */
console.log('=== 自检：反证锚点 ===');
let anchorBad = 0;
for (const c of CASES) {
  const src = read(c.file);
  const n = src.split(c.good).length - 1;
  if (n !== 1) { console.log(`  ❌ ${c.file} 锚点出现 ${n} 次（要求恰好 1）：${c.good.slice(0, 50)}`); anchorBad++; }
  else console.log(`  ✅ ${c.file} 锚点唯一`);
  if (c.check) {
    try { execFileSync(process.execPath, ['--check', abs(c.check)], { stdio: 'ignore' }); }
    catch (e) { console.log(`  ❌ 前置语法检查未过（原文件就是坏的）：${c.check}`); anchorBad++; }
  }
}
if (anchorBad) { console.log('\n❌ 前置自检失败 —— 反证无效，先修锚点'); process.exit(2); }

/* ★★ 还原自检的正确做法：**开跑前的字节快照**，收尾逐字节比。
 *
 * 踩过的坑（本脚本第一版）：原先用「`bad` 串是否还出现在文件里」当残留判据，
 *   结果第 ⑥ 例误报 —— 它的 `bad` 是裸的 `需登录源站`，而这个词**本来就是正确内容的一部分**
 *   （修好后的三元表达式 `? '需登录源站' : '无可用地址'` 里也有它、注释里也有它）。
 *   ⇒ 那条件是**恒真**的，会把「已正确还原」报成「仍残留变异」。
 *   教训与项目铁律一致：判「有没有被改坏」要比**字节**，不要比关键词。
 *   （反向的坑也真实存在：`bad` 若是某个已不存在的写法，残留时反而查不出来。） */
const SNAP = new Map(CASES.map((c) => [c.file, read(c.file)]));

/* ---------- 自检：还原判据本身有效（不许恒绿） ----------
 * ★ 为什么连「比对字节」这么简单的东西也要自检：本项目要求的判据标准是
 *   **判据自己先被反证过**。这里故意改一个字节，判据必须判出「不一致」；
 *   判不出说明写歪了，那后面 7 条「已还原 ✅」全是空的。 */
{
  const probe = CASES[0].file;
  const before = SNAP.get(probe);
  write(probe, before + '\n<!-- probe -->');
  const detected = read(probe) !== before;
  write(probe, before);
  if (!detected) { console.log('❌ 还原判据自检失败（恒绿）—— 反证无效'); process.exit(2); }
  console.log('✅ 还原判据自检：故意改一个字节能被判出「不一致」，且已还原\n');
}

/* ---------- 逐条打坏 → 复跑 → 校验失败文案 → 还原 ---------- */
let okN = 0, badN = 0;
const unverified = [];

for (const c of CASES) {
  const orig = read(c.file);
  console.log(`\n▶ ${c.nm}`);
  console.log(`   打坏 ${c.file} → 复跑 ${c.suite}`);
  let out = '';
  try {
    write(c.file, orig.replace(c.good, c.bad));
    /* 变异必须**能加载**，否则翻红是「崩了」不是「抓住了」 */
    if (c.check) {
      try { execFileSync(process.execPath, ['--check', abs(c.check)], { stdio: 'ignore' }); }
      catch (e) { out = '__SYNTAX_BROKEN__'; }
    }
    if (out !== '__SYNTAX_BROKEN__') {
      try {
        out = execFileSync(process.execPath, [abs('tools/' + c.suite)], { cwd: ROOT, encoding: 'utf8', timeout: 300000 });
      } catch (e) { out = (e.stdout || '') + (e.stderr || ''); }
    }
  } finally {
    write(c.file, orig);
  }
  if (out === '__SYNTAX_BROKEN__') {
    console.log('   ⚠️ 变异后语法就坏了 ⇒ UNVERIFIED（这条反证不算数）');
    unverified.push(c.nm + '（变异后语法坏）');
    badN++;
    continue;
  }
  const failLines = out.split(/\r?\n/).filter((l) => FAIL_LINE.test(l));
  const missed = c.expect.filter((x) => !failLines.some((l) => l.indexOf(x) >= 0));
  if (!failLines.length) {
    console.log('   ❌ 打坏后**一条都没红** ⇒ 这条护栏是假绿');
    badN++;
  } else if (missed.length) {
    console.log(`   ❌ 红了 ${failLines.length} 条，但**指定的那条没红**（${missed.join('、')}）`);
    console.log('      实际红的是：' + failLines.slice(0, 4).map((l) => l.trim()).join(' ｜ '));
    badN++;
  } else {
    console.log(`   ✅ 变红 ${failLines.length} 条，指定断言命中：${c.expect.join('、')}`);
    okN++;
  }
}

/* ---------- 还原自检：与开跑前的字节快照逐字节比（不用关键词启发式，见上面 SNAP 的说明） ---------- */
console.log('\n=== 还原自检（与开跑前快照逐字节比）===');
let restoreBad = 0;
for (const [f, before] of SNAP) {
  const now = read(f);
  if (now === before) console.log(`  ✅ ${f} 与快照逐字节一致`);
  else {
    console.log('  ❌ ' + f + ' 与快照不一致 —— 快照 ' + Buffer.byteLength(before) + 'B / 现在 '
      + Buffer.byteLength(now) + 'B，**文件处于被破坏状态，先手工还原再继续**');
    restoreBad++;
  }
}

console.log('\n' + '='.repeat(52));
console.log(`反证：${okN} / ${CASES.length} 成立，${badN} 不成立，还原异常 ${restoreBad} 处`);
if (unverified.length) console.log('UNVERIFIED：' + unverified.join('；'));
console.log('='.repeat(52));
/* ★ 还原异常也要计入退出码：文件被留在被破坏状态比「反证不充分」更严重 */
process.exit(badN || restoreBad ? 1 : 0);
