#!/usr/bin/env node
/* tools/_counterproof-v1033.js —— v10.33 静态层的**反证**（「打坏必须变红」）
 *
 * 做法：把项目里被守护的文件复制到 `_cf133/`（test-v1033.js 的 ROOT 由 __dirname
 * 推导 ⇒ 自动指向副本，隔离干净），单点变异后跑套件。
 *
 * 判据 = **退出码非零 且 指定断言名出现在 FAIL 行**。
 *   · 只看「退出码非零」不够：崩溃 / 语法错也会非零，那不是「断言抓住了」；
 *   · 只看「断言名出现」也不够：它可能本来就红。
 *   ⇒ 外加两条前置：基准（无变异）必须全绿；变异必须**真的改到了内容**（没改到就单独报错，
 *     否则会出现「变异没生效 + 套件本来就绿 = 假合规」）。
 *
 * ⚠️ 本工具会覆盖 `_cf133/` 下的副本，**不动**项目正本。
 */
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const ROOT = path.join(__dirname, '..');
const CF = path.join(ROOT, '_cf133');
/* 副本必须包含 test 脚本自己会去读的东西：
 *   ⑤g 会真跑一次 build-steam-req.js --dry ⇒ 需要 games.json；
 *   ⑤g 还会 statSync 缓存文件 ⇒ 需要 steam-req.json 存在。 */
const FILES = [
  'tools/test-v1033.js',
  'tools/build-steam-req.js',
  'data/pcreq.js',
  'data/steam-req.json',
  'data/games.json',
  'server.js',
  'public/index.html',
  'public/emulator.html',
  'public/unpack.html',
];

const MUT = [
  {
    id: '① 原子写退化成「直接覆盖正本」（删掉 rename）',
    file: 'data/pcreq.js',
    expect: '①b',
    f: (s) => s.replace('fs.renameSync(tmp, FILE);', '/* rename 被删掉了 */'),
  },
  {
    id: '① 主路径额外插一条「直接覆盖正本」的写',
    file: 'data/pcreq.js',
    expect: '①c',
    f: (s) => s.replace('const tmp = FILE',
      "fs.writeFileSync(FILE, JSON.stringify({ builtAt: 1, src: 'x', count: 0, map: db.map }));\n      const tmp = FILE"),
  },
  {
    id: '② mergeDisk 变成覆盖式（会抹掉内存里已有的键）',
    file: 'data/pcreq.js',
    expect: '②i',
    f: (s) => s.replace('if (!d.map[k]) { d.map[k] = j.map[k]; added += 1; }',
      '{ d.map[k] = j.map[k]; added += 1; }'),
  },
  {
    id: '③ 退回「只走封面解析」（漏掉顶层 appid 字段）',
    file: 'tools/build-steam-req.js',
    expect: '③c',
    f: (s) => s.replace('appid: fromCover || fromField,', 'appid: fromCover,'),
  },
  {
    id: '④ --gap 默认改回 1100（双重限流，全量变 11 小时）',
    file: 'tools/build-steam-req.js',
    expect: '④a',
    f: (s) => s.replace("val('gap', '0')", "val('gap', '1100')"),
  },
  {
    id: '④ 退避退回「从 0 起翻倍」的死写法（退避完全失效）',
    file: 'tools/build-steam-req.js',
    expect: '④e',
    f: (s) => s.replace('Math.min(Math.max(gap, THROTTLE_GAP) * 2, 12000)', 'Math.min(gap * 2, 12000)'),
  },
  {
    id: '④ 节流常量与 pcreq.MIN_GAP 漂移（改一处忘另一处）',
    file: 'tools/build-steam-req.js',
    expect: '④i',
    f: (s) => s.replace('const THROTTLE_GAP = 1100;', 'const THROTTLE_GAP = 999;'),
  },
  {
    id: '⑤ 把 mergeDisk 挪到 flushNow 之后（顺序反了会覆盖服务端新数据）',
    file: 'tools/build-steam-req.js',
    expect: '⑤b',
    f: (s) => s
      .replace('const m = pcreq.mergeDisk();', 'const m = 0;')
      .replace('if (pcreq.flushNow()) wrote += 1;', 'if (pcreq.flushNow()) wrote += 1;\n    pcreq.mergeDisk();'),
  },
  {
    id: '⑥ resolve 不再收到 appid（预热的缓存前端读不到）',
    file: 'server.js',
    expect: '⑥c',
    f: (s) => s.replace('await pcreq.resolve({ title: t, cover, appid })', 'await pcreq.resolve({ title: t, cover })'),
  },
  {
    id: '⑥ 去掉库里顶层 appid 字段的兜底',
    file: 'server.js',
    expect: '⑥a',
    f: (s) => s.replace("String((selfRec && selfRec.appid) || '').trim()", "''"),
  },
  {
    id: '⑦ 派生页 emulator.html 的调用掉了 &id=',
    file: 'public/emulator.html',
    expect: '⑦ emulator.html',
    /* 用 split/join 做**全局**替换：该页有两个调用点（两条分支），
       只替换第一处的话，另一处仍带 id ⇒ 断言不该绿，但也不足以证明「判据覆盖了每个调用点」。
       初版正是被这一条抓出「断言只判存在一处」的缺陷（现已改成计数判据）。 */
    f: (s) => s.split("(id ? '&id=' + encodeURIComponent(id) : '')").join("''"),
  },
  {
    id: '⑦ 派生页**只掉一处** id（另一处还在）',
    file: 'public/emulator.html',
    expect: '⑦ emulator.html',
    /* ★ 这一条专门盯「部分退化」：`String.replace` 只替第一处。
       判据若写「存在一处即通过」，这里就会假绿 —— 实测第二版计数判据
       （withId >= calls）也栽在这条上（页面里别的接口也用同样写法拼 id）。
       ⇒ 现在判据按**调用点**逐个检查（qs 定义与 pcreq 调用作为整体匹配）。 */
    f: (s) => s.replace("(id ? '&id=' + encodeURIComponent(id) : '')", "''"),
  },
  {
    id: '⑧ 服务端落盘不再 merge（会把预热刚写的整批抹掉）',
    file: 'data/pcreq.js',
    /* 这条是本轮**最危险**的退化：删掉 mergeDisk 后一切照常跑、不报错，
       只是服务端每次落盘都用自己内存里那 700 多条覆盖磁盘，
       把预热 5 小时的成果悄悄抹掉。⑧a 是文本断言，⑧f 是行为断言（都会红）。 */
    expect: '⑧a',
    f: (s) => s.replace('      mergeDisk();\n      db.count', '      db.count'),
  },
  {
    id: '⑧ peek 不再看磁盘（预热数据不重启就看不见）',
    file: 'data/pcreq.js',
    /* 文本断言 ⑧b 与行为断言 ⑧e 都会红：删掉这一行后 peek 未命中就直接 return。 */
    expect: '⑧e',
    f: (s) => s.replace(
      '    if (refreshFromDisk() > 0) e = ensure().map[appid];\n    if (!e) return null;',
      '    return null;'),
  },
  {
    id: '⑧ refreshFromDisk 变成空操作（合并失效）',
    file: 'data/pcreq.js',
    expect: '⑧e',
    /* 补的是一个**假绿**：初版 ⑧e 写的是「先 seed 含 999 再 require 再 peek、断言读到」，
       而 ensure() 惰性 ⇒ 那样测的是「ensure 首次读盘」，删掉 refreshFromDisk 照样绿。
       现在改「先 peek('111') 触发 ensure、再写盘」，本变异会让 ⑧e 变红。
       （另一处：初版还断言过「peek('999') === null」—— 那是把正确行为当成期望值写反了。） */
    f: (s) => s.replace('  lastMerge = now;\n  return mergeDisk();', '  lastMerge = now;\n  return 0;'),
  },
];

function buildBase() {
  fs.rmSync(CF, { recursive: true, force: true });
  for (const f of FILES) {
    const dst = path.join(CF, f);
    fs.mkdirSync(path.dirname(dst), { recursive: true });
    fs.copyFileSync(path.join(ROOT, f), dst);
  }
}

function runSuite() {
  try {
    const out = execFileSync(process.execPath, [path.join(CF, 'tools', 'test-v1033.js')],
      { encoding: 'utf8', cwd: CF, timeout: 300000 });
    return { code: 0, out };
  } catch (e) {
    return { code: e.status || 1, out: String(e.stdout || '') + String(e.stderr || '') };
  }
}

console.log('\n=== 反证 v10.33：基准（无变异）必须全绿 ===');
buildBase();
const base = runSuite();
const baseLine = (base.out.match(/(\d+) \/ (\d+)/) || [])[0] || '(取不到)';
if (base.code !== 0) {
  console.log('  × 基准就是红的，反证无意义。输出尾部：\n' + base.out.slice(-1200));
  process.exit(1);
}
console.log('  PASS  基准全绿  — ' + baseLine + '\n');

console.log('=== 逐条变异（期望：退出码非零 **且** 指定断言出现在 FAIL 行） ===\n');
let good = 0, bad = 0;
for (const m of MUT) {
  const src = fs.readFileSync(path.join(ROOT, m.file), 'utf8');
  const mut = m.f(src);
  const dst = path.join(CF, m.file);
  if (mut === src) {
    bad += 1;
    console.log('  × [' + m.id + '] 变异**未生效**（替换串没匹配上 ' + m.file + '）—— 这条不算合规\n');
    continue;
  }
  fs.writeFileSync(dst, mut, 'utf8');
  const r = runSuite();
  fs.copyFileSync(path.join(ROOT, m.file), dst);   // 立刻还原副本

  const hitLine = r.out.split(/\r?\n/).find((l) => l.includes('× FAIL') && l.includes(m.expect)) || '';
  const passed = r.code !== 0 && !!hitLine;
  if (passed) { good += 1; console.log('  PASS  ' + m.id + '\n        └ 变红于：' + hitLine.trim()); }
  else {
    bad += 1;
    console.log('  × FAIL  ' + m.id);
    console.log('        └ 期望断言「' + m.expect + '」出现在 FAIL 行；实际退出码=' + r.code +
      (hitLine ? '' : '（该断言未变红）'));
    if (!hitLine) {
      const anyFail = r.out.split(/\r?\n/).filter((l) => l.includes('× FAIL')).slice(0, 3);
      console.log('        └ 实际红的是：' + (anyFail.join(' | ') || '(没有任何 FAIL 行)'));
    }
  }
  console.log('');
}

console.log('=== 反证结果 ===');
console.log('  合规 ' + good + ' / ' + MUT.length + (bad ? '   ★ 不合规 ' + bad + ' 条，必须修断言或修实现' : '') + '\n');
process.exit(bad ? 1 : 0);
