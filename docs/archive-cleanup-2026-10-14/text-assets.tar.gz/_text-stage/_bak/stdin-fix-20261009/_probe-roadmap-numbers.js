/* _probe-roadmap-numbers.js —— 临时探针（只读，不入库）
 * 目的：补测 ROADMAP.md 改写所需的剩余数字（字节口径 / 封面-匹配镜像 / 线上版本）。
 * 用法：node tools/_probe-roadmap-numbers.js
 */
const fs = require('fs');
const path = require('path');
const http = require('http');
const { spawnSync } = require('child_process');

const ROOT = path.join(__dirname, '..');
const P = (f) => path.join(ROOT, f);
const get = (p) => new Promise((res) => {
  const r = http.get({ host: '127.0.0.1', port: 8123, path: p, timeout: 15000 }, (s) => {
    let d = ''; s.on('data', (c) => (d += c)); s.on('end', () => { try { res(JSON.parse(d)); } catch { res(d); } });
  });
  r.on('error', () => res(null)); r.on('timeout', () => { r.destroy(); res(null); });
});

(async () => {
  console.log('=== 1. 三页字节口径（Buffer.byteLength，不是字符数）===');
  let tot = 0;
  for (const f of ['public/index.html', 'public/emulator.html', 'public/unpack.html']) {
    const b = fs.readFileSync(P(f));
    const s = b.toString('utf8');
    const js = (s.match(/<script[^>]*>([\s\S]*?)<\/script>/g) || []).join('');
    const css = (s.match(/<style[^>]*>([\s\S]*?)<\/style>/g) || []).join('');
    const kb = (n) => (Buffer.byteLength(n, 'utf8') / 1024).toFixed(0);
    tot += Buffer.byteLength(s, 'utf8');
    console.log(f.padEnd(20) + (b.length / 1024).toFixed(0) + ' KB 字节（JS ' + kb(js) + ' / CSS ' + kb(css) + '）  ' +
      b.length + ' bytes / ' + s.length + ' chars');
  }
  console.log('三页合计 ' + (tot / 1024).toFixed(0) + ' KB / ' + (tot / 1024 / 1024).toFixed(2) + ' MB');

  console.log('');
  console.log('=== 2. 「封面缺失」是不是匹配率的镜像（同源的 libId / libCover）===');
  const mh = await get('/api/mobilehub/stats');
  if (mh && mh.items) {
    const t = mh.items;
    const hasId = t.filter((x) => x.libId != null).length;
    const hasCov = t.filter((x) => x.libCover).length;
    console.log('手游中心 items n=' + t.length + '  libId ' + hasId + ' (' + (hasId / t.length * 100).toFixed(1) + '%)  libCover ' + hasCov + ' (' + (hasCov / t.length * 100).toFixed(1) + '%)');
  } else { console.log('手游中心：接口未直接给 items ⇒ 走 data 层'); }

  const tn = await get('/api/trainers/stats');
  console.log('修改器 matchedRate ' + tn.matchedRate + '%（matched ' + tn.matched + '）');
  const sv = await get('/api/saves/stats');
  console.log('云存档 total ' + sv.total + ' / 在端游库 ' + sv.inPcLib + ' (' + (sv.inPcLib / sv.total * 100).toFixed(1) + '%)');

  console.log('');
  console.log('=== 3. 详情抽屉分区数（源码实测）===');
  const idx = fs.readFileSync(P('public/index.html'), 'utf8');
  const secs = [...idx.matchAll(/data-sec="([^"]+)"/g)].map((m) => m[1]);
  const uniq = [...new Set(secs)];
  console.log('data-sec 出现 ' + secs.length + ' 次 / 去重 ' + uniq.length + ' 个：' + uniq.join(' · '));

  console.log('');
  console.log('=== 4. 线上 LIVE 版本（实测 md5 + 口径指纹）===');
  const { execFileSync } = require('child_process');
  let md5 = '';
  try {
    const buf = execFileSync(process.execPath, ['-e', `
      const https=require('https');const c=require('crypto');
      https.get('https://gamehub-agg-v4.app.workbuddy.host/',r=>{const a=[];r.on('data',d=>a.push(d));r.on('end',()=>{
        const s=Buffer.concat(a).toString('utf8');console.log(c.createHash('md5').update(s).digest('hex').slice(0,10)+' '+s.length);});})
      .on('error',e=>console.log('ERR '+e.message));`], { encoding: 'utf8', timeout: 40000 });
    md5 = String(buf).trim();
  } catch (e) { md5 = 'ERR ' + e.message.slice(0, 60); }
  const local = fs.readFileSync(P('public/index.html'), 'utf8');
  const lmd5 = require('crypto').createHash('md5').update(local).digest('hex').slice(0, 10);
  console.log('线上 ' + md5 + '  ／  本地 ' + lmd5 + ' ' + local.length + (md5.startsWith(lmd5) ? '   ⇒ ✅ 同版' : '   ⇒ ❌ 不是同一版'));

  console.log('');
  console.log('=== 5. 项目目录体积 ===');
  const du = spawnSync(process.platform === 'win32' ? 'powershell' : 'du',
    process.platform === 'win32'
      ? ['-NoProfile', '-Command', '(Get-ChildItem -Recurse -File -Force | Measure-Object -Property Length -Sum).Sum']
      : ['-sh', '.'],
    { cwd: ROOT, encoding: 'utf8' });
  const bytes = parseInt(String(du.stdout).trim(), 10);
  console.log('目录合计 ' + (isNaN(bytes) ? '?' : (bytes / 1024 / 1024).toFixed(0) + ' MB'));
})();
