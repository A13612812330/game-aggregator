#!/usr/bin/env node
/* tools/_counterproof-audit.js —— 「审计门禁自检」新护栏的**反证**（一次性工具，跑完即删）
 *
 * 判据：**故意把被守护的行为打坏，断言必须变红**。红不了 = 这条断言没在守东西。
 *
 * 为什么要给 audit-apps.js 做反证：
 *   它是**收尾判定「线上到底是哪一版」的唯一依据**。它自己出错时结论会**正好反着来**
 *   （把最新的 LIVE 判成「旧版」），而本项目已因「判定报反」让用户看过旧界面。
 *   2026-09-20 实测就又踩了一次：门禁写死 `total === 3181`，而当天数据已涨到 3,195
 *   ⇒ LIVE 只差一个 v10.24，却被报成「停在 v10.21 之前」。
 *
 * 一、门禁不能写死会增长的数字（tools/test-audit-apps.js D-2）
 *   1. audit-apps.js  `total >= 3181` 退回 `total === 3181`
 *   2. audit-apps.js  砍掉本地自检分支（远端缺就一律算真缺口）
 *   3. audit-apps.js  砍掉 STALE 记录（本地也缺的门禁悄悄消失，不再提示修探针）
 *
 * 二、防线自己的「切片防假绿」护栏
 *   4. test-audit-apps.js  GATES 代码块切不到（地标改掉）→ 必须报「切不到」而不是静默空跑
 *
 * ★ 铁律：每处改动都**先备份原始字节、跑完立刻还原并校验 md5**，
 *   任何一步还原失败就整体中止（绝不留下被破坏的源码）。
 *
 * 用法：node tools/_counterproof-audit.js
 * 退出码：0 = 四处全部「打坏即变红」；1 = 有护栏打了还是绿（假断言）。
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execFileSync } = require('child_process');

const ROOT = path.join(__dirname, '..');
const md5 = (b) => crypto.createHash('md5').update(b).digest('hex');
const SUITE = 'tools/test-audit-apps.js';

const CASES = [
  {
    title: '门禁写死会增长的数字（total === 3181）',
    file: 'tools/audit-apps.js',
    find: "test: (r) => r.body && r.body.total >= 3181 },",
    repl: "test: (r) => r.body && r.body.total === 3181 },   /* 反证：退回写死等号 */",
    mustFail: '★ GATES 里的数据量门禁不许写等号',
    why: '这正是当天的真 bug：3,181 是**当时**的值，数据涨到 3,195 后这条永假；' +
      '永假的门禁不会报错，只会把**每个域名**都判成旧版 ⇒ 把「只差 v10.24」污染成「停在 v10.21 之前」',
  },
  {
    title: '砍掉本地自检分支（远端缺就一律算真缺口）',
    file: 'tools/audit-apps.js',
    find: '      if (self.alive.get(g)) missing.push(g);',
    /* ★ 反证代码必须**语法合法** —— 第一版替换成了 `missing.push(g);`，
       结果留下一个悬空 `else` ⇒ 子进程直接 SyntaxError。
       那种「红」是**语法错的红**，不是护栏在守行为，等于没验证（而且 stderr 会漏进输出）。 */
    repl: '      if (true) missing.push(g);   /* 反证：不过本地自检，一律当缺口 */',
    mustFail: '★ 远端缺口按「本地是否满足」分流',
    why: '去掉分流 = 过期门禁重新获得判版本的能力，假红立刻复现',
  },
  {
    title: '砍掉 STALE 记录（失效门禁不再提示）',
    file: 'tools/audit-apps.js',
    find: '      else STALE.set(g, (STALE.get(g) || 0) + 1);   // 本地也不满足 ⇒ 标记失效，不计入',
    repl: '      else { /* 反证：本地也不满足的门禁直接静默丢弃 */ }',
    mustFail: '★ 本地也不满足的门禁进 STALE 并单列',
    why: '静默丢弃比假红更坏：探针过期这件事从此无人知道，下次继续拿它报错版本',
  },
  {
    title: '防线自己的切片护栏（GATES 地标改掉 ⇒ 必须报「切不到」）',
    file: 'tools/test-audit-apps.js',
    find: "  const s = SRC.indexOf('const GATES = [');",
    repl: "  const s = SRC.indexOf('const GATES_XX = [');   /* 反证：地标失效 */",
    mustFail: '★ 切到了 GATES 代码块本身',
    why: '切片失败若静默返回空串，下面几条 `!==` 型断言会**全绿**（空串里当然没有反例）——' +
      '这正是 PITFALLS 15 的形态，所以必须先断言「切到了」',
  },
];

let pass = 0, fail = 0;
const files = [...new Set(CASES.map((c) => c.file))];
const backup = new Map();
let restored = true;

function restoreAll() {
  for (const [f, buf] of backup) fs.writeFileSync(path.join(ROOT, f), buf);
}

/* 先备份全部会动的文件，任一读不到就中止 */
try {
  for (const f of files) backup.set(f, fs.readFileSync(path.join(ROOT, f)));
} catch (e) {
  console.log('❌ 备份失败，未做任何改动：' + e.message);
  process.exit(1);
}

process.on('exit', () => { if (!restored) restoreAll(); });

console.log('# audit-apps.js 门禁自检 —— 反证\n');

for (const c of CASES) {
  const p = path.join(ROOT, c.file);
  const orig = backup.get(c.file).toString('utf8');
  if (!orig.includes(c.find)) {
    fail++;
    console.log('✗ ' + c.title);
    console.log('   锚点没找到（源码变了？）—— 这条反证无效，请先修锚点\n');
    continue;
  }
  const before = md5(fs.readFileSync(p));

  fs.writeFileSync(p, orig.replace(c.find, c.repl));

  /* ★ 先确认「打坏后的代码仍然语法合法」——
     否则子进程是 **SyntaxError 变红**，那证明不了护栏在守行为（等于没验证）。
     本项目 2026-09-20 实测踩到：把 `if (self.alive.get(g)) …` 换成裸语句后留下悬空 `else`。 */
  let syntaxOk = true;
  try { execFileSync(process.execPath, ['--check', c.file], { cwd: ROOT, encoding: 'utf8' }); }
  catch (e) { syntaxOk = false; }

  let out = '', red = false;
  if (syntaxOk) {
    try {
      out = execFileSync(process.execPath, [SUITE], { cwd: ROOT, encoding: 'utf8', timeout: 180000 });
    } catch (e) {
      out = String(e.stdout || '') + String(e.stderr || '');
      red = true;                                 // 退出码非 0 = 断言变红
    }
  }
  const named = out.includes(c.mustFail);         // ★ 还必须**是那条**断言红的
  fs.writeFileSync(p, backup.get(c.file));
  const after = md5(fs.readFileSync(p));

  if (after !== before) { restored = false; console.log('❌ 还原失败，已中止：' + c.file); process.exit(1); }

  const okCase = syntaxOk && red && named;
  if (okCase) pass++; else fail++;
  console.log((okCase ? '✅' : '❌') + ' ' + c.title);
  if (!syntaxOk) {
    console.log('   ⚠️ **打坏后的代码语法不合法** —— 这种红是 SyntaxError 的红，证明不了护栏有效，请改反证写法');
  } else {
    console.log('   打坏 → ' + (red ? '变红' : '**仍然全绿（假断言！）**') +
      ' ｜ 命中目标断言：' + (named ? '是' : '**否（红的是别的断言）**'));
  }
  console.log('   为什么该红：' + c.why + '\n');
}

/* 收尾：全部文件逐字节还原 */
for (const f of files) {
  const cur = fs.readFileSync(path.join(ROOT, f));
  if (md5(cur) !== md5(backup.get(f))) { console.log('❌ ' + f + ' 未还原！'); process.exit(1); }
}
restored = true;

/* 还原后必须重新全绿 —— 否则说明改动有残留 */
let finalOut = '', finalRed = false;
try { finalOut = execFileSync(process.execPath, [SUITE], { cwd: ROOT, encoding: 'utf8', timeout: 180000 }); }
catch (e) { finalRed = true; finalOut = String(e.stdout || ''); }
const finalLine = (finalOut.match(/通过 \d+ \/ \d+/) || ['(无输出)'])[0];
console.log('--- 还原校验 ---');
console.log('全部文件已逐字节还原（md5 一致）：' + files.join(' · '));
console.log('还原后防线：' + (finalRed ? '❌ 仍红（有残留破坏）' : '✅ 全绿') + ' ｜ ' + finalLine.charAt(0).toUpperCase() + finalLine.slice(1));

console.log('\n反证 ' + pass + ' / ' + (pass + fail) +
  (fail ? '  —— 有护栏打了还是绿，说明它是假断言' : '  —— 全部「打坏即变红」，护栏有效'));
process.exit(fail || finalRed ? 1 : 0);
