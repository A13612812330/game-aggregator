#!/usr/bin/env node
/* tools/_counterproof-v1032.js —— v10.32 静态层断言反证（打坏 → 必须变红）
 *
 * 三重目的：
 *   ① 证明 test-v1032.js 的每条断言**真的能抓到回归**（首跑全绿不等于守得住）；
 *   ② 证明**锚点找对了**（变异未生效会单独报出来，而不是悄悄算过）；
 *   ③ 顺带证明反向断言不是恒真的（把「单独一项」加回来，它必须红）。
 *
 * 做法：把 public/ 与 data/pcreq.js 复制到 _cf132/（test-v1032.js 的 ROOT 由 __dirname
 * 推导 ⇒ 自动指向副本），单点变异后跑套件。
 * 判据 = **退出码非零 且 指定断言名出现在 FAIL 行** —— 只看退出码会把
 * 「撞红了别的断言」误判成通过。
 *
 * 运行：node tools/_counterproof-v1032.js
 */
const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const ROOT = path.join(__dirname, '..');
const TMP = path.join(ROOT, '_cf132');

/* file 缺省为 public/index.html */
const MUTS = [
  {
    id: '① 定位条退回「修改器」「云存档」两项',
    expect: '不再有单独的「修改器」项',
    f: (s) => s.replace("{ k: 'trsv', nm: '修改器/云存档', sel: ['#trSvSlot'] },",
      "{ k: 'tr', nm: '修改器', sel: ['#trBlock'] },\n  { k: 'sv', nm: '云存档', sel: ['#svBlock'] },"),
  },
  {
    id: '②a 跳转余量写死回 14（绕开 cover）',
    /* ⚠️ 期望关键词写**正向**那条（「落点里减掉小条的遮挡高度」）。
       反向那条 `!/raw - \d/` 也会红，但正向这条更直接说明「余量没经过 cover」。 */
    expect: '落点里减掉小条的遮挡高度',
    f: (s) => s.replace('raw - cover - gap', 'raw - 14'),
  },
  {
    id: '②b cover 恒为 0（等于看不穿小条）',
    expect: '先算「不含余量」的落点',
    f: (s) => s.replace('const cover = raw >= heroH ? miniH : 0;', 'const cover = 0;'),
  },
  {
    id: '②c 小条高度写死 0（不再读实测高）',
    expect: '读小条实际高度',
    f: (s) => s.replace('const miniH = mini ? mini.offsetHeight : 0;', 'const miniH = 0;'),
  },
  {
    id: '③a 删掉 titleParts 定义（退回单段搜索）',
    file: 'data/pcreq.js',
    expect: 'titleParts（中文段 + 英文段）已定义',
    f: (s) => s.replace('function titleParts(title) {', 'function titleParts_gone(title) {'),
  },
  {
    id: '③b 交叉判据改名（三级判据缺一）',
    file: 'data/pcreq.js',
    expect: '三级判据都在',
    f: (s) => s.replace("how: 'cross'", "how: 'x'"),
  },
  {
    id: '③c 删掉未命中的负缓存',
    file: 'data/pcreq.js',
    expect: '未命中写负缓存',
    f: (s) => s.replace('save(key, { miss: true });', '/* removed */'),
  },
  {
    id: '③d 等级 2 判据改坏（不再要求完全相等）',
    file: 'data/pcreq.js',
    expect: '等级 2 = 归一化后完全相等',
    f: (s) => s.replace('if (q === r) return 2;', 'if (false) return 2;'),
  },
  {
    id: '③e 删掉「包含」的最小长度闸门（短串乱配）',
    file: 'data/pcreq.js',
    expect: '等级 1 = 包含',
    f: (s) => s.replace('if (q.length >= minLen && r.includes(q)) lvl = 1;', 'if (r.includes(q)) lvl = 1;'),
  },
  {
    id: '③f 判据顺序颠倒（loose 提到 cross 之前）',
    file: 'data/pcreq.js',
    expect: '判据顺序',
    f: (s) => s.replace('  /* ② 多段候选交集（强证据优先于字符串包含） */',
      "  if (loose) return Object.assign({ how: 'loose' }, loose);\n  /* ② 多段候选交集 */"),
  },
  {
    id: '③g 退回「取首条不校验」',
    file: 'data/pcreq.js',
    expect: '① 用「完全相等」筛候选',
    f: (s) => s.replace('const exact = cands.find((c) => nameMatchLevel(c.name, parts) === 2);', 'const exact = cands[0];'),
  },
  {
    id: '③h 旧 searchAppid 复活（单语通路）',
    file: 'data/pcreq.js',
    expect: '旧的 searchAppid（只取中文段）已移除',
    f: (s) => 'async function searchAppid(name) { return ""; }\n' + s,
  },
  {
    id: '④ 派生页未重建（emulator.html 仍是合并前的两项）',
    file: 'public/emulator.html',
    expect: 'emulator.html 已同步「修改器/云存档」项',
    f: (s) => s.replace("{ k: 'trsv', nm: '修改器/云存档', sel: ['#trSvSlot'] },",
      "{ k: 'tr', nm: '修改器', sel: ['#trBlock'] },\n  { k: 'sv', nm: '云存档', sel: ['#svBlock'] },"),
  },
  /* ---------- ⑤ 底部提示文案三行骨架（v10.32 第 4 条） ---------- */
  {
    id: '⑤a 修改器提示少一个 <br>（合并两段 ⇒ 退回四行）',
    expect: '修改器 的提示是**显式三行**',
    f: (s) => s.replace('（与主程序 .exe 同级）。<br>\n        启动前先运行', '（与主程序 .exe 同级）。启动前先运行'),
  },
  {
    id: '⑤b 云存档提示退回「一整段靠自动折行」',
    expect: '云存档 的提示是**显式三行**',
    f: (s) => s.replace('是占位符。<br>\n        按你自己的账号替换；<b>存档前先退出游戏</b>，避免被覆盖。<br>\n        数据来自',
      '是占位符，按你自己的账号替换，<b>存档前先退出游戏</b>，避免被覆盖。数据来自'),
  },
  {
    id: '⑤c 某段写太长（窄屏 286px 下必折行）',
    expect: '每段都在一行内放得下',
    f: (s) => s.replace('数据来自 Ludusavi 开源清单（MIT）。',
      '数据来自 Ludusavi 开源清单（MIT），这是一句故意写得很长很长的话用来把这一行撑爆。'),
  },
  {
    id: '⑤d 用空行凑高度（用户明说「不是说真预留」）',
    expect: '没有空行凑高度',
    f: (s) => s.replace('是占位符。<br>', '是占位符。<br><br>'),
  },
  {
    id: '⑤e 用「；」把两件事挤回一行',
    expect: '不再用「；」把两件事挤进一行',
    f: (s) => s.replace('（与主程序 .exe 同级）。', '（与主程序 .exe 同级）；'),
  },
  {
    id: '⑤f 派生页两块提示没同步三行（只改了主源）',
    file: 'public/emulator.html',
    expect: '两块提示也已是三行骨架',
    f: (s) => s.replace('是占位符。<br>', '是占位符。'),
  },
];

/* ---------- 准备副本 ---------- */
fs.rmSync(TMP, { recursive: true, force: true });
fs.mkdirSync(path.join(TMP, 'tools'), { recursive: true });
fs.mkdirSync(path.join(TMP, 'public'), { recursive: true });
fs.mkdirSync(path.join(TMP, 'data'), { recursive: true });
const FILES = ['public/index.html', 'public/emulator.html', 'public/unpack.html', 'data/pcreq.js'];
for (const f of FILES) fs.copyFileSync(path.join(ROOT, f), path.join(TMP, f));
fs.copyFileSync(path.join(__dirname, 'test-v1032.js'), path.join(TMP, 'tools', 'test-v1032.js'));
const ORIG = {};
for (const f of FILES) ORIG[f] = fs.readFileSync(path.join(TMP, f), 'utf8');

const runSuite = () => cp.spawnSync(process.execPath, ['tools/test-v1032.js'],
  { cwd: TMP, encoding: 'utf8', timeout: 120000 });

let good = 0, bad = 0;
console.log('v10.32 静态断言反证（打坏 → 必须变红）\n');

/* ---------- 基准：未变异必须绿 ---------- */
{
  const r = runSuite();
  const out = (r.stdout || '') + (r.stderr || '');
  const m = /通过 (\d+)\/(\d+)/.exec(out);
  if (r.status === 0 && m) console.log('【基准】无变异 → ' + m[1] + '/' + m[2] + ' 绿 ✅\n');
  else { bad++; console.log('【基准】⚠️ 无变异竟然不绿，后面的结论都不可信：\n' + out.slice(-800) + '\n'); }
}

/* ---------- 逐条变异 ---------- */
for (const mut of MUTS) {
  const rel = mut.file || 'public/index.html';
  const target = path.join(TMP, rel);
  const mutated = mut.f(ORIG[rel]);
  if (mutated === ORIG[rel]) {
    bad++;
    console.log('× ' + mut.id + '\n   → 变异**未生效**（锚点在源码里没找到，断言名可能已经改了）\n');
    continue;
  }
  fs.writeFileSync(target, mutated);
  const r = runSuite();
  const out = (r.stdout || '') + (r.stderr || '');
  const fails = out.split('\n').filter((l) => /FAIL/.test(l));
  const keys = Array.isArray(mut.expect) ? mut.expect : [mut.expect];
  const hitAll = keys.every((k) => fails.some((l) => l.includes(k)));
  if (r.status !== 0 && hitAll) {
    good++;
    console.log('✅ ' + mut.id + '\n   → 退出码 ' + r.status + ' · FAIL ' + fails.length + ' 条 · 命中「' + keys.join(' + ') + '」');
  } else if (r.status !== 0) {
    bad++;
    console.log('× ' + mut.id + '\n   → 变红了但**不是期望那条**（关键词未出现）');
    fails.slice(0, 3).forEach((l) => console.log('       ' + l.trim()));
  } else {
    bad++;
    console.log('× ' + mut.id + '\n   → ⚠️ **打坏了却全绿**：这条断言形同虚设');
  }
  fs.writeFileSync(target, ORIG[rel]);   // 每条之间还原，避免变异叠加
}

fs.rmSync(TMP, { recursive: true, force: true });
console.log('\n============================');
console.log('  反证合规 ' + good + '/' + MUTS.length + '（异常 ' + bad + '）');
console.log('============================');
process.exit(bad ? 1 : 0);
