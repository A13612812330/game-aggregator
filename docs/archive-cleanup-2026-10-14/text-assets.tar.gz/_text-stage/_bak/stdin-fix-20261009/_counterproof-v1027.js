/* 反证：把 v10.27 下载弹窗的六个关键行为逐个打坏，断言必须变红。
 * 用法：node tools/_counterproof-v1027.js     （跑完自动还原，无论成败）
 *
 * ★ 为什么每条都要挑「同一个语义」而不是「随便删一行」：
 *   反证的价值在于证明**这条断言真的在守那个行为**。
 *   删一行无关的代码让它变红，只能说明测试会挂，说明不了它在守什么。
 */
const fs = require('fs');
const { execFileSync } = require('child_process');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const TEST = 'tools/test-v1027-dlpop.js';

const CASES = [
  {
    name: '① 一行一帖打坏：归帖键退成「地址本身」（回到改前一地址一行）',
    file: 'public/index.html',
    from: "    const k = it.postId || it.postUrl || ('u:' + it.real);",
    to: "    const k = 'u:' + it.real;",
    expect: '5 个网盘地址归成 2 帖',
  },
  {
    name: '② 前端排序去掉「有标题优先」（与后端规则漂移）',
    file: 'public/index.html',
    from: '    const at = a.title ? 1 : 0, bt = b.title ? 1 : 0;',
    to: '    const at = 1, bt = 1;',
    expect: '前端 dlSorted 与后端 sortPosts 顺序一致',
  },
  {
    name: '③ 发布时间不透传（ct 恒为 null ⇒ 切「最近发布」全变 0 分并列）',
    file: 'fetchers/download.js',
    from: '          ct: p.ct || null,',
    to: '          ct: null,',
    expect: 'flatFrom 透传 ct',
  },
  {
    name: '④ 补抓条件打坏：取满了也去补一页 sort=new（白花一次请求）',
    file: 'fetchers/jidiPosts.js',
    from: '  if (!(base.count > base.list.length)) return out;',
    to: '  if (false) return out;',
    expect: '补抓条件是',
  },
  {
    name: '⑤ 盘口筛选打坏：dlFiltered 原样返回（筛了等于没筛）',
    file: 'public/index.html',
    from: "  return filt ? items.filter((i) => dlBrand(i.server).cls === filt) : items;",
    to: '  return items;',
    expect: '筛选后每帖只剩该盘口的链接',
  },
  {
    name: '⑥ 弹窗宽度改回 580（长标题没地方落脚）',
    file: 'public/index.html',
    from: '.dlpop-box{position:relative;width:min(760px,100%)',
    to: '.dlpop-box{position:relative;width:min(580px,100%)',
    expect: '弹窗加宽到 760px',
  },
  {
    name: '⑦ 标题样式退回 nowrap 单行省略（又变成一屏「【亲测可玩】…」）',
    file: 'public/index.html',
    from: '  .dl-it .tx b{display:-webkit-box;',
    to: '  .dl-it .tx b{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:block;',
    expect: '标题是 2 行折行',
  },
];

function runTest() {
  try {
    return execFileSync(process.execPath, [TEST], { cwd: ROOT, encoding: 'utf8', stdio: 'pipe' });
  } catch (e) {
    return (e.stdout || '') + (e.stderr || '');
  }
}

/** ★ 子进程真的跑起来了才算数：没有汇总行 = 脚本本身失败 ——
 *  绝不能被当成「断言没变红」（那会把「工具坏了」误判成「断言是假绿」）。
 *  v10.26 的反证脚本正是在这里栽过一次。 */
function ranOk(out) {
  return /通过 \d+\/\d+/.test(String(out));
}

function lineFor(out, kw) {
  const l = String(out).split(/\r?\n/).find((x) => x.includes(kw));
  return l ? l.trim() : '(未找到该断言行)';
}

let bad = 0;
for (const c of CASES) {
  const p = path.join(ROOT, c.file);
  const orig = fs.readFileSync(p, 'utf8');
  if (!orig.includes(c.from)) {
    console.log('⚠️  ' + c.name + '\n     找不到要替换的原文，反证无效（文件可能与测试不同步）');
    bad++;
    continue;
  }
  try {
    fs.writeFileSync(p, orig.replace(c.from, c.to), 'utf8');
    const out = runTest();
    if (!ranOk(out)) {
      console.log('❌ 测试没跑起来（拿不到汇总行）  ' + c.name);
      console.log('     前 200 字：' + String(out).slice(0, 200).replace(/\s+/g, ' '));
      bad++;
      continue;
    }
    const line = lineFor(out, c.expect);
    const isFail = /× FAIL/.test(line);
    const summary = (out.match(/通过 \d+\/\d+（失败 \d+）/) || ['(无汇总)'])[0];
    console.log((isFail ? '✅ 变红' : '❌ 没变红') + '  ' + c.name);
    console.log('     ' + line);
    console.log('     ' + summary);
    if (!isFail) bad++;
  } finally {
    fs.writeFileSync(p, orig, 'utf8');       // ★ 无论成败都还原
  }
}

console.log('\n============================');
console.log(bad ? ('❌ ' + bad + ' 条反证未变红（断言是假绿）') : '✅ 全部反证通过：打坏即变红');
console.log('已还原全部文件');
console.log('============================');
process.exit(bad ? 1 : 0);
