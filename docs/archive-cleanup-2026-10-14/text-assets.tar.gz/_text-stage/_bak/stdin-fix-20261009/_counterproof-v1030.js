/* 反证：把 v10.30「置顶不再闪 + 卡片格式统一」的关键护栏逐个打坏，对应断言必须变红。
 * 用法：node tools/_counterproof-v1030.js   （跑完自动还原，无论成败）
 *
 * ★ 本版重点反证三类最容易**假绿**的判据：
 *   ① **CSS 反向断言**（「不许再有 height:56px」）—— 字符串判据很容易命中注释或别处，
 *      必须证明打坏真正的规则行会红。
 *   ② **前置闸（check-card-rules.js）本身**—— 它是新写的，没人验过它会红。
 *      闸门自己不红 = 一道永远不会拦人的门（本项目已栽过同类：「退出码不随失败变」）。
 *      所以有三条用例专门打给它（⑤⑥⑦）。
 *   ③ **「常量 + 用法」成对**的判据 —— 例如双阈值滞后：
 *      只留着 `MINI_GAP` 这个声明、把用法换掉，闸门必须能发现（见 ⑨）。
 *
 * ★ 每条都挑**同一个语义**打坏，而不是「随便删一行」：
 *   反证的价值在于证明「这条断言真的在守那个行为」。删一行无关代码让它变红，
 *   只能说明测试会挂，说明不了它在守什么。
 */
const fs = require('fs');
const { execFileSync } = require('child_process');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const DEFAULT_TEST = 'tools/test-v1030-cards.js';

const CASES = [
  /* ---------- 卡片统一：三重锁 ---------- */
  {
    name: '① .rel-it 去掉 min-width 锁（flex item 默认 min-width:auto 会被长标题撑开 —— 实测 106 vs 123.2）',
    file: 'public/index.html',
    from: 'min-width:var(--cd-s);max-width:var(--cd-s);',
    to: 'max-width:var(--cd-s);',
    expect: 'min-width 也锁定',
  },
  {
    name: '② .rel-it 再去掉 max-width 锁（只剩 flex-basis，仍可能被撑开）',
    file: 'public/index.html',
    from: 'min-width:var(--cd-s);max-width:var(--cd-s);',
    to: 'min-width:var(--cd-s);',
    expect: 'max-width 也锁定',
  },
  {
    name: '③ 缩略图退回「定高不定比例」height:56px（比例会漂到 1.571~1.879）',
    file: 'public/index.html',
    from: '.rel-row .rel-it img,.rel-row .rel-it .noimg{display:block;width:100%;height:auto;aspect-ratio:var(--th-ar)',
    to: '.rel-row .rel-it img,.rel-row .rel-it .noimg{display:block;width:100%;height:56px',
    expect: '反向断言：不再有硬编码 height:56px',
  },
  {
    /* ⚠️ 必须替换**整段 body**里带值的那一句，不能写成「在 `{` 后面插一个 `min-height:0;`」——
       那样只是多了一条声明，原值仍在，判据照样绿（本轮初稿就栽在这，才发现原断言
       只判 `/min-height:/` 存在、`min-height:0` 也算过 —— 现在值已收紧为
       `var(--cd-t2) | 2.6em` 二选一）。 */
    name: '④ 同类游戏卡标题去掉「预留两行」的 min-height（只剩 clamp ⇒ 短标题卡片矮一截、一排不等高）',
    file: 'public/index.html',
    from: '.rel-row .rel-it .t{font-size:11.5px;font-weight:650;line-height:var(--cd-lh);min-height:var(--cd-t2);',
    to: '.rel-row .rel-it .t{font-size:11.5px;font-weight:650;line-height:var(--cd-lh);min-height:0;',
    expect: '标题固定',
  },
  {
    name: '⑤ 父级 .bd 加回 nowrap（压住子级 clamp ⇒ 子元素 clamp 生效但父级不换行，等于没改）',
    file: 'public/index.html',
    from: '.x-src .x-it .bd{',
    to: '.x-src .x-it .bd{white-space:nowrap;',
    expect: '父级 .bd 也不许 nowrap',
  },
  {
    /* 与 ④ 打的是**不同族**（④ 同类游戏卡，⑥ 搜索结果标题），
       证明「其余卡片族」那段断言不是摆设 —— 只守用户点名的那两族就等于没统一。 */
    name: '⑥ 搜索结果标题 .row-card h3 去掉预留两行（其余卡片族漏改）',
    file: 'public/index.html',
    from: '.row-card h3{font-size:14.5px;font-weight:750;line-height:var(--cd-lh);min-height:var(--cd-t2);',
    to: '.row-card h3{font-size:14.5px;font-weight:750;line-height:var(--cd-lh);min-height:0;',
    expect: '搜索结果标题 固定预留两行',
  },
  {
    /* ★ 骨架屏断点是**最容易漏改**的地方（三处媒体查询各写一遍，本轮就漏了两处）。
       打坏最后一处，证明那条「3/3」断言真的在守全部三处。 */
    name: '⑦ 骨架屏第三处断点退回定高（加载完成的一瞬卡片跳一截）',
    file: 'public/index.html',
    from: '.skeleton .sk-th{width:96px;height:auto;aspect-ratio:var(--th-ar)}',
    to: '.skeleton .sk-th{width:96px;height:58px}',
    expect: '三处断点的骨架屏缩略图都同步了',
  },
  {
    name: '⑧ 骨架屏容器圆角退回硬编码 13px（真卡片是 12px ⇒ 加载完成圆角跳一档）',
    file: 'public/index.html',
    from: '.skeleton{display:flex;gap:13px;background:#fff;border:1px solid var(--c-border);border-radius:var(--cd-r)',
    to: '.skeleton{display:flex;gap:13px;background:#fff;border:1px solid var(--c-border);border-radius:13px',
    expect: '骨架屏容器',
  },

  /* ---------- 顶图小标题条（断言在 test-v1028-detail.js）---------- */
  {
    name: '⑨ 小条去掉负 margin（正文整体下移 62px —— 小条「占流」了）',
    file: 'public/index.html',
    from: 'height:62px;margin-bottom:-62px;',
    to: 'height:62px;',
    expect: '负 margin **不占文档流**',
    test: 'tools/test-v1028-detail.js',
  },
  {
    /* ★ 这是「常量还在、用法没了」的典型：只删用法，`MINI_GAP` 声明与注释都还在文件里。
       如果判据写成「文件里有没有 MINI_GAP」，这条会假绿。 */
    name: '⑨-b 只删双阈值**用法**、留着 MINI_GAP 声明（滞后带归零 = 退回单阈值 = 会闪）',
    file: 'public/index.html',
    from: 'const off = Math.max(24, on - MINI_GAP);',
    to: 'const off = Math.max(24, on - 0);',
    expect: '双阈值滞后',
    test: 'tools/test-v1028-detail.js',
  },
  {
    name: '⑩ 阈值写死 200（窄屏大图 190px ⇒ 留空档，小条晚出现）',
    file: 'public/index.html',
    from: 'const on = Math.max(60, hero.offsetHeight - 62 + 12);',
    to: 'const on = Math.max(60, 200 - 62 + 12);',
    expect: '阈值跟大图',
    test: 'tools/test-v1028-detail.js',
  },
  {
    name: '⑪ 状态另存模块变量（不再读 DOM class ⇒ 换游戏后没法天然复位）',
    file: 'public/index.html',
    from: "const cur = h.classList.contains('on');",
    to: 'const cur = !!window.__miniOn;',
    expect: '状态以 DOM class 为唯一事实来源',
    test: 'tools/test-v1028-detail.js',
  },
  {
    name: '⑫ 大图退回 sticky（布局反过来影响 scrollTop，正是自激振荡的根）',
    file: 'public/index.html',
    from: '.d-hero{position:relative;z-index:8;',
    to: '.d-hero{position:sticky;z-index:8;',
    expect: '不再 sticky',
    test: 'tools/test-v1028-detail.js',
  },

  /* ---------- 前置闸 check-card-rules.js 自身（三处）---------- */
  {
    name: '⑬ 【闸门】图片槽定高且无 aspect-ratio ⇒ check-card-rules 必须红',
    file: 'public/index.html',
    from: '.rk-card .th{width:74px;height:auto;aspect-ratio:var(--th-ar)',
    to: '.rk-card .th{width:74px;height:42px',
    expect: '图片槽定高且无 aspect-ratio',
    test: 'tools/check-card-rules.js',
  },
  {
    name: '⑭ 【闸门】卡片族新加一条硬编码圆角（未登记进例外表）⇒ check-card-rules 必须红',
    file: 'public/index.html',
    from: '.rk-card.big{',
    to: '.rk-card.big{border-radius:14px;',
    optional: true, // 该选择器不存在时自动改用下面那条
    expect: '圆角未走变量',
    test: 'tools/check-card-rules.js',
  },
  {
    // 备用：直接往 `:root` 之外新塞一条未登记圆角，保证这条反证总有靶子
    name: '⑭-b 【闸门】给 .emu-card 增补一条硬编码圆角（未登记例外）⇒ check-card-rules 必须红',
    file: 'public/index.html',
    from: '.emu-grid.sv .emu-card{border-color:#DBEAFE}',
    to: '.emu-grid.sv .emu-card{border-color:#DBEAFE;border-radius:14px}',
    expect: '圆角未走变量',
    test: 'tools/check-card-rules.js',
  },
  {
    name: '⑮ 【闸门】例外表塞一条不存在的选择器 ⇒ 陈旧自检必须红（否则例外表会退化成静默跳过）',
    file: 'tools/check-card-rules.js',
    from: "    sel: '.emu-card .cov', h: 92,",
    to: "    sel: '.emu-card .cov-nonexistent', h: 92,",
    expect: '已陈旧',
    test: 'tools/check-card-rules.js',
  },

  /* ---------- 派生页漂移 ---------- */
  {
    name: '⑯ 派生页漂移：emulator.html 的规范变量被改（主源改了没重建 —— 不报错，只悄悄漂移）',
    file: 'public/emulator.html',
    from: '--th-ar:16 / 9;',
    to: '--th-ar:4 / 3;',
    expect: 'emulator.html 已同步规范变量',
  },
];

function runTest(p) {
  try {
    return execFileSync(process.execPath, [p], { cwd: ROOT, encoding: 'utf8', stdio: 'pipe' });
  } catch (e) {
    return (e.stdout || '') + (e.stderr || '');
  }
}

/** ★ 子进程真的跑起来了才算数：没有汇总行 = 脚本本身失败 ——
 *  绝不能被当成「断言没变红」（那会把「工具坏了」误判成「断言是假绿」）。 */
function ranOk(out) {
  return /通过 \d+\/\d+/.test(String(out)) || /发现 \d+ 处不合规/.test(String(out));
}

/** 前置闸不吐「通过 n/m」，它的红是「发现 N 处不合规」+ exit 1。 */
function isGateRed(out) {
  return /发现 \d+ 处不合规/.test(String(out));
}

function lineFor(out, kw) {
  const l = String(out).split(/\r?\n/).find((x) => x.includes(kw));
  return l ? l.trim() : '(未找到该断言行)';
}

let bad = 0;
const skipped = [];
for (const c of CASES) {
  const tf = c.test || DEFAULT_TEST;
  const p = path.join(ROOT, c.file);
  const orig = fs.readFileSync(p, 'utf8');
  const hits = orig.split(c.from).length - 1;
  if (hits === 0) {
    if (c.optional) { console.log('－ 跳过（靶子不存在）  ' + c.name); continue; }
    console.log('⚠️  ' + c.name + '\n     找不到要替换的原文，反证无效（文件可能与测试不同步）');
    bad++;
    continue;
  }
  if (hits > 1) skipped.push(c.name + '（原文出现 ' + hits + ' 次，只替换了第 1 处）');
  try {
    fs.writeFileSync(p, orig.replace(c.from, c.to), 'utf8');
    const out = runTest(tf);
    if (!ranOk(out)) {
      console.log('❌ 测试没跑起来（拿不到汇总行）  ' + c.name);
      console.log('     前 240 字：' + String(out).slice(0, 240).replace(/\s+/g, ' '));
      bad++;
      continue;
    }
    const gate = c.test === 'tools/check-card-rules.js';
    const line = gate ? lineFor(out, c.expect) : lineFor(out, '× FAIL');
    const isFail = gate
      ? (isGateRed(out) && (c.expect ? String(out).includes(c.expect) : true))
      : /× FAIL/.test(lineFor(out, c.expect));
    const summary = gate
      ? (out.match(/发现 \d+ 处不合规/) || ['(闸门未报不合规)'])[0]
      : (out.match(/通过 \d+\/\d+（失败 \d+）/) || ['(无汇总)'])[0];
    console.log((isFail ? '✅ 变红' : '❌ 没变红') + '  ' + c.name);
    console.log('     ' + (gate ? lineFor(out, c.expect) : line));
    console.log('     ' + summary);
    if (!isFail) bad++;
  } finally {
    fs.writeFileSync(p, orig, 'utf8');       // ★ 无论成败都还原
  }
}

if (skipped.length) {
  console.log('\n⚠️ 以下条目的原文在文件里出现多次，替换的是第 1 处，判据可能没落在同一段代码上：');
  for (const s of skipped) console.log('   · ' + s);
}

console.log('\n============================');
console.log(bad ? ('❌ ' + bad + ' 条反证未变红（断言是假绿）') : '✅ 全部反证通过：打坏即变红');
console.log('已还原全部文件');
console.log('============================');
process.exit(bad ? 1 : 0);
