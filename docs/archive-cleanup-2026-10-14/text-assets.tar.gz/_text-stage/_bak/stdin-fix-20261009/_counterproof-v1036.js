#!/usr/bin/env node
/* tools/_counterproof-v1036.js —— v10.36「跨源名字匹配」的**反证**
 *
 * 做法：把被守护的文件复制到 `_cf136/`（套件的 ROOT 由 __dirname 推导 ⇒ 自动指向副本），
 *   单点变异后跑 `tools/test-v1036.js`。
 *
 * 判据 = **退出码非零** 且 **指定断言名出现在 FAIL 行**，且**必须跑完**（有汇总行）。
 *   三态区分沿用 v10.34 学到的：跑完+无 FAIL = 真·假绿；没跑完 = UNVERIFIED（不许算合规）。
 *
 * ★ 本版的变异设计针对一个**成对**的失败模式：
 *   本轮的护栏（代际数字）有「该拦的拦」与「不该拦的不许拦」两面 ——
 *   把 `numMismatchByTitle` 调成恒 true（过度收紧）与恒 false（形同没有）**都会**
 *   让套件变红，因为正向与反向断言是成对写的。变异③④⑤专门打「取数口径」，
 *   变异⑨专打「过度收紧」，变异⑧专打「阈值被顺手调高」（8→10 会丢 18 条正确匹配）。
 *
 * ⚠️ 覆盖 `_cf136/` 下的副本，**不动**项目正本。
 */
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const ROOT = path.join(__dirname, '..');
const CF = path.join(ROOT, '_cf136');
/* test-v1036 会真的加载 phonecfg（需要 games.json/phonecfg.json/cn-names.json）、
   mobilehub（需要 mobilehub.json）；副本里必须齐，否则基准就跑不起来。 */
const FILES = [
  'tools/test-v1036.js',
  'data/name-normalize.js',
  'data/phonecfg.js',
  'data/mobilehub.js',
  'data/cover-url.js',
  'data/games.json',
  'data/phonecfg.json',
  'data/mobilehub.json',
  'data/cn-names.json',
  'data/mobilehub-names.json',
  'tools/build-mobilehub.js',
];

const MUT = [
  {
    id: '①a 归一化漏剥 ™（回到 v10.35 的旧字符类）',
    file: 'data/name-normalize.js',
    expect: '™ 必须被剥掉',
    f: (s) => s.replace('const SYMBOLS = /[™®©', 'const SYMBOLS = /[®©'),
  },
  {
    id: '①b 归一化漏剥 ®（同上，另一个字符）',
    file: 'data/name-normalize.js',
    expect: '★ 商标号 ® 必须被剥掉',
    f: (s) => s.replace('const SYMBOLS = /[™®©', 'const SYMBOLS = /[™©'),
  },
  {
    /* ★ 唯一真源被架空：phonecfg 又长出自己的一份 normKey（v10.35 之前的现状）。
     *  ⚠️ 第一版变异写成「在文件里插一个 function normKey」—— 那会与顶部的
     *     `const { normKey } = require(...)` **重复声明** ⇒ SyntaxError ⇒ 模块加载即崩、
     *     套件连汇总行都没有 ⇒ 反证只能报 UNVERIFIED（工具是对的，变异是错的）。
     *     能加载的等价形态 = **把 require 换成同名的本地实现**。 */
    id: '①c phonecfg 重新自带 normKey（第二实现复活，唯一真源被架空）',
    file: 'data/phonecfg.js',
    expect: '★ data/phonecfg.js 不许再自带 normKey 定义',
    f: (s) => s.replace(
      "const { normKey, numMismatchByTitle } = require('./name-normalize');",
      "function normKey(s) { return String(s == null ? '' : s).toLowerCase(); }\n"
      + 'function numMismatchByTitle() { return false; }'),
  },
  {
    id: '②a 代际数字退回「从归一化钥匙取数」（踩 v10.36 实测过的坑）',
    file: 'data/name-normalize.js',
    expect: 'genNums("Call of Duty Modern Warfare 2 2009")',
    f: (s) => s.replace("  const raw = String(s == null ? '' : s);\n  const cleaned = raw.replace",
      '  const raw = normKey(s);\n  const cleaned = raw.replace'),
  },
  {
    id: '②b 4 位年份也当代际（过度收紧，会误杀 F1 2014 / Dead Space 2008）',
    file: 'data/name-normalize.js',
    expect: 'genNums("F1 2014")',
    f: (s) => s.replace("return cleaned.match(/(?<![0-9])\\d{1,2}(?![0-9])/g) || [];",
      'return cleaned.match(/(?<![0-9])\\d{1,4}(?![0-9])/g) || [];'),
  },
  {
    id: '②c 贴字母的数字也当代际（ProjectZomboid32 因此永远配不上）',
    file: 'data/name-normalize.js',
    expect: 'genNums("ProjectZomboid32")',
    f: (s) => s.replace("  const cleaned = raw.replace(/[a-z]+[-_]?\\d+/gi, ' ');", '  const cleaned = raw;'),
  },
  {
    id: '③a 护栏形同没有（numMismatchByTitle 恒 false）',
    file: 'data/name-normalize.js',
    expect: '★ AC3 配到「刺客信条1」⇒ 判冲突',
    f: (s) => s.replace('  if (!libItem) return false;', '  if (!libItem) return false;\n  if (true) return false;'),
  },
  {
    id: '③b 护栏过度收紧（库侧数字集合恒空 ⇒ 所有带代际数字的查询全被拒）',
    file: 'data/name-normalize.js',
    expect: '★ 反向：Call of Duty Modern Warfare 2 2009',
    f: (s) => s.replace('  const tn = genNums(libItem.title);', '  const tn = [];'),
  },
  {
    id: '④ build-mobilehub 的某条返回通道漏挂护栏（≥5 处 → 1 处）',
    file: 'tools/build-mobilehub.js',
    expect: 'build-mobilehub 的**每条**返回通道都挂了代际护栏',
    f: (s) => {
      const all = s.split('numMismatchByTitle(');
      if (all.length < 6) return s;
      /* 保留第一处（通道①），其余全部拿掉 —— 模拟「只挂了一条通道」 */
      return all[0] + 'numMismatchByTitle(' + all.slice(1).join('__x__(');
    },
  },
  {
    id: '⑤ 前缀包含通道阈值被顺手调高（8 → 10；实测会丢 18 条正确匹配）',
    file: 'tools/build-mobilehub.js',
    expect: '★ 前缀包含通道阈值仍是 8',
    f: (s) => s.replace('if (whole.length >= 8) {', 'if (whole.length >= 10) {'),
  },
  {
    id: '⑥ 尾缀表被重新放进 reloaded（Tropico Reloaded 会被错配到海岛大亨6）',
    file: 'tools/build-mobilehub.js',
    expect: '★ 反向：尾缀表里仍然不许有 reloaded',
    f: (s) => s.replace("  /\\bHYPERVISOR\\b/gi,", '  /\\breloaded\\b/gi,\n  /\\bHYPERVISOR\\b/gi,'),
  },
  {
    id: '⑦ 尾缀表新增的「运行环境残渣」被拿掉（dx 版本号不再剥）',
    file: 'tools/build-mobilehub.js',
    expect: '尾缀表覆盖 d3d|dx',
    f: (s) => s.replace('(d3d|dx)\\s*1[0-2]', '(gdi|voodoo)\\s*1[0-2]'),
  },
  {
    id: '⑧ EDITION_WORDS 的 CJK 版本词被拿掉（恐怖黎明/武士少女这类又配不上）',
    file: 'tools/build-mobilehub.js',
    expect: 'EDITION_WORDS 已含 CJK 版本词',
    f: (s) => s.replace("  '终极版', '完整版', '豪华版',", "  '__e1__', '__e2__', '__e3__',"),
  },
  {
    id: '⑨ phonecfg 侧的护栏被摘（实测库那半边又回到滥配）',
    file: 'data/phonecfg.js',
    expect: '★ phonecfg 的 libMatch 同样挂了护栏',
    f: (s) => s.replace(/numMismatchByTitle\(t, it\)/g, '__gone__(t, it)'),
  },
];

function cp(src, dst) {
  fs.mkdirSync(path.dirname(dst), { recursive: true });
  if (!fs.existsSync(src)) { console.log('  (跳过不存在的基础文件 ' + path.relative(ROOT, src) + ')'); return; }
  fs.copyFileSync(src, dst);
}
function buildBase() { for (const f of FILES) cp(path.join(ROOT, f), path.join(CF, f)); }
function runSuite() {
  try {
    return { code: 0, out: execFileSync(process.execPath, [path.join(CF, 'tools', 'test-v1036.js')],
      { encoding: 'utf8', cwd: CF, timeout: 180000 }) };
  } catch (e) {
    return { code: e.status || 1, out: String(e.stdout || '') + String(e.stderr || '') };
  }
}
const RAN_OK = /通过 \d+\/\d+/;

console.log('\n=== 反证 v10.36：基准（无变异）必须全绿 ===');
buildBase();
const base = runSuite();
if (base.code !== 0 || !RAN_OK.test(base.out)) {
  console.log('  × 基准就是红的（或没跑完），反证无意义。输出尾部：\n' + base.out.slice(-1600));
  process.exit(1);
}
console.log('  PASS  基准全绿  — ' + (base.out.match(/通过 \d+\/\d+/) || [])[0] + '\n');

console.log('=== 逐条变异（期望：退出码非零 **且** 指定断言出现在 FAIL 行） ===\n');
let good = 0, bad = 0, unv = 0;
for (const m of MUT) {
  const src = fs.readFileSync(path.join(ROOT, m.file), 'utf8');
  const mut = m.f(src);
  const dst = path.join(CF, m.file);
  if (mut === src) {
    bad += 1;
    console.log('  × [' + m.id + '] 变异**未生效**（替换串没匹配上 ' + m.file + '）—— 这条不算合规\n');
    continue;
  }
  fs.writeFileSync(dst, mut, 'utf8');
  const r = runSuite();
  fs.copyFileSync(path.join(ROOT, m.file), dst);   // 立刻还原副本

  const lines = r.out.split(/\r?\n/);
  const hit = lines.find((l) => l.includes('× FAIL') && l.includes(m.expect)) || '';
  if (!RAN_OK.test(r.out)) {
    unv += 1;
    console.log('  ? UNVERIFIED  ' + m.id);
    console.log('        └ 套件**未跑完**（没有汇总行）⇒ 这次变异什么都没验到，不许算合规');
    console.log('        └ 输出尾部：' + r.out.slice(-300).replace(/\s+/g, ' '));
  } else if (r.code !== 0 && hit) {
    good += 1;
    console.log('  PASS  ' + m.id + '\n        └ 变红于：' + hit.trim());
  } else {
    bad += 1;
    console.log('  × FAIL  ' + m.id);
    console.log('        └ 期望断言含「' + m.expect + '」；实际退出码=' + r.code + (hit ? '' : '（该断言未变红）'));
    if (!hit) {
      const anyFail = lines.filter((l) => l.includes('× FAIL')).slice(0, 3);
      console.log('        └ 实际红的是：' + (anyFail.join(' | ') || '(没有任何 FAIL 行 —— 套件跑完了却全绿 ⇒ 真·假绿)'));
    }
  }
  console.log('');
}

console.log('=== 反证结果 ===');
console.log('  合规 ' + good + ' / ' + MUT.length +
  (bad ? '   ★ 不合规 ' + bad + ' 条（打不红）' : '') +
  (unv ? '   ★ 不可判定 ' + unv + ' 条（套件崩了，等于没验）' : '') + '\n');
process.exit(bad || unv ? 1 : 0);
