/* 反证 v10.44：把本轮**新增/改写的判据**逐个打坏，对应套件必须变红。
 *
 * 本轮改了什么（用户口径）：
 *   ① 手游的样式更新 + 划分模块 MOD / 存档 / 修改器
 *   ② 手机专区回归「手机中心 + 机型兼容 + 模拟器指南」
 *   ③ 详情页新增的 mod/存档/修改器 要分区
 *   ⇒ 落地为「新建 /resources.html 第 4 张派生页 + 手机专区收缩为 3 页签 + 守卫放宽 IS_SUB_PAGE」。
 *
 * 铁律（v10.39 用血换来的，逐条照做）：
 *   · 「变异把它弄坏了」≠「变异按设计弄坏了它」⇒ 每个变异必须先 selfCheck 生效，
 *     否则该组判「作废」，且**不算已抓住**（也不许算失败）。
 *   · 变异必须能加载：改出 SyntaxError 只说明「崩了」，不等于判据抓住了。
 *   · 备份/还原按**字节**，还原后校验 md5。
 *   · 未变异的基线必须先全绿 —— 否则说明不了任何事。
 *   · 失败行识别器**自身**先自检（三套件失败行格式各异，见 DETECT_SAMPLES）。
 *
 * 本轮专守 8 条「坏了不报错」：
 *   ① 顶栏丢了第 4 个入口 ⇒ 端游资源页**没有入口可进**（页面还在，等于隐身）
 *   ② 手机专区漂回一个 tr/sv 页签 ⇒ 点它没反应（key 已不在本页 ET_MAP）
 *   ③ 资源页 ET_MAP 漏 key ⇒ 点页签切到不存在的分区（一片空白，不报错）
 *   ④ 存档默认口径继承旧默认（仅看手机能玩）⇒ 端游资源语境下默认只给 1/6
 *   ⑤ 两页复用同一套页签类名 ⇒ 改 A 页样式意外改到 B 页（用户对样式基线的要求）
 *   ⑥ 幂等哨兵锚到不存在的函数 ⇒ 每跑一次重复注入整份驱动脚本（v9.3 坑 11）
 *   ⑦ 改主源不重建派生页 ⇒ 样式/顶栏/脚本悄悄漂移（本项目最容易犯的错）
 *   ⑧ 资源页骨架缺一个节点 ⇒ 切过去少一个筛选开关（存在≠可见的反面：不存在却看不出来）
 */
const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const crypto = require('crypto');

const ROOT = path.join(__dirname, '..');
const md5 = (b) => crypto.createHash('md5').update(b).digest('hex').slice(0, 10);
const p = (f) => path.join(ROOT, f);
const readTxt = (f) => fs.readFileSync(p(f), 'utf8');
const write = (f, s) => fs.writeFileSync(p(f), s);

/* ---------- 失败行识别器 ---------- */
/* ★ 本项目三套件格式已逐一核对（本轮全部用 `× FAIL`，但识别器按「都认」写，
 *   免得将来某个套件换格式时**反证把自己骗了**）：
 *     test-emulator-structure.js  `  × FAIL  name   [实际 N]`
 *     test-resource-page.js       `  × FAIL  name   [class=…]`
 *     test-emulator-page.js       `  × FAIL  name`
 *     test-pages-sync.js          `  × FAIL  name  — detail` */
const FAIL_RE = /^\s*(?:[×✗✘]|FAIL\b)/;
const run = (suite) => {
  const r = cp.spawnSync(process.execPath, [path.join(ROOT, 'tools', suite)], { cwd: ROOT, encoding: 'utf8', maxBuffer: 1e8 });
  const out = (r.stdout || '') + (r.stderr || '');
  return { code: r.status, out, fails: out.split(/\r?\n/).filter((l) => FAIL_RE.test(l)) };
};

const DETECT_SAMPLES = [
  ['  × FAIL  首页顶栏恰好 4 个入口（首页 / 手机专区 / 端游资源 / 解包匹配）   [实际 3]', true],
  ['  × FAIL  独立页已彻底摘掉「修改器」页签（tr 已搬 /resources.html）', true],
  ['  × FAIL  ET_MAP 覆盖全部 3 个分区（漏一个就有页签点了没反应）', true],
  ['  × FAIL  存档「仅看手机能玩」默认**关闭**（本页是端游资源语境，默认给全量）   [class=emu-refresh sv em-tg]', true],
  ['  × FAIL  ★ CSS 与主源同步（未落后）  — 主源 CSS 尾部已变 → 请重跑对应的 build-*.js', true],
  ['  × FAIL  生成器幂等哨兵锚在 initMd 上（v9.3 曾锚在已删函数上导致重复注入）', true],
  ['  PASS  端游资源页 <style> 唯一', false],
  ['  PASS  ★ 通用脚本与主源同步（函数无缺失）  — 126 个函数齐备', false],
  ['结构体检：164 / 164 通过', false],
  ['结果：68 / 68 通过', false],
  ['  通过 40/40（失败 0）', false],
];
const detBad = DETECT_SAMPLES.filter(([l, want]) => FAIL_RE.test(l) !== want);
if (detBad.length) {
  console.log('★ 失败行识别器自检未过：' + detBad.map(([l]) => JSON.stringify(l.trim().slice(0, 46))).join(' ｜ '));
  process.exit(4);
}
console.log('探针自检：失败行识别器 ' + DETECT_SAMPLES.length + ' 个样本（含四套件真实格式 + 三种汇总行）判定全部正确');

/* ---------- 被守护的文件（字节级快照） ---------- */
const GUARDED = [
  'public/index.html',          /* 主源 */
  'public/emulator.html',       /* 派生页 1 */
  'public/resources.html',      /* 派生页 2（本轮新建） */
  'tools/build-resource-page.js',
  'tools/resource-sections.js',
];
const snap = {};
for (const f of GUARDED) snap[f] = fs.existsSync(p(f)) ? fs.readFileSync(p(f)) : null;
const restoreAll = () => {
  for (const f of GUARDED) if (snap[f] !== null) write(f, snap[f]);
};

/* ---------- 起始环境自检：快照必须是「没被上轮反证污染」的原状 ---------- */
/* 判据：主源里有 navRes（本轮新增的入口），资源页里有 res-tab。
 * 两者任一缺失 ⇒ 盘上是残留变异载荷，直接拒跑（否则基线就红，反证没意义）。 */
if (!readTxt('public/index.html').includes('id="navRes"')) {
  console.log('★ 主源里找不到 #navRes ⇒ 盘上疑似残留变异载荷，请先人工确认再跑反证。');
  process.exit(3);
}
if (!readTxt('public/resources.html').includes('class="res-tab')) {
  console.log('★ public/resources.html 里找不到 .res-tab ⇒ 盘上疑似残留变异载荷（或派生页没重建）。');
  process.exit(3);
}

/* ---------- 变异定义 ---------- */
const CASES = [
  {
    name: '① 顶栏删掉第 4 个入口「端游资源」（页面还在，但没人进得去）',
    suite: 'test-emulator-structure.js', file: 'public/index.html',
    apply: () => {
      const t = readTxt('public/index.html');
      const n = t.replace('<a href="/resources.html" id="navRes">🎮 端游资源</a>', '');
      write('public/index.html', n); return n !== t;
    },
    selfCheck: () => !readTxt('public/index.html').includes('id="navRes"'),
    why: '新页没有入口可进 = 隐身（且首页看起来完全正常）',
  },
  {
    name: '② 手机专区漂回一个「修改器」页签（tr 已搬走，key 不在本页 ET_MAP）',
    suite: 'test-emulator-structure.js', file: 'public/emulator.html',
    apply: () => {
      const t = readTxt('public/emulator.html');
      const n = t.replace('<div class="emu-tabs" id="emuTabs">',
        '<div class="emu-tabs" id="emuTabs">\n    <button class="emu-tab" data-et="tr" type="button">修改器</button>');
      write('public/emulator.html', n); return n !== t;
    },
    selfCheck: () => readTxt('public/emulator.html').includes('data-et="tr"'),
    why: '点它没反应（switchEmuTab 对不在 ET_MAP 里的 key 直接 return），用户以为页面坏了',
  },
  {
    name: '③ 资源页 ET_MAP 漏掉 md（点「MOD」页签切到不存在的分区）',
    suite: 'test-emulator-structure.js', file: 'public/resources.html',
    apply: () => {
      const t = readTxt('public/resources.html');
      const n = t.replace("ET_MAP = { md: '#mods', sv: '#resSaves', tr: '#resTrainers' }",
        "ET_MAP = { sv: '#resSaves', tr: '#resTrainers' }");
      write('public/resources.html', n); return n !== t;
    },
    selfCheck: () => readTxt('public/resources.html').includes("ET_MAP = { sv: '#resSaves'"),
    why: '切过去一片空白，控制台不报错 —— 本项目最阴的一类',
  },
  {
    name: '④ 存档默认口径继承旧默认（仅看手机能玩）⇒ 端游语境下默认只给 1/6',
    suite: 'test-resource-page.js', file: 'public/resources.html',
    apply: () => {
      const t = readTxt('public/resources.html');
      const n = t.replace("const svState = { q: '', sort: 'paths', phone: false,",
        "const svState = { q: '', sort: 'paths', phone: true,");
      write('public/resources.html', n); return n !== t;
    },
    selfCheck: () => readTxt('public/resources.html').includes("sort: 'paths', phone: true,"),
    why: '搬家的经典遗漏：代码搬了、默认口径没搬 ⇒ 6625 款变 1163 款，页面上看不出异常',
  },
  {
    name: '⑤ 两页复用同一套页签类名（.res-tab 上**追加** .emu-tab token）',
    suite: 'test-emulator-structure.js', file: 'public/resources.html',
    /* ★ 变异要**窄**。两版教训：
     *   1) 「class="res-tab on" 整个换成 class="emu-tab on"」⇒ 命中「页签恰好 3 个 [实际 2]」——
     *      页签计数也一起掉了，抓住它的不是「类名隔离」那条；
     *   2) 于是改成「追加到尾部」，结果**两条都没红** —— 暴露了隔离判据当时是按
     *      字符串前缀 `.test('<button class="emu-tab')` 写的，追加就能绕过。
     *   ⇒ 先把判据改成按**类名 token** 判，再用「追加」这个窄变异复验。
     *      （这条正是反证的价值：不是「验证判据生效」，而是**发现判据写错了**。） */
    apply: () => {
      const t = readTxt('public/resources.html');
      const n = t.replace('<button class="res-tab on" data-et="md"', '<button class="res-tab on emu-tab" data-et="md"');
      write('public/resources.html', n); return n !== t;
    },
    selfCheck: () => readTxt('public/resources.html').includes('<button class="res-tab on emu-tab"'),
    why: '改手机专区页签样式会意外改到资源页（用户对样式基线的要求）',
  },
  {
    name: '⑥ 幂等哨兵锚到不存在的函数（v9.3 坑 11：每跑一次重复注入整份驱动脚本）',
    suite: 'test-emulator-structure.js', file: 'tools/build-resource-page.js',
    apply: () => {
      const t = readTxt('tools/build-resource-page.js');
      const n = t.replace('const SEC_SENTINEL = /function initMd\\s*\\(/;', 'const SEC_SENTINEL = /function initRes\\s*\\(/;');
      write('tools/build-resource-page.js', n); return n !== t;
    },
    selfCheck: () => readTxt('tools/build-resource-page.js').includes('function initRes'),
    why: '哨兵失效后重建会再注入一整份 → initMd 定义两次 → 页面直接崩',
  },
  {
    name: '⑦ 改了主源 CSS 但没重建派生页（本项目最容易犯、最难发现的错）',
    suite: 'test-pages-sync.js', file: 'public/index.html',
    apply: () => {
      const L = readTxt('public/index.html').split(/\r?\n/);
      const i = L.findIndex((l) => l.trim() === '</style>');
      if (i < 0) return false;
      L.splice(i, 0, '.cp1044-canary{color:#010203}');
      write('public/index.html', L.join('\r\n')); return true;
    },
    selfCheck: () => readTxt('public/index.html').includes('.cp1044-canary'),
    why: '派生页不报错，只是样式慢慢漂移、顶栏少入口 —— 首页看起来完全正常',
  },
  {
    name: '⑧ 资源页骨架缺一个开关节点（#svCloud 丢了）',
    suite: 'test-emulator-structure.js', file: 'public/resources.html',
    apply: () => {
      const t = readTxt('public/resources.html');
      const n = t.replace('id="svCloud"', 'id="svCloudMissing"');
      write('public/resources.html', n); return n !== t;
    },
    selfCheck: () => !readTxt('public/resources.html').includes('id="svCloud"'),
    why: '「云同步」筛选凭空消失，但页面不报错；驱动脚本 getElementById 拿到 null 后静默跳过绑定',
  },
];

/* ---------- 基线：未变异必须先全绿 ---------- */
const SUITES_USED = ['test-emulator-structure.js', 'test-resource-page.js', 'test-pages-sync.js'];
console.log('\n=== 基线（未变异）===');
const baselineBad = [];
for (const s of SUITES_USED) {
  const r = run(s);
  if (r.code !== 0) baselineBad.push(s);
  console.log('  ' + s.padEnd(30) + ' exit=' + r.code + (r.code === 0 ? '  ✓ 绿' : '  ★ 基线就是红的') +
    (r.fails.length ? '  ← ' + r.fails[0].trim().slice(0, 80) : ''));
}
if (baselineBad.length) {
  console.log('\n★ 基线不绿，反证没有意义 ⇒ 中止。红的套件：' + baselineBad.join(', '));
  console.log('  （提醒：test-resource-page.js 需要 8123 在跑，别在跑防线时把服务杀掉）');
  restoreAll();
  process.exit(2);
}

/* ---------- 逐个变异 ---------- */
console.log('\n=== 逐条反证 ===');
const results = [];
for (const c of CASES) {
  const applied = c.apply();
  const live = c.selfCheck();
  if (!applied || !live) {
    results.push({ name: c.name, verdict: '作废', note: '变异未按设计生效（applied=' + applied + ' live=' + live + '）' });
    console.log('  ' + c.name + '\n      ⇒ 作废（变异未生效，不算已抓住）');
    restoreAll();
    continue;
  }
  const r = run(c.suite);
  const caught = r.code !== 0 && r.fails.length > 0;
  const crashed = r.code !== 0 && r.fails.length === 0 && /SyntaxError|ReferenceError|TypeError/.test(r.out);
  results.push({
    name: c.name, verdict: crashed ? '崩了' : caught ? '已抓住' : '假断言',
    note: caught ? r.fails[0].trim().slice(0, 100) : (crashed ? '变异导致套件崩溃（没有以 FAIL 形式报告）' : '套件仍全绿'),
  });
  console.log('  ' + c.name);
  console.log('      文件 ' + c.file + ' ｜ 期望红于 ' + c.suite + ' ｜ ' + c.why);
  console.log('      ' + (caught ? '✓ 已抓住' : crashed ? '★ 崩了（不等于抓住）' : '★ 假断言 —— 套件仍绿') +
    (r.fails.length ? '\n        命中：' + r.fails[0].trim().slice(0, 100) : '\n        （无 FAIL 行）'));
  restoreAll();
}

/* ---------- 还原核验 ---------- */
console.log('\n=== 还原核验（按字节比 md5）===');
let restoreBad = 0;
for (const f of GUARDED) {
  const now = fs.existsSync(p(f)) ? fs.readFileSync(p(f)) : null;
  const same = (snap[f] === null && now === null) || (snap[f] !== null && now !== null && md5(snap[f]) === md5(now));
  if (!same) { restoreBad++; console.log('  ★ ' + f + ' 未还原一致'); }
}
console.log('  ' + (restoreBad ? restoreBad + ' 个文件未还原' : GUARDED.length + ' 个文件全部按字节还原'));

/* ---------- 还原后复跑：必须回到全绿 ---------- */
console.log('\n=== 还原后复跑（必须回绿，证明上面的红是变异造成的）===');
let afterBad = 0;
for (const s of SUITES_USED) {
  const r = run(s);
  if (r.code !== 0) { afterBad++; console.log('  ★ ' + s + ' 仍红：' + (r.fails[0] || '').trim().slice(0, 90)); }
  else console.log('  ' + s.padEnd(30) + ' → ✓ 绿');
}

/* ---------- 汇总 ---------- */
const n = (v) => results.filter((r) => r.verdict === v).length;
console.log('\n=== 汇总 ===');
console.log('  已抓住 ' + n('已抓住') + ' / ' + CASES.length +
  ' ｜ 假断言 ' + n('假断言') + ' ｜ 崩了 ' + n('崩了') + ' ｜ 作废 ' + n('作废') +
  ' ｜ 还原 ' + (restoreBad ? restoreBad + ' 个失败' : '正常') + ' ｜ 复跑 ' + (afterBad ? afterBad + ' 套仍红' : '全绿'));
const allOk = n('已抓住') === CASES.length && restoreBad === 0 && afterBad === 0;
console.log('  ' + (allOk ? '✓ 全部合规' : '★ 有未达标项'));
process.exit(allOk ? 0 : 1);
