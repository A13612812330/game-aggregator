/* 反证 v10.42：把本轮**改过/新增的判据**逐个打坏，对应套件必须变红。
 *
 * 铁律（v10.39 用血换来的）：
 *   · 「变异把它弄坏了」≠「变异按设计弄坏了它」⇒ 每个变异必须先 selfCheck 生效，
 *     否则该组判「作废」，且**不算已抓住**（也不许算失败）。
 *   · 变异必须能加载：改出 SyntaxError 只说明「崩了」，不等于判据抓住了。
 *   · 备份/还原按**字节**，还原后校验 md5。
 *   · 未变异的基线必须先全绿 —— 否则说明不了任何事。
 *
 * 本轮重点守三条「坏了不报错」：
 *   ① report.js 若还去读已删的 CODEX-INDEX.md ⇒ 读到空串、mv 退化成 '?'、
 *      indexHas 恒 false ⇒ 汇报里悄悄变成「缺 v?」；
 *   ② server.js 若退回「EADDRINUSE 就自增」⇒ 重启失败会静默起出 8124 副实例；
 *   ③ README 若又「往上长」/ CODEX-INDEX.md 若回潮 ⇒ 文档重复与职责不清重来一遍。
 */
const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const crypto = require('crypto');

const ROOT = path.join(__dirname, '..');
const md5 = (b) => crypto.createHash('md5').update(b).digest('hex').slice(0, 10);

/** 失败行识别器。
 *  ★ 踩过（2026-09-28 实测）：旧写法 `/× FAIL|FAIL |✘/` **认不出** `test-launcher.js` 的
 *    `  ✗ FAIL: …`（`FAIL` 后面跟的是冒号不是空格）⇒ 明明已经变红的套件被记成「假断言」，
 *    **反证把自己骗了**。三套件的实际格式已逐一核对：
 *      test-report.js        `  × FAIL  <name>`
 *      test-doc-structure.js `  FAIL  <name>`
 *      test-launcher.js      `  ✗ FAIL: <name>`
 *  ★ 并且**探针自身必须先自检**（见下面 DETECT_SAMPLES）—— 否则「识别器坏了」这一类
 *    会被伪装成「断言是假的」，方向完全反。 */
const FAIL_RE = /^\s*(?:[×✗✘]|FAIL\b)/;
const run = (suite) => {
  const r = cp.spawnSync(process.execPath, [path.join(ROOT, 'tools', suite)], { cwd: ROOT, encoding: 'utf8', maxBuffer: 1e8 });
  const out = (r.stdout || '') + (r.stderr || '');
  return { code: r.status, out, fails: out.split(/\r?\n/).filter((l) => FAIL_RE.test(l)) };
};

/* ---------- 探针自检：失败行识别器 ---------- */
const DETECT_SAMPLES = [
  ['  × FAIL  ★ 索引真源 = docs/versions/README.md（v10.42 起）', true],
  ['  FAIL  根目录无 CODEX-INDEX.md（v10.42 移除：它的版本块与 README 的重复）', true],
  ['  ✗ FAIL: 自增**只在开关打开时**才走', true],
  ['  PASS  docs/versions/README.md 索引行数与日志文件数一致', false],
  ['  ✓ 幂等启动：端口正则必须带尾随空格', false],
  ['通过 54 / 56', false],
];
const detBad = DETECT_SAMPLES.filter(([l, want]) => FAIL_RE.test(l) !== want);
if (detBad.length) {
  console.log('★ 失败行识别器自检未过：' + detBad.map(([l]) => JSON.stringify(l.trim().slice(0, 40))).join(' ｜ '));
  process.exit(4);
}
console.log('探针自检：失败行识别器 ' + DETECT_SAMPLES.length + ' 个样本（含 3 套件各自的真实格式）判定全部正确');

/* ---------- 被守护的文件（字节级快照） ---------- */
const GUARDED = ['tools/report.js', 'tools/test-report.js', 'tools/test-launcher.js', 'tools/test-doc-structure.js',
  'server.js', '启动聚合站.cmd', '启动聚合站-静默.vbs', 'README.md', 'WORKFLOW.md', 'docs/versions/README.md'];
const snap = {};
for (const f of GUARDED) {
  const p = path.join(ROOT, f);
  snap[f] = fs.existsSync(p) ? fs.readFileSync(p) : null;
}
const CODEX_INDEX = path.join(ROOT, 'CODEX-INDEX.md');
const STASH = path.join(ROOT, '_preview');
if (!fs.existsSync(STASH)) fs.mkdirSync(STASH, { recursive: true });

/** 把「不该存在的文件」挪走。
 *  ★ 踩过 1（2026-09-28 实测）：这里原本用 `fs.unlinkSync`，但沙箱的 safe-delete 护栏按
 *    **本回累计删除数**拦（实测 `count=520 > threshold=50`）⇒ 跑到 ⑦ 还原时抛
 *    `SAFE_DELETE_BULK_CONFIRM_REQUIRED`，**进程直接崩、变异载荷留在盘上** ⇒ 下一轮
 *    「基线就红」且报出的 FAIL 与判据无关。
 *  ★ 踩过 2（同轮）：`hadCidx` 取样在「起始环境自检」**之前** ⇒ 残留载荷被当成
 *    「这文件本来就该在」⇒ 还原走 `else` 分支写回一个**空文件**，把后面 ⑧⑨⑩⑪ 四条
 *    全污染成同一个命中（看着像都抓住了，其实测的不是各自那条）。
 *    ⇒ 顺序硬约束：**先清理环境，再取 hadCidx**。
 *  ★ 改法：**改名 ≠ 删除**（本项目既有约定，见 v10.40「旧载荷先改名挪开」），落到 `_preview/`（已 gitignore）。 */
const stashAway = (abs) => {
  if (!fs.existsSync(abs)) return true;
  const tmp = path.join(STASH, '_stashed-' + path.basename(abs) + '-' + Date.now());
  try { fs.renameSync(abs, tmp); return true; } catch (e) {
    console.log('  ★ 无法改名挪走 ' + path.basename(abs) + '：' + e.message);
    return false;
  }
};

/* ---------- 起始环境自检（★ 必须在取 hadCidx 之前跑） ---------- */
/* ★ 上一轮反证被**中途打断**时来不及 restoreAll，变异 ⑦ 的载荷 `CODEX-INDEX.md`
 *   会留在盘上 ⇒ 下一轮「基线就红」，而报出来的 FAIL 是「根目录无 CODEX-INDEX.md」——
 *   看着像判据坏了，其实环境不干净。这里做**身份校验后**才挪走：只认变异载荷本身
 *   （33 B 且内容逐字相同），其余一律拒跑。 */
if (fs.existsSync(CODEX_INDEX)) {
  const b = fs.readFileSync(CODEX_INDEX);
  const t = b.toString('utf8');
  if (t === '# CODEX-INDEX（回潮测试）\r\n') {
    console.log('★ 发现上一轮中断留下的反证载荷 CODEX-INDEX.md（' + b.length + ' B）⇒ 已改名挪走，继续');
    stashAway(CODEX_INDEX);
  } else {
    console.log('★ 根目录存在 CODEX-INDEX.md（' + b.length + ' B），但不是反证载荷 ⇒ 属真实回潮，');
    console.log('  请先人工确认并处理，再跑反证（否则基线必红，反证没有意义）。');
    process.exit(3);
  }
}
const hadCidx = fs.existsSync(CODEX_INDEX);   // ★ 清理之后才取样
const restoreAll = () => {
  for (const f of GUARDED) {
    const p = path.join(ROOT, f);
    if (snap[f] === null) { if (fs.existsSync(p)) stashAway(p); }
    else fs.writeFileSync(p, snap[f]);
  }
  if (!hadCidx) stashAway(CODEX_INDEX);
};
const readTxt = (f) => fs.readFileSync(path.join(ROOT, f), 'utf8');

/* ---------- 变异定义 ---------- */
const CASES = [
  {
    name: '① report.js 的索引真源退回已删的 CODEX-INDEX.md',
    suite: 'test-report.js', file: 'tools/report.js',
    apply: () => { const t = readTxt('tools/report.js'); const n = t.replace("const INDEX_FILE = LOG_DIR + '/README.md';", "const INDEX_FILE = 'CODEX-INDEX.md';"); fs.writeFileSync(path.join(ROOT, 'tools/report.js'), n); return n !== t; },
    selfCheck: () => readTxt('tools/report.js').includes("const INDEX_FILE = 'CODEX-INDEX.md';"),
    why: '读空串不报错 ⇒ 汇报里静默变成「缺 v?」',
  },
  {
    name: '② report.js 读回 CODEX-INDEX.md（在真源之外再加一处 read）',
    suite: 'test-report.js', file: 'tools/report.js',
    apply: () => { const t = readTxt('tools/report.js'); const n = t.replace("const index = read(INDEX_FILE);", "const index = read(INDEX_FILE);\n  const _junk = read('CODEX-INDEX.md');"); fs.writeFileSync(path.join(ROOT, 'tools/report.js'), n); return n !== t; },
    selfCheck: () => readTxt('tools/report.js').includes("read('CODEX-INDEX.md')"),
    why: '判据要求「不再读已删文件」',
  },
  {
    name: '③ runtimeCacheRow 退化成「恒报一致」（取不到也说一致）',
    suite: 'test-report.js', file: 'tools/report.js',
    apply: () => {
      const t = readTxt('tools/report.js');
      const n = t.replace(/function runtimeCacheRow\(local, live\) \{[\s\S]*?\n\}/, "function runtimeCacheRow(local, live) {\n  return '一致（' + ((live && live.v) || 0) + '）';\n}");
      fs.writeFileSync(path.join(ROOT, 'tools/report.js'), n); return n !== t;
    },
    selfCheck: () => /function runtimeCacheRow\(local, live\) \{\r?\n  return '一致/.test(readTxt('tools/report.js')),
    why: '正是 v10.41 漏掉的那类假绿：把「没采到/线上为空」说成「一致」',
  },
  {
    name: '④ server.js 退回「EADDRINUSE 就直接自增」（静默起副实例）',
    suite: 'test-launcher.js', file: 'server.js',
    apply: () => {
      const t = readTxt('server.js');
      const n = t.replace("if (ALLOW_PORT_SHIFT && triesLeft > 0) {", "if (e.code === 'EADDRINUSE' && triesLeft > 0) {");
      fs.writeFileSync(path.join(ROOT, 'server.js'), n); return n !== t;
    },
    selfCheck: () => readTxt('server.js').includes("if (e.code === 'EADDRINUSE' && triesLeft > 0) {"),
    why: '本轮要修的就是它 —— 端口未释放时静默退到 8124',
  },
  {
    name: '⑤ .vbs 退回「固定 sleep 后直接开浏览器」（不再核实是否监听上了）',
    suite: 'test-launcher.js', file: '启动聚合站-静默.vbs',
    apply: () => {
      const t = readTxt('启动聚合站-静默.vbs');
      /* ★ 旧写法（2026-09-28 修）：正则里凭空多写了一个 `End If` —— 实际源码里
       *   `Dim n` 与 `If PortBusy(PORT) Then` 之间**没有** `End If`，于是 replace 不生效、
       *   该组被判「作废」。作废不等于通过，但也等于白测一条 ⇒ 这里按真实形态重写。 */
      const n = t.replace(
        /Dim n\r?\nn = 0\r?\nDo While n < 15\r?\n[\s\S]*?\r?\nLoop\r?\n\r?\nIf PortBusy\(PORT\) Then\r?\n  shell\.Run "http:\/\/localhost:" & PORT, 1, False\r?\nElse/,
        'Dim n\r\nn = 0\r\nWScript.Sleep 2600\r\nIf Not PortBusy(PORT) Then WScript.Sleep 2500\r\nIf PortBusy(PORT) Then\r\n  shell.Run "http://localhost:" & PORT, 1, False\r\nElse');
      fs.writeFileSync(path.join(ROOT, '启动聚合站-静默.vbs'), n); return n !== t;
    },
    selfCheck: () => !/Do While n < 15/.test(readTxt('启动聚合站-静默.vbs')) && /WScript\.Sleep 2600/.test(readTxt('启动聚合站-静默.vbs')),
    why: '启动失败也照样开一个死页面，用户看不出为什么',
  },
  {
    name: '⑥ .cmd 的等待计数塞进小括号块（%WAITS% 被解析期固化）',
    suite: 'test-launcher.js', file: '启动聚合站.cmd',
    apply: () => {
      const t = readTxt('启动聚合站.cmd');
      const n = t.replace('if %WAITS% GEQ 20 goto FREENO', 'if %WAITS% GEQ 20 (\r\n  set /a WAITS+=0\r\n  goto FREENO\r\n)');
      fs.writeFileSync(path.join(ROOT, '启动聚合站.cmd'), n); return n !== t;
    },
    selfCheck: () => /if %WAITS% GEQ 20 \(/.test(readTxt('启动聚合站.cmd')),
    why: '块内 %VAR% 在解析期展开 ⇒ 死循环；判据要求用 goto 循环做比较',
  },
  {
    name: '⑦ CODEX-INDEX.md 回潮（根目录重新出现该文件）',
    suite: 'test-doc-structure.js', file: 'CODEX-INDEX.md',
    apply: () => { fs.writeFileSync(CODEX_INDEX, '# CODEX-INDEX（回潮测试）\r\n'); return true; },
    selfCheck: () => fs.existsSync(CODEX_INDEX),
    why: '重复的版本索引回来 ⇒ 职责又不清楚了',
  },
  {
    name: '⑧ WORKFLOW.md 里重新写「版本索引看 CODEX-INDEX.md」',
    suite: 'test-doc-structure.js', file: 'WORKFLOW.md',
    apply: () => {
      const t = readTxt('WORKFLOW.md');
      const n = t.replace('---\r\n\r\n## 〇、一页速览', '> 版本索引见 `CODEX-INDEX.md`。\r\n\r\n---\r\n\r\n## 〇、一页速览');
      fs.writeFileSync(path.join(ROOT, 'WORKFLOW.md'), n); return n !== t;
    },
    selfCheck: () => readTxt('WORKFLOW.md').includes('版本索引见 `CODEX-INDEX.md`'),
    why: '活文档里不许再把已删文件当索引指路',
  },
  {
    name: '⑨ README 又「往上长」（在 H1 之前插一个版本摘要块）',
    suite: 'test-doc-structure.js', file: 'README.md',
    apply: () => {
      const L = readTxt('README.md').split(/\r?\n/);
      L.unshift('## ★ v10.36 增量（回潮测试）', '');
      fs.writeFileSync(path.join(ROOT, 'README.md'), L.join('\r\n')); return true;
    },
    selfCheck: () => /^## ★ v10\.36 增量/.test(readTxt('README.md').split(/\r?\n/)[0]),
    why: '版本块挤到项目说明前面 ⇒ 访客看不到「这是什么项目」',
  },
  {
    name: '⑩ docs/versions/README.md 索引表删一行（索引与文件漂移）',
    suite: 'test-doc-structure.js', file: 'docs/versions/README.md',
    apply: () => {
      const t = readTxt('docs/versions/README.md');
      const n = t.replace(/^\| \[v10\.40\]\(v10\.40\.md\)[^\n]*\n/m, '');
      fs.writeFileSync(path.join(ROOT, 'docs/versions/README.md'), n); return n !== t;
    },
    selfCheck: () => !/\[v10\.40\]\(v10\.40\.md\)/.test(readTxt('docs/versions/README.md')),
    why: '补了日志文件却忘了补索引行 ⇒ 两边都看不出来',
  },
  {
    name: '⑪ README 里加一行「以 CODEX-INDEX.md 为键的表格行」（守判据收窄后的表格分支）',
    suite: 'test-doc-structure.js', file: 'README.md',
    apply: () => {
      const t = readTxt('README.md');
      const n = t.replace('## 更新日志\r\n', '## 更新日志\r\n\r\n| `CODEX-INDEX.md` | ★★ **版本索引**（回潮测试） |\r\n');
      fs.writeFileSync(path.join(ROOT, 'README.md'), n); return n !== t;
    },
    selfCheck: () => /^\s*\|\s*`CODEX-INDEX\.md`\s*\|/m.test(readTxt('README.md')),
    why: '★ 判据刚为「不误报 changelog」收窄过（只判指路形态）—— 表格键这一支必须另有反证，否则收了窄还抓不住',
  },
];

/* ---------- 基线：未变异必须先全绿 ---------- */
console.log('=== 基线（未变异）===');
const baseFail = {};
for (const s of ['test-report.js', 'test-launcher.js', 'test-doc-structure.js']) {
  const r = run(s);
  baseFail[s] = r.code;
  console.log('  ' + s.padEnd(24) + ' exit=' + r.code + (r.code === 0 ? '  ✓ 绿' : '  ★ 基线就是红的') +
    (r.fails.length ? '  ← ' + r.fails[0].trim().slice(0, 80) : ''));
}
const baselineBad = Object.entries(baseFail).filter(([, c]) => c !== 0).map(([s]) => s);
if (baselineBad.length) {
  console.log('\n★ 基线不绿，反证没有意义 ⇒ 中止。红的套件：' + baselineBad.join(', '));
  restoreAll();
  process.exit(2);
}

/* ---------- 逐个变异 ---------- */
console.log('\n=== 逐条反证 ===');
const results = [];
for (const c of CASES) {
  const applied = c.apply();
  const live = c.selfCheck();
  if (!applied || !live) {
    results.push({ name: c.name, verdict: '作废', note: '变异未按设计生效（applied=' + applied + ' live=' + live + '）' });
    console.log('  ' + c.name + '\n      ⇒ 作废（变异未生效，不算已抓住）');
    restoreAll();
    continue;
  }
  const r = run(c.suite);
  const caught = r.code !== 0 && r.fails.length > 0;
  const crashed = r.code !== 0 && r.fails.length === 0 && /SyntaxError|ReferenceError|TypeError/.test(r.out);
  results.push({
    name: c.name, verdict: crashed ? '崩了' : caught ? '已抓住' : '假断言',
    note: caught ? r.fails[0].trim().slice(0, 96) : (crashed ? '变异导致套件崩溃（没有以 FAIL 形式报告）' : '套件仍全绿'),
  });
  console.log('  ' + c.name);
  console.log('      ' + (caught ? '✓ 已抓住' : crashed ? '★ 崩了（不等于抓住）' : '★ 假断言 —— 套件仍绿') +
    (r.fails.length ? '\n        命中：' + r.fails[0].trim().slice(0, 96) : '\n        （无 FAIL 行）'));
  restoreAll();
}

/* ---------- 还原核验 ---------- */
console.log('\n=== 还原核验（按字节比 md5）===');
let restoreBad = 0;
for (const f of GUARDED) {
  const p = path.join(ROOT, f);
  const now = fs.existsSync(p) ? fs.readFileSync(p) : null;
  const same = (snap[f] === null && now === null) || (snap[f] !== null && now !== null && md5(snap[f]) === md5(now));
  if (!same) { restoreBad++; console.log('  ★ ' + f + ' 未还原一致'); }
}
console.log('  ' + (restoreBad ? restoreBad + ' 个文件未还原' : GUARDED.length + ' 个文件全部按字节还原'));
console.log('  CODEX-INDEX.md 是否仍不存在:', !fs.existsSync(CODEX_INDEX));

/* ---------- 汇总 ---------- */
const n = (v) => results.filter((r) => r.verdict === v).length;
console.log('\n=== 汇总 ===');
console.log('  已抓住 ' + n('已抓住') + ' / ' + CASES.length +
  ' ｜ 假断言 ' + n('假断言') + ' ｜ 崩了 ' + n('崩了') + ' ｜ 作废 ' + n('作废') +
  ' ｜ 还原 ' + (restoreBad ? restoreBad + ' 个失败' : '正常'));
const okAll = n('已抓住') === CASES.length && restoreBad === 0 && !fs.existsSync(CODEX_INDEX);
console.log('  ' + (okAll ? '✓ 全部合规' : '★ 有未达标项'));
process.exit(okAll ? 0 : 1);
