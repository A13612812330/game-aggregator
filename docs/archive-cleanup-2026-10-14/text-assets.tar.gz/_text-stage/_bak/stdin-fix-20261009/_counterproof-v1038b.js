#!/usr/bin/env node
/* _counterproof-v1038b.js —— v10.38 补（线上判定加服务端判据）的反证
 *
 * 用途：把 tools/report.js 里**新加的每一条判据**逐条打坏，确认 tools/test-report.js 会变红。
 * 判据坏了却不变红 = 假断言（守了个寂寞），比没写还危险 —— 因为它让人以为已经守住了。
 *
 * 手法：**就地变异**（report.js 太大，且 test-report.js 依赖 .git / 十余份文档，
 *       复制到别处会因缺 .git 直接崩 ⇒ 只能就近改）。所以：
 *       ① 先把原文件按**字节**备份；② 每个变异跑一遍套件；③ 无论成败都还原；
 *       ④ 末了比对 md5 证明「文件已完全还原」。
 *       ★ 还原失败会让 report.js 留在坏状态 ⇒ 必须用 try/finally + 末位 md5 校验。
 *
 * 三种判定（与 v10.38 的 daily-sync 反证一致）：
 *   有 FAIL            ⇒ 已抓住
 *   无 FAIL 且退出码≠0 ⇒ 崩了（变异体加载不了/套件自身炸了）—— **不算抓住**
 *   无 FAIL 且退出码=0 ⇒ ★★ 假断言
 *
 * tools/_* 已在 .gitignore，本文件不入库。跑完可删。
 */
'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execFileSync } = require('child_process');

const ROOT = path.join(__dirname, '..');
const TARGET = path.join(ROOT, 'tools', 'report.js');
const SUITE = path.join(ROOT, 'tools', 'test-report.js');
const md5 = (s) => crypto.createHash('md5').update(s).digest('hex');

const ORIG = fs.readFileSync(TARGET, 'utf8');
const ORIG_MD5 = md5(ORIG);

/* ================= 变异清单 =================
   from 必须在原文里**恰好出现一次**（出现 0 次 = 变异没生效，
   ★ 那会让「没变红」看起来像假断言，其实是变异写错了 ⇒ 必须单独判） */
const VARIANTS = [
  {
    name: '① 线上缺指纹也算「一致」（missing 恒空）',
    from: '  const missing = SERVER_FEATURES.filter((f) => !probe.has[f.key]);',
    to: '  const missing = SERVER_FEATURES.filter((f) => false);',
    expect: '「本地有 + 线上没有 ⇒ 线上旧」必须红',
  },
  {
    name: '② 删掉「本地源码找不到指纹 ⇒ 判据失效」护栏',
    from: "  const lost = SERVER_FEATURES.filter((f) => !f.srcRe.test(localSrc || ''));",
    to: '  const lost = SERVER_FEATURES.filter((f) => false);',
    expect: '「判据失效不许静默放行」必须红',
  },
  {
    name: '③ 判据失效时仍返回 ok:true（静默放行的另一半）',
    from: "    return { ver: '本地源码里找不到 `' + lost[0].key + '` ⇒ 判据失效（先去修 report.js）', missing: [], ok: false };",
    to: "    return { ver: '本地源码里找不到 `' + lost[0].key + '` ⇒ 判据失效（先去修 report.js）', missing: [], ok: true };",
    expect: '同上一条断言必须红',
  },
  {
    name: '④ 剥注释失效（archRule 会被注释撑成假绿）',
    from: "const stripComments = (s) => s.replace(/\\/\\*[\\s\\S]*?\\*\\//g, '').replace(/(^|[^:])\\/\\/.*$/gm, '$1');",
    to: 'const stripComments = (s) => s;',
    expect: '「stripComments 真的剥掉块注释」必须红',
  },
  {
    name: '⑤ 服务端缺指纹时仍渲染成 ✓',
    from: "  return SERVER_FEATURES.map((f) => f.key + ((probe && probe.has && probe.has[f.key]) ? ' ✓' : ' ✗（本地有）')).join(' · ');",
    to: "  return SERVER_FEATURES.map((f) => f.key + ' ✓').join(' · ');",
    expect: '「缺该指纹时那一行必须出现 ✗」必须红',
  },
  {
    name: '⑥ 退回归「只看 index.html md5 就判已是最新」',
    from: "    p('| 判定 | ' + verdict + ' |');",
    to: "    p('| 判定 | ' + (live.same ? '✅ 与本地逐字节一致 = 已是最新' : verdict) + ' |');",
    expect: '反向断言（已删掉单判据写法）必须红',
  },
  {
    name: '⑦ 不真去探测服务端，用硬编码 stub 冒充',
    from: "    const srv = await probeServer(LINKS.LIVE.replace(/\\/$/, ''));",
    to: "    const srv = { ok: true, http: 200, has: { archRule: true }, err: null, api: '/api/spec/dict' };",
    expect: '「真的去探测服务端接口」必须红',
  },
  {
    name: '⑧ 前端同版但服务端旧时，弱化文案（去掉「不能判为已是最新」）',
    from: "    else verdict = '⚠️ 前端同版，但 ' + sv.ver + ' ⇒ **不能判为已是最新**';",
    to: "    else verdict = '⚠️ 前端同版，但 ' + sv.ver;",
    expect: '「明确写不能判为已是最新」必须红',
  },
];

function runSuite() {
  try {
    const out = execFileSync(process.execPath, [SUITE], { cwd: ROOT, encoding: 'utf8', maxBuffer: 1 << 26 });
    return { code: 0, out };
  } catch (e) {
    return { code: e.status == null ? -1 : e.status, out: String((e.stdout || '') + (e.stderr || '')) };
  }
}

function failsOf(out) {
  return out.split(/\r?\n/).filter((l) => /× FAIL/.test(l));
}

function restore() {
  fs.writeFileSync(TARGET, ORIG);
}

let caught = 0, missed = [], crashed = [], noop = [];

/* ===== 第 0 步：未变异基线必须先全绿 =====
   ★ 基线不绿的话，下面「变红了」就说明不了任何事（可能本来就是红的）。 */
console.log('=== 第 0 步：未变异基线 ===');
const base = runSuite();
const baseFails = failsOf(base.out);
const baseLine = base.out.split(/\r?\n/).filter((l) => /^结果/.test(l))[0] || '(没读到结果行)';
console.log('  ' + baseLine + '  ·  退出码 ' + base.code + '  ·  FAIL ' + baseFails.length + ' 条');
if (base.code !== 0 || baseFails.length) {
  console.log('  ✗ 基线不绿 ⇒ 反证无意义，先修好再跑。');
  process.exit(2);
}
console.log('  ✓ 基线全绿，可以开始变异\n');

console.log('=== 变异 ===');
try {
  for (const v of VARIANTS) {
    const hits = ORIG.split(v.from).length - 1;
    if (hits !== 1) {
      noop.push({ name: v.name, hits });
      console.log('  ? 变异未生效（from 命中 ' + hits + ' 次，应为 1）：' + v.name);
      continue;
    }
    fs.writeFileSync(TARGET, ORIG.replace(v.from, v.to));
    const r = runSuite();
    restore();
    const fs2 = failsOf(r.out);
    if (fs2.length) {
      caught++;
      console.log('  ✓ 已抓住：' + v.name);
      console.log('      红：' + fs2.map((l) => l.replace(/^\s*× FAIL\s*/, '').split('  — ')[0]).join(' / ').slice(0, 180));
    } else if (r.code !== 0) {
      crashed.push(v.name);
      console.log('  ✗ 崩了（不算抓住）：' + v.name + '  退出码 ' + r.code);
    } else {
      missed.push(v.name);
      console.log('  ★★ 假断言：' + v.name + '  —— 打坏了却全绿（期望：' + v.expect + '）');
    }
  }
} finally {
  restore();
}

/* ===== 末位校验：文件必须**字节级**还原 ===== */
const after = md5(fs.readFileSync(TARGET, 'utf8'));
console.log('\n=== 回验 ===');
console.log('  报告脚本 md5 : ' + after + (after === ORIG_MD5 ? '  ✓ 与变异前一致（已完全还原）' : '  ✗✗ 与变异前不一致！必须手工修回'));
console.log('  合规 : ' + caught + ' / ' + VARIANTS.length + ' 条被抓住');
if (missed.length) console.log('  ★★ 假断言：\n    - ' + missed.join('\n    - '));
if (crashed.length) console.log('  ✗ 崩了（不算抓住）：\n    - ' + crashed.join('\n    - '));
if (noop.length) console.log('  ? 变异未生效（清单写错了，等于漏测）：\n    - ' + noop.map((n) => n.name + '（命中 ' + n.hits + ' 次）').join('\n    - '));

const bad = missed.length || crashed.length || noop.length || after !== ORIG_MD5;
process.exit(bad ? 1 : 0);
