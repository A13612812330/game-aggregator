/* 一次性迁移：根目录 39 份 CODEX-DONE-v10.*.md → docs/versions/v10.*.md
 *
 * 背景（用户 2026-09-28 要求）：
 *   ① 仓库根目录被 39 个版本日志"铺满"，GitHub 上第一屏看不见源码
 *      （截图可见 CODEX-DONE-v10.1 / v10.10 / v10.11 … 一路排下去）
 *   ② 项目已由 WorkBuddy 全权负责，不再由 Codex 负责 ⇒ 去掉 `CODEX-DONE-` 前缀
 *   ③ 以后每次更新都要留一份 md 日志，需要有**固定的留档目录**
 *
 * 迁移矩阵（就这几类形态，117 种上下文归并而成）：
 *   A 标题行           `# CODEX-DONE-v10.N —— …`        → `# v10.N —— …`
 *   B 反引号引用（活引用）`` `CODEX-DONE-v10.M.md` ``     → 可点击 md 链接
 *   C 纯路径文本       `…\game-aggregator\CODEX-DONE-…`  → `…\game-aggregator\docs\versions\…`
 *   D HTML 注释        `见 CODEX-DONE-v10.30`            → `见 docs/versions/v10.30.md`
 *
 * ★ 字节安全：所有替换都在**整串**上做 String.replace，不 split/join ⇒ 行尾（CRLF/LF）
 *   原样保留。改完逐个校验行尾构成与迁移前一致。
 *
 * 用法：
 *   node tools/_migrate-logs-v1040.js --dry     # 只打印矩阵与替换计数
 *   node tools/_migrate-logs-v1040.js           # 真正执行（git mv + 改内容）
 */
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const crypto = require('crypto');

const ROOT = path.join(__dirname, '..');
const DEST_REL = 'docs/versions';
const DEST = path.join(ROOT, 'docs', 'versions');
const DRY = process.argv.includes('--dry');

const md5 = (s) => crypto.createHash('md5').update(s).digest('hex').slice(0, 8);
const crlf = (s) => (s.match(/\r\n/g) || []).length;

/* ---------- 1. 枚举待迁移文件 ---------- */
const RE_LOG = /^CODEX-DONE-v10\.(\d+)\.md$/;
const logs = fs.readdirSync(ROOT)
  .filter((f) => RE_LOG.test(f))
  .map((f) => ({ old: f, minor: Number(RE_LOG.exec(f)[1]) }))
  .sort((a, b) => a.minor - b.minor);

console.log('=== 迁移矩阵 ===');
console.log('根目录待迁移版本日志：' + logs.length + ' 份');
const minors = logs.map((x) => x.minor);
const maxM = Math.max(...minors);
const gaps = [];
for (let i = 1; i <= maxM; i++) if (!minors.includes(i)) gaps.push(i);
console.log('版本区间：v10.' + Math.min(...minors) + ' ~ v10.' + maxM + '（缺号：' + (gaps.length ? gaps.join(',') : '无') + '）');
for (const x of logs) x.nw = 'v10.' + x.minor + '.md';
logs.forEach((x) => console.log('  ' + x.old.padEnd(24) + ' → ' + DEST_REL + '/' + x.nw));

if (gaps.length) { console.error('\n★ 版本号不连续，先查清再迁移'); process.exit(1); }

/* ---------- 2. 待改内容的文件清单 ---------- */
const ROOT_DOCS = ['README.md', 'CODEX-INDEX.md', 'HANDOFF.md', 'CODEX-HANDOFF.md',
  'CODEX-TASKS.md', 'WORKFLOW.md', 'ROADMAP.md', 'PITFALLS.md', 'DESIGN.md'];
const HTML = ['public/index.html'];           // ★ 只改主源，派生页由构建脚本重建
const TOOLS_JS = ['tools/test-doc-structure.js', 'tools/_upd-docs-v1035b.js'];

/* ---------- 3. 替换规则 ----------
 * ★ 实测：日志标题有**四种不一致形态**，只匹配一种会漏掉 35/39 份：
 *     `# CODEX-DONE-v10.N`（连字符，7 处）· `# CODEX-DONE v10.N`（空格，20 处）
 *     `# GameHub v10.N`（2 处）· `# v10.N`（已规范）
 *   ⇒ 用统一的归一化正则，并把 `CODEX-DONE[-\s]+` 一律吃掉。 */
const CD = 'CODEX-DONE[-\\s]+v10\\.(\\d+)';
const reg = (src, flags) => new RegExp(src, flags);

/* prefix：'' = 同目录（docs/versions 内部互引）；'docs/versions/' = 根目录文档指向 */
function rulesFor(prefix, kind) {
  const link = (m) => '[' + m + '](' + prefix + m + '.md)';
  const r = [
    /* A 标题归一并去掉旧前缀（只动行首 # 行） */
    ['A 标题归一', /^#\s*(?:CODEX-DONE[-\s]+|GameHub\s+)?v10\.(\d+)/gm, '# v10.$1'],
    /* B 反引号引用 → 可点击 md 链接 */
    ['B 引用→链接', reg('`' + CD + '\\.md`', 'g'), (m, n) => '[v10.' + n + '](' + prefix + 'v10.' + n + '.md)'],
    /* C 路径文本（Windows 反斜杠全路径）—— 仅根文档需要 */
    ['C 全路径', reg('game-aggregator\\\\' + CD + '\\.md', 'g'),
      (m, n) => 'game-aggregator\\' + prefix.replace(/\//g, '\\') + 'v10.' + n + '.md'],
    /* D 纯文件名 */
    ['D 纯文件名', reg(CD + '\\.md', 'g'), (m, n) => prefix + 'v10.' + n + '.md'],
    /* E 裸版本号（无 .md） */
    ['E 裸版本号', reg(CD, 'g'), (m, n) => prefix + 'v10.' + n],
  ];
  if (kind === 'log') {
    /* F 日志里还有 `GameHub v10.N` 的行文提及 */
    r.push(['F GameHub 提及', /GameHub\s+v10\.(\d+)/g, 'v10.$1']);
  }
  return r;
}

/* ---------- 4. 执行（或只统计） ---------- */
const plan = [];

function planFile(p, rules, label) {
  const abs = path.join(ROOT, p);
  if (!fs.existsSync(abs)) { plan.push({ p, label, skip: '不存在' }); return; }
  const before = fs.readFileSync(abs, 'utf8');
  let cur = before;
  const detail = [];
  for (const [name, re, rep] of rules) {
    const m = cur.match(re);
    const n = m ? m.length : 0;
    if (n) { cur = cur.replace(re, rep); detail.push(name + '×' + n); }
  }
  if (cur === before) { plan.push({ p, label, skip: '内容无变化' }); return; }
  plan.push({ p, label, detail, before, after: cur, md5b: md5(before), md5a: md5(cur),
    crlfb: crlf(before), crlfa: crlf(cur) });
}

/* ★ dry 阶段日志文件还在根目录（尚未 mv）⇒ 按**当前路径**统计，
 *   内容与迁移后完全一致，所以计数等价、且能真正看到要改什么。 */
const logPaths = () => (DRY ? logs.map((x) => x.old) : logs.map((x) => DEST_REL + '/' + x.nw));

/* ★ 每个文件都新建一组正则：带 /g 的正则对象有 lastIndex 状态，跨文件复用会漏匹配 */
const LOGS_R = () => rulesFor('', 'log');
const ROOT_R = () => rulesFor('docs/versions/', 'root');
const HTML_R = () => rulesFor('docs/versions/', 'root');
const TOOL_R = () => rulesFor('docs/versions/', 'root');

console.log('\n=== 内容改写计划 ===');
for (const p of logPaths()) planFile(p, LOGS_R(), '日志');
for (const f of ROOT_DOCS) planFile(f, ROOT_R(), '根文档');
for (const f of HTML) planFile(f, HTML_R(), '主源页');
for (const f of TOOLS_JS) planFile(f, TOOL_R(), '工具');

let totalHits = 0, touched = 0;
for (const r of plan) {
  if (r.skip) { console.log('  --  ' + r.p + '  （' + r.skip + '）'); continue; }
  touched++;
  const n = r.detail.reduce((a, s) => a + Number(s.split('×')[1]), 0);
  totalHits += n;
  console.log('  ✔  ' + r.p.padEnd(34) + r.detail.join(' · ') +
    '   行尾 ' + r.crlfb + '→' + r.crlfa + (r.crlfb === r.crlfa ? ' ok' : ' ★变化'));
}
console.log('\n涉及文件 ' + touched + ' 个 · 替换 ' + totalHits + ' 处');

if (DRY) { console.log('\n--dry：未做任何写入。'); process.exit(0); }

/* ---------- 5. 真跑 ---------- */
console.log('\n=== 执行 ===');
fs.mkdirSync(DEST, { recursive: true });
for (const x of logs) {
  execFileSync('git', ['mv', x.old, DEST_REL + '/' + x.nw], { cwd: ROOT, stdio: 'pipe' });
}
console.log('  git mv 完成：' + logs.length + ' 份');

const written = [];
function applyFile(p, rules, label) {
  const abs = path.join(ROOT, p);
  if (!fs.existsSync(abs)) return;
  const before = fs.readFileSync(abs, 'utf8');
  let cur = before;
  for (const [, re, rep] of rules) cur = cur.replace(re, rep);
  if (cur === before) return;
  if (crlf(before) !== crlf(cur)) throw new Error('行尾被改变：' + p);
  fs.writeFileSync(abs, cur);
  written.push([label, p, md5(before), md5(cur)]);
}
for (const x of logs) applyFile(DEST_REL + '/' + x.nw, LOGS_R(), '日志');
for (const f of ROOT_DOCS) applyFile(f, ROOT_R(), '根文档');
for (const f of HTML) applyFile(f, HTML_R(), '主源页');
for (const f of TOOLS_JS) applyFile(f, TOOL_R(), '工具');

console.log('  改写完成：' + written.length + ' 个文件');
written.forEach(([l, p, b, a]) => console.log('    ' + l + '  ' + p + '  ' + b + ' → ' + a));

/* ---------- 6. 收尾自检 ---------- */
console.log('\n=== 自检 ===');
const rootLeft = fs.readdirSync(ROOT).filter((f) => RE_LOG.test(f));
console.log('  根目录残余 CODEX-DONE-*.md ：' + rootLeft.length + (rootLeft.length ? ' ★' : ' ok'));
const destNow = fs.readdirSync(DEST).filter((f) => /^v10\.\d+\.md$/.test(f));
console.log('  ' + DEST_REL + ' 下 v10.N.md ：' + destNow.length + ' 份' +
  (destNow.length === logs.length ? ' ok' : ' ★ 数量不符'));
