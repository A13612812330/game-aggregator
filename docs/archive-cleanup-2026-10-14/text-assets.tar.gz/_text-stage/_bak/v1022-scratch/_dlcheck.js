const url = process.argv[2];
(async () => {
  const r = await fetch(url);
  const j = await r.json();
  console.log('HTTP ' + r.status + '  ok=' + j.ok);
  if (!j.ok) { console.log('  error: ' + j.error); return; }
  console.log('  title  : ' + j.title);
  console.log('  version: ' + j.version);
  console.log('  可点链接数: ' + j.count);
  for (const x of (j.items || [])) {
    console.log('   [' + (x.real ? '✓' : '✗') + '] ' + x.server + ' → ' + (x.real || x.error) + (x.pwd ? '  码=' + x.pwd : ''));
  }
})().catch((e) => console.log('ERR ' + e.message));
