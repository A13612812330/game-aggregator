
'use strict';
/* ================= 工具 ================= */
const $ = (s, r) => (r || document).querySelector(s);
const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const okScoreV = (v) => v != null && v > 0 && v <= 10;
let toastTimer;
function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), 2400); }
const api = (p) => p;
const SRC = { xdgamer: { nm: 'XDGAME', cls: 'xd' }, xdgamer2: { nm: 'XDGAME', cls: 'xd' }, jidi: { nm: '机地', cls: 'jidi' } };

function splitName(title) {
  const s = String(title || '').trim();
  const i = s.indexOf('/');
  if (i > 0) return { zh: s.slice(0, i).trim(), en: s.slice(i + 1).trim() };
  return { zh: s, en: '' };
}
function coverHtml(it, cls) {
  if (it.cover) return `<img src="${esc(it.cover)}" alt="${esc(it.zh || it.title)}" loading="lazy" onerror="this.parentNode.classList.add('noimg');this.remove()">`;
  const ch = (it.zh || it.title || '?').trim().charAt(0).toUpperCase() || '?';
  return `<div class="${cls ? 'ph' : ''}" style="display:grid;place-items:center;width:100%;height:100%;color:#fff;font-weight:800;font-size:22px;background:linear-gradient(135deg,#5B86E5,#7F6FF0)">${esc(ch)}</div>`;
}
/* ★ v10.8 日期键归一化：两个源站格式不同（XD `2026-09-14` / 机地 `2026/9/9`），
   旧版 normTime 只认含 `-` 的写法，机地那批会**原样输出 `2026/8/12`** ——
   同一列里既有 `09-14` 又有 `2026/8/12`。这里统一成 ISO 键再取紧凑展示。
   越界的月/日（脏数据）不硬转，按原样返回，避免造出 `09-89` 这种更糟的显示。 */
function normDateKey(d) {
  const m = String(d == null ? '' : d).match(/(\d{4})[-/](\d{1,2})[-/](\d{1,2})/);
  if (!m) return '';
  const mo = +m[2], dy = +m[3];
  if (mo < 1 || mo > 12 || dy < 1 || dy > 31) return '';
  return `${m[1]}-${String(mo).padStart(2, '0')}-${String(dy).padStart(2, '0')}`;
}
function normTime(d) {
  const k = normDateKey(d);
  if (k) return k.slice(5);           // → 09-14
  return d ? String(d) : '';
}

/* ================= 分类 ================= */
// 参考 XD 官网分类：全部 + 库内实际收录的类型（与 games.json genres 对齐）
const CATS = ['全部', '动作冒险', '角色扮演', '模拟经营', '休闲益智', '策略战棋', '恐怖惊悚', '枪战射击', '体育竞速', '即时战略', '联机整合', '免费专区', '模拟器整合'];
const SORTS = [
  { k: 'updated', nm: '最新更新', lb: 'NEW' },
  { k: 'score', nm: '评分最高', lb: 'SCORE' },
  { k: 'size', nm: '容量最大', lb: 'SIZE' },
];
/* 容量区间筛选（min/max 单位 GB，null=不限；min 含、max 不含） */
const SIZES = [
  { k: 'all', nm: '不限', lb: 'ALL', min: null, max: null },
  { k: 's', nm: '5GB 以下', lb: 'XS', min: null, max: 5 },
  { k: 'm', nm: '5-15GB', lb: 'S', min: 5, max: 15 },
  { k: 'l', nm: '15-30GB', lb: 'M', min: 15, max: 30 },
  { k: 'xl', nm: '30-60GB', lb: 'L', min: 30, max: 60 },
  { k: 'xxl', nm: '60GB 以上', lb: 'XL', min: 60, max: null },
];
let curCat = '全部';
let curSort = 'updated';
let curSize = 'all';    // SIZES[].k
let curBh = false;      // 仅看有手机模拟器配置（BannerHub 社区）的游戏
let curPc = false;      // 仅看本站实测库里有记录的游戏（phonecfg）
let curTr = false;      // ★ v10.5 仅看「修改器」库收录到的游戏
let curSv = false;      // ★ v10.5 仅看「云存档」库收录到的游戏
let offset = 0, total = 0, listEl = null, loading = false;

/** 当前筛选 → 附加查询串（容量区间 + 仅手机可玩 + 仅有实测记录 + 有修改器/云存档） */
function filterQuery() {
  const s = SIZES.find((x) => x.k === curSize) || SIZES[0];
  let q = '';
  if (s.min != null) q += '&sizeMin=' + s.min;
  if (s.max != null) q += '&sizeMax=' + s.max;
  if (curBh) q += '&bh=1';
  if (curPc) q += '&pc=1';
  if (curTr) q += '&tr=1';
  if (curSv) q += '&sv=1';
  return q;
}
/** 筛选条：三行「标签 + 分段控件」—— 排序 / 容量 / 筛选
 *  与上方「分类」行同语言：行首标签定名，控件组横排，结果计数贴右。
 *  ★ v10.5：开关从「容量」行拆出来独占「筛选」行 —— 四个开关挤在容量行里会溢出换行，
 *  行内出现半行空档、读起来像排版事故；单独成行既对齐手机专区的分行结构，
 *  也让「筛选」这件事有了名字。 */
function filterBarHtml() {
  return `<div class="filter-bar">
    <div class="filter-row">
      <span class="filter-lb">排序</span>
      <div class="sort-pills" id="sortPills">${SORTS.map(s => `<button class="sort-pill ${curSort === s.k ? 'on' : ''}" data-s="${s.k}"><span class="lb">${s.lb}</span>${s.nm}</button>`).join('')}</div>
      <span class="fx-sp"></span>
      <span class="filter-count" id="filterCount"></span>
    </div>
    <div class="filter-row">
      <span class="filter-lb">容量</span>
      <div class="size-pills" id="sizePills">${SIZES.map(s => `<button class="size-pill ${curSize === s.k ? 'on' : ''}" data-z="${s.k}"><span class="lb">${s.lb}</span>${s.nm}</button>`).join('')}</div>
    </div>
    <div class="filter-row">
      <span class="filter-lb">筛选</span>
      <button class="bh-toggle ${curBh ? 'on' : ''}" id="bhToggle" type="button" title="只看有 BannerHub 社区模拟器配置的游戏">📱 社区有配置</button>
      <button class="bh-toggle pc-badge ${curPc ? 'on' : ''}" id="pcToggle" type="button" title="只看本站实测库里有记录的 PC 游戏">🎮 有实测记录</button>
      <button class="bh-toggle tr-badge ${curTr ? 'on' : ''}" id="trToggle" type="button" title="只看「修改器」库里收录到的游戏（按端游库 id 关联）">🛠 有修改器</button>
      <button class="bh-toggle sv-badge ${curSv ? 'on' : ''}" id="svToggle" type="button" title="只看「云存档」库里查到存档位置的游戏（按端游库 id 关联）">💾 有云存档</button>
      <span class="fx-sp"></span>
    </div>
  </div>`;
}

/** 筛选结果计数文案 */
function filterCountText(n) {
  const bits = [];
  const s = SIZES.find((x) => x.k === curSize);
  if (s && s.k !== 'all') bits.push(s.nm);
  if (curBh) bits.push('📱 社区有配置');
  if (curPc) bits.push('🎮 有实测记录');
  if (curTr) bits.push('🛠 有修改器');
  if (curSv) bits.push('💾 有云存档');
  return (bits.length ? bits.join(' · ') + ' · ' : '') + `命中 ${n.toLocaleString()} 款`;
}

function renderCats() {  $('#catRow').innerHTML = `<span class="cat-title">分类</span>` +
    CATS.map(c => `<button class="cat ${c === curCat ? 'on' : ''}" data-c="${esc(c)}">${esc(c)}</button>`).join('') +
    `<span class="grow"></span><span class="statline" id="statline"></span>`;
  $$('#catRow .cat').forEach(b => b.addEventListener('click', () => {
    curCat = b.dataset.c; offset = 0; renderCats(); renderList(true);
  }));
}

function statlineHtml(st) {
  const j = st.bySource && (st.bySource.jidi || 0);
  const x = st.bySource && (st.bySource.xdgamer || 0);
  return `库内 <b>${st.total ? st.total.toLocaleString() : '–'}</b> 款 · 机地 <b>${j || 0}</b> · XD <b>${x || 0}</b>`;
}

/* ================= 主列表（内容库浏览,参考 XD 行卡） ================= */
function skeletonRows(n) {
  return Array.from({ length: n }).map(() => `<div class="skeleton"><div class="sk sk-th"></div><div style="flex:1;min-width:0"><div class="sk sk-l1"></div><div class="sk sk-l2"></div><div class="sk sk-l3"></div></div></div>`).join('');
}
function rowCard(it) {
  const n = splitName(it.title);
  const meta = [];
  const okScore = it.score != null && it.score > 0 && it.score <= 10;
  if (okScore) meta.push(`<span class="pill score">★ ${it.score}</span>`);
  if ((it.genres || []).length) meta.push(`<span class="pill type">${esc(it.genres.slice(0, 2).join(' / '))}</span>`);
  if (it.size) meta.push(`<span class="pill size">${esc(it.size)}</span>`);
  meta.push(`<span class="pill time">${esc(normTime(it.dateLabel))}</span>`);
  if (it.bh) meta.push(`<span class="bh-badge" title="BannerHub 社区已上传 ${it.bh.c} 份手机模拟器配置">📱 可玩 <b>${it.bh.c}</b></span>`);
  if (it.pc) meta.push(`<span class="bh-badge pc-badge" title="本站实测库有 ${it.pc.c} 条记录，最佳帧率 ${it.pc.best || '未标'}">🎮 实测 <b>${it.pc.c}</b></span>`);
  // 库内兜底字段(data-fb)：详情源站解析缺字段时用库内值补全
  /* ★ v10.22 加 jidiUrl：详情页「⬇ 网盘下载」要能**一次把两源的链接都取回来**。
     库内 XD 条目若已合并进机地同款（13,448 条），就带上机地详情页 URL ——
     弹窗里分成「XD 官方盘口」「机地社区分享」两组展示，比只给一边完整。 */
  const fb = { id: it.id || '', title: it.title || '', cover: it.cover || '', score: okScore ? it.score : null, size: it.size || '', genres: (it.genres || []).slice(0, 4), dateLabel: it.dateLabel || '', jidiUrl: it.jidiUrl || '' };
  const fbJson = encodeURIComponent(JSON.stringify(fb));
  return `<article class="row-card" data-url="${esc(it.url)}" data-fb="${fbJson}">
    <div class="th">${coverHtml({ ...it, zh: n.zh })}</div>
    <div class="bd">
      <div class="tt"><h3>${esc(n.zh)}</h3><span class="src-badge ${SRC[it.source] ? SRC[it.source].cls : 'xd'}">${SRC[it.source] ? SRC[it.source].nm : 'XDGAME'}</span></div>
      ${n.en ? `<div class="en">${esc(n.en)}</div>` : ''}
      <div class="meta">${meta.join('')}</div>
    </div>
    <span class="go">查看 <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg></span>
  </article>`;
}
/* 按 dateLabel 日期分组渲染(仅默认视图生效)，组间插入日期分隔条
   用 lastDateShown 跨批次去重组头：追加批次首项与上批末项同日则不重复插头 */
let lastDateShown = null;
function groupByDate(items) {
  const out = [];
  const today = new Date(), y = today.getFullYear(), m = today.getMonth() + 1, d = today.getDate();
  const dayKey = `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
  const yest = new Date(Date.now() - 86400e3), y2 = yest.getFullYear(), m2 = yest.getMonth() + 1, d2 = yest.getDate();
  const yestKey = `${y2}-${String(m2).padStart(2, '0')}-${String(d2).padStart(2, '0')}`;
  const friendly = (k) => k === dayKey ? '今天更新' : k === yestKey ? '昨天更新' : k ? k.slice(5) + ' 更新' : '近期';
  items.forEach((it) => {
    const k = normDateKey(it.dateLabel);        // ★ v10.8：用归一化键，两种格式都能识别
    if (k && k !== lastDateShown) {
      out.push(`<div class="date-sep"><span class="ds-bar"></span>${friendly(k)}<span class="ds-en">${k}</span></div>`);
      lastDateShown = k;
    }
    out.push(rowCard(it));
  });
  return out.join('');
}
async function renderList(reset) {
  const col = $('#colMain');
  if (reset) {
    col.innerHTML = filterBarHtml() + `<div id="libList">${skeletonRows(7)}</div>`;
    const lt = $('#listTitle'); if (lt) lt.textContent = curCat === '全部' ? '最新收录' : curCat;
  }
  listEl = $('#libList');
  loading = true;
  const moreBtn = $('#moreBtn'); if (moreBtn) moreBtn.disabled = true;
  if (reset) {
    const sp = $('#sortPills'); if (sp) sp.addEventListener('click', (e) => {
      const b = e.target.closest('.sort-pill'); if (!b || curSort === b.dataset.s) return;
      curSort = b.dataset.s; offset = 0; renderList(true);
    });
    const zp = $('#sizePills'); if (zp) zp.addEventListener('click', (e) => {
      const b = e.target.closest('.size-pill'); if (!b || curSize === b.dataset.z) return;
      curSize = b.dataset.z; offset = 0; renderList(true);
    });
    const bt = $('#bhToggle'); if (bt) bt.addEventListener('click', () => {
      curBh = !curBh; offset = 0; renderList(true);
    });
    const pt = $('#pcToggle'); if (pt) pt.addEventListener('click', () => {
      curPc = !curPc; offset = 0; renderList(true);
    });
    /* ★ v10.5 两个横切筛选：库里有修改器 / 库里有云存档（按钮宽度恒定，只切 on 态） */
    const tt = $('#trToggle'); if (tt) tt.addEventListener('click', () => {
      curTr = !curTr; offset = 0; renderList(true);
    });
    const st = $('#svToggle'); if (st) st.addEventListener('click', () => {
      curSv = !curSv; offset = 0; renderList(true);
    });
  }
  try {
    const g = curCat === '全部' ? '' : curCat;
    const url = api('/api/library/browse?g=' + encodeURIComponent(g) + '&sort=' + curSort + '&limit=40&offset=' + offset + filterQuery());
    const j = await fetch(url).then(r => r.json());
    if (!j.ok) throw new Error(j.error || '加载失败');
    total = j.total || 0;
    const items = j.items || [];
    // 默认「全部 × 最新更新」视图按日期分组（今日/昨日/日期），其余视图平铺
    const grouped = (curCat === '全部' && curSort === 'updated');
    const renderBatch = () => grouped ? groupByDate(items) : items.map(rowCard).join('');
    if (reset) {
      lastDateShown = null;
      const c = $('#listCount'); if (c) c.textContent = `共 ${total.toLocaleString()} 款`;
      const fc = $('#filterCount'); if (fc) fc.textContent = filterCountText(total);
      listEl.innerHTML = items.length ? renderBatch() : `<div class="empty"><div class="big">📂</div>当前筛选下暂无收录<br><span class="note" style="font-size:12px">试试放宽容量区间或取消「📱 社区有配置」「🎮 有实测记录」</span></div>`;
      offset = items.length;
    } else {
      listEl.insertAdjacentHTML('beforeend', renderBatch());
      offset += items.length;
    }
    bindRowCards(listEl);
    const hasMore = offset < total;
    const endMark = $('#listEnd'); if (endMark) endMark.remove();
    const mb = $('#moreBtn');
    if (hasMore) {
      if (mb) { mb.style.display = 'block'; mb.disabled = false; mb.textContent = `加载更多 · 剩余 ${(total - offset).toLocaleString()} 款`; }
      else if (items.length) listEl.insertAdjacentHTML('afterend', `<button class="load-more" id="moreBtn" style="display:block">加载更多 · 剩余 ${(total - offset).toLocaleString()} 款</button>`);
    } else {
      if (mb) mb.remove();
      if (listEl && items.length) listEl.insertAdjacentHTML('afterend', `<div class="list-end" id="listEnd">— 已全部加载（${total.toLocaleString()} 款）—</div>`);
    }
    const mb2 = $('#moreBtn'); if (mb2) mb2.addEventListener('click', () => { renderList(false); });
  } catch (e) {
    if (reset) listEl.innerHTML = `<div class="empty"><div class="big">⚠️</div>加载失败：${esc(e.message)}</div>`;
  } finally { loading = false; }
}
async function loadStats() {
  try {
    const j = await fetch(api('/api/library/stats')).then(r => r.json());
    const sl = $('#statline');
    if (j.ok && sl) sl.innerHTML = statlineHtml(j);
    const sm = $('#smTotal'); if (j.ok && sm) sm.textContent = (j.total || 0).toLocaleString();
    const el = $('#srcStat'); if (el) el.innerHTML = j.ok ? `
      <div class="it"><span>本地库总量</span><b>${(j.total || 0).toLocaleString()}</b></div>
      <div class="it"><span>XDGAME 收录</span><b>${((j.bySource && j.bySource.xdgamer) || 0).toLocaleString()}</b></div>
      <div class="it"><span>机地收录</span><b>${((j.bySource && j.bySource.jidi) || 0).toLocaleString()}</b></div>
      <div class="it"><span>索引运行</span><b>${j.running ? '进行中' : '空闲'}</b></div>` : '';
    return j;
  } catch (e) { return { ok: false }; }
}
/* ============ 🔥 首页热榜舞台（双热度合并榜：XD 官方周/月/全站 + 机地社区） ============ */
let rankCache = {};     // {week:[],month:[],year:[],community:[]} — 前端缓存,切档秒显
let rankAt = {};        // {week:ms,…} — 各档数据抓取时间(供 meta 展示)
let rankDrop = {};      // {week:n,…} — 各档被服务端滤除的非游戏条目数（meta 说明用）
let rankPeriod = 'week';
const RANK_META_TXT = {
  week: 'XD 官网 · 本周热门', month: 'XD 官网 · 当月最热', year: 'XD 官网 · 全站最热', community: '机地 · 社区热度（周）',
};
function rankFb(it) {
  return encodeURIComponent(JSON.stringify({
    id: it.id || '', title: it.title, cover: it.cover || '', score: okScoreV(it.score) ? it.score : null,
    size: it.size || '', genres: (it.genres || []).slice(0, 4), dateLabel: it.dateLabel || '',
    jidiUrl: it.jidiUrl || '',      /* v10.22：热榜/搜索结果进详情时也要能取双源下载链接 */
  }));
}
function hhmm(ts) { return new Date(ts).toTimeString().slice(0, 5); }
/* 榜单 #1：冠军大卡（大图 + 中英文名 + 类型/容量/日期 + 评分） */
function champHtml(it) {
  if (!it) return '';
  const n = splitName(it.title);
  const bdg = it.source === 'jidi' ? '<span class="bdg jidi">机地</span>' : '<span class="bdg xd">XD</span>';
  const meta = [];
  if ((it.genres || []).length) meta.push(`<span class="it">${esc(it.genres.slice(0, 2).join(' / '))}</span>`);
  if (it.size) meta.push(`<span class="it">${esc(it.size)}</span>`);
  if (it.dateLabel) meta.push(`<span class="it">${esc(it.dateLabel)}</span>`);
  if (it.bh) meta.push(`<span class="it" style="color:#C2410C;font-weight:750">📱 可玩 ${it.bh.c}</span>`);
  return `<div class="rk-champ" data-url="${esc(it.url)}" data-fb="${rankFb(it)}" title="${esc(it.title)}">
    <span class="no1">1</span>
    <div class="th">${it.cover ? `<img src="${esc(it.cover)}" alt="" loading="lazy" onerror="this.style.visibility='hidden'">` : `<div class="ph">${esc(n.zh.charAt(0))}</div>`}</div>
    <div class="bd">
      <div class="up"><span class="tag1">NO.1</span>${bdg}</div>
      <div class="t">${esc(n.zh)}</div>
      ${n.en ? `<div class="en">${esc(n.en)}</div>` : ''}
      ${meta.length ? `<div class="meta2">${meta.join('')}</div>` : ''}
    </div>
    ${okScoreV(it.score) ? `<div class="sc2">${it.score}<small>玩家评分</small></div>` : ''}
  </div>`;
}
/* 榜单 #2-10：网格大卡（排名 + 封面 + 中文名 + 源徽标 + 类型/容量 + 评分） */
function rankCard(it) {
  const n = splitName(it.title);
  const bdg = it.source === 'jidi' ? '<span class="bdg jidi">机地</span>' : '<span class="bdg xd">XD</span>';
  const sub = [(it.genres || [])[0] || '', it.size || ''].filter(Boolean).join(' · ');
  return `<div class="rk-card" data-url="${esc(it.url)}" data-fb="${rankFb(it)}" title="${esc(it.title + (sub ? ' · ' + sub : ''))}">
    <span class="no ${it.rank <= 3 ? 'r' + it.rank : ''}">${it.rank}</span>
    <div class="th">${it.cover ? `<img src="${esc(it.cover)}" alt="" loading="lazy" onerror="this.style.visibility='hidden'">` : `<div class="ph">${esc(n.zh.charAt(0))}</div>`}</div>
    <div class="bd"><div class="t">${esc(n.zh)}</div><div class="s">${bdg}${it.bh ? `<span class="g" style="color:#FFD9C2;font-weight:750">📱 ${it.bh.c}</span>` : ''}${sub ? `<span class="g">${esc(sub)}</span>` : ''}</div></div>
    ${okScoreV(it.score) ? `<span class="sc">★${it.score}</span>` : ''}
  </div>`;
}
/* 榜单内高亮当前打开条目（openDetail 联动，主列/榜单/搜索任一入口打开详情时同步） */
function rankMark(url) {
  const el = $('#rankList'); if (!el || !url) return;
  $$('#rankList [data-url]').forEach(o => o.classList.toggle('on', o.dataset.url === url));
}
function rankSkeleton() {
  return `<div class="rk-skel" style="height:162px;margin-bottom:14px"></div><div class="rk-grid">${'<div class="rk-skel" style="height:66px"></div>'.repeat(9)}</div>`;
}
function paintRank() {
  const el = $('#rankList'); if (!el) return;
  const list = rankCache[rankPeriod] || [];
  el.innerHTML = list.length
    ? champHtml(list[0]) + `<div class="rk-grid">${list.slice(1).map(rankCard).join('')}</div>`
    : `<div class="sm-empty" style="color:rgba(255,255,255,.6)"><div class="big">📭</div>该档榜单暂无数据</div>`;
  const meta = $('#rankMeta');
  if (meta) {
    /* 源站榜单里混着「运行库 / 检测工具」这类非游戏条目（全站榜第 1 名就是），
       服务端已滤除并重编号；这里如实说明，免得用户以为数据丢了。 */
    const dropped = rankDrop[rankPeriod] || 0;
    meta.textContent = RANK_META_TXT[rankPeriod]
      + (dropped ? ` · 已滤除 ${dropped} 条工具条目` : '')
      + (rankAt[rankPeriod] ? ' · 更新 ' + hhmm(rankAt[rankPeriod]) : '');
  }
  $$('#rankList [data-url]').forEach(x => x.addEventListener('click', () => openDetail(x.dataset.url, x.dataset.fb)));
}
async function refreshRank(force) {
  const el = $('#rankList'), meta = $('#rankMeta'), btn = $('#rankRefresh');
  if (!el) return;
  if (!force && rankCache[rankPeriod]) { paintRank(); return; } // 缓存秒显,不重复请求
  if (meta) meta.textContent = '加载中…';
  if (btn) btn.classList.add('busy');
  if (!rankCache[rankPeriod]) el.innerHTML = rankSkeleton();
  try {
    const j = await fetch(api('/api/rank?p=' + rankPeriod + (force ? '&refresh=1' : ''))).then(r => r.json());
    if (!j.ok || !j.list) throw new Error(j.error || '榜单不可用');
    rankCache[rankPeriod] = j.list;
    rankAt[rankPeriod] = j.fetchedAt || Date.now();
    rankDrop[rankPeriod] = (j.meta && j.meta.dropped) || 0;
    paintRank();
  } catch (e) {
    el.innerHTML = `<div class="sm-empty" style="color:rgba(255,255,255,.65)"><div class="big">⚠️</div>榜单加载失败：${esc(e.message)}<br><span style="font-size:11.5px;opacity:.8">可点右侧「刷新」重试</span></div>`;
    if (meta) meta.textContent = '';
  } finally { if (btn) btn.classList.remove('busy'); }
}
/* ★ v10.4 顶栏搜索入口 —— **两页共用，必须留在 bindRankUI 之外**。
   背景：生成器会把派生页(/emulator.html)里的 `bindRankUI();` 调用注释掉
   （该函数还要绑 #rankPills / #rankRefresh，而这两个节点在专区页不存在）。
   这行过去就在 bindRankUI 内部 —— 于是**手机专区的顶栏搜索按钮点了完全没反应**。
   凡「两页都要用」的绑定一律放这里，不要塞进任何会被生成器摘除的函数。 */
$('#searchOpen').addEventListener('click', () => openSearch());

/* 顶栏搜索触发 + 榜单周期切换/刷新（仅首页） */
function bindRankUI() {
  $('#rankPills').addEventListener('click', (e) => {
    const b = e.target.closest('.stage-pill'); if (!b || b.dataset.p === rankPeriod) return;
    rankPeriod = b.dataset.p;
    $$('#rankPills .stage-pill').forEach(x => x.classList.toggle('on', x === b));
    refreshRank(false);
  });
  $('#rankRefresh').addEventListener('click', () => { toast('正在刷新榜单…'); refreshRank(true); });
}
function renderSide() {
  $('#colSide').innerHTML = `
    <div class="side-card stat-card"><h4><span class="ic" style="background:linear-gradient(135deg,#2E6BFF,#6366F1)"></span>内容库状态</h4><div id="srcStat"></div>
      <div style="display:flex;gap:8px;margin-top:10px">
        <button class="mini-btn" id="idxBtn" style="flex:1.35">↻ 增量更新</button>
        <button class="mini-btn" id="calBtn" style="flex:1;background:#fff;color:var(--c-t2);border-color:var(--c-border2)">校准续跑</button>
      </div>
      <button class="mini-btn" id="jidiBtn" style="background:rgba(230,65,93,.07);border-color:rgba(230,65,93,.3);color:var(--c-jidi)">⇅ 同步机地话题入本地库</button>
      <div class="idx-bar" id="idxBar"><i id="idxBarI"></i></div>
      <div class="idx-tip" id="idxTip"></div>
    </div>
    <div class="side-card"><h4><span class="ic" style="background:linear-gradient(135deg,#16A34A,#4ADE80)"></span>关于本站</h4>
      <div class="note">合并<b>机地(jidiyouxi.com)</b>与<b>XDGAME(xdgame.com)</b>两个爬取内容源：XD 游戏库全量本地索引 + 机地首页/热榜话题同步入库，搜索与浏览<b>双源打通</b>。<br><br>· 页面顶部<b>🔥 全站热榜</b>＝XD 官方热度（周/月/全站）+ 机地社区热度合并榜<br>· 点顶栏<b>搜索框 / Ctrl K</b> 打开搜索弹窗，一键<b>搜本地库</b>（毫秒），未收录时可<b>实时查源站</b><br>· 卡片点击看<b>详情抽屉</b>（源站实时抓取），<b>←/→</b> 切换条目、<b>Esc</b> 关闭<br>· 本站<b style="color:var(--c-danger)">不含下载资源</b></div></div>`;
  $('#idxBtn').addEventListener('click', () => runXdIndex('incr'));
  $('#calBtn').addEventListener('click', () => runXdIndex('calibrate'));
  $('#jidiBtn').addEventListener('click', syncJidi);
  updateIdxTip();
}

/* ============ 内容库维护：增量更新 / 校准续跑 / 机地双源同步 ============ */
let idxTimer = null;
function setBtnsDisabled(v) { $$('#colSide .mini-btn').forEach(b => { b.disabled = v; }); }
function idxBarPct(pct) { const barI = $('#idxBarI'); if (barI) barI.style.width = pct + '%'; }
function idxBarShow(pct, tipTxt) {
  const bar = $('#idxBar'), tip = $('#idxTip');
  if (bar) bar.style.display = 'block';
  idxBarPct(pct);
  if (tipTxt != null) tip.textContent = tipTxt;
}
function idxBarFinish(tipTxt) {
  idxBarPct(100);
  if (tipTxt != null) $('#idxTip').textContent = tipTxt;
  const bar = $('#idxBar');
  setTimeout(() => { if (bar) bar.style.display = 'none'; }, 3200);
}
function humanAgo(ts) {
  if (!ts) return null;
  const s = Math.max(1, Math.round((Date.now() - ts) / 1000));
  if (s < 60) return s + ' 秒前';
  if (s < 3600) return Math.round(s / 60) + ' 分钟前';
  if (s < 86400) return Math.round(s / 3600) + ' 小时前';
  return Math.round(s / 86400) + ' 天前';
}
/** 空闲态摘要: 显示校准/断点/机地同步情况 */
async function updateIdxTip() {
  const tip = $('#idxTip'); if (!tip) return;
  try {
    const j = await fetch(api('/api/library/index/state')).then(r => r.json());
    if (!j.ok) return;
    const st = j.state.xdgame, ji = j.state.jidi;
    const parts = [];
    if (st.maxKnown && st.nextPage > st.maxKnown) parts.push('XD 校准至第 ' + st.maxKnown + ' 页' + (st.lastFullAt ? '（' + humanAgo(st.lastFullAt) + '）' : ''));
    else if (st.nextPage > 0 && st.maxKnown && st.nextPage <= st.maxKnown) parts.push('XD 断点:第 ' + st.nextPage + '/' + st.maxKnown + ' 页待续');
    else parts.push('XD 库待首次校准');
    if (ji.synced) parts.push('机地 ' + ji.synced + ' 款（' + humanAgo(ji.lastSyncAt) + '）');
    tip.textContent = parts.join(' · ');
  } catch (e) { /* 忽略 */ }
}
async function runXdIndex(kind) {
  if (idxTimer) { clearTimeout(idxTimer); idxTimer = null; }
  setBtnsDisabled(true);
  idxBarShow(3, kind === 'calibrate' ? '校准/续跑中…（可离开页面,服务端后台执行）' : '增量抓取最近页（约 10-30s）…');
  try {
    const r = await fetch(api('/api/library/index/' + kind), { method: 'POST' });
    const j = await r.json();
    if (!j.ok && r.status !== 409) throw new Error(j.error || '启动失败');
    if (r.status === 409) { toast(j.error || '任务进行中'); pollIdx(); return; }
    if (j.quick) { idxBarFinish(); toast(j.message || '已校准'); setBtnsDisabled(false); loadStats(); refreshMainIfBrowse(); updateIdxTip(); return; }
    if (j.ok) { toast(j.message || '任务已启动'); pollIdx(); }
  } catch (e) {
    idxBarFinish(); toast('启动失败：' + e.message);
    setBtnsDisabled(false); updateIdxTip();
  }
}
async function syncJidi() {
  if (idxTimer) { clearTimeout(idxTimer); idxTimer = null; }
  setBtnsDisabled(true);
  idxBarShow(3, '同步机地话题（首页新游 + 周月年热榜）…');
  try {
    const r = await fetch(api('/api/library/index/jidi'), { method: 'POST' });
    const j = await r.json();
    if (!j.ok && r.status !== 409) throw new Error(j.error || '启动失败');
    if (r.status === 409) { toast(j.error || '任务进行中'); pollIdx(); return; }
    if (j.ok) { toast(j.message || '机地同步已启动'); pollIdx(); }
  } catch (e) {
    idxBarFinish(); toast('启动失败：' + e.message);
    setBtnsDisabled(false); updateIdxTip();
  }
}
function refreshMainIfBrowse() { if (!lastQ) renderList(true); }
async function pollIdx() {
  try {
    const j = await fetch(api('/api/library/progress')).then(r => r.json());
    const run = j.run, runJ = j.runJ, st = (j.state && j.state.xdgame) || {};
    const xdBusy = run && !run.done;
    const jBusy = runJ && !runJ.done;
    const tip = $('#idxTip');
    if (xdBusy) {
      const span = Math.max(1, (run.end - run.start + 1));
      idxBarPct(Math.min(98, Math.round(((run.page - run.start + 1) / span) * 100)));
      const kindNm = run.kind === 'calibrate' ? '校准' : run.kind === 'incr' ? '增量' : '索引';
      tip.textContent = `${kindNm}中：第 ${Math.min(run.page, run.end)}/${run.end} 页 · 已收录 ${(run.total || 0).toLocaleString()} 款`;
      idxTimer = setTimeout(pollIdx, 1200);
      return;
    }
    if (jBusy) {
      idxBarPct(70);
      tip.textContent = '机地同步中：候选 ' + (runJ.got || 0) + ' 款 · 新增 ' + (runJ.added || 0) + ' 款…';
      idxTimer = setTimeout(pollIdx, 1200);
      return;
    }
    // —— 全部空闲：收尾提示 + 刷新 ——
    const last = (run && run.done) ? run : ((runJ && runJ.done) ? runJ : null);
    idxBarFinish();
    if (last) {
      if (last.error) toast((last.kind === 'jidi' ? '机地同步' : '索引任务') + '未完全成功：' + last.error);
      else if (last.kind === 'jidi') toast('✓ 机地话题已入库，库总 ' + (last.total || 0).toLocaleString() + ' 款');
      else if (last.kind === 'calibrate') toast('✓ 校准完成至第 ' + (st.maxKnown || last.end) + ' 页');
      else toast('✓ 增量完成 · 库 ' + (last.total || 0).toLocaleString() + ' 款');
    }
    setBtnsDisabled(false);
    loadStats();
    refreshMainIfBrowse();
    updateIdxTip();
  } catch (e) {
    idxBarFinish(); setBtnsDisabled(false);
    $('#idxTip').textContent = '进度查询失败：' + e.message;
  }
}

/* ================= 🔍 搜索弹窗（本地库秒搜 + 联想 + 源站兜底，全部在弹窗内完成） ================= */
let lastQ = '';
let smOpen = false, sugIdx = -1, sugTimer = null, liveSearching = false;
/* 详情抽屉的「来路」：从搜索弹窗进入时记住现场，关闭详情后原样还原搜索态 */
let detailFromSearch = false;
let smSnapshot = null; // { q, html, scroll }
let lastDetailUrl = ''; // 最近一次打开的详情 url（返回搜索态后保留行高亮）
/* 关闭详情后回到搜索弹窗：直接还原快照（含联想/本地命中/源站实时结果），无需重新请求 */
function restoreSearch() {
  if (!smSnapshot) { unlockBody(); return; }
  smOpen = true;
  $('#smask').classList.add('show');
  $('#smodal').classList.add('show');
  lockBody();
  const inp = $('#searchInput');
  inp.value = smSnapshot.q || '';
  $('#smClear').classList.toggle('hidden', !inp.value);
  const body = $('#smBody');
  body.innerHTML = smSnapshot.html;
  bindSmRows();
  // 刚看过的条目保持高亮，方便连续浏览
  if (lastDetailUrl) $$('#smBody .sm-row').forEach(r => r.classList.toggle('on-drawer', r.dataset.url === lastDetailUrl));
  body.scrollTop = smSnapshot.scroll || 0;
  sugIdx = -1;
  setTimeout(() => { inp.focus(); const l = inp.value.length; try { inp.setSelectionRange(l, l); } catch (e) {} }, 60);
}
/* 由弹窗内任意结果行进入详情：先存快照，再关弹窗开抽屉 */
function openDetailFromSearch(el) {
  const body = $('#smBody');
  smSnapshot = { q: (lastQ || $('#searchInput').value.trim()), html: body.innerHTML, scroll: body.scrollTop };
  closeSearch();
  openDetail(el.dataset.url, el.dataset.fb, true);
}
const QUICK_WORDS = ['艾尔登法环', '赛博朋克2077', '只狼', '巫师3', '剑星', '荒野大镖客', 'GTA5', '生化危机4', '死亡搁浅'];
function lockBody() { document.body.style.overflow = 'hidden'; }
function unlockBody() { if (!$('#drawer').classList.contains('show') && !smOpen) document.body.style.overflow = ''; }
function openSearch(seed) {
  smOpen = true;
  $('#smask').classList.add('show');
  $('#smodal').classList.add('show');
  lockBody();
  const inp = $('#searchInput');
  if (seed != null) inp.value = seed;
  $('#smClear').classList.toggle('hidden', !inp.value);
  setTimeout(() => { inp.focus(); inp.select(); }, 60);
  if (inp.value.trim()) doSearch(); else paintSearchHome();
}
function closeSearch() {
  if (!smOpen) return;
  smOpen = false;
  $('#smask').classList.remove('show');
  $('#smodal').classList.remove('show');
  sugIdx = -1;
  unlockBody();
}
/* 弹窗初始态（★ v10.15 重做）
 *   旧版是「试试这些 chips + 一个 30px 放大镜漂在 271px 空白中间」，主体一片空。
 *   现补上「库内速览」—— 四个库的口径与规模一次讲清，空白区也有了实信息。
 *   数字全部取自各库的**内存统计端点**（都不查盘），取一次缓存住；
 *   任一失败就整块不渲染 —— 宁可少一块，也不给用户看四个 0。 */
let smStatCache = null;
async function loadSmStats() {
  if (smStatCache) return smStatCache;
  try {
    const [pc, mob, tr, sv] = await Promise.all([
      fetch(api('/api/library/stats')).then(r => r.json()),
      fetch(api('/api/mobilehub/stats')).then(r => r.json()),
      fetch(api('/api/trainers/stats')).then(r => r.json()),
      fetch(api('/api/saves/stats')).then(r => r.json()),
    ]);
    smStatCache = [
      { cls: 'pc', n: pc.total, lb: '端游库', id: 'smTotal' },
      { cls: 'mob', n: mob.total, lb: '手游中心' },
      { cls: 'tr', n: tr.total, lb: '修改器' },
      { cls: 'sv', n: sv.total, lb: '云存档' },
    ];
    return smStatCache;
  } catch (e) { return null; }
}
function paintSearchHome() {
  const q = QUICK_WORDS.map(k => `<button type="button" onclick="quickSearch('${esc(k)}')">${esc(k)}</button>`).join('');
  const skeleton = '<div class="st"><b>…</b><span>读取中</span></div>'.repeat(4);
  $('#smBody').innerHTML = `<div class="sm-home">
    <div class="sm-sec">热门搜索<span class="cnt">点击即搜</span></div>
    <div class="sm-quick">${q}</div>
    <div class="sm-sec">库内速览<span class="cnt">本地秒搜 · 不走网络</span></div>
    <div class="sm-stat" id="smStat">${skeleton}</div>
    <div class="sm-tip">四个库一起搜：<b>端游库</b>点得进完整详情，<b>手游中心</b>给手机配置与实测，<b>修改器 / 云存档</b>直接给下载与存档路径。</div>
  </div>`;
  loadSmStats().then((rows) => {
    const el = $('#smStat');
    if (!el) return;                                   // 用户已经打字走了，别回填
    if (!rows) { el.innerHTML = ''; return; }
    el.innerHTML = rows.map(r => `<div class="st ${r.cls}"><b${r.id ? ` id="${r.id}"` : ''}>${(r.n || 0).toLocaleString()}</b><span>${r.lb}</span></div>`).join('');
  });
}
function quickSearch(k) { const inp = $('#searchInput'); inp.value = k; $('#smClear').classList.remove('hidden'); doSearch(); }
/* 弹窗内统一结果行（联想 / 本地命中 / 源站实时共用同一渲染） */
function smRow(it) {
  const n = splitName(it.title);
  const meta = [];
  if (okScoreV(it.score)) meta.push(`<span class="pill score">★ ${it.score}</span>`);
  if ((it.genres || []).length) meta.push(`<span class="pill type">${esc(it.genres.slice(0, 2).join(' / '))}</span>`);
  if (it.size) meta.push(`<span class="pill size">${esc(it.size)}</span>`);
  if (it.dateLabel) meta.push(`<span class="pill time">${esc(normTime(it.dateLabel))}</span>`);
  const s = SRC[it.source] || { nm: 'XDGAME', cls: 'xd' };
  return `<div class="sm-row" data-url="${esc(it.url)}" data-fb="${rankFb(it)}">
    ${it.cover ? `<img src="${esc(it.cover)}" alt="" loading="lazy" onerror="this.style.visibility='hidden'">` : `<span class="ph2">${esc(n.zh.charAt(0))}</span>`}
    <div class="bd"><div class="t">${esc(n.zh)}</div>${n.en ? `<div class="en">${esc(n.en)}</div>` : ''}<div class="m">${meta.join('')}</div></div>
    <span class="src-badge ${s.cls}">${s.nm}</span>
    <span class="go2">查看详情 →</span>
  </div>`;
}
function smSkeleton(n) { return `<div class="sm-load">${'<div class="sk"></div>'.repeat(n || 4)}</div>`; }

/* ★ 手游中心结果行（统一搜索的第二个分组）
 *   与端游行的区别：手游走**手游中心合并索引**，标注「N 套配置 / M 条实测 / 实测 XX 帧」，
 *   点击后**不跳源站**，而是打开端游库详情（若命中 libId）或提示未收录。 */
function smMobileRow(it) {
  const meta = [];
  if (it.configs) meta.push(`<span class="pill hot">${it.configs} 套配置</span>`);
  if (it.records) meta.push(`<span class="pill rec">${it.records} 条实测</span>`);
  if (it.bestLabel) meta.push(`<span class="pill fps">${esc(String(it.bestLabel))}</span>`);
  const gpus = (it.gpus || []).slice(0, 2).map((g) => `<span class="pill type">${esc(g)}</span>`).join('');
  const alt = (it.alt || [])[0];
  const lid = it.libId || '';
  /* 有端游库命中 → 可直接进详情；否则给「未收录」提示样式 */
  const go = lid ? '查看详情 →' : '仅手游数据';
  const cls = lid ? 'sm-row' : 'sm-row no-lib';
  return `<div class="${cls}" data-mlib="${esc(lid)}" data-mtitle="${esc(it.libTitle || it.name)}">
    ${it.libCover ? `<img src="${esc(it.libCover)}" alt="" loading="lazy" onerror="this.style.visibility='hidden'">` : `<span class="ph2 mob">${esc(String(it.name || '?').charAt(0))}</span>`}
    <div class="bd"><div class="t">${esc(it.name || '')}</div>${alt ? `<div class="en">${esc(alt)}</div>` : ''}<div class="m">${meta.join('')}${gpus}</div></div>
    <span class="src-badge mob">📱 手游</span>
    <span class="go2">${go}</span>
  </div>`;
}
function bindSmRows() {
  $$('#smBody .sm-row').forEach(r => r.addEventListener('click', () => openDetailFromSearch(r)));
  /* 手游结果行：点了开抽屉（有 libId 用 libId，没有再退回按名字找） */
  $$('#smBody .sm-row[data-mlib]').forEach(r => r.addEventListener('click', () => {
    const body = $('#smBody');
    smSnapshot = { q: (lastQ || $('#searchInput').value.trim()), html: body.innerHTML, scroll: body.scrollTop };
    closeSearch();
    const lid = r.dataset.mlib, t = r.dataset.mtitle;
    if (lid && typeof openDetailById === 'function') openDetailById(lid, t);
    else toast('这款未收录进本地端游库，暂无详情页');
  }));
  /* ★ v10：修改器结果行 —— 有 libId 开详情，否则给出「获取方式」提示 */
  $$('#smBody .sm-row[data-trlib]').forEach(r => r.addEventListener('click', () => {
    const body = $('#smBody');
    smSnapshot = { q: (lastQ || $('#searchInput').value.trim()), html: body.innerHTML, scroll: body.scrollTop };
    closeSearch();
    const lid = r.dataset.trlib, t = r.dataset.trtitle;
    if (lid && typeof openDetailById === 'function') openDetailById(lid, t);
    else toast('这款未关联端游库，到手机专区「修改器」页可看获取方式');
  }));
  /* ★ v10：云存档结果行 —— 同理；未关联时提示去云存档页看完整路径 */
  $$('#smBody .sm-row[data-svlib]').forEach(r => r.addEventListener('click', () => {
    const body = $('#smBody');
    smSnapshot = { q: (lastQ || $('#searchInput').value.trim()), html: body.innerHTML, scroll: body.scrollTop };
    closeSearch();
    const lid = r.dataset.svlib, t = r.dataset.svtitle;
    if (lid && typeof openDetailById === 'function') openDetailById(lid, t);
    else toast('到手机专区「云存档」页可看这款的完整存档路径');
  }));
}

/* ★ v10（统一搜索分组③）：修改器结果行
 *   数据来自 Game Cheats Manager 公开清单，标注来源与版本；
 *   点进详情的前提是这款能对上端游库（有 libId）。 */
const SM_TR_LABEL = { fling: '风灵月影', cheat_table: 'CE 修改表', community: '社区贡献', xiaoxing: '小幸修改器', gcm: 'GCM 精选' };
function smTrainerRow(it) {
  const title = it.zh || it.name || '?';
  const en = (it.zh && it.name && it.zh !== it.name) ? it.name : '';
  const meta = [`<span class="pill src-tr">${esc(SM_TR_LABEL[it.source] || it.source || '')}</span>`];
  if (it.version) meta.push(`<span class="pill ver2">v ${esc(it.version)}</span>`);
  const lid = it.libId || '';
  return `<div class="sm-row${lid ? '' : ' no-lib'}" data-trlib="${esc(lid)}" data-trtitle="${esc(it.libTitle || title)}">
    ${it.libCover ? `<img src="${esc(it.libCover)}" alt="" loading="lazy" onerror="this.style.visibility='hidden'">` : `<span class="ph2 tr">${esc(String(title).charAt(0))}</span>`}
    <div class="bd"><div class="t">${esc(title)}</div>${en ? `<div class="en">${esc(en)}</div>` : ''}<div class="m">${meta.join('')}</div></div>
    <span class="src-badge tr">🛠 修改器</span>
    <span class="go2">${lid ? '查看详情 →' : '仅修改器数据'}</span>
  </div>`;
}

/* ★ v10（统一搜索分组④）：云存档结果行
 *   ★ 直接把「存档路径」铺在行里 —— 用户搜这款游戏，十有八九就是想找存档放哪。 */
function smSaveRow(it) {
  const title = it.title || it.name || '?';
  const en = (it.name && it.name !== title) ? it.name : '';
  const meta = [`<span class="pill">${it.pathCount || 0} 条存档</span>`];
  if (it.regCount) meta.push(`<span class="pill">${it.regCount} 项注册表</span>`);
  (it.cloud || []).slice(0, 1).forEach(c => meta.push(`<span class="pill cld">☁ ${esc(String(c).toUpperCase())}</span>`));
  const p0 = (it.paths || [])[0] || '';
  const lid = it.libId || '';
  return `<div class="sm-row${lid ? '' : ' no-lib'}" data-svlib="${esc(lid)}" data-svtitle="${esc(title)}">
    ${it.libCover ? `<img src="${esc(it.libCover)}" alt="" loading="lazy" onerror="this.style.visibility='hidden'">` : `<span class="ph2 sv">${esc(String(title).charAt(0))}</span>`}
    <div class="bd"><div class="t">${esc(title)}</div>${en ? `<div class="en">${esc(en)}</div>` : ''}
      <div class="m">${meta.join('')}</div>
      ${p0 ? `<div class="pth" title="${esc(p0)}">${esc(p0)}</div>` : ''}</div>
    <span class="src-badge sv">💾 云存档</span>
    <span class="go2">${lid ? '查看详情 →' : '仅存档数据'}</span>
  </div>`;
}
async function doSearch() {
  const q = $('#searchInput').value.trim();
  if (!q) { paintSearchHome(); return; }
  if (q.length > 40) { toast('关键词过长（限 40 字）'); return; }
  lastQ = q; sugIdx = -1;
  const body = $('#smBody');
  body.innerHTML = `<div class="sm-sec">正在搜索全站（端游库 + 手游中心 + 修改器 + 云存档） “${esc(q)}”…</div>${smSkeleton(4)}`;
  try {
    /* ★ 统一搜全站：一个端点同时返回**四个库**的结果，分组渲染。
     *   这样在手机专区点顶栏搜索也能搜到手游玩法与资源，而不是只搜端游库。 */
    const j = await fetch(api('/api/search/all?q=' + encodeURIComponent(q) + '&limit=12')).then(r => r.json());
    const pc = (j && j.pc) || { items: [] };
    const mob = (j && j.mobile) || { items: [] };
    const tr = (j && j.trainer) || { items: [] };
    const sv = (j && j.save) || { items: [] };
    const allEmpty = !(pc.items || []).length && !(mob.items || []).length
      && !(tr.items || []).length && !(sv.items || []).length;
    // 四个库都空 且 偏好「自动兜底」开启 → 免点击直接实时查源站
    if (allEmpty && localStorage.getItem('ghAutoLive') === '1') {
      toast('本地库未收录，正在自动实时查源站…');
      await searchLive(q);
    } else paintSearchResult(q, j);
  } catch (e) {
    body.innerHTML = `<div class="sm-empty"><div class="big">⚠️</div>搜索失败：${esc(e.message)}</div>`;
  }
}
/* 统一结果渲染：★ v10 起四个分组
 *   ① 📱 手游中心（手机能玩吗 · 配置 + 实测）
 *   ② 🛠 修改器（有哪些修改器、哪个源、什么版本）
 *   ③ 💾 云存档（存档放哪 —— 用户搜游戏时常找的就是这个）
 *   ④ 🖥️ 端游库（全站收录 · 兜底）
 *   手游放最前是因为在「手机专区」语境下用户更关心它；
 *   端游库放最后是兜底口径（什么都搜不到时它最可能命中）。 */
function paintSearchResult(q, j) {
  const body = $('#smBody');
  const aliasHtml = j.aliasNote ? `<span class="cnt" style="color:var(--c-score)">别名 ${esc(j.aliasNote.alias)} → ${esc(j.aliasNote.to)}</span>` : '';
  /* ★ v10.7：打分用「实际生效的关键词」—— 别名命中时标题里出现的是别名目标名，
   *   拿原词去打分会四组全 0，排序退化成旧顺序。 */
  const qEff = (j.aliasNote && j.aliasNote.to) || q;
  const pc = (j.pc || { items: [], count: 0 });
  const mob = (j.mobile || { items: [], count: 0 });
  const tr = (j.trainer || { items: [], count: 0 });
  const sv = (j.save || { items: [], count: 0 });
  const pcHit = (pc.items || []).slice(0, 30);
  const mobHit = (mob.items || []).slice(0, 20);
  const trHit = (tr.items || []).slice(0, 20);
  const svHit = (sv.items || []).slice(0, 20);

  if (!pcHit.length && !mobHit.length && !trHit.length && !svHit.length) {
    const total = (pc.total || 15000).toLocaleString();
    body.innerHTML = `<div class="sm-sec">全站命中<span class="cnt">0 款</span></div>
      <div class="sm-empty"><div class="big">🕳️</div>四个库（端游 <b>${total}</b> 款 / 手游 / 修改器 / 云存档）都未收录「<b>${esc(q)}</b>」<br><span style="font-size:11.5px">每日 09:30 自动增量同步，可稍后再搜；也可直接实时查源站</span></div>
      <div class="sm-acts"><button class="mini-btn" style="flex:1" type="button" data-q="${esc(q)}" onclick="searchLive(this.dataset.q)">↗ 仍要实时搜源站（XDGAME / 机地）</button></div>
      <div style="padding:0 11px 6px"><label class="auto-live" style="margin:0"><input type="checkbox" ${localStorage.getItem('ghAutoLive') === '1' ? 'checked' : ''} onchange="toggleAutoLive(this)"> 以后本地搜不到时自动查源站（免点击）</label></div>`;
    return;
  }

  /* ★ v10.7：分组按「贴合度」动态排序（原先是写死 手游→修改器→云存档→端游库）
   *
   *  问题：搜「剑星」时，四个库都有命中，而**用户真正要找的那款游戏**在「端游库」——
   *  写死的顺序把它压到第 4 组，得滚动才看得到；首屏反而是手游配置、修改器版本。
   *
   *  规则：以「标题 ↔ 关键词」的贴合度给四组打分，高的排前；同分保持原顺序
   *        （Array#sort 在 V8 是稳定排序，所以「都不沾关键词」时行为与旧版一致）。
   *        3 = 归一化后完全同名（搜「剑星」命中「剑星」）
   *        2 = 以关键词开头（搜「剑星」命中「剑星-虚拟机版」）
   *        1 = 包含关键词
   *        0 = 标题里根本没有关键词（靠英文名/别名/子串兜底命中的）
   *  归一化去掉空格与常见分隔符（`剑星-虚拟机版`→`剑星虚拟机版`、
   *  `Resident Evil 2: Remake`→`residentevil2remake`），并**优先用别名解析后的词**
   *  （用户搜别名时，标题里出现的是别名目标名，用原词打分会全组 0 分）。
   *
   *  ⚠️ 只按贴合度排会失效：四个库收录的是**同一批游戏**，「完全同名」经常四组同时命中
   *  —— 实测搜「艾尔登法环」四组全 3 分、「只狼」「GTA」四组全 2 分，全平局又退回原顺序，
   *  端游库照样垫底，等于没改。所以再加一条**本体提权**：端游库拿到 2 分以上
   *  （即本名精确或近似命中）时 +1 分 —— 它代表的是「游戏本体」这一实体，
   *  也是四组里唯一能点进完整详情页的；其余三组都是「关于这款游戏」的附加信息。
   *  提权只在端游库确有本名命中时生效，其余情况一律不动默认顺序。 */
  const rn = (s) => String(s == null ? '' : s).toLowerCase().replace(/[\s\-_:：·・/\\|'"“”‘’()（）\[\]]/g, '');
  const qn = rn(qEff);
  const fit = (...nameLists) => {
    let best = 0;
    for (const list of nameLists) {
      for (const nm of list || []) {
        for (const one of String(nm || '').split('/')) {
          const s = rn(one);
          if (!s || !qn) continue;
          const v = s === qn ? 3 : (s.startsWith(qn) ? 2 : (s.includes(qn) ? 1 : 0));
          if (v > best) best = v;
        }
      }
    }
    return best;
  };
  const pcFit = fit(pcHit.map((x) => x.title));
  const groups = [
    { i: 0, icon: '📱', name: '手游中心 · 手机能玩吗', tag: 'MOBILE', tagCls: 'match', cnt: mob.count, unit: '款',
      score: fit(mobHit.map((x) => x.name), mobHit.map((x) => x.libTitle)),
      rows: mobHit.length ? mobHit.map(smMobileRow).join('') : `<div class="sm-empty" style="padding:14px">手游中心无命中</div>` },
    { i: 1, icon: '🛠', name: '修改器 · 有没有修改器', tag: 'TRAINER', tagCls: 'match', cnt: tr.count, unit: '条',
      score: fit(trHit.map((x) => x.zh), trHit.map((x) => x.name), trHit.map((x) => x.libTitle)),
      rows: trHit.length ? trHit.map(smTrainerRow).join('') : `<div class="sm-empty" style="padding:14px">修改器库无命中</div>` },
    { i: 2, icon: '💾', name: '云存档 · 存档放在哪', tag: 'SAVE', tagCls: 'match', cnt: sv.count, unit: '款',
      score: fit(svHit.map((x) => x.title), svHit.map((x) => x.name)),
      rows: svHit.length ? svHit.map(smSaveRow).join('') : `<div class="sm-empty" style="padding:14px">云存档库无命中</div>` },
    { i: 3, icon: '🖥️', name: '端游库 · 全站收录', tag: 'LOCAL', tagCls: 'local', cnt: pc.count, unit: '款',
      score: pcFit + (pcFit >= 2 ? 1 : 0),
      rows: pcHit.length ? pcHit.map(smRow).join('') : `<div class="sm-empty" style="padding:14px">端游库无命中</div>` },
  ];
  groups.sort((a, b) => b.score - a.score || a.i - b.i);

  /* 分组小标题：首组不加顶部间距，后续组加 padding-top 拉开层次 */
  let html = '';
  groups.forEach((g, k) => {
    html += `<div class="sm-sec"${k === 0 ? '' : ' style="padding-top:12px"'}>${g.icon} ${g.name}<span class="tag ${g.tagCls}">${g.tag}</span><span class="cnt">${g.cnt || 0} ${g.unit}</span>${aliasHtml}</div>`;
    html += g.rows;
  });
  body.innerHTML = html;
  bindSmRows();
}
/* 本地 0 命中后的兜底：实时查 XDGAME / 机地两个源站（结果不进库、不缓存） */
async function searchLive(q) {
  if (liveSearching) return;
  liveSearching = true;
  const body = $('#smBody');
  body.innerHTML = `<div class="sm-sec">正在实时搜索源站 “${esc(q)}”…<span class="cnt">约 3-8s</span></div>${smSkeleton(4)}`;
  try {
    const j = await fetch(api('/api/search?q=' + encodeURIComponent(q) + '&refresh=1')).then(r => r.json());
    const xd = j.sources && j.sources.xdgamer;
    const ji = j.sources && j.sources.jidi;
    let html = `<div class="sm-sec">源站实时结果 · 本地库未收录<span class="tag real">LIVE</span></div>`;
    html += `<div class="sm-sec" style="padding-top:4px">XDGAME 站内<span class="tag real">LIVE</span><span class="cnt">${xd && xd.ok ? (xd.items || []).length + ' 款' : '不可用'}</span></div>`;
    if (!xd || !xd.ok) html += `<div class="sm-empty" style="padding:14px">XDGAME 站内搜索不可用：${esc((xd && xd.error) || '网络异常')}</div>`;
    else if (!(xd.items || []).length) html += `<div class="sm-empty" style="padding:14px">XDGAME 站内无结果</div>`;
    else html += (xd.items || []).map(smRow).join('');
    html += `<div class="sm-sec" style="padding-top:12px">机地站内<span class="tag match">LIVE</span><span class="cnt">${ji && ji.ok ? (ji.items || []).length + ' 款' : '不可用'}</span></div>`;
    if (!ji || !ji.ok) html += `<div class="sm-empty" style="padding:14px">机地搜索不可用：${esc((ji && ji.error) || '网络异常')}</div>`;
    else if (!(ji.items || []).length) html += `<div class="sm-empty" style="padding:14px">机地站内无结果</div>`;
    else html += (ji.items || []).map(smRow).join('');
    html += `<div class="sm-acts" style="padding-top:12px">
      <a class="mini-btn" style="flex:1;text-decoration:none" href="${esc((j.searchUrl && j.searchUrl.xdgamer) || 'https://www.xdgame.com/')}" target="_blank" rel="noopener">前往 XDGAME 站内搜 ↗</a>
      <a class="mini-btn" style="flex:1;text-decoration:none;background:rgba(230,65,93,.07);border-color:rgba(230,65,93,.3);color:var(--c-jidi)" href="${esc((j.searchUrl && j.searchUrl.jidi) || 'https://jidiyouxi.com/')}" target="_blank" rel="noopener">前往机地站内搜 ↗</a>
    </div>`;
    body.innerHTML = html;
    bindSmRows();
  } catch (e) {
    body.innerHTML = `<div class="sm-empty"><div class="big">⚠️</div>实时搜索失败：${esc(e.message)}</div>`;
  } finally { liveSearching = false; }
}
/* 偏好：本地 0 命中是否自动实时查源站（localStorage 'ghAutoLive'，默认关=手动） */
function toggleAutoLive(el) {
  localStorage.setItem('ghAutoLive', el.checked ? '1' : '0');
  toast(el.checked ? '已开启：本地搜不到时自动实时查源站' : '已关闭自动查源站（恢复手动）');
  if (el.checked && lastQ) searchLive(lastQ);
}
function bindRowCards(root) {
  $$('.row-card', root || document).forEach(c => c.addEventListener('click', () => openDetail(c.dataset.url, c.dataset.fb)));
}

/* ============ 键盘 ←/→ 切换详情 / Esc 关闭 ============ */
let keyRows = [];     // 当前可见行卡数组
let keyIdx = -1;
/* 当前可切换的条目集：搜索进入 → 弹窗结果行；列表进入 → 主列行卡 */
function collectRows() { keyRows = $$(detailFromSearch ? '#smBody .sm-row' : '#colMain .row-card'); }
/* 详情切换共用：dir=+1 下一款 / -1 上一款（键盘 ←/→ 与移动端抽屉横滑共用） */
function switchDetail(dir) {
  if (!$('#drawer').classList.contains('show')) return false;
  if (drawerMode !== 'game') return false;   // 配置面板（bh / pc）不支持左右切换
  if (!keyRows.length) collectRows();
  const cur = document.querySelector('.on-drawer') || keyRows[keyIdx >= 0 ? keyIdx : 0];
  keyIdx = Math.max(0, keyRows.indexOf(cur));
  const next = keyRows[keyIdx + dir];
  if (next) {
    keyIdx = keyRows.indexOf(next);
    next.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    openDetail(next.dataset.url, next.dataset.fb, detailFromSearch);
    return true;
  }
  return false;
}
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    if (smOpen) { closeSearch(); return; }   // 搜索弹窗优先关闭
    closeDetail();
    return;
  }
  if (!$('#drawer').classList.contains('show')) return;
  if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
  e.preventDefault();
  if (!switchDetail(e.key === 'ArrowRight' ? 1 : -1)) toast('已是列表边缘，没有更多条目');
});
/* 移动端抽屉横滑：左滑=下一款 / 右滑=上一款（桌面另有 ←/→ 键） */
(function bindSwipe() {
  const el = $('#drawer');
  let x0 = null, y0 = null;
  el.addEventListener('touchstart', (e) => { const t = e.touches[0]; x0 = t.clientX; y0 = t.clientY; }, { passive: true });
  el.addEventListener('touchend', (e) => {
    if (x0 == null) return;
    const t = e.changedTouches[0];
    const dx = t.clientX - x0, dy = t.clientY - y0;
    x0 = null; y0 = null;
    if (Math.abs(dx) < 60 || Math.abs(dy) > Math.abs(dx) * 1.2) return; // 需明显横向
    switchDetail(dx < 0 ? 1 : -1);
  }, { passive: true });
})();

/* ================= 联想（弹窗内本地库秒搜，↑/↓ 选择 + 回车直达） ================= */
function sugItems() { return $$('#smBody .sm-row'); }
function moveSug(dir) {
  const items = sugItems();
  if (!items.length) return;
  sugIdx = (sugIdx + dir + items.length) % items.length;
  items.forEach((x, i) => x.classList.toggle('on', i === sugIdx));
  const cur = items[sugIdx]; if (cur) cur.scrollIntoView({ block: 'nearest' });
}
function pickSug() {
  const items = sugItems();
  const el = sugIdx >= 0 ? items[sugIdx] : null;
  if (!el) return false;
  openDetailFromSearch(el);
  return true;
}
/* 联想渲染：输入停顿 180ms 后拉本地库前 8 条，直接铺进弹窗 */
function showSug(items) {
  if (!items.length) {
    sugIdx = -1;
    $('#smBody').innerHTML = `<div class="sm-empty" style="padding:22px 16px"><div class="big">🔍</div>没有匹配的联想<br><span style="font-size:11.5px">按 <b>Enter</b> 搜索本地库</span></div>`;
    return;
  }
  sugIdx = -1;
  $('#smBody').innerHTML = `<div class="sm-sec">本地库联想<span class="tag local">SUGGEST</span><span class="cnt">${items.length} 款</span></div>` + items.slice(0, 8).map(smRow).join('');
  bindSmRows();
  const its = sugItems();
  its.forEach((x, i) => x.addEventListener('mousemove', () => {
    if (sugIdx !== i) { sugIdx = i; its.forEach((y, k) => y.classList.toggle('on', k === i)); }
  }));
}
$('#searchInput').addEventListener('input', () => {
  clearTimeout(sugTimer);
  const q = $('#searchInput').value.trim();
  $('#smClear').classList.toggle('hidden', !q);
  if (!q) { paintSearchHome(); return; }
  sugTimer = setTimeout(async () => {
    try {
      const j = await fetch(api('/api/library?q=' + encodeURIComponent(q) + '&limit=8')).then(r => r.json());
      showSug(j.items || []);
    } catch (e) { /* 联想失败保持现状 */ }
  }, 180);
});
$('#searchInput').addEventListener('keydown', e => {
  if (e.key === 'ArrowDown') { e.preventDefault(); moveSug(1); }
  else if (e.key === 'ArrowUp') { e.preventDefault(); moveSug(-1); }
  else if (e.key === 'Enter') {
    e.preventDefault();
    if (!pickSug()) doSearch(); // 未用键盘选择过 → 回车=搜本地库
  }
});
$('#smClear').addEventListener('click', () => {
  const inp = $('#searchInput'); inp.value = ''; inp.focus();
  $('#smClear').classList.add('hidden');
  sugIdx = -1;
  paintSearchHome();
});
$('#smask').addEventListener('click', closeSearch);
/* 全局快捷键：Ctrl/Cmd+K 唤起（或关闭）搜索弹窗；「/」在非输入态唤起 */
document.addEventListener('keydown', (e) => {
  const typing = /^(INPUT|TEXTAREA|SELECT)$/.test((e.target && e.target.tagName) || '');
  if ((e.ctrlKey || e.metaKey) && (e.key === 'k' || e.key === 'K')) {
    e.preventDefault();
    if ($('#drawer').classList.contains('show')) { closeDetail(); if (!smOpen) openSearch(); return; } // 详情态：先关闭（来自搜索会自动还原弹窗）
    smOpen ? closeSearch() : openSearch();
    return;
  }
  if (e.key === '/' && !typing && !smOpen && !$('#drawer').classList.contains('show')) { e.preventDefault(); openSearch(); }
});

/* ================= 移动端底部 Tab 导航（<=760px 显示） ================= */
$('#tabbar').addEventListener('click', (e) => {
  const a = e.target.closest('a[data-tab]'); if (!a) return;
  e.preventDefault();
  $$('#tabbar a').forEach(x => x.classList.toggle('on', x === a));
  const t = a.dataset.tab;
  if (t === 'rank') {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  } else if (t === 'latest') {
    const el = $('#latest'); if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  } else if (t === 'search') {
    openSearch();
  } else if (t === 'emu' || t === 'pc' || t === 'eg') {
    // 手机三个入口 = 跳到独立专区页的对应子页签
    goEmuPage(t);
  } else if (t === 'about') {
    const el = document.querySelector('footer'); if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
});
/* 桌面顶栏导航。
   首页：热榜 + 最新收录本就是首页的两个分区，点击回顶部即自然看到热榜，
   往下滚就是最新收录，不必再占一个顶栏位（v9.1）。
   ★ v10.2：独立页（手机专区 /emulator.html）上「🏠 首页」必须是**真跳转回聚合首页**
     —— 那里没有 #rankStage，若也拦成「回顶部」就等于点了没反应。历史上正是因为这个，
     页内又塞了一个「← 返回聚合首页」按钮，同一个出口在屏幕上出现两次。
     这里用 body 上的页面标记区分两页语义，而不是各写一份脚本。 */
const IS_EMU_PAGE = document.body.getAttribute('data-page') === 'emulator';
$('#navHome').addEventListener('click', (e) => {
  if (IS_EMU_PAGE) return;              // 独立页：交回 href="/" 正常跳转
  e.preventDefault();
  window.scrollTo({ top: 0, behavior: 'smooth' });
});
/* 三个手机分区已拆到独立页 /emulator.html，点击 = 页面跳转（见下方专区跳转块） */

/* ================= 📱 手机模拟器专区（独立页跳转） =================
   专区已独立成页 public/emulator.html（三段式：手游可玩 / 实测配置 / 兼容·指南），
   首页顶栏只留「手机专区」一个入口，点击直达。
   由 tools/build-emulator-page.js 从本文件派生 emulator.html（单源双页，样式不漂移）。
*/
const EMU_PAGE_HREF = '/emulator.html';
function goEmuPage(hash) { location.href = EMU_PAGE_HREF + (hash ? '#' + hash : ''); }
/* 顶栏「手机专区」入口 → 直达独立页（落「手游可玩」默认页签） */
(function bindNavEmu() {
  const el = document.getElementById('navEmu');
  if (!el) return;
  el.setAttribute('href', EMU_PAGE_HREF);
})();
/* 首页底部 Tab 的手机入口：直达独立页的「手游可玩」默认页签
   （独立页内部再分 手游可玩 / 实测配置 / 兼容·指南，不再各占一个首页 Tab） */
(function bindTabEmu() {
  const el = document.getElementById('tabEmu');
  if (!el) return;
  el.setAttribute('href', EMU_PAGE_HREF + '#emu');
})();
/* [派生页锚点] 以下内容由 tools/build-emulator-page.js 整体替换，请勿删除本行 */

/* ================= 详情抽屉 ================= */
let drawerMode = 'game';   // 'game'=游戏详情 | 'bh'=BannerHub 社区配置面板 | 'pc'=实测配置面板
/* 关闭详情抽屉（✕ / 遮罩 / Esc 共用）—— 原先缺失导致关闭报错且滚动被锁 */
function closeDetail() {
  const d = $('#drawer');
  if (!d.classList.contains('show')) return;
  d.classList.remove('show');
  $('#mask').classList.remove('show');
  $$('.on-drawer').forEach(x => x.classList.remove('on-drawer'));
  if (drawerMode !== 'game') { drawerMode = 'game'; unlockBody(); return; }  // 配置面板：关掉即回页面
  if (detailFromSearch) restoreSearch(); // 从搜索进入 → 原样回到搜索结果
  else unlockBody();
}
/* 详情抽屉关闭键：来自搜索时显示「← 返回搜索」，否则显示「✕ 关闭」 */
function closeBtnHtml() {
  return detailFromSearch
    ? `<button class="d-close d-back" onclick="closeDetail()" title="返回搜索结果"><span class="ar">←</span>返回搜索</button>`
    : `<button class="d-close" onclick="closeDetail()" title="关闭 (Esc)">✕</button>`;
}
/* 从手机两库（社区配置 / 实测配置）的卡片直达游戏详情。
   卡片只持有匹配到的本地库 id → 先按 id 取本地库条目，再走统一详情链路。
   fb 兜底数据一次性给全（title/cover/score/size/genres/dateLabel），
   这样源站抓取慢或失败时抽屉里也有完整信息，不会白屏。 */
async function openDetailById(id, fallbackTitle) {
  if (!id) return;
  let it = null;
  try {
    const j = await fetch(api('/api/library/item?id=' + encodeURIComponent(id))).then(r => r.json());
    if (j && j.ok) it = j.item;
  } catch (e) { /* 取不到就用本地卡片已有的标题兜底 */ }
  if (!it) { toast('本地库未收录该游戏'); return; }
  const fb = {
    id: it.id || '',
    title: it.title || fallbackTitle || '',
    cover: it.cover || '',
    score: it.score || '',
    size: it.size || '',
    genres: it.genres || [],
    dateLabel: it.dateLabel || '',
    jidiUrl: it.jidiUrl || '',    /* v10.22：手机专区卡片直达详情后，下载弹窗也能取双源 */
  };
  openDetail(it.url, encodeURIComponent(JSON.stringify(fb)), false);
}

function openDetail(url, fbEnc, fromSearch) {
  if (!url) return;
  drawerMode = 'game';
  detailFromSearch = !!fromSearch; // 记录来路：true=详情关闭后回到搜索弹窗
  lastDetailUrl = url;
  let fb = {};
  try { fb = JSON.parse(decodeURIComponent(fbEnc || '{}')); } catch (e) {}
  // 高亮当前行卡 + 记录键盘索引
  collectRows();
  const cur = keyRows.find(r => r.dataset.url === url);
  if (cur) { keyIdx = keyRows.indexOf(cur); $$('.on-drawer').forEach(x => x.classList.remove('on-drawer')); cur.classList.add('on-drawer'); }
  rankMark(url); // 热榜同步高亮（若该游戏在榜）
  const body = $('#drawerBody');
  $('#drawer').classList.add('show'); $('#mask').classList.add('show');
  lockBody();
  // 先用库内记录渲染基础信息（秒开），源站详情返回后补全
  const pre = fb.title ? splitName(fb.title) : null;
  const preChip = [fb.size && `容量 ${esc(fb.size)}`, okScoreV(fb.score) && `评分 ${fb.score}`, (fb.genres || []).length && `类型 ${esc(fb.genres.join('/'))}`].filter(Boolean).join(' · ');
  body.innerHTML = `
    ${fb.cover ? `<div class="d-hero"><div class="d-top">${closeBtnHtml()}<span class="src-badge xd" style="color:#fff;background:rgba(11,123,255,.8);align-self:center">XDGAME · 本地库</span></div>
      <img src="${esc(fb.cover)}" onerror="this.remove()"><div class="d-title"><h2>${pre ? esc(pre.zh) : ''}</h2>${pre && pre.en ? `<div class="en">${esc(pre.en)}</div>` : ''}</div></div>` : ''}
    <div class="d-body">
      ${pre ? `<div class="d-hint" style="margin-top:${fb.cover ? '0' : '16px'}"><b>${esc(pre.zh)}</b>${fb.cover ? ' · ' : ''}本地库记录${preChip ? '：' + preChip : '已就绪'} · 正在同步源站最新详情…</div>` : `<div class="d-hint">正在抓取源站详情…</div>`}
      <div class="d-load"><div class="spin"></div></div>
    </div>`;
  fetch(api('/api/detail?url=' + encodeURIComponent(url)))
    .then(r => r.json())
    .then(j => { if (!j.ok) throw new Error(j.error || '解析失败'); paintDetail(j.detail, fb); })
    .catch(e => {
      body.innerHTML = `<div class="d-err"><div style="font-size:30px;margin-bottom:10px">⚠️</div><p>详情抓取失败</p><p style="font-size:12px;margin:6px 0 14px">${esc(e.message)}</p><a class="go xd" href="${esc(url)}" target="_blank" rel="noopener">前往源站查看完整详情 ↗</a></div>`;
    });
}
function paintDetail(d, fb) {
  fb = fb || {};
  const body = $('#drawerBody');
  // 库内字段兜底：源站解析缺 cover/score/size/genres/dateLabel 时用本地库记录补全
  const okScore = (v) => v != null && v > 0 && v <= 10;
  const score = okScore(d.score) ? d.score : (okScore(fb.score) ? fb.score : null);
  const cover = d.cover || fb.cover || '';
  const genres = (d.genres && d.genres.length) ? d.genres : (fb.genres || []);
  const size = d.size || fb.size || '';
  const title = d.title || fb.title || '';
  const n = splitName(title);
  const s = SRC[d.source] || { nm: 'XDGAME', cls: 'xd' };
  const kv = [];
  if (d.source === 'jidi') {
    if (d.releaseDate) kv.push(['发行日期', d.releaseDate]);
    if (d.updateLabel) kv.push(['最近更新', d.updateLabel]);
  } else {
    /* ★ v10.5：XD 详情改版适配后，厂商/发行日期/标签都能从源站取到了 */
    if (d.publisher) kv.push(['游戏厂商', d.publisher]);
    if (d.releaseDate) kv.push(['发行日期', d.releaseDate]);
    if (d.updateLabel) kv.push(['更新时间', d.updateLabel]);
    else if (d.dateLabel) kv.push(['更新日期', d.dateLabel]);
    else if (fb.dateLabel) kv.push(['更新日期', fb.dateLabel]);
  }
  if (size) kv.push(['游戏大小', size]);
  if (genres.length) kv.push(['游戏类型', genres.join(' / ')]);
  if ((d.tags || []).length) kv.push(['游戏标签', d.tags.slice(0, 8).join(' / ')]);
  /* ★ v10.15：原先这里还有一行 `kv.push(['玩家评分', score + ' / 10（Steam 好评率 …）'])`。
   *   同一页里评分因此出现两次（上方 .score-line 的大号分 + 这张表里的「玩家评分 8.6 / 10」），
   *   用户口径「评分重复了，可以减少一个」→ 删掉这里，保留上方那个视觉锚点。
   *   ⚠️ Steam 好评率是**另一条信息**，不跟着删，挪到大号分旁边（见下面 .score-line）。 */
  /* ★ v10.13：不再在这里内联「最低配置要求」。
   *   原因：源站自带的 requirements **只有机地有**，XD 详情页改版后完全没有；
   *   内联写法是「没有就不渲染」→ XD 的 15,302 款游戏那块信息永久空白，
   *   而用户看到的是「详情页的游玩配置没了」。
   *   现在统一交给 #reqSlot 的 loadReqBlock()：源站有就用源站的，
   *   没有就去 Steam 官方接口补（本库 97.2% 的封面带 Steam appid）。
   *   位置也从「版本介绍之后」提到抽屉前段 —— 能不能跑是打开详情页最先想知道的事。 */
  const versionHtml = d.version ? `<div class="block"><h4><span class="ic"></span>版本介绍</h4><p>${esc(d.version)}</p></div>` : '';
  const descHtml = d.desc || d.description ? `<div class="block"><h4><span class="ic"></span>游戏介绍</h4><p>${esc(d.desc || d.description)}</p></div>` : '';
  const shotsHtml = (d.shots && d.shots.length) ? `<div class="block"><h4><span class="ic"></span>游戏预览</h4><div class="shots">${d.shots.slice(0, 6).map(u => `<img src="${esc(u)}" loading="lazy" alt="预览" onerror="this.style.display='none'">`).join('')}</div></div>` : '';
  body.innerHTML = `
    <div class="d-hero">
      <div class="d-top">${closeBtnHtml()}<span class="src-badge ${s.cls}" style="color:#fff;background:${s.cls === 'jidi' ? 'rgba(230,65,93,.8)' : 'rgba(11,123,255,.8)'};align-self:center">${s.nm} 来源</span></div>
      ${cover ? `<img src="${esc(cover)}" alt="${esc(n.zh)}" onerror="this.remove()">` : ''}
      <div class="d-title"><h2>${esc(n.zh)}</h2>${n.en ? `<div class="en">${esc(n.en)}</div>` : ''}</div>
    </div>
    <div class="d-body">
      <div class="d-hint"><b>GameHub 仅为信息聚合站：</b>以下为源站实时抓取的详情与更新信息，本站不提供下载资源。完整内容请前往源站。</div>
      <div id="bhSlot"></div>
      <div id="reqSlot"></div>
      <div id="trBlock"></div>
      <div id="svBlock"></div>
      <div id="crossSrc"></div>
      ${score ? `<div class="score-line"><span class="score-big">${score}</span><span class="score-meta">玩家评分 · 满分 10${d.steamRate ? `<i>Steam 好评率 ${esc(String(d.steamRate))}</i>` : ''}</span></div>` : ''}
      <div class="kv">${kv.map(([k, v]) => `<div class="it"><div class="k">${esc(k)}</div><div class="v">${esc(v)}</div></div>`).join('')}</div>
      ${descHtml}${versionHtml}${shotsHtml}
      <!-- ★ v10.7：「同分类更多」挪到本块信息之后。
           原先它挂在 #crossSrc 之后（第 6 位），用户一打开抽屉先看到的是**别人的推荐**，
           自己的评分 / 参数 / 介绍反而要往下翻 —— 推荐位不该抢本体的位置。 -->
      <div id="relSlot"></div>
      <!-- ★ v10.11：下载入口放在**最后**（用户口径：「给下载链接的详情页跳转即可（在后面）」）。
           这里只给「跳转到源站帖子」的入口，不铺正文、不复制网盘直链 ——
           本站仍定位信息聚合站，资源与文件都在源站社区帖内。 -->
      <div id="dlSlot"></div>
      <div class="no-dl">🚫 仅聚合 <b>详情页与更新内容</b>，不含任何下载资源</div>
      <div class="d-actions">
        <!-- ★ v10.22：把「跳转到源站」升级成**取回下载链接**。
             用户口径：「将游戏详情页的跳转链接变成获取到对应游戏的下载链接（弹窗展示，
             大部分 XD 都是有多个下载链接，最好是获取到完整的标题）」。
             ⇒ 下载升为主操作（独占一行），源站详情退为次操作 —— 但**仍然保留**：
               更新日志 / 版本介绍 / 评论只在源站有，删掉会丢信息。
             ★ 双源一起取：data-dl-url 给当前源详情页，data-dl-jidi 给机地详情页 URL
               （XD 库里合并进来的 13,448 条都带 jidiUrl）。
               两个都给 → 弹窗里分「XD 官方盘口」「机地社区分享」两组展示，
               比只给一边更接近「把这个游戏的下载链接都拿到」。 -->
        ${(d.url || fb.jidiUrl) ? `<button class="go dl" type="button" id="dlBtn"
           data-dl-open data-dl-title="${esc(n.zh)}" data-dl-sub="${esc(n.en || '')}"
           data-dl-url="${esc(d.url || '')}" data-dl-jidi="${esc(fb.jidiUrl || '')}">⬇ 网盘下载</button>` : ''}
        ${d.url ? `<a class="go ${s.cls}" href="${esc(d.url)}" target="_blank" rel="noopener">前往${s.nm}详情 ↗</a>` : ''}
        <!-- ★ v10.15：跨源按钮**默认隐藏**，只有 linkCounterpart() 查到「这款游戏在另一源的详情页」
             时才显形；查不到就保持不显示。
             用户口径：「详情页中，机地无详情页链接跳转，则不显示」——
             v10.14 那版是「查不到就退到站内搜索结果页」，但一个只能跳到搜索列表的按钮
             和一个跳首页的按钮，对用户来说差别不大（都到不了这款游戏）——不如不显示。
             注意：这里连 href 都不再预置搜索页，避免任何「看起来能点、点过去找不到」的中间态。 -->
        <a class="go ${s.cls === 'jidi' ? 'xd' : 'jidi'}" id="crossGo" hidden
           target="_blank" rel="noopener">${s.cls === 'jidi' ? 'XDGAME' : '机地'}找同名 ↗</a>
      </div>
    </div>`;
  linkCounterpart(d);        // 异步检测另一源同名收录 → 一键互跳 + 决定底部跨源按钮显不显示
  syncDActions();            // ★ v10.15：先按「当前可见按钮数」定列数（跨源按钮默认隐藏，查到详情页才显形）
  loadBhBlock(d, title);     // 📱 手机模拟器配置（命中则给逐条参数，未命中给入口）
  loadReqBlock(d, fb);       // 🖥 PC 配置要求（源站优先，缺则 Steam 官方接口补）★ v10.13
  loadTrBlock(d, title);     // 🛠 修改器（v10.1）
  loadSvBlock(d, title);     // 💾 云存档位置（v10.1）
  loadRelated(d, fb);        // 同分类推荐（库内数据 · 多因子打分）
  loadDlBlock(d, fb, title); // 📥 下载入口（机地社区 MOD / 修改器帖）
}
/* ★ v10.1：端游详情抽屉的三个「外部资源」区块（懒加载 —— 抽屉打开后才请求，不进首包）
 *
 *   🛠 修改器   → /api/trainers/match   风灵月影 / CE 修改表 / 社区贡献 / 小幸 / GCM
 *   💾 云存档   → /api/saves/match      真实落地路径（占位符已人性化）+ 注册表项
 *   📱 手机配置 → /api/mobilehub/match  安卓机上跑通本作的配置数 / 实测帧率
 *
 *   ★ 顺带修掉一个 v9.3 拆独立页时遗留的 bug：loadBhBlock 当时只留下了调用点，
 *     函数定义被删掉了。paintDetail 执行到那一行会抛 ReferenceError，
 *     导致其后的 linkCounterpart() 与 loadRelated() **从未执行** ——
 *     表现为详情里的「另一源也有收录」「同分类更多」两个区块永远不显示。
 *     这里把 loadBhBlock 补回实现，并顺手接上修改器 / 云存档两块。
 *
 *   三个接口都自带**子串检索兜底**（精确名不中时退化为子串匹配），
 *   所以详情标题即使是「中文/English」拼接串也可整体传参 —— 实测两种写法都命中。
 */
const D_TR_SRC = {
  fling: '风灵月影', cheat_table: 'CE 修改表', community: '社区贡献',
  xiaoxing: '小幸修改器', gcm: 'GCM 精选',
};
const D_GCM_URL = 'https://github.com/dyang886/Game-Cheats-Manager/releases';

/* ================= 📱 手机模拟器配置（v10.13 重写） =================
 *
 * 两处改动，都来自用户口径「详情页的游玩配置没有了」：
 *   ① **常显**：原来「匹配不到就整个区块不渲染」。用户打开详情页看到的是「什么都没有」，
 *      分不清是「这游戏没人跑通」还是「这个功能没了」。现在没命中也给区块 +
 *      说明 + 去手机专区的入口（明确告诉用户「是没人跑过，不是没这功能」）。
 *   ② **铺开逐条参数**：原来只有 [机型 | GPU | 日期 | 下载 JSON] ——
 *      真正的玩法参数（Turnip 驱动版本 / DXVK / 容器 / Box64 预设 / 分辨率 / 内存上限）
 *      全在那份 JSON 里，等于「答案在附件中」。现在服务端解析后直接铺在卡上。
 */
const BH_EMU_URL = '/emulator.html#emu';
const BH_DM_URL = '/emulator.html#dm';

/** 一条社区配置 → 参数芯片行（抽屉与完整面板共用同一份渲染，避免两处漂移）
 *  ★ v10.14：新增「机型 → 芯片规格」行（SoC / 品牌 / CPU 核簇 / 性能分）。
 *   p.spec 由服务端 /api/bh/params 注入（服务端一次算完，避免前端 N+1）。 */
function bhParamCard(p) {
  const chips = [];
  const add = (label, val, cls) => { if (val) chips.push(`<span class="kv ${cls || ''}"><b>${esc(label)}</b>${esc(String(val))}</span>`); };
  add('驱动', p.driver, 'hot');
  add('DXVK', p.dxvk, 'hot');
  add('VKD3D', p.vkd3d);
  add('容器', p.container);
  add('翻译层', p.translator, 'ok');
  add('分辨率', p.resolution);
  add('内存', p.maxMem);
  add('核心', p.cores);
  add('FEX', p.fexBuild);
  if (p.vibration) add('振动', '开');
  (p.translatorFlags || []).slice(0, 3).forEach((f) => add('', f));
  const sp = p.spec;
  const specRow = (sp && (sp.soc || sp.gpu))
    ? `<div class="spec">
        ${sp.soc ? `<span class="sp soc"><b>${sp.approx ? '≈' : ''}${esc(sp.soc)}</b></span>` : ''}
        ${sp.brand ? `<span class="sp">${esc(sp.brand)}</span>` : ''}
        ${sp.cpu ? `<span class="sp cpu">${esc(sp.cpu)}</span>` : ''}
        ${sp.score ? `<span class="sp">性能分 <b>${esc(String(Math.round(sp.score)))}</b></span>` : ''}
        ${!sp.soc && sp.gpu ? `<span class="sp">GPU <b>${esc(sp.gpu)}</b></span>` : ''}
      </div>`
    : `<div class="spec"><span class="sp none">该机型代号暂无芯片规格</span></div>`;
  return `<div class="d-param">
    <div class="ph"><span>${esc(p.device || '未知机型')}</span><span class="gpu">${esc(p.gpu || '')}</span>
      <span class="dt">${esc(p.date || '')}</span></div>
    ${specRow}
    <div class="pb">${chips.join('') || '<span class="kv">该份配置未记录可解析参数</span>'}</div>
  </div>`;
}

/** 一条「本站实测记录」→ 抽屉里的紧凑卡片（★ v10.15 新增）
 *  与手游专区「实测配置」面板（openPcPanel）同源同义，这里只是压到抽屉的宽度。
 *  信息优先级按用户抄参数的习惯排：能不能跑 → 什么芯片 → 什么帧率 → 怎么配的。 */
function bhRecRow(x) {
  const kv = [];
  const add = (k, v) => { if (v) kv.push(`<span class="kv-i"><b>${esc(k)}</b>${esc(String(v))}</span>`); };
  add('兼容层', x.layer);
  add('运行模式', x.mode);
  add('驱动', x.gpu);
  add('DXVK', x.dxvk);
  add('vkd3d', x.vkd3d);
  add('运行库', x.runtime);
  add('主程序', x.exe);
  const fps = [x.fpsTier, x.fpsLabel].filter(Boolean).join(' · ');
  return `<div class="r">
    <div class="hd"><span class="pill ${x.ok ? 'ok' : 'no'}">${x.ok ? '可玩' : '不可玩'}</span>
      <span class="dev">${esc(x.chipName || x.chip || '—')}</span>
      ${fps ? `<span class="fps">${esc(fps)}</span>` : ''}</div>
    <div class="kv">${kv.join('') || '<span class="kv-i">这条记录没留下可解析参数</span>'}</div>
    ${x.note ? `<div class="nt">💡 ${esc(x.note)}</div>` : ''}
  </div>`;
}

/* ================= 📱 机型硬件参数面板（★ v10.16 新增） =================
 *  用户口径：「前端显示品牌+型号 如 Xiaomi 25053PC47G → xiaomi Poco F7，
 *            点击可以查看对应手机的硬件配置参数」。
 *
 *  两条数据源分工（实测确认，别搞混）：
 *    · 「内部代号 → 品牌 + 型号」= `data/device-market.json`（MobileModels，离线）
 *    · 「型号名 → 硬件参数」      = `/api/device/hardware`（kalvo，未命中时实时抓 + 落盘）
 *  ⚠️ kalvo 只按**营销名**搜（`POCO F7` 命中、`25053PC47G` 搜不到），
 *     所以按钮上带的是 `data-hw`（译出的型号名），不是 `data-m`（原始代号）。
 *
 *  交互：再点同一台 = 收起；点另一台 = 换成那一台。一次只开一个，避免抽屉越撑越长。 */
let _hwOpen = '';                         // 当前展开的机型（原始名），用于「再点收起」与互斥
/* 默认只展开这几节（按优先级排前面）—— 全量 12 节展开有 1800+px，
   在本来就长的抽屉里等于逼人一直滚。剩下的收进「展开全部」。 */
const HW_KEEP = ['基本信息', '硬件配置', '屏幕', '电池'];
function hwPanelHtml(r) {
  const short = esc(String(r.name || '').split(' - ')[0]);
  const src = r.url ? `<a href="${esc(r.url)}" target="_blank" rel="noopener">kalvo ↗</a>` : '';
  const dg = (r.digest || []).map((d) => `<span><i>${esc(d.label)}</i>${esc(d.value)}</span>`).join('');
  const all = r.groups || [];
  const head = all.filter((g) => HW_KEEP.some((k) => g.name.indexOf(k) >= 0));
  const rest = all.filter((g) => !HW_KEEP.some((k) => g.name.indexOf(k) >= 0));
  const grpOf = (g) => `<div class="grp"><h4>${esc(g.name)}</h4>
      <div class="kvs2">${g.items.map((it) => `<div><span title="${esc(it.k)}">${esc(it.k)}</span><b>${esc(it.v)}</b></div>`).join('')}</div>
    </div>`;
  return `<div class="d-hw"><div class="hw-hd"><b>${short}</b>
      <span class="tag">硬件参数</span>
      ${r.cached ? '' : '<span class="tag more-tag">刚抓取</span>'}
      <span class="src">${src}</span></div>
    ${dg ? `<div class="dg">${dg}</div>` : ''}
    ${head.map(grpOf).join('')}
    ${rest.length ? `<div class="hw-rest" hidden>${rest.map(grpOf).join('')}</div>
      <button type="button" class="hw-more" data-lb="展开全部参数（还有 ${rest.length} 节：${esc(rest.map((g) => g.name).join(' / '))}）"
        onclick="hwToggleRest(this)">展开全部参数（还有 ${rest.length} 节：${esc(rest.map((g) => g.name).join(' / '))}）</button>` : ''}
    </div>`;
}
/** 「展开全部 / 收起」开关 */
function hwToggleRest(btn) {
  const box = btn.parentNode.querySelector('.hw-rest');
  if (!box) return;
  const open = box.hasAttribute('hidden');
  if (open) box.removeAttribute('hidden'); else box.setAttribute('hidden', '');
  btn.textContent = open ? '收起其余参数' : (btn.getAttribute('data-lb') || '展开全部参数');
}
async function toggleDevHardware(btn) {
  const slot = $('#bhHwSlot');
  if (!slot) return;
  const raw = btn.getAttribute('data-m') || '';
  const q = btn.getAttribute('data-hw') || raw;
  const list = btn.closest('.d-devlist');

  /* 再点同一台 → 收起 */
  if (_hwOpen === raw && slot.innerHTML) {
    _hwOpen = ''; slot.innerHTML = '';
    btn.classList.remove('on'); btn.setAttribute('aria-expanded', 'false');
    return;
  }
  if (list) list.querySelectorAll('.dv.on').forEach((b) => { b.classList.remove('on'); b.setAttribute('aria-expanded', 'false'); });
  btn.classList.add('on'); btn.setAttribute('aria-expanded', 'true');
  _hwOpen = raw;

  slot.innerHTML = `<div class="d-hw"><div class="hw-hd"><b>${esc(btn.querySelector('.hd b') ? btn.querySelector('.hd b').textContent : q)}</b>
      <span class="tag">硬件参数</span><span class="src">正在读取…</span></div>
    <div class="load">正在从 kalvo 读取该机型参数…</div></div>`;

  let r = null;
  try {
    r = await fetch(api('/api/device/hardware?m=' + encodeURIComponent(q))).then((x) => x.json());
  } catch (e) { r = null; }
  if (_hwOpen !== raw) return;                    // 期间用户点了别的机型，丢弃这次结果
  if (!r || !r.ok) {
    /* 未收录就如实说「没查到」，不去猜、也不显示空壳面板 */
    slot.innerHTML = `<div class="d-hw"><div class="hw-hd">
        <b>${esc(btn.querySelector('.hd b') ? btn.querySelector('.hd b').textContent : q)}</b>
        <span class="tag">硬件参数</span></div>
      <div class="load">没查到这台机型的参数（kalvo 只按营销名收录，内部代号搜不到）。
        ${r && r.reason === 'not-found' ? '' : '可到 '}<a href="https://zh.kalvo.com/" target="_blank" rel="noopener">kalvo</a> 自行搜索核对。</div></div>`;
    return;
  }
  slot.innerHTML = hwPanelHtml(r);
}

/* ================= 🔗 跨源解析（★ v10.14 新增） =================
 *  用户口径：「机地是跳转到首页，而不是详情页」。
 *  现场：抽屉底部第二个按钮是 `href="https://jidiyouxi.com/"`（**写死的站点根**），
 *        XD 源的游戏点过去就是机地首页，跟这款游戏毫无关系。
 *
 *  修法：跨源要跳「这款游戏在另一源的**详情页**」——
 *    ① 另一源有同名收录（且那条带详情页 url）→ 直接跳该详情页；
 *    ② 没有 → **不显示这个按钮**。
 *
 *  ★ v10.15 补：②原本是「退到该站站内搜索结果页」（jidiyouxi.com/search?keyword=…）。
 *    用户口径变成「机地无详情页链接跳转，则不显示」—— 想通了也对：
 *    一个只能落到搜索列表的按钮，和 v10.14 之前那个落首页的按钮，对用户是同一件事
 *    （都到不了这款游戏），只是体面一点。所以现在查不到就不显示，连带那两个
 *    搜索 URL 构造器（JIDI_SEARCH / XD_SEARCH）也一并删掉，不留没人用的出口。
 *
 *  「另一源是否收录了同款」这件事同时被两个区块需要，所以只查一次（cpCache 按抽屉条目缓存）：
 *    · linkCounterpart() → 渲染「另一源也有收录」卡片 + 决定底部跨源按钮显不显示
 *    · loadBhBlock()     → 把另一源的 libId / 标题（常含英文名）传给 /api/mobilehub/match 做跨中英桥接
 */
let cpCache = { key: '', p: null };

function resolveCounterpart(d) {
  const key = String((d && (d.url || d.id || d.title)) || '');
  if (cpCache.key === key && cpCache.p) return cpCache.p;
  const p = (async () => {
    if (!d || !d.title || !d.source) return null;
    const n = splitName(d.title);
    const zh = (n.zh || d.title).trim();
    if (zh.length < 2) return null;
    /* ★ 查三轮：整名 → 去版本词 → 再去标点。
     *   机地叫「生化危机4**重置版**」、XD 叫「生化危机4**：**重制版」——
     *   直接拿整名去搜本地库往往 0 结果，于是这个区块几乎永远为空。
     *   ⚠️ v10.14 补第三轮：光剥版本词会留下**尾随冒号**（`生化危机4：`），
     *      检索词对不上机地的「生化危机4重置版」，于是这款明明两源都有、
     *      却仍然退到站内搜索。剥掉标点后的 `生化危机4` 才检索得到。
     *   放宽的只是**检索词**，最终是否算同款仍由 sameGame() 把关（带防误配闸门）。 */
    const qs = [zh];
    const PUNCT = /[\s\u3000:：·・\-–—_/／|｜,，.。!！?？'"“”‘’()（）\[\]【】《》<>~～+*&]/g;
    const loose = zh.replace(/重置版|重製版|重制版|重置|高清版|终极版|决定版|完全版|豪华版|年度版/gi, '')
      .replace(PUNCT, '').trim();
    if (loose.length >= 2 && loose !== zh) qs.push(loose);
    const curSrc = d.source === 'jidi' ? 'jidi' : 'xdgamer';
    const otherSrc = curSrc === 'jidi' ? 'xdgamer' : 'jidi';
    const seen = new Set();
    const pool = [];
    for (const q of qs) {
      let j = null;
      try { j = await fetch(api('/api/library?q=' + encodeURIComponent(q) + '&limit=30')).then((r) => r.json()); }
      catch (e) { continue; }
      for (const it of (j && j.items) || []) {
        if (!it || it.source !== otherSrc || seen.has(it.id)) continue;
        seen.add(it.id);
        pool.push(it);
      }
    }
    /* ★ 命中里优先挑「归一后完全相等」的那条 ——
     *   同一检索词常带出一串同系列（生化危机4 → 重制版 / 高清项目2022 / 终极高清版），
     *   若只取 find() 首条，结果会随检索返回顺序漂移。 */
    const want = normGameTitle(zh);
    const cand = pool.filter((it) => sameGame(d.title, it.title));
    /* ★ v10.15：命中里还要**带详情页**才作数。
     *   库内两个源的详情页形态固定（机地 /topic/detail/<id>、XD /game/<id>.html），
     *   实测 15,354 条**无一缺 url**；这里做一次形态校验是为了兜住源站改版后
     *   可能混进来的列表页 / 首页地址 —— 那种地址点过去到不了这款游戏，
     *   按用户口径「无详情页链接则不显示」，不如让按钮不出现。 */
    const ok = cand.filter(hasDetailUrl);
    return ok.find((it) => normGameTitle(splitName(it.title).zh) === want) || ok[0] || null;
  })();
  cpCache = { key, p };
  return p;
}

/** 该条目是否有「可跳的详情页」（两个源的详情页 URL 里都带数字 id） */
function hasDetailUrl(it) {
  return !!(it && it.url) && /\/(topic\/detail|game)\/\d+/i.test(String(it.url));
}

/** 标题归一化：版本词收敛 + 去标点空白（两源命名习惯不同，直接比原文匹配率极低） */
function normGameTitle(s) {
  let x = String(s || '').toLowerCase();
  x = x.replace(/重置版|重製版|重制版|重置/gi, '重制版');
  const junk = /高清版|终极版|决定版|完全版|豪华版|年度版|中文版|重制版|remastered|definitive|ultimate|deluxe|complete|remake|(^|[^a-z])hd([^a-z]|$)/gi;
  let prev;
  do { prev = x; x = x.replace(junk, '$1$2'); } while (x !== prev);   // 反复剥（「终极高清版」要剥两次）
  return x.replace(/[\s\u3000·・:：\-–—_/／|｜,，.。!！?？'"“”‘’()（）\[\]【】《》<>~～+*&]+/g, '');
}

/** 两源标题是否同一款（★ 带防误配闸门） */
function sameGame(a, b) {
  const A = splitName(a), B = splitName(b);
  const zhA = normGameTitle(A.zh), zhB = normGameTitle(B.zh);
  if (zhA && zhB) {
    if (zhA === zhB) return true;
    /* 包含匹配（「生化危机4重制版」⊃「生化危机4」）—— 两边都要够长，否则短名会吸走一堆 */
    if (zhA.length >= 3 && zhB.length >= 3 && (zhA.includes(zhB) || zhB.includes(zhA))) return true;
    /* ⚠️ 防误配闸门：两边**都有**中文段却不相等时，**不退到英文段** ——
       否则「古墓丽影：崛起」和「古墓丽影：暗影」会因为共享英文前缀 Tomb Raider 而互认。 */
    return false;
  }
  const enA = normGameTitle(A.en), enB = normGameTitle(B.en);
  return !!(enA && enB && enA === enB);
}

async function loadBhBlock(d, title) {
  const slot = $('#bhSlot');
  if (!slot) return;
  const t = String(title || (d && d.title) || '').trim();
  if (t.length < 2) return;
  try {
    /* ★ v10.14：把「另一源的同款条目」一起带上 —— 它的 libId 与标题（常含英文名）用于跨中英桥接。
       不这么做的话，机地源的中文标题（「生化危机4重置版」）对不上 mobilehub 的英文名（`Resident Evil 4`），
       会显示「暂无记录」的**假阴性**（同一款游戏从 XD 入口看却有 63 套配置）。 */
    const cp = await resolveCounterpart(d);
    const qs = new URLSearchParams({ t });
    const ownId = String((d && d.id) || '').trim();
    if (ownId) qs.set('id', ownId);
    if (cp) {
      if (cp.id) qs.set('id', cp.id);
      const altNames = [cp.title, splitName(cp.title).en].filter(Boolean);
      if (altNames.length) qs.set('alts', altNames.join(','));
    }
    const j = await fetch(api('/api/mobilehub/match?' + qs.toString())).then(r => r.json());
    const h = j && j.hit;
    /* ---- 未命中：也给区块，明确「是没人跑过」而不是「功能没了」 ---- */
    if (!h) {
      slot.innerHTML = `<div class="d-blk"><h4><span class="ic"></span>手机模拟器配置<span class="cnt">暂无记录</span></h4>
        <div class="d-req-empty">社区配置库与本站实测库里<b>还没有这款游戏</b>的跑通记录 ——
          意味着暂时没有「照着抄就能用」的参数可参考，不代表手机上一定跑不了。</div>
        <div class="d-hint2">可去 <a href="${BH_DM_URL}">手机专区 · 机型兼容</a> 查你的机型能跑哪些游戏，
          或到 <a href="${BH_EMU_URL}">手游中心</a> 看同类游戏的配置（同引擎的作品参数往往通用）。</div></div>`;
      return;
    }
    const tags = [];
    if (h.configs) tags.push(`<span class="d-tg community">社区配置 ${h.configs} 套</span>`);
    if (h.records) tags.push(`<span class="d-tg gcm">本站实测 ${h.records} 条</span>`);
    if (h.bestLabel) tags.push(`<span class="d-tg cloud">最佳 ${esc(String(h.bestLabel))}</span>`);
    if (h.tier) tags.push(`<span class="d-tg phone">档位 ${esc(h.tier)}</span>`);
    /* ★ v10.14：计数改用「机型」为主 —— 用户想知道的是「哪些机型能跑」，
       而 GPU 一列在清洗脏值后信息量本来就更少（942 条只剩机型可依据）。 */
    const devCnt = (h.devices || []).length;
    const gpuCnt = (h.gpus || []).length;
    const cntTxt = [devCnt ? `${devCnt} 款机型` : '', gpuCnt ? `${gpuCnt} 种 GPU` : ''].filter(Boolean).join(' · ');
    _hwOpen = '';                     // 换了一款游戏 → 硬件面板的「已展开」状态一并作废
    slot.innerHTML = `<div class="d-blk"><h4><span class="ic"></span>手机模拟器配置<span class="cnt">${cntTxt}</span></h4>
      <div class="d-tg-row">${tags.join('')}</div>
      <div id="bhDevSlot"></div>
      <div id="bhHwSlot"></div>
      <div id="bhRecSlot"></div>
      <div id="bhParamSlot"><div class="d-hint2" style="border:0;padding-top:4px">正在读取逐条游玩参数…</div></div>
      <div class="d-hint2">参数为玩家在安卓机上跑通本作后导出的实际配置（驱动 / DXVK / 容器 / 翻译层）。
        完整清单见 <a href="${BH_EMU_URL}">手机专区 · 手游中心</a>。</div></div>`;

    /* ---- ① 机型清单：按「性能分」从弱到强排，并标出**门槛机型** ----
     *   ★ v10.15：看这一块的人真正的问题是「我的手机能不能跑」。
     *   旧的平铺 chips 只回答「谁跑过」，还得自己一台台去认型号。现在：
     *     · 有性能分的按分**升序**排（同分保持原顺序，V8 稳定排序）—— 门槛低的排前面
     *     · 最弱那台标「门槛」：它跑通过，比它强的机型基本也能跑
     *     · 每台补一个性能分数字，跨品牌（Adreno / Mali / PowerVR）可以直接比大小 */
    /* ★ v10.17：`h.devices` 现在是「社区库聚合摘要（上游只有 6 格）+ 逐条配置里的机型」合并后的全量，
       服务端已去重并对齐了写法（`MTN NX3` 与 `HONOR MTN-NX3` 视为同一台）。这里只负责截断展示。 */
    const allDevs = h.devices || [];
    const devs = allDevs.slice(0, 24);
    const ds = $('#bhDevSlot');
    if (devs.length && ds) {
      let specs = {};
      try {
        const sr = await fetch(api('/api/device/specs?models=' + encodeURIComponent(devs.join('|')))).then((r) => r.json());
        specs = (sr && sr.specs) || {};
      } catch (e) { specs = {}; }
      const arr = devs.map((m) => {
        const s = specs[m] || null;
        const mk = (s && s.mkt) || null;
        const disp = (mk && mk.display) || '';
        const w0 = disp.split(' ')[0] || '';
        const codeShort = (w0 && m.toLowerCase().startsWith(w0.toLowerCase() + ' ')) ? m.slice(w0.length + 1).trim() : m;
        return {
          m,
          name: disp || m,
          code: (mk && mk.resolved && disp && disp.toLowerCase() !== m.toLowerCase()) ? codeShort : '',
          hwq: (mk && (mk.market || mk.display)) || m,
          /* ★ v10.18：芯片由服务端三级降级的**本地两级**给出（配对索引 → 串内芯片号），
             拿不到就是空 —— 空的那批下面会自动联网补（fillMissingDevChips）。 */
          chip: (s && s.chip) || '',
          chipSrc: (s && s.chipSrc) || '',
          score: (s && s.score) || 0,
          approx: !!(s && s.approx),
        };
      });
      const sorted = arr.slice().sort((a, b) => (a.score || 1e9) - (b.score || 1e9));
      const gate = sorted.find((x) => x.score > 0) || null;   // 有性能分的最弱一台 = 门槛
      /* ★ v10.18：门槛不再单起一行摘要（那行与清单首行是同一台，读起来像重复）。
         改成两条：① 那台机型上加橙色「门槛」徽标 ② 表头补一格图例说明含义。 */
      const cntEl = slot.querySelector('.d-blk .cnt');
      if (cntEl && gate) {
        cntEl.innerHTML = esc(cntTxt)
          + `<span class="d-devlist-lg" title="橙色那台是实测跑通过的最弱机型 —— 比它强的机型基本也能跑">门槛机型</span>`;
      }
      const hiddenDev = allDevs.length - devs.length;
      const more = hiddenDev > 0
        ? `<span class="dv more">还有 ${hiddenDev} 台机型未展开（上游共汇总 ${h.configs} 套配置）</span>` : '';
      /* 芯片名太长（如 `Dimensity 8350 (MT6897 MT6897Z_B/ZA MT8792Z/NA)`、
         `Samsung Exynos 2200 (国际版本) / Qualcomm Snapdragon 8 Gen 1 (美国)`）徽标里放不下，
         只留**主名**（第一个 `(` 或第一个 ` / ` 之前），完整值挂在 title 上、详情面板里也有。 */
      const chipFull = (s) => String(s || '').trim();
      const chipShort = (s) => {
        const t = chipFull(s);
        const cut = [t.indexOf('（'), t.indexOf('('), t.indexOf(' / '), t.indexOf('/')]
          .filter((i) => i > 0).sort((a, b) => a - b)[0];
        return (cut ? t.slice(0, cut) : t).trim() || t;
      };
      /* 芯片来源标记：只标「非默认路径」的两种，默认（本地配对）不加标记降低噪音 */
      const chipTag = (src) => (src === 'kalvo'
        ? '<u title="本地库没有 → 已联网（kalvo）自动补全">网</u>'
        : (src === 'token' ? '<u title="芯片号直接写在机型串里，本地解析得到">串</u>' : ''));
      const chipHtml = (x, extraCls) => {
        if (!x.chip) return `<i class="chip none${extraCls || ''}" title="本地库与联网都查不到 —— 如实标注，未编造">未收录</i>`;
        const cls = 'chip' + (x.chipSrc === 'kalvo' ? ' ol' : '') + (extraCls || '');
        const full = chipFull(x.chip);
        const t = (x.approx ? '≈' : '') + chipShort(x.chip);
        return `<i class="${cls}" title="${esc(full)}">${chipTag(x.chipSrc)}${esc(t)}</i>`;
      };
      const devRow = (x) => {
        const isGate = !!(gate && x.m === gate.m);
        return `<button type="button" class="dv${isGate ? ' gate' : ''}"
          data-m="${esc(x.m)}" data-hw="${esc(x.hwq)}" aria-expanded="false">
          <span class="hd"><b>${esc(x.name)}</b>${isGate ? '<u class="gtag" title="橙色：实测跑通过的最弱机型 —— 比它强的机型基本也能跑">门槛</u>' : ''}${x.score ? `<em>${esc(String(Math.round(x.score)))}</em>` : ''}<u class="chev">▼</u></span>
          <span class="sub">${chipHtml(x)}${x.code ? `<s>${esc(x.code)}</s>` : ''}</span>
        </button>`;
      };
      ds.innerHTML = `<div class="d-devlist">${sorted.map(devRow).join('')}${more}</div>`;
      ds.onclick = (ev) => {
        const b = ev.target.closest && ev.target.closest('.dv[data-hw]');
        if (b) toggleDevHardware(b);
      };

      /* ---- ★ v10.18 ③：未收录的机型**自动联网补全** ----
       *   本地两级解决不了的（如 `Honor MTN-NX3` → 本地无芯片，但 kalvo 有 `Honor Magic8 Lite`），
       *   这里异步补：先把待补的标成「联网查询中…」，回来后**原地替换**那枚徽标 ——
       *   不重渲染整个清单（重渲染会把用户已经展开的硬件面板一起收掉）。
       *   补不到就保持「未收录」，联网失败也不假装成功。 */
      const pending = sorted.filter((x) => !x.chip).map((x) => x.m);
      if (pending.length) {
        const btnOf = (m) => {
          for (const el of ds.querySelectorAll('.dv[data-m]')) if (el.getAttribute('data-m') === m) return el;
          return null;
        };
        const paint = (m, html) => {
          const el = btnOf(m);
          const box = el && el.querySelector('.sub .chip');
          if (box) box.outerHTML = html;
        };
        for (const m of pending) paint(m, '<i class="chip wait">联网查询中…</i>');
        (async () => {
          let fills = {};
          try {
            const fr = await fetch(api('/api/device/fill?models=' + encodeURIComponent(pending.join('|')))).then((r) => r.json());
            fills = (fr && fr.fills) || {};
          } catch (e) { fills = {}; }
          for (const m of pending) {
            const f = fills[m] || null;
            if (f && f.chip) {
              paint(m, chipHtml({ chip: f.chip, chipSrc: f.chipSrc, approx: false }));
            } else {
              paint(m, chipHtml({ chip: '', chipSrc: '' }));
            }
          }
        })();
      }
    }

    /* ---- ② 本站实测记录（★ v10.15 新增） ----
     *   旧版这一块**只有一个「本站实测 N 条」标签**，一条内容都看不到 ——
     *   用户口径「我需要看到手游专区里游戏详情页能看到对应手机配置（实测 / 社区库）」。
     *   社区那半边（逐条参数）本来就有，缺的正是**实测**这半边：
     *   表格里的 兼容层 / 运行模式 / 驱动 / DXVK / 帧率 全在 /api/pc/records 里，只是抽屉从没调过。
     *   版式直接用 `.pc-rec`（这套 CSS 早就在，一直只在手游专区的实测面板里用）。 */
    const rec = $('#bhRecSlot');
    if (rec && h.records > 0) {
      try {
        const rj = await fetch(api('/api/pc/records?k=' + encodeURIComponent(t))).then((r) => r.json());
        const recs = (rj && rj.items) || [];
        rec.innerHTML = recs.length
          ? `<div class="bh-sub">本站实测记录<span class="n">${recs.length} 条</span>
               <a href="${BH_EMU_URL}">看全部实测 ↗</a></div>
             <div class="pc-rec">${recs.map(bhRecRow).join('')}</div>`
          : '';
      } catch (e) { rec.innerHTML = ''; }
    }

    /* ---- ③ 铺开逐条参数（社区库）：把该游戏的所有候选仓库键一起传（服务端挑份数最多的那个） ---- */
    const keys = (h.bhKeys || []).join(',');
    const ps = $('#bhParamSlot');
    if (!keys || !ps) {
      if (ps) ps.innerHTML = '<div class="d-hint2" style="border:0;padding-top:4px">这款只有本站实测记录，逐条社区参数见手机专区。</div>';
      return;
    }
    const pj = await fetch(api('/api/bh/params?k=' + encodeURIComponent(keys) + '&limit=3')).then(r => r.json());
    const items = (pj && pj.items) || [];
    if (!items.length) { ps.innerHTML = ''; return; }
    ps.innerHTML = items.map(bhParamCard).join('')
      + (h.configs > items.length
        ? `<div class="more">共 ${h.configs} 份配置，这里显示最近的 ${items.length} 份 —— 去 <a href="${BH_EMU_URL}">手游中心</a> 点「📋 社区配置」看全部</div>`
        : '');
  } catch (e) { /* 静默：区块是锦上添花，失败不打扰用户 */ }
}

/* ================= 🖥 PC 配置要求（v10.13 新增） =================
 *
 * 用户口径：「详情页的游玩配置没有了」。
 * 根因：XDGAME 详情页改版后**本身就没有配置要求数据**，而老代码是
 *       `d.requirements ? 渲染 : ''` —— XD 来源的 15,302 款游戏这块**永久空白**。
 * 补法：源站有（机地）直接用；没有就走 /api/pcreq（Steam 官方接口，
 *       本库 97.2% 的封面里带 Steam appid，能拿到官方简体中文的配置）。
 * 位置：放在「手机模拟器配置」之后、「修改器」之前 —— 「能不能跑」是打开详情页最先想知道的事。
 */
const REQ_LABEL = { os: '系统', cpu: 'CPU', ram: '内存', gpu: '显卡', dx: 'DirectX', net: '网络', storage: '存储', note: '附注' };
const REQ_ORDER = ['os', 'cpu', 'ram', 'gpu', 'dx', 'net', 'storage', 'note'];

/** 一组配置字段 → 一栏 */
function reqCol(title, req, cls) {
  const rows = REQ_ORDER.filter((k) => req && req[k])
    .map((k) => `<div class="rr"><i>${REQ_LABEL[k]}</i><span>${esc(req[k])}</span></div>`).join('');
  if (!rows) return '';
  return `<div class="rc ${cls || ''}"><div class="rc-h">${title}</div>${rows}</div>`;
}

async function loadReqBlock(d, fb) {
  const slot = $('#reqSlot');
  if (!slot) return;
  const title = String(d.title || (fb && fb.title) || '').trim();
  /* ① 源站自带（机地详情页有 game_sys_reqs）—— 不再等到网络回包，立刻渲染 */
  if (d.requirements && Object.keys(d.requirements).length) {
    slot.innerHTML = `<div class="d-blk"><h4><span class="ic"></span>配置要求<span class="cnt">源站提供</span></h4>
      <div class="d-req">${reqCol('最低配置', d.requirements)}</div>
      <div class="d-hint2">来自源站详情页的最低配置要求，供参考；实际体验受画质设置与驱动影响。</div></div>`;
    return;
  }
  const id = (fb && fb.id) || d.id || '';
  const cover = d.cover || (fb && fb.cover) || '';
  if (!id && !title && !cover) return;
  slot.innerHTML = `<div class="d-blk"><h4><span class="ic"></span>配置要求<span class="cnt">查询中…</span></h4>
    <div class="d-req-empty">源站详情页未提供配置要求，正在从 Steam 官方接口查询…</div></div>`;
  try {
    const qs = '?t=' + encodeURIComponent(title) + (id ? '&id=' + encodeURIComponent(id) : '') + (cover ? '&cover=' + encodeURIComponent(cover) : '');
    const j = await fetch(api('/api/pcreq' + qs)).then((r) => r.json());
    if (!j || !j.hit) {
      slot.innerHTML = `<div class="d-blk"><h4><span class="ic"></span>配置要求<span class="cnt">暂无数据</span></h4>
        <div class="d-req-empty">源站与 Steam 官方接口都<b>没有这款游戏的配置要求</b>（多为独立小游戏 / 未上架 Steam 的作品）。</div>
        <div class="d-hint2">多为独立小游戏 / 未上架 Steam 的作品。可到
          <a href="${esc(d.url || '#')}" target="_blank" rel="noopener">源站详情页</a> 或
          <a href="https://store.steampowered.com/search/?term=${encodeURIComponent(String(d.title || '').split('/')[0])}" target="_blank" rel="noopener">Steam 商店</a> 自行核对。</div></div>`;
      return;
    }
    const srcLabel = j.src === 'jidi' ? '机地' : 'Steam 官方';
    const cols = reqCol('最低配置', j.min) + reqCol('推荐配置', j.rec, 'rec');
    slot.innerHTML = `<div class="d-blk"><h4><span class="ic"></span>配置要求<span class="cnt">${srcLabel}</span></h4>
      <div class="d-req">${cols}</div>
      <div class="d-hint2">数据来自 <b>${srcLabel}</b>${j.name ? '（' + esc(j.name) + '）' : ''}，为 <b>PC(Windows)</b> 端配置；
        想在<b>手机</b>上跑请看上一块「手机模拟器配置」。</div></div>`;
  } catch (e) {
    slot.innerHTML = '';
  }
}

/* 🛠 修改器：这款有没有修改器、来自哪个来源、什么版本 */
async function loadTrBlock(d, title) {
  const slot = $('#trBlock');
  if (!slot) return;
  const t = String(title || (d && d.title) || '').trim();
  if (t.length < 2) return;
  try {
    const j = await fetch(api('/api/trainers/match?t=' + encodeURIComponent(t))).then(r => r.json());
    const items = (j && j.items) || [];
    if (!items.length) { slot.innerHTML = ''; return; }             // 无收录就不占版面
    const rows = items.slice(0, 8).map((it) => {
      const src = it.source || 'gcm';
      const nm = it.zh || it.name || '';
      return `<div class="d-tr-it"><span class="d-tg ${esc(src)}">${esc(D_TR_SRC[src] || src)}</span>
        <span class="nm" title="${esc(it.name || nm)}">${esc(nm)}</span>
        ${it.version ? `<span class="ver">v ${esc(it.version)}</span>` : ''}</div>`;
    }).join('');
    const more = items.length > 8 ? `<div class="more">另有 ${items.length - 8} 个来源未展示，去手机专区「修改器」页看全部</div>` : '';
    slot.innerHTML = `<div class="d-blk"><h4><span class="ic"></span>修改器<span class="cnt">${items.length} 个来源</span></h4>${rows}${more}
      <div class="d-hint2">修改器文件放到<b>游戏安装根目录</b>（与主程序 .exe 同级）后再启动；CE 修改表需先运行 Cheat Engine 再加载表格。<br>
        清单聚合自 Game Cheats Manager 公开数据，<a href="${D_GCM_URL}" target="_blank" rel="noopener">打开 GCM 下载页 ↗</a></div></div>`;
  } catch (e) {}
}

/* 💾 云存档：存档文件放哪（用户最想要的答案），路径不截断，直接给可抄的完整串 */
async function loadSvBlock(d, title) {
  const slot = $('#svBlock');
  if (!slot) return;
  const t = String(title || (d && d.title) || '').trim();
  if (t.length < 2) return;
  try {
    const j = await fetch(api('/api/saves/match?t=' + encodeURIComponent(t))).then(r => r.json());
    const h = j && j.hit;
    if (!h) { slot.innerHTML = ''; return; }
    const paths = h.paths || [], regs = h.regs || [];
    if (!paths.length && !regs.length) { slot.innerHTML = ''; return; }
    const MAXP = 3, MAXR = 2;
    const rows = [];
    for (const p of paths.slice(0, MAXP)) {
      const tg = (p.tags && p.tags.length) ? String(p.tags[0]) : 'save';
      const label = tg === 'save' ? '存档' : (tg === 'config' ? '配置' : tg);
      rows.push(`<div class="p"><i>${esc(label)}</i><span>${esc(p.shown || p.raw)}</span></div>`);
    }
    for (const r of regs.slice(0, MAXR)) rows.push(`<div class="p reg"><i>注册表</i><span>${esc(r.raw)}</span></div>`);
    const hidden = (paths.length - Math.min(paths.length, MAXP)) + (regs.length - Math.min(regs.length, MAXR));
    const more = hidden > 0 ? `<div class="more">另有 ${hidden} 条存档位置未展示，去手机专区「云存档」页看全部</div>` : '';
    const tags = [];
    (h.cloud || []).forEach(c => tags.push(`<span class="d-tg cloud">☁ ${esc(String(c).toUpperCase())}</span>`));
    if (h.phone) tags.push('<span class="d-tg phone">手机能玩</span>');
    if (h.installDir) tags.push(`<span class="d-tg dim">安装目录 ${esc(h.installDir)}</span>`);
    slot.innerHTML = `<div class="d-blk"><h4><span class="ic"></span>云存档位置<span class="cnt">${paths.length + regs.length} 条记录</span></h4>
      ${tags.length ? `<div class="d-tg-row" style="margin-bottom:6px">${tags.join('')}</div>` : ''}
      <div class="d-sv">${rows.join('')}</div>${more}
      <div class="d-hint2">路径中的 <code>&lt;用户名&gt;</code> / <code>&lt;平台账号ID&gt;</code> 是占位符，按你自己的账号替换。<b>存档前请先退出游戏</b>，避免被覆盖。数据来自 Ludusavi 开源清单（MIT）。</div></div>`;
  } catch (e) {}
}

/* 详情内双源互链：机地话题 ↔ XD 版本（用现有本地库搜索端点实现,不动后端）
 *
 *  ★ v10.14 两处改动：
 *   ① 匹配改用 sameGame()（版本词收敛 + 去标点）—— 旧实现直接比原文，
 *      机地「生化危机4重置版」对不上 XD「生化危机4：重制版」，所以这个区块**几乎总是空的**。
 *   ② 顺带修正底部那个跨源按钮的落点：查到同名 → 指向该条详情页；
 *      查不到 → 保持站内搜索页（渲染时已给），**不再**是写死的站点首页。
 *   匹配结果与 loadBhBlock 共用（resolveCounterpart 只查一次）。 */
async function linkCounterpart(d) {
  const slot = $('#crossSrc');
  if (!slot || !d || !d.title || !d.source) return;
  const go = $('#crossGo');
  try {
    slot.innerHTML = '<div class="x-none">正在检查另一源收录…</div>';
    /* ★ v10.15：resolveCounterpart 现在只认「另一源**有详情页**」的命中（见那里的注释），
       所以这里不必再区分「详情页 / 搜索页」—— 有 hit 就是详情页，没有就保持按钮隐藏。 */
    const hit = await resolveCounterpart(d);
    if (!hit || !hit.url) {
      slot.innerHTML = '';
      if (go) go.hidden = true;          // 无详情页可跳 → 不显示（用户口径）
      syncDActions();
      return;
    }
    const otherSrc = d.source === 'jidi' ? 'xdgamer' : 'jidi';
    const s = SRC[otherSrc] || { nm: 'XDGAME', cls: 'xd' };
    /* 底部按钮改指「这款游戏在另一源的详情页」 */
    if (go) {
      go.setAttribute('href', hit.url);
      go.textContent = `前往${s.nm}详情 ↗`;
      go.hidden = false;
    }
    syncDActions();
    const fb = encodeURIComponent(JSON.stringify({
      id: hit.id || '', title: hit.title, cover: hit.cover || '', score: okScoreV(hit.score) ? hit.score : null,
      size: hit.size || '', genres: (hit.genres || []).slice(0, 4), dateLabel: hit.dateLabel || '',
      jidiUrl: hit.jidiUrl || '',    /* v10.22：跨源跳转进详情后，下载弹窗也能取双源 */
    }));
    slot.innerHTML = `<div class="block" style="margin-bottom:12px"><h4><span class="ic" style="background:linear-gradient(135deg,#E6415D,#0B7BFF)"></span>另一源也有收录
        <a href="${esc(hit.url || '#')}" target="_blank" rel="noopener" style="margin-left:auto;font-size:11px;font-weight:700;color:var(--c-t3);text-decoration:none">去源站 ↗</a></h4>
      <div class="x-src"><button class="x-it" onclick="openDetail('${esc(hit.url)}','${fb}',detailFromSearch)">
        <span class="src-badge ${s.cls}">${s.nm}</span><span class="bd"><span class="t">${esc(hit.title)}</span></span>
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
      </button></div></div>`;
  } catch (e) { slot.innerHTML = ''; if (go) go.hidden = true; syncDActions(); }
}
/** 底部动作区：列数与显隐跟着「实际可见的按钮数」走。
 *  ★ v10.15 为什么必须有它：跨源按钮要等另一源查完才知道显不显示，
 *    而 .d-actions 是 2 列网格 —— 只剩一个按钮时会空掉右半边。
 *    同时兜住「本条目没有 d.url」的情况：两个按钮都不可见时整块收起，
 *    不留一条空的分隔线。 */
function syncDActions() {
  const box = $('.d-actions');
  if (!box) return;
  const n = $$('.d-actions > a.go').filter((a) => !a.hasAttribute('hidden')).length;
  box.classList.toggle('one', n <= 1);
  box.style.display = n ? '' : 'none';
}
/* 同分类推荐 ★ v10.11：改走后端多因子打分（类型 IDF + 系列名 + 评分接近度 + 容量接近度）
 *
 *  旧做法：取 genres[0] → /api/library/browse?g=…&sort=score → 取 100 条随机洗牌 6 条。
 *  两个致命问题（用户反馈「同分类更多里的游戏不太适配」）：
 *    ① 库里每款游戏**只有一个类型标签**，而「动作冒险」独占 36.8%（5,627 条）
 *       —— 按它取高分再洗牌 = 抽卡，跟当前游戏毫无关系；
 *    ② 标签里混着 `免费专区` / `联机整合` / `模拟器整合` 这类**运营标签**，
 *       它们描述「怎么玩/收不收费」而不是「玩什么」，参与推荐会把风马牛不相及的游戏凑一桌。
 *  现由 /api/library/related 统一打分并返回 why 标签（同系列 / 同类型）。 */
async function loadRelated(d, fb) {
  const slot = $('#relSlot');
  if (!slot || !d) return;
  const g = (d.genres && d.genres.length) ? d.genres[0] : ((fb && fb.genres && fb.genres[0]) || '');
  const t = String(d.title || (fb && fb.title) || '').trim();
  const id = (fb && fb.id) || d.id || '';
  if (!g && !t) { slot.innerHTML = ''; return; }
  try {
    const qs = 'limit=8'
      + (id ? '&id=' + encodeURIComponent(id) : '')
      + (t ? '&t=' + encodeURIComponent(t) : '')
      + (g ? '&g=' + encodeURIComponent(g) : '');
    const j = await fetch(api('/api/library/related?' + qs)).then(r => r.json());
    if (!j || !j.ok) { slot.innerHTML = ''; return; }
    const picks = (j.items || [])
      .filter(it => it && it.url && it.url !== d.url)
      .slice(0, 6);
    if (!picks.length) { slot.innerHTML = ''; return; }
    const head = j.genre ? `同分类更多 · ${esc(j.genre)}` : '相似推荐';
    slot.innerHTML = `<div class="block" style="margin-bottom:12px"><h4><span class="ic" style="background:linear-gradient(135deg,#0B7BFF,#6366F1)"></span>${head}</h4>
      <div class="rel-row">${picks.map(it => {
        const fb2 = encodeURIComponent(JSON.stringify({ id: it.id || '', title: it.title, cover: it.cover || '', score: okScoreV(it.score) ? it.score : null, size: it.size || '', genres: (it.genres || []).slice(0, 4), dateLabel: it.dateLabel || '' }));
        const why = (it.why && it.why.length) ? `<span class="why">${esc(it.why[0])}</span>` : '';
        return `<button class="rel-it" onclick="openDetail('${esc(it.url)}','${fb2}',detailFromSearch)">
          ${it.cover ? `<img src="${esc(it.cover)}" loading="lazy" alt="" onerror="this.remove()">` : '<span class="noimg"></span>'}
          <span class="bd"><span class="t">${esc(splitName(it.title).zh)}</span><span class="s">${okScoreV(it.score) ? `<b>★${it.score}</b>` : ''}${why}</span></span>
        </button>`;
      }).join('')}</div></div>`;
  } catch (e) { slot.innerHTML = ''; }
}

/* 📥 下载入口 ★ v10.11 新增 —— 详情页里「云存档等下载链接」缺失的补位
 *
 *  用户口径：「给下载链接的详情页跳转即可（在后面）」→ 只做**跳转入口**：
 *  帖子标题 + 网盘类型 + 直链条数 + 时间，点一下去源站帖子取件。
 *  不铺正文、不复制网盘直链 —— 本站继续是信息聚合站，文件都在源站社区帖里。
 *
 *  ★ 查询必须**同时传 t 与 id**：机地的话题游戏名与端游库标题是两套命名，
 *    只传 id 会漏（同一款游戏的话题可能挂在别的 libId 上），只传名称遇到
 *    「中文/English」拼接串或别名时也会漏。后端 /api/mods/match 做 id ∪ 名称 联合兜底。
 *    另注意：这一块与上面的「🛠 修改器」是**两套数据**，互不替代 ——
 *    上面的 trainers 来自 Game Cheats Manager（英文站元数据，没有下载地址），
 *    这里的 mods 来自机地社区帖（99.9% 带网盘直链，是真能拿到东西的那一套）。 */
const D_DL_KIND = { mod: 'MOD', modifier: '修改器' };
const D_JIDI_MODS = 'https://jidiyouxi.com/modify/list';
async function loadDlBlock(d, fb, title) {
  const slot = $('#dlSlot');
  if (!slot) return;
  const t = String(title || (d && d.title) || (fb && fb.title) || '').trim();
  const id = (fb && fb.id) || (d && d.id) || '';
  if (t.length < 2 && !id) return;
  try {
    const qs = [];
    if (id) qs.push('id=' + encodeURIComponent(id));
    if (t) qs.push('t=' + encodeURIComponent(t));
    const j = await fetch(api('/api/mods/match?' + qs.join('&'))).then(r => r.json());
    const items = (j && j.items) || [];
    if (!items.length) { slot.innerHTML = ''; return; }   // 社区没收录就不占版面
    const rows = items.slice(0, 4).map(it => {
      const kind = D_DL_KIND[it.kind] || '资源';
      const nets = [...new Set((it.links || []).map(l => l.kind).filter(Boolean))].slice(0, 2).join(' / ');
      const when = it.ut ? new Date(it.ut * 1000).toISOString().slice(0, 10) : '';
      const cnt = (it.links || []).length;
      const meta = [nets ? esc(nets) : '', cnt ? cnt + ' 个直链' : '', when].filter(Boolean).join(' · ');
      return `<a class="d-dl-it" href="${esc(it.url || D_JIDI_MODS)}" target="_blank" rel="noopener">
        <span class="k${it.kind === 'modifier' ? ' mf' : ''}">${kind}</span>
        <span class="bd"><span class="t" title="${esc(it.title || '')}">${esc(it.title || '')}</span>
        <span class="m">${meta}</span></span>
        <span class="go">打开帖子 ↗</span></a>`;
    }).join('');
    const rest = j.count > 4 ? `<div class="more">另有 ${j.count - 4} 条未展示，去机地社区搜「${esc(t ? splitName(t).zh : '')}」看全部</div>` : '';
    slot.innerHTML = `<div class="d-blk"><h4><span class="ic"></span>下载入口<span class="cnt">机地社区 ${j.count} 条</span></h4>
      ${rows}${rest}
      <div class="d-dl-links">
        <a href="${D_JIDI_MODS}" target="_blank" rel="noopener">机地 MOD / 修改器区 ↗</a>
        <a href="/emulator.html#sv">云存档位置</a>
        <a href="/emulator.html#tr">修改器库</a>
      </div>
      <div class="d-hint2">以上为<b>机地社区帖</b>（MOD / 修改器），网盘链接与文件都在源站帖子内，本站不转存、不提供文件。<br>
        云存档那一套给的是<b>存档文件应该放哪</b>（真实路径），不是下载链接 —— 见手机专区「云存档」。</div></div>`;
  } catch (e) { slot.innerHTML = ''; }
}
$('#mask').addEventListener('click', closeDetail);

/* ================= 启动 ================= */
async function init() {
  bindRankUI();      // 顶栏搜索触发 + 榜单周期切换/刷新
  renderSide();
  renderCats();
  renderList(true);
  refreshRank(false); // 首页主体：热榜（缓存秒显 / 首次拉取）
  // 手机三个分区（社区配置 / 实测配置 / 指南）已拆到 /emulator.html，
  // 首页只保留入口卡（数字由上面的专区跳转块异步回填），此处不再初始化。
  loadStats().then((j) => { if (j && j.ok && j.running) { setBtnsDisabled(true); pollIdx(); } });
  // 离线快照(双击 HTML / 无后端)时降级展示
  try {
    const r = await fetch(api('/api/health'), { signal: AbortSignal.timeout(3500) });
    if (!r.ok) throw 0;
  } catch (e) {
    const snap = window.__SNAPSHOT__;
    if (snap && snap.feedItems) {
      const items = snap.feedItems.filter(i => i.source === 'xdgamer');
      const lib = $('#libList');
      if (lib) lib.innerHTML = items.map(rowCard).join('') || '<div class="empty">快照无 XD 数据</div>';
      bindRowCards(lib);
      const c = $('#listCount'); if (c) c.textContent = `离线快照 · ${items.length} 条`;
    }
    $('#liveTxt').textContent = '快照';
  }
  // URL 直达：?q= 搜索 / ?c= 分类 / ?sort=
  const sp = new URLSearchParams(location.search);
  const qp = sp.get('q'); if (qp && qp.trim()) openSearch(qp.trim()); // 直达：自动打开搜索弹窗并出结果
  const cp = sp.get('c'); if (cp && CATS.includes(cp)) { curCat = cp; renderCats(); renderList(true); }
  const sp2 = sp.get('sort'); if (sp2 && SORTS.some(s => s.k === sp2)) { curSort = sp2; renderCats(); renderList(true); }
  document.documentElement.setAttribute('data-ready', '1');
}
/* ================= 📥 网盘下载弹窗（v10.22 新增） =================
 * 用户口径：「将游戏详情页的跳转链接变成获取到对应游戏的下载链接（弹窗展示，
 *            大部分 XD 都是有多个下载链接，最好是获取到完整的标题）」。
 *
 * 链路：前端 → GET /api/download → fetchers/download.js
 *   · XD   解析详情页 .article-down 的 a.downbtn，再跟随 /plus/download.php 的 302
 *          拿真实网盘地址（实测 6 个盘口全部可解）
 *   · 机地 解析详情页 SSR 的 ssrData.postsMap，抽社区帖正文里的网盘直链
 *   ★ 必须走服务端：这两个源站都没有 CORS 头，前端直连必被浏览器拦；
 *     而且它们对浏览器指纹敏感（见项目抓取经验，node fetch 正常、浏览器会被 403）。
 *
 * ★ 为什么允许「一次取两源」：
 *   同一款游戏在 XD 与机地**不是同一批链接**（XD 是官方盘口，机地是社区分享帖）。
 *   库里 13,448 条 XD 条目已与机地同款合并（带 jidiUrl），所以「⬇ 网盘下载」能
 *   把两侧一起取回来、分两组展示。两个 URL 相同时自动去重，不会重复请求。
 *
 * ★ 不用 Promise.all 直接并发两源也无所谓，但**单个源失败不能拖垮另一个**：
 *   用 allSettled 语义（.catch 成 {ok:false}），一个挂掉另一个照常显示。
 */
const DL_BRAND = [
  [/百度/, 'baidu', '度'], [/天翼|189/, '189', '翼'], [/迅雷/, 'xunlei', '雷'],
  [/夸克|quark/i, 'quark', '夸'], [/移动|139/, '139', '移'], [/阿里|ali/i, 'ali', '阿'],
  [/123/, '123', '12'], [/蓝奏|lanzou/i, 'lanzou', '蓝'], [/pikpak/i, 'pikpak', 'P'],
  [/steam|正版/i, 'steam', '正'], [/uc/i, 'other', 'U'],
];
function dlBrand(s) {
  const t = String(s == null ? '' : s);
  for (const [re, cls, ab] of DL_BRAND) if (re.test(t)) return { cls, ab };
  return { cls: 'other', ab: t.slice(0, 1) || '?' };
}
function dlHost(u) {
  try { return new URL(u).host.replace(/^www\./, ''); } catch (e) { return ''; }
}
/** 单条链接行。★ `real` 为空的一律显式标「不可用」——不要把中间页当结果给用户点。 */
function dlRow(it) {
  const real = it.real || '';
  const b = dlBrand(it.server);
  const bits = [];
  const h = real ? dlHost(real) : '';
  if (h) bits.push(h);
  if (it.pwd) bits.push('提取码 ' + String(it.pwd).replace(/^访问码[：:]\s*/, ''));
  if (!real && it.error) bits.push('解析失败：' + it.error);
  const name = it.postTitle || it.server || '下载';
  const sub = [it.server, bits.join(' · ')].filter(Boolean).join(' · ');
  const act = real
    ? '<a class="act" href="' + esc(real) + '" target="_blank" rel="noopener">打开 ↗</a>' +
      '<button class="act" type="button" data-dl-copy="' + esc(real) + '">复制</button>'
    : '<span class="act" style="color:var(--c-t3);border-color:var(--c-border);background:#F3F5F9">不可用</span>';
  return '<div class="dl-it' + (real ? '' : ' bad') + '">' +
    '<span class="bd bd-' + b.cls + '">' + esc(b.ab) + '</span>' +
    '<div class="tx"><b title="' + esc(name) + '">' + esc(name) + '</b>' +
    '<span title="' + esc(real) + '">' + esc(sub) + '</span></div>' + act + '</div>';
}
function dlSection(title, srcCls, srcName, items, cap) {
  const n = items.filter((x) => x.real).length;
  const shown = cap && items.length > cap ? items.slice(0, cap) : items;
  const more = items.length > shown.length
    ? '<div class="dl-note" style="margin:8px 0 0">另有 ' + (items.length - shown.length) + ' 条未展示（同一款游戏的重复分享帖）</div>' : '';
  return '<div class="dl-grp"><div class="h"><b>' + esc(title) + '</b>' +
    '<span class="src ' + srcCls + '">' + esc(srcName) + '</span>' +
    '<span class="n">' + n + ' / ' + items.length + ' 条可用</span></div>' +
    '<div class="l">' + shown.map(dlRow).join('') + '</div>' + more + '</div>';
}
function dlCopy(el) {
  const txt = el.dataset.dlCopy || '';
  const back = el.textContent;
  const done = () => {
    el.textContent = '已复制 ✓';
    el.classList.add('done');
    setTimeout(() => { el.textContent = back; el.classList.remove('done'); }, 1400);
  };
  const fallback = () => {
    try {
      const ta = document.createElement('textarea');
      ta.value = txt;
      ta.style.cssText = 'position:fixed;left:-9999px;top:0';
      document.body.appendChild(ta); ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta); done();
    } catch (e) { toast('复制失败，请手动选中链接'); }
  };
  if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(txt).then(done, fallback);
  else fallback();
}
function closeDownload() {
  const pop = $('#dlPop');
  if (!pop || pop.hidden) return;
  pop.classList.remove('on');
  setTimeout(() => { pop.hidden = true; const b = $('#dlBody'); if (b) b.innerHTML = ''; }, 180);
}
/**
 * 打开下载弹窗。
 * @param {{title?:string, sub?:string, url?:string, jidi?:string}} ctx
 *   url  —— 当前源详情页（XD 或机地，服务端 parseDetailUrl 兼容两者）
 *   jidi —— 另一侧的机地详情页（库里合并进来的 XD 条目才有）
 */
async function openDownload(ctx) {
  const pop = $('#dlPop');
  if (!pop) return;
  const o = ctx || {};
  /* 去重：url 本身就是机地详情页时，jidi 不再重复请求 */
  const isJidi = (u) => /jidiyouxi\.com/.test(String(u || ''));
  const jobs = [];
  if (o.url) jobs.push({ tag: isJidi(o.url) ? 'jidi' : 'xd', u: o.url });
  if (o.jidi && o.jidi !== o.url && !jobs.some((j) => j.u === o.jidi)) jobs.push({ tag: 'jidi', u: o.jidi });

  $('#dlTitle').textContent = o.title || '网盘下载';
  $('#dlSub').textContent = o.sub || '';
  $('#dlFoot').innerHTML = '';
  pop.hidden = false;
  requestAnimationFrame(() => pop.classList.add('on'));

  if (!jobs.length) {
    $('#dlBody').innerHTML = '<div class="dlpop-empty">这款游戏没有可解析的下载来源<br>' +
      '<span style="font-size:11.5px">库里既没有 XD 详情页，也没有合并的机地话题</span></div>';
    return;
  }
  $('#dlBody').innerHTML = '<div class="dlpop-load"><i></i><span>正在解析网盘地址（XD 需逐个跟随跳转，约 3-8 秒）…</span></div>';

  const res = await Promise.all(jobs.map((j) =>
    fetch(api('/api/download?url=' + encodeURIComponent(j.u)))
      .then((r) => r.json())
      .then((d) => ({ tag: j.tag, d }))
      /* ★ 单个源失败不能拖垮另一个 —— 兜成同一个返回形状，下面统一渲染 */
      .catch((e) => ({ tag: j.tag, d: { ok: false, error: e.message } }))));

  /* 标题优先用源站返回的**完整标题**（用户要的就是「完整的标题」，别用库里的短名盖掉） */
  const good = res.filter((x) => x.d && x.d.ok);
  const head = good.map((x) => x.d.title).filter(Boolean)[0];
  if (head) $('#dlTitle').textContent = head;
  const subs = [];
  for (const x of good) { if (x.d.version) subs.push(x.d.version); else if (x.d.subtitle) subs.push(x.d.subtitle); }
  if (subs.length) $('#dlSub').textContent = subs.join(' · ');

  if (!good.length) {
    const errs = res.map((x) => (x.d && x.d.error) || '未知错误').join('；');
    $('#dlBody').innerHTML = '<div class="dlpop-empty">没有取到可用的下载链接<br>' +
      '<span style="font-size:11.5px">' + esc(errs) + '</span></div>';
    $('#dlFoot').innerHTML = '<b>说明</b>：链接由源站实时解析，可能因为源站改版 / 网络抖动失败，稍后重试即可。';
    return;
  }

  const secs = [];
  const xd = good.find((x) => x.tag === 'xd');
  const ji = good.find((x) => x.tag === 'jidi');
  if (xd) {
    const items = (xd.d.items || []).filter((i) => i.real || i.error);
    if (items.length) secs.push(dlSection('XDGAME 官方盘口', 'xd', 'XD', items, 0));
  }
  if (ji) {
    /* 机地同一款游戏常有多份分享帖，全铺出来会很长 —— 取前 12 条，
       按帖子热度（服务端已排序）优先，并如实告知还有多少条未展示。 */
    const items = (ji.d.items || []).filter((i) => i.real);
    if (items.length) secs.push(dlSection('机地社区分享（按帖子热度）', 'jidi', '机地', items, 12));
  }
  $('#dlBody').innerHTML = secs.length
    ? '<div class="dl-note">共 <b>' + secs.length + '</b> 组来源 · 链接均为源站实时解析的真实网盘地址</div>' + secs.join('')
    : '<div class="dlpop-empty">没有取到可用的下载链接<br><span style="font-size:11.5px">这些条目在源站也可能只是话题、尚无资源帖</span></div>';
  $('#dlFoot').innerHTML = '<b>链接来自源站</b>：XD 的地址由 <code>/plus/download.php</code> 跳转解析，' +
    '机地的来自社区帖正文。本站只做聚合与解析，<b>不转存、不提供文件</b>；下载前请自行核对文件安全。';
}
/* 绑定一次（弹层与 Toggle 都是共享资产的常驻节点）。
   ★ 用**事件委托**而不是给每个按钮绑：解包匹配页的卡片是动态重绘的，
     逐个绑定会在重绘后全部失效（本项目在机型清单上踩过同类坑）。 */
(function bindDownloadPopup() {
  const pop = $('#dlPop');
  if (!pop) return;
  pop.addEventListener('click', (e) => {
    if (e.target.closest('[data-dl="close"]')) { closeDownload(); return; }
    const cp = e.target.closest('[data-dl-copy]');
    if (cp) dlCopy(cp);
  });
  /* ESC 关弹窗：用捕获阶段并截断 —— 搜索弹窗也监听 ESC，
     不截断会出现「一下 ESC 把两个都关掉」。只在弹窗真的开着时才抢。 */
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape' || pop.hidden) return;
    e.stopPropagation();
    closeDownload();
  }, true);
  document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-dl-open]');
    if (!b) return;
    e.preventDefault();
    e.stopPropagation();
    openDownload({
      title: b.dataset.dlTitle || '',
      sub: b.dataset.dlSub || '',
      url: b.dataset.dlUrl || '',
      jidi: b.dataset.dlJidi || '',
    });
  });
})();

init();
