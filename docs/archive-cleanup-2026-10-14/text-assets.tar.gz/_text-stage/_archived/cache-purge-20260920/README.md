# 归档：2026-09-20 缓存与临时残留清理

> **这不是删除，是移动。** 全部内容原样在此，可随时还原。

## 为什么有这一批

2026-09-20 盘点输出目录时发现 `.cache/` 累积到 **568.5 MB / 2763 文件**，
其中大部分是**历史遗留**：早期版本的浏览器 profile、调试期的探针脚本与页面样本、
以及某前端站误落到缓存根的构建产物。

归档前逐个做了**反向引用检查**（在所有源码里搜路径），确认移出的项
**源码零引用**；确认保留的 7 项**源码写死依赖**。

## 三部分内容

| 子目录 | 内容 | 体积 |
|---|---|---|
| `profiles/edge-probe/` | 早期用 Edge 调试时的浏览器 profile（1037 文件）。现行代码只用 `chrome-preview`，`findBrowser()` 无论找到 Chrome 还是 Edge，profile 一律用 `chrome-preview` ⇒ 此目录已死 | 421.1 MB |
| `profiles/chrome-probe/` | 旧版 `browser.js` 的 profile 名（359 文件），同样已被 `chrome-preview` 取代 | 22.0 MB |
| `cache-root/` | `.cache/` 根下 47 个调试残留：`probe-*.js` 探针 7 个、`chunk-*.js` 某站构建产物 12 个、`soc*.html`/`nr*.html`/`t.html` 等页面样本、`ludusavi-manifest.yaml` 之外的小样本、日志 | 5.4 MB |
| `workspace-root/` | 从**工作区根**（`2026-09-03-16-11-58/`）移出的 6 项：`=2` / `h4` / `.pill`（0 字节，疑似重定向写错产生）、`_appaudit2.js` / `_appaudit3.js`（临时审计脚本）、`overview.md`（09-18 的 v10.17 修复报告） | 10 KB |

合计 **448.3 MB / 55 项**。

## ★ 明确保留在 `.cache/` 的 7 项（源码依赖，勿动）

| 路径 | 谁在用 |
|---|---|
| `.cache/chrome-preview/` | `tools/browser.js:61` — `--user-data-dir` |
| `.cache/soc-cpu/`（246 个 html） | `tools/fetch-soc-cpu.js:38` — `PAGES`，`--offline` 模式的输入 |
| `.cache/nanoreview-soclist-1~4.html` | `tools/fetch-soc-cpu.js:49`（`LIST_CACHE`）+ `tools/fetch-soc-map.js:38`（`cacheFile(p)`） |
| `.cache/ludusavi-manifest.yaml` | `tools/build-saves.js:43` — `CACHE` |

⚠️ `fetch-soc-map.js` 的缓存文件名是**拼出来的**（`'nanoreview-soclist-' + p + '.html'`），
所以简单的「搜完整文件名」会**漏判**——这次清理前是靠读源码定的清单。

## 怎么还原

全部移回原处（Git Bash）：

```bash
cd "E:/新建文件夹/WorkBuddy/2026-09-03-16-11-58"

# 浏览器 profile
mv game-aggregator/_archived/cache-purge-20260920/profiles/* game-aggregator/.cache/

# .cache 根下的文件
mv game-aggregator/_archived/cache-purge-20260920/cache-root/* game-aggregator/.cache/

# 工作区根的文件
mv game-aggregator/_archived/cache-purge-20260920/workspace-root/* .
```

只还原某一项也可以，直接 `mv` 那一个。

## 怎么彻底删除（释放 448 MB）

确认不需要了再执行——**这一步不可逆**：

```bash
rm -rf "E:/新建文件夹/WorkBuddy/2026-09-03-16-11-58/game-aggregator/_archived/cache-purge-20260920"
```

> 注：本机沙箱**没有可用的回收站机制**（`Add-Type` 被拦、`Shell.Application` COM 被拦、
> `trash`/`gio` 未安装），所以走的是「归档」而非「回收站」。这也正是这份 README 存在的原因——
> 归档目录本身才是回退路径。

## 影响评估

移出的内容**全部可重建**：

- 两个 profile → 下次跑 `tools/browser.js` 会重新拉浏览器 profile（首次启动略慢，无功能影响）
- 探针脚本 / 页面样本 → 属一次性调试产物，对应功能已有正式脚本与正式缓存
- `_appaudit2.js` / `_appaudit3.js` → 读 `~/.workbuddy/audit-log/2026-09-18.jsonl` 的临时分析脚本
- `overview.md` → 内容已被项目内 `CODEX-DONE-v10.17.md` 覆盖

**`.cache` 体积**：568.5 MB → 120.1 MB（-78.9%）
