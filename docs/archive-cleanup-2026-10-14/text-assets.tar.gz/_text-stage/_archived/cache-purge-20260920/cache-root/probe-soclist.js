const fs = require('fs');
const cheerio = require('cheerio');

const h = fs.readFileSync('.cache/soclist.html', 'utf8');
const $ = cheerio.load(h);

const rows = [];
$('tr').each((i, el) => {
  const a = $(el).find('a[href^="/en/soc/"]').first();
  if (!a.length) return;
  const name = a.text().trim();
  const href = a.attr('href');
  const vendor = $(el).find('span.text-gray-small').first().text().trim();
  let gpu = '';
  $(el).find('td').each((j, td) => {
    const t = $(td).text().trim();
    if (/^(Adreno|Mali|Immortalis|Xclipse|PowerVR|Apple GPU|SGX)/i.test(t)) gpu = t;
  });
  rows.push({ name, vendor, gpu, href });
});

console.log('解析条数', rows.length);
console.log('有 GPU 的', rows.filter(r => r.gpu).length);
console.log('\n=== 前 24 条 ===');
rows.slice(0, 24).forEach(r => console.log('  ' + String(r.gpu || '—').padEnd(20), r.vendor.padEnd(10), r.name));

const byGpu = new Map();
for (const r of rows) {
  const k = r.gpu.toLowerCase().trim();
  if (!k) continue;
  if (!byGpu.has(k)) byGpu.set(k, []);
  byGpu.get(k).push(r.name);
}
console.log('\n唯一 GPU', byGpu.size);

// 用 bannerhub 的高频 GPU 检验覆盖
const bf = JSON.parse(fs.readFileSync('data/bannerhub-files.json', 'utf8'));
const cnt = new Map();
for (const g of Object.keys(bf)) for (const x of bf[g] || []) {
  const p = String(x[1] || '').trim(); if (p) cnt.set(p, (cnt.get(p) || 0) + 1);
}
const top = [...cnt.entries()].sort((a, b) => b[1] - a[1]);
console.log('\n=== 高频 GPU 能否在本表命中 ===');
let hitRec = 0, totRec = 0;
for (const [gpu, n] of top.slice(0, 22)) {
  totRec += n;
  const k = gpu.toLowerCase().trim();
  const direct = byGpu.get(k);
  const loose = direct || [...byGpu.keys()].find(x => x.replace(/\s*mc\s*\d+/i, '').trim() === k.replace(/\s*mc\s*\d+/i, '').trim());
  if (loose) hitRec += n;
  console.log('  ' + String(n).padStart(6), gpu.padEnd(18), direct ? '✓ ' + direct.slice(0, 2).join(' / ') : (loose ? '≈ ' + byGpu.get(loose).slice(0, 2).join(' / ') : '✗'));
}
console.log('前 22 个 GPU 覆盖记录数', hitRec, '/', totRec, '=', (hitRec / totRec * 100).toFixed(1) + '%');
