const fs = require('fs');
const d = JSON.parse(fs.readFileSync('data/mods.json', 'utf8'));
const its = d.items;
console.log('items', its.length, 'file', (fs.statSync('data/mods.json').size / 1048576).toFixed(1) + 'MB');

const lens = its.map((x) => String(x.content || '').length).sort((a, b) => a - b);
const q = (p) => lens[Math.floor(lens.length * p)];
console.log('content len  p50=' + q(0.5), 'p75=' + q(0.75), 'p90=' + q(0.9), 'p99=' + q(0.99), 'max=' + lens[lens.length - 1]);
console.log('总正文长度 =', (lens.reduce((a, b) => a + b, 0) / 1048576).toFixed(1) + 'MB');

// 首条链接在正文中的位置分布
const pos = [];
for (const x of its) {
  const i = String(x.content || '').indexOf('http');
  if (i >= 0) pos.push(i);
}
pos.sort((a, b) => a - b);
console.log('首个 http 位置 p50=' + pos[Math.floor(pos.length * 0.5)], 'p90=' + pos[Math.floor(pos.length * 0.9)], 'p99=' + pos[Math.floor(pos.length * 0.99)], 'max=' + pos[pos.length - 1]);
console.log('首链接位置 > 1500 的条数 =', pos.filter((p) => p > 1500).length);

// 字段体积
let byField = {};
for (const x of its) for (const k of Object.keys(x)) byField[k] = (byField[k] || 0) + JSON.stringify(x[k]).length;
console.log('\n字段体积(MB):');
Object.entries(byField).sort((a, b) => b[1] - a[1]).forEach(([k, v]) => console.log('  ' + k.padEnd(12), (v / 1048576).toFixed(2)));

console.log('\n无链接样本:', its.filter((x) => !x.links.length).slice(0, 3).map((x) => x.title));
console.log('游戏名样本:', [...new Set(its.map((x) => x.game))].slice(0, 15));
console.log('未命中端游库但游戏名非空的样本:', its.filter((x) => !x.libId && x.game).slice(0, 10).map((x) => x.game + ' | ' + x.kind));
console.log('游戏名为空的条数 =', its.filter((x) => !x.game).length);
