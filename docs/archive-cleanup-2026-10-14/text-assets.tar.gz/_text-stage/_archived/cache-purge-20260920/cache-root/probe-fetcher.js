const { poll } = require('../fetchers/jidiModify');
(async () => {
  for (const t of ['modifier', 'mod']) {
    const t0 = Date.now();
    const r = await poll(t, { max: 200 });
    console.log(`\n[${t}] count=${r.count} fetched=${r.fetched}  用时 ${((Date.now() - t0) / 1000).toFixed(1)}s`);
    const s = r.items[0];
    console.log('  样本 title =', s.title);
    console.log('  topic     =', s.topic && s.topic.topic, ' cover=', s.topic && s.topic.cover);
    console.log('  content   =', String(s.content || '').slice(0, 120).replace(/\n/g, ' | '));
  }
})();
