const fs = require('fs');
const cheerio = require('cheerio');

/** GPU 名归一化：MP ↔ MC 等价；去 (8 CUs) 之类注记 */
function normGpuKey(s) {
  return String(s || '')
    .toLowerCase()
    .replace(/\((?:tm|r)\)|™|®/g, '')
    .replace(/\bmp\s*(\d+)/g, 'mc$1')
    .replace(/\bmc\s*(\d+)/g, 'mc$1')
    .replace(/\(\s*\d+\s*cus?\s*\)/g, '')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}
const modelOf = (s) => normGpuKey(s).replace(/\s*mc\d+$/, '').trim();

const files = ['1', '2', '3'].map((n) => '.cache/soclist' + n + '.html').filter((f) => fs.existsSync(f));
const all = [];
for (const f of files) {
  const $ = cheerio.load(fs.readFileSync(f, 'utf8'));
  let n = 0;
  $('tr').each((i, el) => {
    const a = $(el).find('a[href^="/en/soc/"]').first();
    if (!a.length) return;
    const name = a.text().trim();
    const vendor = $(el).find('span.text-gray-small').first().text().trim();
    let gpu = '';
    $(el).find('td').each((j, td) => {
      const t = $(td).text().trim();
      if (/^(Adreno|Mali|Immortalis|Xclipse|PowerVR|Apple GPU|SGX)/i.test(t)) gpu = t;
    });
    all.push({ name, vendor, gpu });
    n++;
  });
  console.log(f, '→', n, '条');
}
const withGpu = all.filter((x) => x.gpu);
console.log('合计', all.length, '有 GPU', withGpu.length);

const exact = new Map(), byModel = new Map();
for (const r of withGpu) {
  const k = normGpuKey(r.gpu);
  if (!exact.has(k)) exact.set(k, []);
  exact.get(k).push(r);
  const m = modelOf(r.gpu);
  if (!byModel.has(m)) byModel.set(m, []);
  byModel.get(m).push(r);
}
console.log('唯一 GPU 键', exact.size, '| 唯一型号', byModel.size);

const bf = JSON.parse(fs.readFileSync('data/bannerhub-files.json', 'utf8'));
const cnt = new Map();
for (const g of Object.keys(bf)) for (const x of bf[g] || []) {
  const p = String(x[1] || '').trim(); if (p) cnt.set(p, (cnt.get(p) || 0) + 1);
}
const top = [...cnt.entries()].sort((a, b) => b[1] - a[1]);
const totalRec = top.reduce((a, b) => a + b[1], 0);

console.log('\n=== 高频 GPU 覆盖（精确 / 型号退化）===');
let hitE = 0, hitM = 0, tE = 0, tM = 0, shown = 0;
for (const [gpu, n] of top) {
  tE += n; tM += n;
  const k = normGpuKey(gpu), m = modelOf(gpu);
  const e = exact.get(k), mm = byModel.get(m);
  if (!e) tE -= n;
  if (!(e || mm)) tM -= n;
  if (shown++ < 24) {
    const label = e ? '✓ ' + e.slice(0, 2).map((x) => x.vendor + ' ' + x.name).join(' / ')
      : (mm ? '≈ ' + mm.slice(0, 2).map((x) => x.vendor + ' ' + x.name).join(' / ') : '✗');
    console.log('  ' + String(n).padStart(5), gpu.padEnd(20), label);
  }
}
console.log('\n全量按记录数：精确命中 ' + (tE / totalRec * 100).toFixed(1) + '%  |  含型号退化 ' + (tM / totalRec * 100).toFixed(1) + '%');

fs.writeFileSync('.cache/soc-full.json', JSON.stringify(all, null, 1));
console.log('已存 .cache/soc-full.json');
