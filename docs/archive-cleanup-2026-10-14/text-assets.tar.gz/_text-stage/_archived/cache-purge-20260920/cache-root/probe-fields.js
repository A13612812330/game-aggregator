/** 试探：limit 上限 + 列表项字段完整结构 */
const crypto = require('crypto');
const fs = require('fs');
const md5 = (s) => crypto.createHash('md5').update(String(s), 'utf8').digest('hex');
function D(e) {
  const t = e.h_m || 0;
  return 'v2-' + md5(String(t) + md5(JSON.stringify(e) + 'YhD6TCs9VpAl'));
}
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0 Safari/537.36';
const HOST = 'https://jidiyouxi.com';

async function getEnv() {
  const r = await fetch(HOST + '/modify/list', { headers: { 'User-Agent': UA } });
  const html = await r.text();
  const m = html.match(/<script id="appState"[^>]*>([\s\S]*?)<\/script>/);
  const j = JSON.parse(m[1].replace(/^window\.[A-Za-z_]+=/, '').trim().replace(/;?\s*$/, ''));
  return j.env;
}
async function api(env, params) {
  const b = Object.assign({}, env, params, { h_ts: Date.now(), h_ch: 'other' });
  b.h_did = b.h_did || '';
  b.sign = D(b);
  const url = HOST + '/api/misc/post_list?websign=' + encodeURIComponent(D(b));
  const r = await fetch(url, {
    method: 'POST',
    headers: { 'User-Agent': UA, 'content-type': 'text/plain' },
    body: JSON.stringify(b),
    signal: AbortSignal.timeout(30000),
  });
  return await r.json();
}

(async () => {
  const env = await getEnv();
  for (const lim of [20, 50, 100, 200]) {
    const t0 = Date.now();
    try {
      const d = await api(env, { sort: 'new', limit: lim, resource_type: 2, next_cb: null });
      const l = (d.data && d.data.list) || [];
      console.log(`limit=${lim} → got ${l.length}  (${Date.now() - t0}ms)`);
    } catch (e) { console.log(`limit=${lim} → ERR ${e.message}`); }
  }
  // 字段结构
  const d = await api(env, { sort: 'new', limit: 20, resource_type: 2, next_cb: null });
  const it = d.data.list[0];
  fs.writeFileSync('.cache/_sample-mod.json', JSON.stringify(it, null, 1), 'utf8');
  console.log('\n=== MOD 样本字段 ===');
  for (const k of Object.keys(it)) {
    const v = it[k];
    const s = typeof v === 'object' ? JSON.stringify(v) : String(v);
    console.log(`  ${k} : ${s.slice(0, 110)}`);
  }
  // 统计 content 平均长度
  let tot = 0;
  for (const x of d.data.list) tot += String(x.content || '').length;
  console.log('\ncontent 平均长度 =', Math.round(tot / d.data.list.length));
})();
