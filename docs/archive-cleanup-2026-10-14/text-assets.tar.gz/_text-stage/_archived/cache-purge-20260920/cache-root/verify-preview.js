/** 验收预览页：JS 报错 / 卡片数 / 抽屉正文与链接是否铺满 */
const puppeteer = require('puppeteer-core');
const path = require('path');
const fs = require('fs');
const EDGE = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const FILE = 'file:///' + path.join(__dirname, '..', '_preview', 'mods-preview.html').replace(/\\/g, '/');
const OUT = path.join(__dirname, '..', '_preview');

(async () => {
  if (!fs.existsSync(OUT)) fs.mkdirSync(OUT, { recursive: true });
  const browser = await puppeteer.launch({ executablePath: EDGE, headless: 'new', args: ['--no-sandbox', '--allow-file-access-from-files'] });
  const page = await browser.newPage();
  await page.setViewport({ width: 1440, height: 1000 });
  const errs = [];
  page.on('pageerror', (e) => errs.push(e.message));
  await page.goto(FILE, { waitUntil: 'networkidle2', timeout: 60000 });
  await new Promise((r) => setTimeout(r, 2000));

  console.log('JS 报错:', errs.length ? errs : '无 ✅');
  const s1 = await page.evaluate(() => ({
    kpis: [...document.querySelectorAll('.pv-kpi')].map((k) => k.querySelector('span').textContent + '=' + k.querySelector('b').textContent),
    cards: document.querySelectorAll('.pv-card').length,
    meta: document.querySelector('#listMeta').textContent,
    top: document.querySelectorAll('.pv-topg').length,
  }));
  console.log('KPI:', s1.kpis.join(' | '));
  console.log('卡片数:', s1.cards, '| 游戏榜:', s1.top, '|', s1.meta);
  await page.screenshot({ path: path.join(OUT, 'mods-preview-top.png'), clip: { x: 0, y: 0, width: 1440, height: 1000 } });

  /* 打开第一张卡片的抽屉 */
  await page.evaluate(() => document.querySelector('.pv-card').click());
  await new Promise((r) => setTimeout(r, 900));
  const d = await page.evaluate(() => {
    const b = document.querySelector('#dBody');
    return {
      open: document.querySelector('#drawer').classList.contains('on'),
      title: document.querySelector('#dTitle').textContent,
      game: (b.querySelector('.pv-game .t b') || {}).textContent,
      links: b.querySelectorAll('.pv-lk').length,
      bodyLen: (document.querySelector('#dContent') || {}).textContent.length,
      scrollable: (() => { const c = document.querySelector('#dContent'); return c ? c.scrollHeight > c.clientHeight : null; })(),
      head: document.querySelector('#dContent').textContent.slice(0, 90).replace(/\n/g, ' | '),
    };
  });
  console.log('\n抽屉:', JSON.stringify(d, null, 1));
  await page.screenshot({ path: path.join(OUT, 'mods-preview-drawer.png'), clip: { x: 0, y: 0, width: 1440, height: 1000 } });

  /* 切到「修改器」页签 */
  await page.evaluate(() => { document.querySelector('#dClose').click(); });
  await new Promise((r) => setTimeout(r, 400));
  await page.evaluate(() => document.querySelector('[data-kind="modifier"]').click());
  await new Promise((r) => setTimeout(r, 600));
  const s2 = await page.evaluate(() => ({
    n: document.querySelectorAll('.pv-card').length,
    meta: document.querySelector('#listMeta').textContent,
    first: (document.querySelector('.pv-card .nm') || {}).textContent,
  }));
  console.log('\n切到修改器:', s2.n, '张 |', s2.meta);
  console.log('  首条:', s2.first);

  /* 关掉「仅看命中」 */
  await page.evaluate(() => document.querySelector('#tgLib').click());
  await new Promise((r) => setTimeout(r, 600));
  const s3 = await page.evaluate(() => ({ meta: document.querySelector('#listMeta').textContent }));
  console.log('取消「仅看命中端游库」:', s3.meta);

  /* 搜索 */
  await page.evaluate(() => {
    const i = document.querySelector('#q');
    i.value = '赛博朋克';
    i.dispatchEvent(new Event('input', { bubbles: true }));
  });
  await new Promise((r) => setTimeout(r, 700));
  const s4 = await page.evaluate(() => ({ n: document.querySelectorAll('.pv-card').length, meta: document.querySelector('#listMeta').textContent }));
  console.log('搜「赛博朋克」:', s4.meta);

  await browser.close();
})();
