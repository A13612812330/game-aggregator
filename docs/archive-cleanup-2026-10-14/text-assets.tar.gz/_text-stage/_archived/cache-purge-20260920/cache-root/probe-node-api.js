/** 纯 Node 直调验证：抓 SSR appState.env → 签名 → POST post_list */
const crypto = require('crypto');
const md5 = (s) => crypto.createHash('md5').update(String(s), 'utf8').digest('hex');
function D(e) {
  const t = e.h_m || 0;
  return 'v2-' + md5(String(t) + md5(JSON.stringify(e) + 'YhD6TCs9VpAl'));
}
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0 Safari/537.36';
const HOST = 'https://jidiyouxi.com';

async function getEnv() {
  const r = await fetch(HOST + '/modify/list', { headers: { 'User-Agent': UA, Accept: 'text/html' } });
  const html = await r.text();
  const m = html.match(/<script id="appState"[^>]*>([\s\S]*?)<\/script>/);
  if (!m) throw new Error('no appState');
  const j = JSON.parse(m[1].replace(/^window\.[A-Za-z_]+=/, '').trim().replace(/;?\s*$/, ''));
  return j.env;
}

async function api(env, params) {
  const b = Object.assign({}, env, params, { h_ts: Date.now(), h_ch: 'other' });
  b.h_did = b.h_did || '';
  b.sign = D(b);
  const ws = D(b);
  const url = HOST + '/api/misc/post_list?websign=' + encodeURIComponent(ws);
  const r = await fetch(url, {
    method: 'POST',
    headers: { 'User-Agent': UA, 'content-type': 'text/plain', Referer: HOST + '/modify/list' },
    body: JSON.stringify(b),
    signal: AbortSignal.timeout(20000),
  });
  return await r.json();
}

(async () => {
  const env = await getEnv();
  console.log('env ok, h_did=', env.h_did, 'host=', env.host);

  for (const [label, p] of [
    ['modifier p1', { sort: 'new', limit: 20, resource_type: 3, next_cb: null }],
    ['modifier p2', { sort: 'new', limit: 20, resource_type: 3, next_cb: '{"offset":20}' }],
    ['mod p1', { sort: 'new', limit: 20, resource_type: 2, next_cb: null }],
    ['mobile p1', { sort: 'new', limit: 20, resource_type: 1, next_cb: null }],
    ['modifier limit50', { sort: 'new', limit: 50, resource_type: 3, next_cb: null }],
  ]) {
    try {
      const d = await api(env, p);
      const pay = d.data || {};
      const l = pay.list || [];
      console.log(`[${label}] ret=${d.ret} count=${pay.count} got=${l.length} more=${pay.more} next_cb=${pay.next_cb}`);
      if (l[0]) console.log('    first id=' + l[0].id + ' | ' + String(l[0].title).slice(0, 60));
    } catch (e) {
      console.log(`[${label}] ERR ${e.message}`);
    }
  }
})();
