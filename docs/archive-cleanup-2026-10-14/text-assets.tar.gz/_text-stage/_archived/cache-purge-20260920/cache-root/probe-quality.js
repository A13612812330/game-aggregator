const fs = require('fs');
const d = JSON.parse(fs.readFileSync('data/mods.json', 'utf8'));
const its = d.items;
console.log('stats:', JSON.stringify(d.stats, null, 1));
console.log('\n有封面', its.filter((x) => x.cover).length, '/', its.length);
console.log('有游戏名', its.filter((x) => x.game).length);
console.log('有作者', its.filter((x) => x.author).length);

const ts = its.map((x) => x.ut || x.ct).filter(Boolean).sort((a, b) => b - a);
console.log('\nut 范围:', new Date(ts[ts.length - 1] * 1000).toISOString().slice(0, 10), '→', new Date(ts[0] * 1000).toISOString().slice(0, 10));
console.log('最新 5 条时间:', ts.slice(0, 5).map((t) => new Date(t * 1000).toLocaleString('zh-CN', { hour12: false })));

console.log('\n=== 样本（各 3 条） ===');
for (const k of ['mod', 'modifier']) {
  console.log('--', k);
  its.filter((x) => x.kind === k).slice(0, 3).forEach((x) => {
    console.log('  ' + x.title);
    console.log('    游戏=' + x.game + ' | 作者=' + x.author + ' | 链接=' + x.links.length + ' 条 | lib=' + (x.libTitle || '—'));
    console.log('    封面=' + x.cover);
    console.log('    首链=' + (x.links[0] ? x.links[0].kind + ' ' + x.links[0].url : '无'));
  });
}

// 链接域名分布
const dom = {};
for (const x of its) for (const l of x.links) {
  try { const h = new URL(l.url).host; dom[h] = (dom[h] || 0) + 1; } catch {}
}
console.log('\n链接域名 TOP10:');
Object.entries(dom).sort((a, b) => b[1] - a[1]).slice(0, 10).forEach(([h, c]) => console.log('  ' + h.padEnd(28), c));

// 高频游戏
const g = {};
for (const x of its) if (x.game) g[x.game] = (g[x.game] || 0) + 1;
console.log('\n条目最多的游戏 TOP15:');
Object.entries(g).sort((a, b) => b[1] - a[1]).slice(0, 15).forEach(([k, c]) => console.log('  ' + String(c).padStart(5) + '  ' + k));
