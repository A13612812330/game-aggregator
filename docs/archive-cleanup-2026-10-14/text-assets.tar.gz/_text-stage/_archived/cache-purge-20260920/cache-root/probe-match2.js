const fs = require('fs');
function normKey(s) {
  return String(s || '').toLowerCase().replace(/[\s\u3000]+/g, '')
    .replace(/[：:·・,，.。!！?？'"“”‘’()（）\[\]【】《》<>~～\-–—_+*&/／|｜\\]/g, '');
}
const gamesDb = require('../data/gamesDb');
gamesDb.load();
const all = gamesDb.all();
const byName = new Map();
const add = (k, it) => { if (k && k.length >= 3 && !byName.has(k)) byName.set(k, it); };
for (const it of all) {
  for (const seg of String(it.title || '').split('/')) add(normKey(seg), it);
  for (const a of it.aliases || []) add(normKey(a), it);
}
console.log('index size', byName.size);
for (const k of ['剑星', '生化危机9安魂曲', '龙之剑觉醒', '幻兽帕鲁', '艾尔登法环']) {
  const h = byName.get(k);
  console.log(k, '→', h ? h.id + ' | ' + h.title : 'MISS');
}

const d = JSON.parse(fs.readFileSync('data/mods.json', 'utf8'));
const bad = d.items.filter((x) => !x.libId && x.game);
console.log('\n未命中总数', bad.length);
// 分段匹配修复后的命中率预估
let fixed = 0;
for (const x of bad) {
  for (const seg of String(x.game).split('/')) {
    if (byName.get(normKey(seg))) { fixed++; break; }
  }
}
console.log('分段重试可救回', fixed, '→', ((fixed / bad.length) * 100).toFixed(1) + '%');
console.log('仍不命中的样本:');
const still = bad.filter((x) => !String(x.game).split('/').some((s) => byName.get(normKey(s))));
console.log('  仍不命中总数', still.length);
[...new Set(still.map((x) => x.game))].slice(0, 25).forEach((g) => console.log('   · ' + g));
