const fs = require('fs');
const cheerio = require('cheerio');

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0 Safari/537.36';

/** GPU 名归一化：MP ↔ MC 等价（都是核心数）；(8 CUs) 这类注记去掉 */
function normGpuKey(s) {
  return String(s || '')
    .toLowerCase()
    .replace(/\((?:tm|r)\)|™|®/g, '')
    .replace(/\bmp\s*(\d+)/g, 'mc$1')      // MP12 → mc12
    .replace(/\bmc\s*(\d+)/g, 'mc$1')
    .replace(/\(\s*\d+\s*cus?\s*\)/g, '')  // Adreno 840 (8 CUs)
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}
const modelOf = (s) => normGpuKey(s).replace(/\s*mc\d+$/, '').trim();

(async () => {
  const all = [];
  for (let p = 1; p <= 5; p++) {
    const url = 'https://nanoreview.net/en/soc-list/rating' + (p > 1 ? '?page=' + p : '');
    const r = await fetch(url, { headers: { 'User-Agent': UA }, signal: AbortSignal.timeout(25000) });
    if (!r.ok) { console.log('page', p, 'HTTP', r.status); break; }
    const h = await r.text();
    const $ = cheerio.load(h);
    let n = 0;
    $('tr').each((i, el) => {
      const a = $(el).find('a[href^="/en/soc/"]').first();
      if (!a.length) return;
      const name = a.text().trim();
      const vendor = $(el).find('span.text-gray-small').first().text().trim();
      let gpu = '';
      $(el).find('td').each((j, td) => {
        const t = $(td).text().trim();
        if (/^(Adreno|Mali|Immortalis|Xclipse|PowerVR|Apple GPU|SGX)/i.test(t)) gpu = t;
      });
      all.push({ name, vendor, gpu });
      n++;
    });
    console.log('page', p, '→', n, '条');
    if (n === 0) break;
  }

  const withGpu = all.filter(x => x.gpu);
  console.log('\n合计', all.length, '条，有 GPU', withGpu.length);

  const exact = new Map(), byModel = new Map();
  for (const r of withGpu) {
    const k = normGpuKey(r.gpu);
    if (!exact.has(k)) exact.set(k, []);
    exact.get(k).push(r);
    const m = modelOf(r.gpu);
    if (!byModel.has(m)) byModel.set(m, []);
    byModel.get(m).push(r);
  }
  console.log('唯一 GPU 键', exact.size, '| 唯一型号', byModel.size);

  const bf = JSON.parse(fs.readFileSync('data/bannerhub-files.json', 'utf8'));
  const cnt = new Map();
  for (const g of Object.keys(bf)) for (const x of bf[g] || []) {
    const p = String(x[1] || '').trim(); if (p) cnt.set(p, (cnt.get(p) || 0) + 1);
  }
  const top = [...cnt.entries()].sort((a, b) => b[1] - a[1]);
  const totalRec = top.reduce((a, b) => a + b[1], 0);

  console.log('\n=== 高频 GPU 覆盖率（精确 / 退化到型号）===');
  let hitE = 0, hitM = 0, shown = 0;
  for (const [gpu, n] of top) {
    if (shown++ >= 24) break;
    const k = normGpuKey(gpu), m = modelOf(gpu);
    const e = exact.get(k), mm = byModel.get(m);
    if (e) hitE += n;
    if (e || mm) hitM += n;
    const label = e ? '✓ ' + e.slice(0, 2).map(x => x.vendor + ' ' + x.name).join(' / ')
      : (mm ? '≈ ' + mm.slice(0, 2).map(x => x.name).join(' / ') : '✗');
    console.log('  ' + String(n).padStart(5), gpu.padEnd(20), label);
  }
  console.log('\nTOP24 记录数', top.slice(0, 24).reduce((a, b) => a + b[1], 0));
  console.log('精确命中', hitE, '| 含型号退化', hitM);

  fs.writeFileSync('.cache/soc-full.json', JSON.stringify(all, null, 1));
  console.log('\n已存 .cache/soc-full.json');
})();
