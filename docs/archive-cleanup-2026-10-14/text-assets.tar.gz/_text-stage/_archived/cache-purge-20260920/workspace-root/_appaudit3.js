const fs = require('fs');
const p = 'C:/Users/komo/.workbuddy/audit-log/2026-09-18.jsonl';
const lines = fs.readFileSync(p, 'utf8').split(/\r?\n/).filter(Boolean);
const apps = ['wbapp_k0YzBHCqnzzK9YrcG5Bru0', 'wbapp_D5cUfPk1IwCJlI3eIgc96h', 'wbapp_WNoF5maytwivZ60TUa6CPA'];
let n = 0;
for (const ln of lines) {
  if (!/gamehub-agg/.test(ln)) continue;
  n++;
  const links = [...new Set((ln.match(/[a-z0-9-]+\.app\.workbuddy\.(?:host|link)/g) || []))];
  const ids = apps.filter(a => ln.includes(a));
  const sb = [...new Set((ln.match(/[a-f0-9]{32}/g) || []))];
  console.log('---');
  console.log('  links :', links.join(' ') || '-');
  console.log('  appIds:', ids.join(' ') || '-');
  console.log('  cand32:', sb.join(' ') || '-');
}
console.log('含 gamehub-agg 的行 ' + n);
// 顺带看首个 appId 行的键名结构
const first = lines.find(l => l.includes('wbapp_WNoF5maytwivZ60TUa6CPA'));
if (first) { console.log('\n=== 结构样本（键名）==='); const j = JSON.parse(first);
  const walk=(o,pre='')=>{ if(o&&typeof o==='object'&&!Array.isArray(o)) for(const k of Object.keys(o)) walk(o[k], pre?pre+'.'+k:k); else if(Array.isArray(o)) console.log(pre+'[]  len='+o.length); else console.log(pre+' = '+String(o).slice(0,90)); };
  walk(j); }
