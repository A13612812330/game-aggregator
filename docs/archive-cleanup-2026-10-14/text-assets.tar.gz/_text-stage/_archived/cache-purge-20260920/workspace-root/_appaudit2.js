const fs = require('fs');
const p = 'C:/Users/komo/.workbuddy/audit-log/2026-09-18.jsonl';
const apps = ['wbapp_k0YzBHCqnzzK9YrcG5Bru0', 'wbapp_D5cUfPk1IwCJlI3eIgc96h', 'wbapp_WNoF5maytwivZ60TUa6CPA'];
const lines = fs.readFileSync(p, 'utf8').split(/\r?\n/).filter(Boolean);
console.log('日志行数 ' + lines.length);
const rows = [];
for (const ln of lines) {
  if (!apps.some(a => ln.includes(a))) continue;
  let j; try { j = JSON.parse(ln); } catch { continue; }
  const s = JSON.stringify(j);
  const links = [...new Set((s.match(/https?:\/\/[a-z0-9-]+\.app\.workbuddy\.(?:host|link)/g) || []))];
  const sb = [...new Set((s.match(/"sandboxId":"([a-f0-9]{32})"/g) || []))].map(x => x.slice(13, 45));
  const hits = apps.filter(a => s.includes(a));
  rows.push({ t: j.timestamp || j.time || j.ts || '', hits, links, sb, tool: j.toolName || j.tool || j.name || '', len: ln.length });
}
rows.sort((a, b) => String(a.t).localeCompare(String(b.t)));
for (const r of rows) console.log([String(r.t).slice(0, 19), r.hits.join(','), (r.links.join(' ') || '-'), (r.sb.join(' ') || '-'), r.tool].join('  |  '));
console.log('命中 ' + rows.length + ' 行');
