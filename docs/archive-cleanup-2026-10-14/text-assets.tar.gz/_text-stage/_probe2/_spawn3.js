/* 决定性对照：完全照抄 run-all.js 的 execFileSync options，看 EBUSY 是否消失 */
'use strict';
const { execFileSync } = require('child_process');
const path = require('path');
const ROOT = path.resolve(__dirname, '..');

function tryIt(label, args, opts) {
  try {
    const out = execFileSync(process.execPath, args, opts);
    console.log(label.padEnd(46), 'OK  ' + String(out).trim().slice(0, 50));
  } catch (e) {
    console.log(label.padEnd(46), (e.status == null ? 'THROW ' : 'EXIT' + e.status + ' ') + (e.code || '') + '/' + (e.errno || ''));
  }
}

const copyOpts = { cwd: ROOT, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], timeout: 180000 };
const plainOpts = { encoding: 'utf8' };
const cwdOnly = { cwd: ROOT, encoding: 'utf8' };
const stdioOnly = { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] };

tryIt('A 无 options 等价（encoding only）', ['-v'], plainOpts);
tryIt('B 只加 cwd', ['-v'], cwdOnly);
tryIt('C 只加 stdio', ['-v'], stdioOnly);
tryIt('D 完全照抄 run-all options', ['-v'], copyOpts);
tryIt('E 照抄 + 跑一个真套件', [path.join(ROOT, 'tools', 'test-doc-structure.js')], copyOpts);
