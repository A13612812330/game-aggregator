/* FR 关键验证：过挑战后，用**页面上下文内的 fetch** 取后续页面（而不是 page.goto 重新导航）。
 * 理由：CF 的 managed challenge 主要拦 navigation；同源 XHR 带着已通过的 cf_clearance + 完整浏览器指纹，
 *       通常可直接放行 ⇒ 这是 FR 能否工程化的分水岭。
 * 同时验证：附件下载链形式 + 是否需登录。 */
const http = require('http');
const path = require('path');
const fs = require('fs');
const { spawn, execFileSync } = require('child_process');
const puppeteer = require('puppeteer-core');

const CAND = ['C:/Users/komo/AppData/Local/Google/Chrome/Application/chrome.exe', 'C:/Program Files/Google/Chrome/Application/chrome.exe'];
const PORT = 9338;
const BASE = 'https://fearlessrevolution.com';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const cdpUp = (port) => new Promise((res) => {
  const r = http.get(`http://127.0.0.1:${port}/json/version`, (x) => { x.resume(); res(x.statusCode === 200); });
  r.on('error', () => res(false)); r.setTimeout(1200, () => { r.destroy(); res(false); });
});
const log = []; const P = (...a) => { const s = a.join(' '); log.push(s); console.log(s); };

(async () => {
  const exe = CAND.find((p) => fs.existsSync(p));
  const profile = path.join(__dirname, '..', '.cache', 'chrome-headed');
  fs.mkdirSync(profile, { recursive: true });
  const child = spawn(exe, ['--no-first-run', '--no-default-browser-check',
    `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`, '--window-size=1280,900', 'about:blank'],
    { detached: true, stdio: 'ignore' });
  child.unref();
  let ok = false;
  for (let i = 0; i < 30 && !(ok = await cdpUp(PORT)); i++) await sleep(500);
  if (!ok) { P('CDP 未就绪'); return; }
  const b = await puppeteer.connect({ browserURL: `http://127.0.0.1:${PORT}` });
  const page = await b.newPage();

  try {
    const t0 = Date.now();
    await page.goto(BASE + '/', { waitUntil: 'domcontentloaded', timeout: 60000 }).catch(() => {});
    let title = '';
    for (let i = 0; i < 20; i++) {
      title = await page.title().catch(() => '');
      if (!/moment|稍候|Attention/i.test(title)) break;
      await sleep(4000);
    }
    P(`过挑战: ${Date.now() - t0}ms  title="${title}"`);

    /* ★ 关键：在页面上下文内 fetch —— 一次过挑战，后续全走 XHR */
    async function xfetch(url) {
      return await page.evaluate(async (u) => {
        try {
          const r = await fetch(u, { credentials: 'include', headers: { 'X-Requested-With': 'XMLHttpRequest' } });
          const t = await r.text();
          return { status: r.status, len: t.length, isCF: /Just a moment|cf-chl/i.test(t), html: t };
        } catch (e) { return { status: 0, len: 0, err: String(e.message).slice(0, 80), html: '' }; }
      }, url);
    }

    P('');
    P('=== 页面内 fetch：连续取 4 页板块列表 ===');
    for (const start of [0, 50, 100, 150]) {
      const r = await xfetch(`/viewforum.php?f=4&start=${start}`);
      const m = r.html.match(/<a[^>]*href="[^"]*viewtopic\.php\?f=4&amp;t=(\d+)[^"]*"[^>]*>([^<]{3,80})<\/a>/g) || [];
      P(`  start=${start}  HTTP ${r.status}  len=${r.len}  CF=${r.isCF}  帖链接=${m.length}`);
      if (start === 0 && m.length) {
        P('    样例: ' + m.slice(0, 3).map((s) => s.replace(/<[^>]+>/g, '').slice(0, 50)).join(' | '));
      }
    }

    P('');
    P('=== 页面内 fetch：搜索页 ===');
    for (const u of ['/search.php?keywords=Elden+Ring', '/search.php?keywords=Elden+Ring&terms=all&sf=titleonly']) {
      const r = await xfetch(u);
      P(`  ${u.slice(0, 50)}  HTTP ${r.status}  len=${r.len}  CF=${r.isCF}`);
    }

    P('');
    P('=== 页面内 fetch：拿一个 topic ===');
    const listHtml = (await xfetch('/viewforum.php?f=4&start=0')).html;
    const ids = [...listHtml.matchAll(/viewtopic\.php\?f=4&amp;t=(\d+)/g)].map((m) => m[1]);
    P('候选 t:', ids.slice(0, 10).join(', '));
    const uniq = [...new Set(ids)].filter((x) => Number(x) > 100);
    if (uniq.length) {
      const t = uniq[uniq.length - 1];
      const r = await xfetch(`/viewtopic.php?f=4&t=${t}`);
      P(`  t=${t}  HTTP ${r.status}  len=${r.len}  CF=${r.isCF}`);
      const attrs = [...r.html.matchAll(/href="([^"]*(?:download|attachment|\.ct|\.zip|\.rar|\.7z|\.exe)[^"]*)"/gi)].map((m) => m[1]);
      P('  附件候选:', JSON.stringify([...new Set(attrs)].slice(0, 12), null, 1));
      const ttl = (r.html.match(/<title>([^<]*)<\/title>/) || [])[1] || '';
      P('  title:', ttl);
      P('  正文摘录:', r.html.replace(/<script[\s\S]*?<\/script>/g, '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').slice(0, 700));
      fs.writeFileSync(path.join(__dirname, 'fr-topic.html'), r.html, 'utf8');
    }
  } catch (e) { P('ERR', String(e.message).slice(0, 200)); }
  finally {
    fs.writeFileSync(path.join(__dirname, 'fr-fetch-test.txt'), log.join('\n'), 'utf8');
    try { await b.disconnect(); } catch (e) {}
    try { execFileSync('taskkill', ['/PID', String(child.pid), '/T', '/F'], { stdio: 'ignore' }); } catch (e) {}
    P('\n已写 _probe2/fr-fetch-test.txt');
  }
})();
