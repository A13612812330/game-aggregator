const fs = require('fs');
const s = fs.readFileSync(process.argv[2], 'utf8');
const rows = [];
let sum = 0;
for (const l of s.split(/\r?\n/)) {
  const m = /^  (\S+\.js)  exit=(\d+)  (\d+)\/(\d+)$/.exec(l);
  if (m) { rows.push(m); sum += Number(m[3]); }
}
console.log('套件成绩行数 =', rows.length, '｜逐套求和 =', sum);
const bad = rows.filter((m) => m[2] !== '0' || m[3] !== m[4]);
console.log('非全绿行 =', bad.length, bad.map((m) => m[1]).join(',') || '(无)');
const want = ['test-doc-structure.js', 'test-report.js', 'test-resource-page.js', 'test-emulator-structure.js', 'test-emulator-page.js', 'check-card-rules.js'];
for (const m of rows) if (want.includes(m[1])) console.log('  ', m[1].padEnd(30), m[3] + '/' + m[4]);
