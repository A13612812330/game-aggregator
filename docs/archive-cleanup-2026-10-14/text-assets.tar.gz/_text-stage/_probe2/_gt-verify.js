const fs = require('fs');
const gt = require('../fetchers/gtrainers');
const l = fs.readFileSync('_probe2/pg1.html', 'utf8');
const items = gt.parseList(l, 'saves');
console.log('=== parseList(saves p1) ===');
console.log('条目数:', items.length, '| maxPage:', gt.maxPageIn(l));
for (const it of items.slice(0, 4)) {
  console.log(`  #${it.id} [${it.date}|${it.size}|${it.count}] ${it.title.slice(0, 56)}`);
  console.log(`      候选: ${JSON.stringify(gt.gameCandidates(it.title))}`);
}
const lt = fs.readFileSync('_probe2/gt-tr.html', 'utf8');
const tr = gt.parseList(lt, 'trainers');
console.log('\n=== parseList(trainers p1) ===');
console.log('条目数:', tr.length, '| maxPage:', gt.maxPageIn(lt));
for (const it of tr.slice(0, 3)) {
  console.log(`  #${it.id} [${it.date}|${it.size}] ${it.title.slice(0, 56)}`);
  console.log(`      候选: ${JSON.stringify(gt.gameCandidates(it.title))}`);
}
const d = fs.readFileSync('_probe2/gt-item.html', 'utf8');
console.log('\n=== parseDetail ===');
console.log(JSON.stringify(gt.parseDetail(d, '15857'), null, 1));
