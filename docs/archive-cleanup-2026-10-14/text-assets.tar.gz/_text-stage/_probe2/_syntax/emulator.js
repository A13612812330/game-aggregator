
'use strict';
/* ================= 工具 ================= */
const $ = (s, r) => (r || document).querySelector(s);
const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
/* ★ v10.24：无封面占位块里的缩写（`.cov.ph > span`）。三页共用一份 —— 机地/手机/解包
   三条链路各写一遍必然出现「同一个游戏三个缩写」（同一语义只留一份实现）。 */
const covAbbr = (name) => {
  const s = String(name == null ? '' : name).trim();
  if (!s) return '?';
  const words = s.split(/[\s:_\-–—]+/).filter(Boolean);
  if (words.length >= 2 && /^[A-Za-z0-9]/.test(words[0])) return (words[0][0] + words[1][0]).toUpperCase();
  return s.slice(0, 2).toUpperCase();
};
/* ★ v10.24：封面图**加载失败**时的兜底 —— 换成同尺寸占位块，**不是**把封面区收起。
   本站既有写法是 `onerror="this.style.visibility='hidden'"`（首页各卡），
   但 `.cov.noimg`（`height:0;display:none`）会让整块封面位塌掉 ——
   同一行其它卡有图时，这张就「少一截」，正是用户说的「很空」。
   写成全局函数（而不是内联一长串）是为了让三条链路共用同一份逻辑。 */
const covErr = (img, abbr) => {
  const box = img && img.parentNode;
  if (!box || !box.classList) return;
  box.classList.add('ph');
  box.textContent = '';
  const sp = document.createElement('span');
  sp.textContent = abbr || '?';
  box.appendChild(sp);
};
window.covErr = covErr;
const okScoreV = (v) => v != null && v > 0 && v <= 10;
let toastTimer;
function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), 2400); }
const api = (p) => p;
const SRC = { xdgamer: { nm: 'XDGAME', cls: 'xd' }, xdgamer2: { nm: 'XDGAME', cls: 'xd' }, jidi: { nm: '机地', cls: 'jidi' } };

function splitName(title) {
  const s = String(title || '').trim();
  const i = s.indexOf('/');
  if (i > 0) return { zh: s.slice(0, i).trim(), en: s.slice(i + 1).trim() };
  return { zh: s, en: '' };
}
function coverHtml(it, cls) {
  if (it.cover) return `<img src="${esc(it.cover)}" alt="${esc(it.zh || it.title)}" loading="lazy" onerror="this.parentNode.classList.add('noimg');this.remove()">`;
  const ch = (it.zh || it.title || '?').trim().charAt(0).toUpperCase() || '?';
  return `<div class="${cls ? 'ph' : ''}" style="display:grid;place-items:center;width:100%;height:100%;color:#fff;font-weight:800;font-size:22px;background:linear-gradient(135deg,#5B86E5,#7F6FF0)">${esc(ch)}</div>`;
}
/* ★ v10.8 日期键归一化：两个源站格式不同（XD `2026-09-14` / 机地 `2026/9/9`），
   旧版 normTime 只认含 `-` 的写法，机地那批会**原样输出 `2026/8/12`** ——
   同一列里既有 `09-14` 又有 `2026/8/12`。这里统一成 ISO 键再取紧凑展示。
   越界的月/日（脏数据）不硬转，按原样返回，避免造出 `09-89` 这种更糟的显示。 */
function normDateKey(d) {
  const m = String(d == null ? '' : d).match(/(\d{4})[-/](\d{1,2})[-/](\d{1,2})/);
  if (!m) return '';
  const mo = +m[2], dy = +m[3];
  if (mo < 1 || mo > 12 || dy < 1 || dy > 31) return '';
  return `${m[1]}-${String(mo).padStart(2, '0')}-${String(dy).padStart(2, '0')}`;
}
function normTime(d) {
  const k = normDateKey(d);
  if (k) return k.slice(5);           // → 09-14
  return d ? String(d) : '';
}

/* ================= 分类 ================= */
// 参考 XD 官网分类：全部 + 库内实际收录的类型（与 games.json genres 对齐）
const CATS = ['全部', '动作冒险', '角色扮演', '模拟经营', '休闲益智', '策略战棋', '恐怖惊悚', '枪战射击', '体育竞速', '即时战略', '联机整合', '免费专区', '模拟器整合'];
const SORTS = [
  { k: 'updated', nm: '最新更新', lb: 'NEW' },
  { k: 'score', nm: '评分最高', lb: 'SCORE' },
  { k: 'size', nm: '容量最大', lb: 'SIZE' },
];
/* 容量区间筛选（min/max 单位 GB，null=不限；min 含、max 不含） */
const SIZES = [
  { k: 'all', nm: '不限', lb: 'ALL', min: null, max: null },
  { k: 's', nm: '5GB 以下', lb: 'XS', min: null, max: 5 },
  { k: 'm', nm: '5-15GB', lb: 'S', min: 5, max: 15 },
  { k: 'l', nm: '15-30GB', lb: 'M', min: 15, max: 30 },
  { k: 'xl', nm: '30-60GB', lb: 'L', min: 30, max: 60 },
  { k: 'xxl', nm: '60GB 以上', lb: 'XL', min: 60, max: null },
];
let curCat = '全部';
let curSort = 'updated';
let curSize = 'all';    // SIZES[].k
let curBh = false;      // 仅看有手机模拟器配置（BannerHub 社区）的游戏
let curPc = false;      // 仅看本站实测库里有记录的游戏（phonecfg）
let curTr = false;      // ★ v10.5 仅看「修改器」库收录到的游戏
let curSv = false;      // ★ v10.5 仅看「云存档」库收录到的游戏
let offset = 0, total = 0, listEl = null, loading = false;

/** 当前筛选 → 附加查询串（容量区间 + 仅手机可玩 + 仅有实测记录 + 有修改器/云存档） */
function filterQuery() {
  const s = SIZES.find((x) => x.k === curSize) || SIZES[0];
  let q = '';
  if (s.min != null) q += '&sizeMin=' + s.min;
  if (s.max != null) q += '&sizeMax=' + s.max;
  if (curBh) q += '&bh=1';
  if (curPc) q += '&pc=1';
  if (curTr) q += '&tr=1';
  if (curSv) q += '&sv=1';
  return q;
}
/** 筛选条：三行「标签 + 分段控件」—— 排序 / 容量 / 筛选
 *  与上方「分类」行同语言：行首标签定名，控件组横排，结果计数贴右。
 *  ★ v10.5：开关从「容量」行拆出来独占「筛选」行 —— 四个开关挤在容量行里会溢出换行，
 *  行内出现半行空档、读起来像排版事故；单独成行既对齐手机专区的分行结构，
 *  也让「筛选」这件事有了名字。 */
function filterBarHtml() {
  return `<div class="filter-bar">
    <div class="filter-row">
      <span class="filter-lb">排序</span>
      <div class="sort-pills" id="sortPills">${SORTS.map(s => `<button class="sort-pill ${curSort === s.k ? 'on' : ''}" data-s="${s.k}"><span class="lb">${s.lb}</span>${s.nm}</button>`).join('')}</div>
      <span class="fx-sp"></span>
      <span class="filter-count" id="filterCount"></span>
    </div>
    <div class="filter-row">
      <span class="filter-lb">容量</span>
      <div class="size-pills" id="sizePills">${SIZES.map(s => `<button class="size-pill ${curSize === s.k ? 'on' : ''}" data-z="${s.k}"><span class="lb">${s.lb}</span>${s.nm}</button>`).join('')}</div>
    </div>
    <div class="filter-row">
      <span class="filter-lb">筛选</span>
      <button class="bh-toggle ${curBh ? 'on' : ''}" id="bhToggle" type="button" title="只看有 BannerHub 社区模拟器配置的游戏">📱 社区有配置</button>
      <button class="bh-toggle pc-badge ${curPc ? 'on' : ''}" id="pcToggle" type="button" title="只看本站实测库里有记录的 PC 游戏">🎮 有实测记录</button>
      <button class="bh-toggle tr-badge ${curTr ? 'on' : ''}" id="trToggle" type="button" title="只看「修改器」库里收录到的游戏（按端游库 id 关联）">🛠 有修改器</button>
      <button class="bh-toggle sv-badge ${curSv ? 'on' : ''}" id="svToggle" type="button" title="只看「云存档」库里查到存档位置的游戏（按端游库 id 关联）">💾 有云存档</button>
      <span class="fx-sp"></span>
    </div>
  </div>`;
}

/** 筛选结果计数文案 */
function filterCountText(n) {
  const bits = [];
  const s = SIZES.find((x) => x.k === curSize);
  if (s && s.k !== 'all') bits.push(s.nm);
  if (curBh) bits.push('📱 社区有配置');
  if (curPc) bits.push('🎮 有实测记录');
  if (curTr) bits.push('🛠 有修改器');
  if (curSv) bits.push('💾 有云存档');
  return (bits.length ? bits.join(' · ') + ' · ' : '') + `命中 ${n.toLocaleString()} 款`;
}

function renderCats() {  $('#catRow').innerHTML = `<span class="cat-title">分类</span>` +
    CATS.map(c => `<button class="cat ${c === curCat ? 'on' : ''}" data-c="${esc(c)}">${esc(c)}</button>`).join('') +
    `<span class="grow"></span><span class="statline" id="statline"></span>`;
  $$('#catRow .cat').forEach(b => b.addEventListener('click', () => {
    curCat = b.dataset.c; offset = 0; renderCats(); renderList(true);
  }));
}

function statlineHtml(st) {
  const j = st.bySource && (st.bySource.jidi || 0);
  const x = st.bySource && (st.bySource.xdgamer || 0);
  return `库内 <b>${st.total ? st.total.toLocaleString() : '–'}</b> 款 · 机地 <b>${j || 0}</b> · XD <b>${x || 0}</b>`;
}

/* ================= 主列表（内容库浏览,参考 XD 行卡） ================= */
function skeletonRows(n) {
  return Array.from({ length: n }).map(() => `<div class="skeleton"><div class="sk sk-th"></div><div style="flex:1;min-width:0"><div class="sk sk-l1"></div><div class="sk sk-l2"></div><div class="sk sk-l3"></div></div></div>`).join('');
}
function rowCard(it) {
  const n = splitName(it.title);
  const meta = [];
  const okScore = it.score != null && it.score > 0 && it.score <= 10;
  if (okScore) meta.push(`<span class="pill score">★ ${it.score}</span>`);
  if ((it.genres || []).length) meta.push(`<span class="pill type">${esc(it.genres.slice(0, 2).join(' / '))}</span>`);
  if (it.size) meta.push(`<span class="pill size">${esc(it.size)}</span>`);
  meta.push(`<span class="pill time">${esc(normTime(it.dateLabel))}</span>`);
  if (it.bh) meta.push(`<span class="bh-badge" title="BannerHub 社区已上传 ${it.bh.c} 份手机模拟器配置">📱 可玩 <b>${it.bh.c}</b></span>`);
  if (it.pc) meta.push(`<span class="bh-badge pc-badge" title="本站实测库有 ${it.pc.c} 条记录，最佳帧率 ${it.pc.best || '未标'}">🎮 实测 <b>${it.pc.c}</b></span>`);
  // 库内兜底字段(data-fb)：详情源站解析缺字段时用库内值补全
  /* ★ v10.22 加 jidiUrl：详情页「⬇ 网盘下载」要能**一次把两源的链接都取回来**。
     库内 XD 条目若已合并进机地同款（13,448 条），就带上机地详情页 URL ——
     弹窗里分成「XD 官方盘口」「机地社区分享」两组展示，比只给一边完整。 */
  const fb = { id: it.id || '', title: it.title || '', cover: it.cover || '', score: okScore ? it.score : null, size: it.size || '', genres: (it.genres || []).slice(0, 4), dateLabel: it.dateLabel || '', jidiUrl: it.jidiUrl || '' };
  const fbJson = encodeURIComponent(JSON.stringify(fb));
  return `<article class="row-card" data-url="${esc(it.url)}" data-fb="${fbJson}">
    <div class="th">${coverHtml({ ...it, zh: n.zh })}</div>
    <div class="bd">
      <div class="tt"><h3>${esc(n.zh)}</h3><span class="src-badge ${SRC[it.source] ? SRC[it.source].cls : 'xd'}">${SRC[it.source] ? SRC[it.source].nm : 'XDGAME'}</span></div>
      ${n.en ? `<div class="en">${esc(n.en)}</div>` : ''}
      <div class="meta">${meta.join('')}</div>
    </div>
    <span class="go">查看 <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg></span>
  </article>`;
}
/* 按 dateLabel 日期分组渲染(仅默认视图生效)，组间插入日期分隔条
   用 lastDateShown 跨批次去重组头：追加批次首项与上批末项同日则不重复插头 */
let lastDateShown = null;
function groupByDate(items) {
  const out = [];
  const today = new Date(), y = today.getFullYear(), m = today.getMonth() + 1, d = today.getDate();
  const dayKey = `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
  const yest = new Date(Date.now() - 86400e3), y2 = yest.getFullYear(), m2 = yest.getMonth() + 1, d2 = yest.getDate();
  const yestKey = `${y2}-${String(m2).padStart(2, '0')}-${String(d2).padStart(2, '0')}`;
  const friendly = (k) => k === dayKey ? '今天更新' : k === yestKey ? '昨天更新' : k ? k.slice(5) + ' 更新' : '近期';
  items.forEach((it) => {
    const k = normDateKey(it.dateLabel);        // ★ v10.8：用归一化键，两种格式都能识别
    if (k && k !== lastDateShown) {
      out.push(`<div class="date-sep"><span class="ds-bar"></span>${friendly(k)}<span class="ds-en">${k}</span></div>`);
      lastDateShown = k;
    }
    out.push(rowCard(it));
  });
  return out.join('');
}
async function renderList(reset) {
  const col = $('#colMain');
  if (reset) {
    col.innerHTML = filterBarHtml() + `<div id="libList">${skeletonRows(7)}</div>`;
    const lt = $('#listTitle'); if (lt) lt.textContent = curCat === '全部' ? '最新收录' : curCat;
  }
  listEl = $('#libList');
  loading = true;
  const moreBtn = $('#moreBtn'); if (moreBtn) moreBtn.disabled = true;
  if (reset) {
    const sp = $('#sortPills'); if (sp) sp.addEventListener('click', (e) => {
      const b = e.target.closest('.sort-pill'); if (!b || curSort === b.dataset.s) return;
      curSort = b.dataset.s; offset = 0; renderList(true);
    });
    const zp = $('#sizePills'); if (zp) zp.addEventListener('click', (e) => {
      const b = e.target.closest('.size-pill'); if (!b || curSize === b.dataset.z) return;
      curSize = b.dataset.z; offset = 0; renderList(true);
    });
    const bt = $('#bhToggle'); if (bt) bt.addEventListener('click', () => {
      curBh = !curBh; offset = 0; renderList(true);
    });
    const pt = $('#pcToggle'); if (pt) pt.addEventListener('click', () => {
      curPc = !curPc; offset = 0; renderList(true);
    });
    /* ★ v10.5 两个横切筛选：库里有修改器 / 库里有云存档（按钮宽度恒定，只切 on 态） */
    const tt = $('#trToggle'); if (tt) tt.addEventListener('click', () => {
      curTr = !curTr; offset = 0; renderList(true);
    });
    const st = $('#svToggle'); if (st) st.addEventListener('click', () => {
      curSv = !curSv; offset = 0; renderList(true);
    });
  }
  try {
    const g = curCat === '全部' ? '' : curCat;
    const url = api('/api/library/browse?g=' + encodeURIComponent(g) + '&sort=' + curSort + '&limit=40&offset=' + offset + filterQuery());
    const j = await fetch(url).then(r => r.json());
    if (!j.ok) throw new Error(j.error || '加载失败');
    total = j.total || 0;
    const items = j.items || [];
    // 默认「全部 × 最新更新」视图按日期分组（今日/昨日/日期），其余视图平铺
    const grouped = (curCat === '全部' && curSort === 'updated');
    const renderBatch = () => grouped ? groupByDate(items) : items.map(rowCard).join('');
    if (reset) {
      lastDateShown = null;
      const c = $('#listCount'); if (c) c.textContent = `共 ${total.toLocaleString()} 款`;
      const fc = $('#filterCount'); if (fc) fc.textContent = filterCountText(total);
      listEl.innerHTML = items.length ? renderBatch() : `<div class="empty"><div class="big">📂</div>当前筛选下暂无收录<br><span class="note" style="font-size:12px">试试放宽容量区间或取消「📱 社区有配置」「🎮 有实测记录」</span></div>`;
      offset = items.length;
    } else {
      listEl.insertAdjacentHTML('beforeend', renderBatch());
      offset += items.length;
    }
    bindRowCards(listEl);
    const hasMore = offset < total;
    const endMark = $('#listEnd'); if (endMark) endMark.remove();
    const mb = $('#moreBtn');
    if (hasMore) {
      if (mb) { mb.style.display = 'block'; mb.disabled = false; mb.textContent = `加载更多 · 剩余 ${(total - offset).toLocaleString()} 款`; }
      else if (items.length) listEl.insertAdjacentHTML('afterend', `<button class="load-more" id="moreBtn" style="display:block">加载更多 · 剩余 ${(total - offset).toLocaleString()} 款</button>`);
    } else {
      if (mb) mb.remove();
      if (listEl && items.length) listEl.insertAdjacentHTML('afterend', `<div class="list-end" id="listEnd">— 已全部加载（${total.toLocaleString()} 款）—</div>`);
    }
    const mb2 = $('#moreBtn'); if (mb2) mb2.addEventListener('click', () => { renderList(false); });
  } catch (e) {
    if (reset) listEl.innerHTML = `<div class="empty"><div class="big">⚠️</div>加载失败：${esc(e.message)}</div>`;
  } finally { loading = false; }
}
async function loadStats() {
  try {
    const j = await fetch(api('/api/library/stats')).then(r => r.json());
    const sl = $('#statline');
    if (j.ok && sl) sl.innerHTML = statlineHtml(j);
    const sm = $('#smTotal'); if (j.ok && sm) sm.textContent = (j.total || 0).toLocaleString();
    const el = $('#srcStat'); if (el) el.innerHTML = j.ok ? `
      <div class="it"><span>本地库总量</span><b>${(j.total || 0).toLocaleString()}</b></div>
      <div class="it"><span>XDGAME 收录</span><b>${((j.bySource && j.bySource.xdgamer) || 0).toLocaleString()}</b></div>
      <div class="it"><span>机地收录</span><b>${((j.bySource && j.bySource.jidi) || 0).toLocaleString()}</b></div>
      <div class="it"><span>索引运行</span><b>${j.running ? '进行中' : '空闲'}</b></div>` : '';
    return j;
  } catch (e) { return { ok: false }; }
}
/* ============ 🔥 首页热榜舞台（双热度合并榜：XD 官方周/月/全站 + 机地社区） ============ */
let rankCache = {};     // {week:[],month:[],year:[],community:[]} — 前端缓存,切档秒显
let rankAt = {};        // {week:ms,…} — 各档数据抓取时间(供 meta 展示)
let rankDrop = {};      // {week:n,…} — 各档被服务端滤除的非游戏条目数（meta 说明用）
let rankPeriod = 'week';
const RANK_META_TXT = {
  week: 'XD 官网 · 本周热门', month: 'XD 官网 · 当月最热', year: 'XD 官网 · 全站最热', community: '机地 · 社区热度（周）',
};
function rankFb(it) {
  return encodeURIComponent(JSON.stringify({
    id: it.id || '', title: it.title, cover: it.cover || '', score: okScoreV(it.score) ? it.score : null,
    size: it.size || '', genres: (it.genres || []).slice(0, 4), dateLabel: it.dateLabel || '',
    jidiUrl: it.jidiUrl || '',      /* v10.22：热榜/搜索结果进详情时也要能取双源下载链接 */
  }));
}
function hhmm(ts) { return new Date(ts).toTimeString().slice(0, 5); }
/* 榜单 #1：冠军大卡（大图 + 中英文名 + 类型/容量/日期 + 评分） */
function champHtml(it) {
  if (!it) return '';
  const n = splitName(it.title);
  const bdg = it.source === 'jidi' ? '<span class="bdg jidi">机地</span>' : '<span class="bdg xd">XD</span>';
  const meta = [];
  if ((it.genres || []).length) meta.push(`<span class="it">${esc(it.genres.slice(0, 2).join(' / '))}</span>`);
  if (it.size) meta.push(`<span class="it">${esc(it.size)}</span>`);
  if (it.dateLabel) meta.push(`<span class="it">${esc(it.dateLabel)}</span>`);
  if (it.bh) meta.push(`<span class="it" style="color:#C2410C;font-weight:750">📱 可玩 ${it.bh.c}</span>`);
  return `<div class="rk-champ" data-url="${esc(it.url)}" data-fb="${rankFb(it)}" title="${esc(it.title)}">
    <span class="no1">1</span>
    <div class="th">${it.cover ? `<img src="${esc(it.cover)}" alt="" loading="lazy" onerror="this.style.visibility='hidden'">` : `<div class="ph">${esc(n.zh.charAt(0))}</div>`}</div>
    <div class="bd">
      <div class="up"><span class="tag1">NO.1</span>${bdg}</div>
      <div class="t">${esc(n.zh)}</div>
      ${n.en ? `<div class="en">${esc(n.en)}</div>` : ''}
      ${meta.length ? `<div class="meta2">${meta.join('')}</div>` : ''}
    </div>
    ${okScoreV(it.score) ? `<div class="sc2">${it.score}<small>玩家评分</small></div>` : ''}
  </div>`;
}
/* 榜单 #2-10：网格大卡（排名 + 封面 + 中文名 + 源徽标 + 类型/容量 + 评分） */
function rankCard(it) {
  const n = splitName(it.title);
  const bdg = it.source === 'jidi' ? '<span class="bdg jidi">机地</span>' : '<span class="bdg xd">XD</span>';
  const sub = [(it.genres || [])[0] || '', it.size || ''].filter(Boolean).join(' · ');
  return `<div class="rk-card" data-url="${esc(it.url)}" data-fb="${rankFb(it)}" title="${esc(it.title + (sub ? ' · ' + sub : ''))}">
    <span class="no ${it.rank <= 3 ? 'r' + it.rank : ''}">${it.rank}</span>
    <div class="th">${it.cover ? `<img src="${esc(it.cover)}" alt="" loading="lazy" onerror="this.style.visibility='hidden'">` : `<div class="ph">${esc(n.zh.charAt(0))}</div>`}</div>
    <div class="bd"><div class="t">${esc(n.zh)}</div><div class="s">${bdg}${it.bh ? `<span class="g" style="color:#FFD9C2;font-weight:750">📱 ${it.bh.c}</span>` : ''}${sub ? `<span class="g">${esc(sub)}</span>` : ''}</div></div>
    ${okScoreV(it.score) ? `<span class="sc">★${it.score}</span>` : ''}
  </div>`;
}
/* 榜单内高亮当前打开条目（openDetail 联动，主列/榜单/搜索任一入口打开详情时同步） */
function rankMark(url) {
  const el = $('#rankList'); if (!el || !url) return;
  $$('#rankList [data-url]').forEach(o => o.classList.toggle('on', o.dataset.url === url));
}
function rankSkeleton() {
  return `<div class="rk-skel" style="height:162px;margin-bottom:14px"></div><div class="rk-grid">${'<div class="rk-skel" style="height:66px"></div>'.repeat(9)}</div>`;
}
function paintRank() {
  const el = $('#rankList'); if (!el) return;
  const list = rankCache[rankPeriod] || [];
  el.innerHTML = list.length
    ? champHtml(list[0]) + `<div class="rk-grid">${list.slice(1).map(rankCard).join('')}</div>`
    : `<div class="sm-empty" style="color:rgba(255,255,255,.6)"><div class="big">📭</div>该档榜单暂无数据</div>`;
  const meta = $('#rankMeta');
  if (meta) {
    /* 源站榜单里混着「运行库 / 检测工具」这类非游戏条目（全站榜第 1 名就是），
       服务端已滤除并重编号；这里如实说明，免得用户以为数据丢了。 */
    const dropped = rankDrop[rankPeriod] || 0;
    meta.textContent = RANK_META_TXT[rankPeriod]
      + (dropped ? ` · 已滤除 ${dropped} 条工具条目` : '')
      + (rankAt[rankPeriod] ? ' · 更新 ' + hhmm(rankAt[rankPeriod]) : '');
  }
  $$('#rankList [data-url]').forEach(x => x.addEventListener('click', () => openDetail(x.dataset.url, x.dataset.fb)));
}
async function refreshRank(force) {
  const el = $('#rankList'), meta = $('#rankMeta'), btn = $('#rankRefresh');
  if (!el) return;
  if (!force && rankCache[rankPeriod]) { paintRank(); return; } // 缓存秒显,不重复请求
  if (meta) meta.textContent = '加载中…';
  if (btn) btn.classList.add('busy');
  if (!rankCache[rankPeriod]) el.innerHTML = rankSkeleton();
  try {
    const j = await fetch(api('/api/rank?p=' + rankPeriod + (force ? '&refresh=1' : ''))).then(r => r.json());
    if (!j.ok || !j.list) throw new Error(j.error || '榜单不可用');
    rankCache[rankPeriod] = j.list;
    rankAt[rankPeriod] = j.fetchedAt || Date.now();
    rankDrop[rankPeriod] = (j.meta && j.meta.dropped) || 0;
    paintRank();
  } catch (e) {
    el.innerHTML = `<div class="sm-empty" style="color:rgba(255,255,255,.65)"><div class="big">⚠️</div>榜单加载失败：${esc(e.message)}<br><span style="font-size:11.5px;opacity:.8">可点右侧「刷新」重试</span></div>`;
    if (meta) meta.textContent = '';
  } finally { if (btn) btn.classList.remove('busy'); }
}
/* ★ v10.4 顶栏搜索入口 —— **两页共用，必须留在 bindRankUI 之外**。
   背景：生成器会把派生页(/emulator.html)里的 `bindRankUI();` 调用注释掉
   （该函数还要绑 #rankPills / #rankRefresh，而这两个节点在专区页不存在）。
   这行过去就在 bindRankUI 内部 —— 于是**手机专区的顶栏搜索按钮点了完全没反应**。
   凡「两页都要用」的绑定一律放这里，不要塞进任何会被生成器摘除的函数。 */
$('#searchOpen').addEventListener('click', () => openSearch());

/* 顶栏搜索触发 + 榜单周期切换/刷新（仅首页） */
function bindRankUI() {
  $('#rankPills').addEventListener('click', (e) => {
    const b = e.target.closest('.stage-pill'); if (!b || b.dataset.p === rankPeriod) return;
    rankPeriod = b.dataset.p;
    $$('#rankPills .stage-pill').forEach(x => x.classList.toggle('on', x === b));
  /* refreshRank：独立页无热榜分区，跳过 */
  });
  $('#rankRefresh').addEventListener('click', () => { toast('正在刷新榜单…'); refreshRank(true); });
}
function renderSide() {
  $('#colSide').innerHTML = `
    <div class="side-card stat-card"><h4><span class="ic" style="background:linear-gradient(135deg,#2E6BFF,#6366F1)"></span>内容库状态</h4><div id="srcStat"></div>
      <div style="display:flex;gap:8px;margin-top:10px">
        <button class="mini-btn" id="idxBtn" style="flex:1.35">↻ 增量更新</button>
        <button class="mini-btn" id="calBtn" style="flex:1;background:#fff;color:var(--c-t2);border-color:var(--c-border2)">校准续跑</button>
      </div>
      <button class="mini-btn" id="jidiBtn" style="background:rgba(230,65,93,.07);border-color:rgba(230,65,93,.3);color:var(--c-jidi)">⇅ 同步机地话题入本地库</button>
      <div class="idx-bar" id="idxBar"><i id="idxBarI"></i></div>
      <div class="idx-tip" id="idxTip"></div>
    </div>
    <div class="side-card"><h4><span class="ic" style="background:linear-gradient(135deg,#16A34A,#4ADE80)"></span>关于本站</h4>
      <div class="note">合并<b>机地(jidiyouxi.com)</b>与<b>XDGAME(xdgame.com)</b>两个爬取内容源：XD 游戏库全量本地索引 + 机地首页/热榜话题同步入库，搜索与浏览<b>双源打通</b>。<br><br>· 页面顶部<b>🔥 全站热榜</b>＝XD 官方热度（周/月/全站）+ 机地社区热度合并榜<br>· 点顶栏<b>搜索框 / Ctrl K</b> 打开搜索弹窗，一键<b>搜本地库</b>（毫秒），未收录时可<b>实时查源站</b><br>· 卡片点击看<b>详情抽屉</b>（源站实时抓取），<b>←/→</b> 切换条目、<b>Esc</b> 关闭<br>· 本站<b style="color:var(--c-danger)">不含下载资源</b></div></div>`;
  $('#idxBtn').addEventListener('click', () => runXdIndex('incr'));
  $('#calBtn').addEventListener('click', () => runXdIndex('calibrate'));
  $('#jidiBtn').addEventListener('click', syncJidi);
  updateIdxTip();
}

/* ============ 内容库维护：增量更新 / 校准续跑 / 机地双源同步 ============ */
let idxTimer = null;
function setBtnsDisabled(v) { $$('#colSide .mini-btn').forEach(b => { b.disabled = v; }); }
function idxBarPct(pct) { const barI = $('#idxBarI'); if (barI) barI.style.width = pct + '%'; }
function idxBarShow(pct, tipTxt) {
  const bar = $('#idxBar'), tip = $('#idxTip');
  if (bar) bar.style.display = 'block';
  idxBarPct(pct);
  if (tipTxt != null) tip.textContent = tipTxt;
}
function idxBarFinish(tipTxt) {
  idxBarPct(100);
  if (tipTxt != null) $('#idxTip').textContent = tipTxt;
  const bar = $('#idxBar');
  setTimeout(() => { if (bar) bar.style.display = 'none'; }, 3200);
}
function humanAgo(ts) {
  if (!ts) return null;
  const s = Math.max(1, Math.round((Date.now() - ts) / 1000));
  if (s < 60) return s + ' 秒前';
  if (s < 3600) return Math.round(s / 60) + ' 分钟前';
  if (s < 86400) return Math.round(s / 3600) + ' 小时前';
  return Math.round(s / 86400) + ' 天前';
}
/** 空闲态摘要: 显示校准/断点/机地同步情况 */
async function updateIdxTip() {
  const tip = $('#idxTip'); if (!tip) return;
  try {
    const j = await fetch(api('/api/library/index/state')).then(r => r.json());
    if (!j.ok) return;
    const st = j.state.xdgame, ji = j.state.jidi;
    const parts = [];
    if (st.maxKnown && st.nextPage > st.maxKnown) parts.push('XD 校准至第 ' + st.maxKnown + ' 页' + (st.lastFullAt ? '（' + humanAgo(st.lastFullAt) + '）' : ''));
    else if (st.nextPage > 0 && st.maxKnown && st.nextPage <= st.maxKnown) parts.push('XD 断点:第 ' + st.nextPage + '/' + st.maxKnown + ' 页待续');
    else parts.push('XD 库待首次校准');
    if (ji.synced) parts.push('机地 ' + ji.synced + ' 款（' + humanAgo(ji.lastSyncAt) + '）');
    tip.textContent = parts.join(' · ');
  } catch (e) { /* 忽略 */ }
}
async function runXdIndex(kind) {
  if (idxTimer) { clearTimeout(idxTimer); idxTimer = null; }
  setBtnsDisabled(true);
  idxBarShow(3, kind === 'calibrate' ? '校准/续跑中…（可离开页面,服务端后台执行）' : '增量抓取最近页（约 10-30s）…');
  try {
    const r = await fetch(api('/api/library/index/' + kind), { method: 'POST' });
    const j = await r.json();
    if (!j.ok && r.status !== 409) throw new Error(j.error || '启动失败');
    if (r.status === 409) { toast(j.error || '任务进行中'); pollIdx(); return; }
    if (j.quick) { idxBarFinish(); toast(j.message || '已校准'); setBtnsDisabled(false); loadStats(); refreshMainIfBrowse(); updateIdxTip(); return; }
    if (j.ok) { toast(j.message || '任务已启动'); pollIdx(); }
  } catch (e) {
    idxBarFinish(); toast('启动失败：' + e.message);
    setBtnsDisabled(false); updateIdxTip();
  }
}
async function syncJidi() {
  if (idxTimer) { clearTimeout(idxTimer); idxTimer = null; }
  setBtnsDisabled(true);
  idxBarShow(3, '同步机地话题（首页新游 + 周月年热榜）…');
  try {
    const r = await fetch(api('/api/library/index/jidi'), { method: 'POST' });
    const j = await r.json();
    if (!j.ok && r.status !== 409) throw new Error(j.error || '启动失败');
    if (r.status === 409) { toast(j.error || '任务进行中'); pollIdx(); return; }
    if (j.ok) { toast(j.message || '机地同步已启动'); pollIdx(); }
  } catch (e) {
    idxBarFinish(); toast('启动失败：' + e.message);
    setBtnsDisabled(false); updateIdxTip();
  }
}
function refreshMainIfBrowse() { if (!lastQ) renderList(true); }
async function pollIdx() {
  try {
    const j = await fetch(api('/api/library/progress')).then(r => r.json());
    const run = j.run, runJ = j.runJ, st = (j.state && j.state.xdgame) || {};
    const xdBusy = run && !run.done;
    const jBusy = runJ && !runJ.done;
    const tip = $('#idxTip');
    if (xdBusy) {
      const span = Math.max(1, (run.end - run.start + 1));
      idxBarPct(Math.min(98, Math.round(((run.page - run.start + 1) / span) * 100)));
      const kindNm = run.kind === 'calibrate' ? '校准' : run.kind === 'incr' ? '增量' : '索引';
      tip.textContent = `${kindNm}中：第 ${Math.min(run.page, run.end)}/${run.end} 页 · 已收录 ${(run.total || 0).toLocaleString()} 款`;
      idxTimer = setTimeout(pollIdx, 1200);
      return;
    }
    if (jBusy) {
      idxBarPct(70);
      tip.textContent = '机地同步中：候选 ' + (runJ.got || 0) + ' 款 · 新增 ' + (runJ.added || 0) + ' 款…';
      idxTimer = setTimeout(pollIdx, 1200);
      return;
    }
    // —— 全部空闲：收尾提示 + 刷新 ——
    const last = (run && run.done) ? run : ((runJ && runJ.done) ? runJ : null);
    idxBarFinish();
    if (last) {
      if (last.error) toast((last.kind === 'jidi' ? '机地同步' : '索引任务') + '未完全成功：' + last.error);
      else if (last.kind === 'jidi') toast('✓ 机地话题已入库，库总 ' + (last.total || 0).toLocaleString() + ' 款');
      else if (last.kind === 'calibrate') toast('✓ 校准完成至第 ' + (st.maxKnown || last.end) + ' 页');
      else toast('✓ 增量完成 · 库 ' + (last.total || 0).toLocaleString() + ' 款');
    }
    setBtnsDisabled(false);
    loadStats();
    refreshMainIfBrowse();
    updateIdxTip();
  } catch (e) {
    idxBarFinish(); setBtnsDisabled(false);
    $('#idxTip').textContent = '进度查询失败：' + e.message;
  }
}

/* ================= 🔍 搜索弹窗（本地库秒搜 + 联想 + 源站兜底，全部在弹窗内完成） ================= */
let lastQ = '';
let smOpen = false, sugIdx = -1, sugTimer = null, liveSearching = false;
/* 详情抽屉的「来路」：从搜索弹窗进入时记住现场，关闭详情后原样还原搜索态 */
let detailFromSearch = false;
let smSnapshot = null; // { q, html, scroll }
let lastDetailUrl = ''; // 最近一次打开的详情 url（返回搜索态后保留行高亮）
/* 关闭详情后回到搜索弹窗：直接还原快照（含联想/本地命中/源站实时结果），无需重新请求 */
function restoreSearch() {
  if (!smSnapshot) { unlockBody(); return; }
  smOpen = true;
  $('#smask').classList.add('show');
  $('#smodal').classList.add('show');
  lockBody();
  const inp = $('#searchInput');
  inp.value = smSnapshot.q || '';
  $('#smClear').classList.toggle('hidden', !inp.value);
  const body = $('#smBody');
  body.innerHTML = smSnapshot.html;
  bindSmRows();
  // 刚看过的条目保持高亮，方便连续浏览
  if (lastDetailUrl) $$('#smBody .sm-row').forEach(r => r.classList.toggle('on-drawer', r.dataset.url === lastDetailUrl));
  body.scrollTop = smSnapshot.scroll || 0;
  sugIdx = -1;
  setTimeout(() => { inp.focus(); const l = inp.value.length; try { inp.setSelectionRange(l, l); } catch (e) {} }, 60);
}
/* 由弹窗内任意结果行进入详情：先存快照，再关弹窗开抽屉 */
function openDetailFromSearch(el) {
  const body = $('#smBody');
  smSnapshot = { q: (lastQ || $('#searchInput').value.trim()), html: body.innerHTML, scroll: body.scrollTop };
  closeSearch();
  openDetail(el.dataset.url, el.dataset.fb, true);
}
const QUICK_WORDS = ['艾尔登法环', '赛博朋克2077', '只狼', '巫师3', '剑星', '荒野大镖客', 'GTA5', '生化危机4', '死亡搁浅'];
function lockBody() { document.body.style.overflow = 'hidden'; }
function unlockBody() { if (!$('#drawer').classList.contains('show') && !smOpen) document.body.style.overflow = ''; }
function openSearch(seed) {
  smOpen = true;
  $('#smask').classList.add('show');
  $('#smodal').classList.add('show');
  lockBody();
  const inp = $('#searchInput');
  if (seed != null) inp.value = seed;
  $('#smClear').classList.toggle('hidden', !inp.value);
  setTimeout(() => { inp.focus(); inp.select(); }, 60);
  if (inp.value.trim()) doSearch(); else paintSearchHome();
}
function closeSearch() {
  if (!smOpen) return;
  smOpen = false;
  $('#smask').classList.remove('show');
  $('#smodal').classList.remove('show');
  sugIdx = -1;
  unlockBody();
}
/* 弹窗初始态（★ v10.15 重做）
 *   旧版是「试试这些 chips + 一个 30px 放大镜漂在 271px 空白中间」，主体一片空。
 *   现补上「库内速览」—— 四个库的口径与规模一次讲清，空白区也有了实信息。
 *   数字全部取自各库的**内存统计端点**（都不查盘），取一次缓存住；
 *   任一失败就整块不渲染 —— 宁可少一块，也不给用户看四个 0。 */
let smStatCache = null;
async function loadSmStats() {
  if (smStatCache) return smStatCache;
  try {
    const [pc, mob, tr, sv] = await Promise.all([
      fetch(api('/api/library/stats')).then(r => r.json()),
      fetch(api('/api/mobilehub/stats')).then(r => r.json()),
      fetch(api('/api/trainers/stats')).then(r => r.json()),
      fetch(api('/api/saves/stats')).then(r => r.json()),
    ]);
    smStatCache = [
      { cls: 'pc', n: pc.total, lb: '端游库', id: 'smTotal' },
      { cls: 'mob', n: mob.total, lb: '手游中心' },
      { cls: 'tr', n: tr.total, lb: '修改器' },
      { cls: 'sv', n: sv.total, lb: '云存档' },
    ];
    return smStatCache;
  } catch (e) { return null; }
}
function paintSearchHome() {
  const q = QUICK_WORDS.map(k => `<button type="button" onclick="quickSearch('${esc(k)}')">${esc(k)}</button>`).join('');
  const skeleton = '<div class="st"><b>…</b><span>读取中</span></div>'.repeat(4);
  $('#smBody').innerHTML = `<div class="sm-home">
    <div class="sm-sec">热门搜索<span class="cnt">点击即搜</span></div>
    <div class="sm-quick">${q}</div>
    <div class="sm-sec">库内速览<span class="cnt">本地秒搜 · 不走网络</span></div>
    <div class="sm-stat" id="smStat">${skeleton}</div>
    <div class="sm-tip">四个库一起搜：<b>端游库</b>点得进完整详情，<b>手游中心</b>给手机配置与实测，<b>修改器 / 云存档</b>直接给下载与存档路径。</div>
  </div>`;
  loadSmStats().then((rows) => {
    const el = $('#smStat');
    if (!el) return;                                   // 用户已经打字走了，别回填
    if (!rows) { el.innerHTML = ''; return; }
    el.innerHTML = rows.map(r => `<div class="st ${r.cls}"><b${r.id ? ` id="${r.id}"` : ''}>${(r.n || 0).toLocaleString()}</b><span>${r.lb}</span></div>`).join('');
  });
}
function quickSearch(k) { const inp = $('#searchInput'); inp.value = k; $('#smClear').classList.remove('hidden'); doSearch(); }
/* 弹窗内统一结果行（联想 / 本地命中 / 源站实时共用同一渲染） */
function smRow(it) {
  const n = splitName(it.title);
  const meta = [];
  if (okScoreV(it.score)) meta.push(`<span class="pill score ${smScoreCls(it.score)}">★ ${it.score}</span>`);
  if ((it.genres || []).length) meta.push(`<span class="pill type">${esc(it.genres.slice(0, 2).join(' / '))}</span>`);
  if (it.size) meta.push(`<span class="pill size">${esc(it.size)}</span>`);
  if (it.dateLabel) meta.push(`<span class="pill time">${esc(normTime(it.dateLabel))}</span>`);
  const s = SRC[it.source] || { nm: 'XDGAME', cls: 'xd' };
  return `<div class="sm-row" data-url="${esc(it.url)}" data-fb="${rankFb(it)}">
    ${it.cover ? `<img src="${esc(it.cover)}" alt="" loading="lazy" onerror="this.style.visibility='hidden'">` : `<span class="ph2">${esc(n.zh.charAt(0))}</span>`}
    <div class="bd"><div class="t">${esc(n.zh)}</div>${n.en ? `<div class="en">${esc(n.en)}</div>` : ''}<div class="m">${meta.join('')}</div></div>
    <span class="src-badge ${s.cls}">${s.nm}</span>
    <span class="go2">查看详情 →</span>
  </div>`;
}
function smSkeleton(n) { return `<div class="sm-load">${'<div class="sk"></div>'.repeat(n || 4)}</div>`; }

/* ★ v10.25：评分分级（≥9 绿 / ≥7.5 蓝 / 其余灰）—— 理由见 CSS 注释。
 *   用函数声明（不用 const 箭头）—— 它在 smRow 之后才出现，函数声明会被提升，
 *   免得将来有人在 script 里同步调用 smRow 时撞上 TDZ。 */
function smScoreCls(v) { return v >= 9 ? 's-hi' : (v >= 7.5 ? 's-mid' : 's-lo'); }

/* ★ v10.25：同款聚拢（搜索弹窗）—— 修「同一款游戏在结果里出现好几遍」
 *
 *  根因不是数据重复，是**源站把同一款拆成多个页面**：XDGAME 上「艾尔登法环」有
 *  `/game/3668.html`（标准版）与 `/game/4156.html`（支持网络联机）两条独立条目，
 *  加上机地主源那条，搜「艾尔登」6 行里「艾尔登法环」就占了 3 行 —— 看着像 bug。
 *
 *  归并键 = `splitName(title).zh`，即标题**第一个「/」之前**那段，完全相等才归并：
 *    「艾尔登法环/ELDEN RING」与「艾尔登法环/ELDEN RING/支持网络联机」→ 同键 ✓
 *    「艾尔登法环 黑夜君临/ELDEN RING NIGHTREIGN」        → 不同键 ✓（那是另一款，不能并）
 *  ⚠️ 刻意**不用子串匹配** —— 子串会把上面两者并成一条（跨源名称匹配的老坑）。
 *
 *  归并只影响**展示**：每个条目都还在，其余收进主行下方的 chip，点了同样进详情。
 *  主行 = 该键**首次出现**的那条（接口已按「标题↔关键词」贴合度排好序，这里不重排）。 */
function smKeyOf(it) { return splitName(it.title).zh.toLowerCase().replace(/\s+/g, ''); }
function smGroup(list) {
  const map = new Map();
  for (const it of (list || [])) {
    const k = smKeyOf(it);
    const g = map.get(k);
    if (g) g.rest.push(it); else map.set(k, { main: it, rest: [] });
  }
  return [...map.values()];
}
/* 非主行条目的区分标签：标题第 2 段起里**带中文**的那一截
 * （`/ELDEN RING/支持网络联机` → 「支持网络联机」）；一截都没有就叫「原版」。 */
function smVariant(it) {
  const cn = String(it.title || '').split('/').slice(1).find((s) => /[\u4e00-\u9fa5]/.test(s));
  return cn ? cn.trim() : '原版';
}
/* 主行下方「另 N 个条目」那一行；只有一个条目时返回空串（大多数情况） */
function smAltHtml(g) {
  if (!g.rest.length) return '';
  const chips = g.rest.map((it) => {
    const s = SRC[it.source] || { nm: 'XDGAME', cls: 'xd' };
    const sc = okScoreV(it.score) ? ` ★${it.score}` : '';
    return `<button type="button" class="sm-alt-b ${s.cls}" data-url="${esc(it.url)}" data-fb="${rankFb(it)}"><span class="sb">${esc(s.nm)}</span> ${esc(smVariant(it))}${sc} <span class="ar">↗</span></button>`;
  }).join('');
  return `<div class="sm-alt"><span class="sm-alt-h"><span class="ic">↳</span> 另 ${g.rest.length} 个条目</span>${chips}</div>`;
}
/* 列表 → HTML：主行 + 其余条目 chips。limit 是**条目**上限（沿用旧口径，聚合后再收窄行数）。 */
function smRows(list, limit) {
  const arr = limit ? (list || []).slice(0, limit) : (list || []);
  return smGroup(arr).map((g) => smRow(g.main) + smAltHtml(g)).join('');
}

/* ★ 手游中心结果行（统一搜索的第二个分组）
 *   与端游行的区别：手游走**手游中心合并索引**，标注「N 套配置 / M 条实测 / 实测 XX 帧」，
 *   点击后**不跳源站**，而是打开端游库详情（若命中 libId）或提示未收录。 */
function smMobileRow(it) {
  const meta = [];
  if (it.configs) meta.push(`<span class="pill hot">${it.configs} 套配置</span>`);
  if (it.records) meta.push(`<span class="pill rec">${it.records} 条实测</span>`);
  if (it.bestLabel) meta.push(`<span class="pill fps">${esc(String(it.bestLabel))}</span>`);
  const gpus = (it.gpus || []).slice(0, 2).map((g) => `<span class="pill type">${esc(g)}</span>`).join('');
  const alt = (it.alt || [])[0];
  const lid = it.libId || '';
  /* 有端游库命中 → 可直接进详情；否则给「未收录」提示样式 */
  const go = lid ? '查看详情 →' : '仅手游数据';
  const cls = lid ? 'sm-row' : 'sm-row no-lib';
  return `<div class="${cls}" data-mlib="${esc(lid)}" data-mtitle="${esc(it.libTitle || it.name)}">
    ${it.libCover ? `<img src="${esc(it.libCover)}" alt="" loading="lazy" onerror="this.style.visibility='hidden'">` : `<span class="ph2 mob">${esc(String(it.name || '?').charAt(0))}</span>`}
    <div class="bd"><div class="t">${esc(it.name || '')}</div>${alt ? `<div class="en">${esc(alt)}</div>` : ''}<div class="m">${meta.join('')}${gpus}</div></div>
    <span class="src-badge mob">📱 手游</span>
    <span class="go2">${go}</span>
  </div>`;
}
function bindSmRows() {
  $$('#smBody .sm-row').forEach(r => r.addEventListener('click', () => openDetailFromSearch(r)));
  /* ★ v10.25：同款聚拢后主行下方的「另 N 个条目」chip —— 与主行**同一条路**进详情
   *   （同样带 data-url/data-fb，所以直接复用 openDetailFromSearch，不另写一套跳转）。 */
  $$('#smBody .sm-alt-b').forEach(r => r.addEventListener('click', () => openDetailFromSearch(r)));
  /* 手游结果行：点了开抽屉（有 libId 用 libId，没有再退回按名字找） */
  $$('#smBody .sm-row[data-mlib]').forEach(r => r.addEventListener('click', () => {
    const body = $('#smBody');
    smSnapshot = { q: (lastQ || $('#searchInput').value.trim()), html: body.innerHTML, scroll: body.scrollTop };
    closeSearch();
    const lid = r.dataset.mlib, t = r.dataset.mtitle;
    if (lid && typeof openDetailById === 'function') openDetailById(lid, t);
    else toast('这款未收录进本地端游库，暂无详情页');
  }));
  /* ★ v10：修改器结果行 —— 有 libId 开详情，否则给出「获取方式」提示 */
  $$('#smBody .sm-row[data-trlib]').forEach(r => r.addEventListener('click', () => {
    const body = $('#smBody');
    smSnapshot = { q: (lastQ || $('#searchInput').value.trim()), html: body.innerHTML, scroll: body.scrollTop };
    closeSearch();
    const lid = r.dataset.trlib, t = r.dataset.trtitle;
    if (lid && typeof openDetailById === 'function') openDetailById(lid, t);
    else toast('这款未关联端游库，到手机专区「修改器」页可看获取方式');
  }));
  /* ★ v10：云存档结果行 —— 同理；未关联时提示去云存档页看完整路径 */
  $$('#smBody .sm-row[data-svlib]').forEach(r => r.addEventListener('click', () => {
    const body = $('#smBody');
    smSnapshot = { q: (lastQ || $('#searchInput').value.trim()), html: body.innerHTML, scroll: body.scrollTop };
    closeSearch();
    const lid = r.dataset.svlib, t = r.dataset.svtitle;
    if (lid && typeof openDetailById === 'function') openDetailById(lid, t);
    else toast('到手机专区「云存档」页可看这款的完整存档路径');
  }));
}

/* ★ v10（统一搜索分组③）：修改器结果行
 *   数据来自 Game Cheats Manager 公开清单，标注来源与版本；
 *   点进详情的前提是这款能对上端游库（有 libId）。 */
const SM_TR_LABEL = { fling: '风灵月影', cheat_table: 'CE 修改表', community: '社区贡献', xiaoxing: '小幸修改器', gcm: 'GCM 精选' };
function smTrainerRow(it) {
  const title = it.zh || it.name || '?';
  const en = (it.zh && it.name && it.zh !== it.name) ? it.name : '';
  const meta = [`<span class="pill src-tr">${esc(SM_TR_LABEL[it.source] || it.source || '')}</span>`];
  if (it.version) meta.push(`<span class="pill ver2">v ${esc(it.version)}</span>`);
  const lid = it.libId || '';
  return `<div class="sm-row${lid ? '' : ' no-lib'}" data-trlib="${esc(lid)}" data-trtitle="${esc(it.libTitle || title)}">
    ${it.libCover ? `<img src="${esc(it.libCover)}" alt="" loading="lazy" onerror="this.style.visibility='hidden'">` : `<span class="ph2 tr">${esc(String(title).charAt(0))}</span>`}
    <div class="bd"><div class="t">${esc(title)}</div>${en ? `<div class="en">${esc(en)}</div>` : ''}<div class="m">${meta.join('')}</div></div>
    <span class="src-badge tr">🛠 修改器</span>
    <span class="go2">${lid ? '查看详情 →' : '仅修改器数据'}</span>
  </div>`;
}

/* ★ v10（统一搜索分组④）：云存档结果行
 *   ★ 直接把「存档路径」铺在行里 —— 用户搜这款游戏，十有八九就是想找存档放哪。 */
function smSaveRow(it) {
  const title = it.title || it.name || '?';
  const en = (it.name && it.name !== title) ? it.name : '';
  const meta = [`<span class="pill">${it.pathCount || 0} 条存档</span>`];
  if (it.regCount) meta.push(`<span class="pill">${it.regCount} 项注册表</span>`);
  (it.cloud || []).slice(0, 1).forEach(c => meta.push(`<span class="pill cld">☁ ${esc(String(c).toUpperCase())}</span>`));
  const p0 = (it.paths || [])[0] || '';
  const lid = it.libId || '';
  return `<div class="sm-row${lid ? '' : ' no-lib'}" data-svlib="${esc(lid)}" data-svtitle="${esc(title)}">
    ${it.libCover ? `<img src="${esc(it.libCover)}" alt="" loading="lazy" onerror="this.style.visibility='hidden'">` : `<span class="ph2 sv">${esc(String(title).charAt(0))}</span>`}
    <div class="bd"><div class="t">${esc(title)}</div>${en ? `<div class="en">${esc(en)}</div>` : ''}
      <div class="m">${meta.join('')}</div>
      ${p0 ? `<div class="pth" title="${esc(p0)}">${esc(p0)}</div>` : ''}</div>
    <span class="src-badge sv">💾 云存档</span>
    <span class="go2">${lid ? '查看详情 →' : '仅存档数据'}</span>
  </div>`;
}
async function doSearch() {
  const q = $('#searchInput').value.trim();
  if (!q) { paintSearchHome(); return; }
  if (q.length > 40) { toast('关键词过长（限 40 字）'); return; }
  lastQ = q; sugIdx = -1;
  const body = $('#smBody');
  body.innerHTML = `<div class="sm-sec">正在搜索全站（端游库 + 手游中心 + 修改器 + 云存档） “${esc(q)}”…</div>${smSkeleton(4)}`;
  try {
    /* ★ 统一搜全站：一个端点同时返回**四个库**的结果，分组渲染。
     *   这样在手机专区点顶栏搜索也能搜到手游玩法与资源，而不是只搜端游库。 */
    const j = await fetch(api('/api/search/all?q=' + encodeURIComponent(q) + '&limit=12')).then(r => r.json());
    const pc = (j && j.pc) || { items: [] };
    const mob = (j && j.mobile) || { items: [] };
    const tr = (j && j.trainer) || { items: [] };
    const sv = (j && j.save) || { items: [] };
    const allEmpty = !(pc.items || []).length && !(mob.items || []).length
      && !(tr.items || []).length && !(sv.items || []).length;
    // 四个库都空 且 偏好「自动兜底」开启 → 免点击直接实时查源站
    if (allEmpty && localStorage.getItem('ghAutoLive') === '1') {
      toast('本地库未收录，正在自动实时查源站…');
      await searchLive(q);
    } else paintSearchResult(q, j);
  } catch (e) {
    body.innerHTML = `<div class="sm-empty"><div class="big">⚠️</div>搜索失败：${esc(e.message)}</div>`;
  }
}
/* 统一结果渲染：★ v10 起四个分组
 *   ① 📱 手游中心（手机能玩吗 · 配置 + 实测）
 *   ② 🛠 修改器（有哪些修改器、哪个源、什么版本）
 *   ③ 💾 云存档（存档放哪 —— 用户搜游戏时常找的就是这个）
 *   ④ 🖥️ 端游库（全站收录 · 兜底）
 *   手游放最前是因为在「手机专区」语境下用户更关心它；
 *   端游库放最后是兜底口径（什么都搜不到时它最可能命中）。 */
function paintSearchResult(q, j) {
  const body = $('#smBody');
  const aliasHtml = j.aliasNote ? `<span class="cnt" style="color:var(--c-score)">别名 ${esc(j.aliasNote.alias)} → ${esc(j.aliasNote.to)}</span>` : '';
  /* ★ v10.7：打分用「实际生效的关键词」—— 别名命中时标题里出现的是别名目标名，
   *   拿原词去打分会四组全 0，排序退化成旧顺序。 */
  const qEff = (j.aliasNote && j.aliasNote.to) || q;
  const pc = (j.pc || { items: [], count: 0 });
  const mob = (j.mobile || { items: [], count: 0 });
  const tr = (j.trainer || { items: [], count: 0 });
  const sv = (j.save || { items: [], count: 0 });
  const pcHit = (pc.items || []).slice(0, 30);
  const mobHit = (mob.items || []).slice(0, 20);
  const trHit = (tr.items || []).slice(0, 20);
  const svHit = (sv.items || []).slice(0, 20);

  if (!pcHit.length && !mobHit.length && !trHit.length && !svHit.length) {
    const total = (pc.total || 15000).toLocaleString();
    body.innerHTML = `<div class="sm-sec">全站命中<span class="cnt">0 款</span></div>
      <div class="sm-empty"><div class="big">🕳️</div>四个库（端游 <b>${total}</b> 款 / 手游 / 修改器 / 云存档）都未收录「<b>${esc(q)}</b>」<br><span style="font-size:11.5px">每日 09:30 自动增量同步，可稍后再搜；也可直接实时查源站</span></div>
      <div class="sm-acts"><button class="mini-btn" style="flex:1" type="button" data-q="${esc(q)}" onclick="searchLive(this.dataset.q)">↗ 仍要实时搜源站（XDGAME / 机地）</button></div>
      <div style="padding:0 11px 6px"><label class="auto-live" style="margin:0"><input type="checkbox" ${localStorage.getItem('ghAutoLive') === '1' ? 'checked' : ''} onchange="toggleAutoLive(this)"> 以后本地搜不到时自动查源站（免点击）</label></div>`;
    return;
  }

  /* ★ v10.7：分组按「贴合度」动态排序（原先是写死 手游→修改器→云存档→端游库）
   *
   *  问题：搜「剑星」时，四个库都有命中，而**用户真正要找的那款游戏**在「端游库」——
   *  写死的顺序把它压到第 4 组，得滚动才看得到；首屏反而是手游配置、修改器版本。
   *
   *  规则：以「标题 ↔ 关键词」的贴合度给四组打分，高的排前；同分保持原顺序
   *        （Array#sort 在 V8 是稳定排序，所以「都不沾关键词」时行为与旧版一致）。
   *        3 = 归一化后完全同名（搜「剑星」命中「剑星」）
   *        2 = 以关键词开头（搜「剑星」命中「剑星-虚拟机版」）
   *        1 = 包含关键词
   *        0 = 标题里根本没有关键词（靠英文名/别名/子串兜底命中的）
   *  归一化去掉空格与常见分隔符（`剑星-虚拟机版`→`剑星虚拟机版`、
   *  `Resident Evil 2: Remake`→`residentevil2remake`），并**优先用别名解析后的词**
   *  （用户搜别名时，标题里出现的是别名目标名，用原词打分会全组 0 分）。
   *
   *  ⚠️ 只按贴合度排会失效：四个库收录的是**同一批游戏**，「完全同名」经常四组同时命中
   *  —— 实测搜「艾尔登法环」四组全 3 分、「只狼」「GTA」四组全 2 分，全平局又退回原顺序，
   *  端游库照样垫底，等于没改。所以再加一条**本体提权**：端游库拿到 2 分以上
   *  （即本名精确或近似命中）时 +1 分 —— 它代表的是「游戏本体」这一实体，
   *  也是四组里唯一能点进完整详情页的；其余三组都是「关于这款游戏」的附加信息。
   *  提权只在端游库确有本名命中时生效，其余情况一律不动默认顺序。 */
  const rn = (s) => String(s == null ? '' : s).toLowerCase().replace(/[\s\-_:：·・/\\|'"“”‘’()（）\[\]]/g, '');
  const qn = rn(qEff);
  const fit = (...nameLists) => {
    let best = 0;
    for (const list of nameLists) {
      for (const nm of list || []) {
        for (const one of String(nm || '').split('/')) {
          const s = rn(one);
          if (!s || !qn) continue;
          const v = s === qn ? 3 : (s.startsWith(qn) ? 2 : (s.includes(qn) ? 1 : 0));
          if (v > best) best = v;
        }
      }
    }
    return best;
  };
  const pcFit = fit(pcHit.map((x) => x.title));
  const groups = [
    { i: 0, icon: '📱', name: '手游中心 · 手机能玩吗', tag: 'MOBILE', tagCls: 'match', cnt: mob.count, unit: '款',
      score: fit(mobHit.map((x) => x.name), mobHit.map((x) => x.libTitle)),
      rows: mobHit.length ? mobHit.map(smMobileRow).join('') : `<div class="sm-empty" style="padding:14px">手游中心无命中</div>` },
    { i: 1, icon: '🛠', name: '修改器 · 有没有修改器', tag: 'TRAINER', tagCls: 'match', cnt: tr.count, unit: '条',
      score: fit(trHit.map((x) => x.zh), trHit.map((x) => x.name), trHit.map((x) => x.libTitle)),
      rows: trHit.length ? trHit.map(smTrainerRow).join('') : `<div class="sm-empty" style="padding:14px">修改器库无命中</div>` },
    { i: 2, icon: '💾', name: '云存档 · 存档放在哪', tag: 'SAVE', tagCls: 'match', cnt: sv.count, unit: '款',
      score: fit(svHit.map((x) => x.title), svHit.map((x) => x.name)),
      rows: svHit.length ? svHit.map(smSaveRow).join('') : `<div class="sm-empty" style="padding:14px">云存档库无命中</div>` },
    { i: 3, icon: '🖥️', name: '端游库 · 全站收录', tag: 'LOCAL', tagCls: 'local', cnt: pc.count, unit: '款',
      score: pcFit + (pcFit >= 2 ? 1 : 0),
      rows: pcHit.length ? smRows(pcHit) : `<div class="sm-empty" style="padding:14px">端游库无命中</div>` },
  ];
  groups.sort((a, b) => b.score - a.score || a.i - b.i);

  /* 分组小标题：首组不加顶部间距，后续组加 padding-top 拉开层次 */
  let html = '';
  groups.forEach((g, k) => {
    html += `<div class="sm-sec"${k === 0 ? '' : ' style="padding-top:12px"'}>${g.icon} ${g.name}<span class="tag ${g.tagCls}">${g.tag}</span><span class="cnt">${g.cnt || 0} ${g.unit}</span>${aliasHtml}</div>`;
    html += g.rows;
  });
  body.innerHTML = html;
  bindSmRows();
}
/* 本地 0 命中后的兜底：实时查 XDGAME / 机地两个源站（结果不进库、不缓存） */
async function searchLive(q) {
  if (liveSearching) return;
  liveSearching = true;
  const body = $('#smBody');
  body.innerHTML = `<div class="sm-sec">正在实时搜索源站 “${esc(q)}”…<span class="cnt">约 3-8s</span></div>${smSkeleton(4)}`;
  try {
    const j = await fetch(api('/api/search?q=' + encodeURIComponent(q) + '&refresh=1')).then(r => r.json());
    const xd = j.sources && j.sources.xdgamer;
    const ji = j.sources && j.sources.jidi;
    let html = `<div class="sm-sec">源站实时结果 · 本地库未收录<span class="tag real">LIVE</span></div>`;
    html += `<div class="sm-sec" style="padding-top:4px">XDGAME 站内<span class="tag real">LIVE</span><span class="cnt">${xd && xd.ok ? (xd.items || []).length + ' 款' : '不可用'}</span></div>`;
    if (!xd || !xd.ok) html += `<div class="sm-empty" style="padding:14px">XDGAME 站内搜索不可用：${esc((xd && xd.error) || '网络异常')}</div>`;
    else if (!(xd.items || []).length) html += `<div class="sm-empty" style="padding:14px">XDGAME 站内无结果</div>`;
    else html += smRows(xd.items || []);
    html += `<div class="sm-sec" style="padding-top:12px">机地站内<span class="tag match">LIVE</span><span class="cnt">${ji && ji.ok ? (ji.items || []).length + ' 款' : '不可用'}</span></div>`;
    if (!ji || !ji.ok) html += `<div class="sm-empty" style="padding:14px">机地搜索不可用：${esc((ji && ji.error) || '网络异常')}</div>`;
    else if (!(ji.items || []).length) html += `<div class="sm-empty" style="padding:14px">机地站内无结果</div>`;
    else html += smRows(ji.items || []);
    html += `<div class="sm-acts" style="padding-top:12px">
      <a class="mini-btn" style="flex:1;text-decoration:none" href="${esc((j.searchUrl && j.searchUrl.xdgamer) || 'https://www.xdgame.com/')}" target="_blank" rel="noopener">前往 XDGAME 站内搜 ↗</a>
      <a class="mini-btn" style="flex:1;text-decoration:none;background:rgba(230,65,93,.07);border-color:rgba(230,65,93,.3);color:var(--c-jidi)" href="${esc((j.searchUrl && j.searchUrl.jidi) || 'https://jidiyouxi.com/')}" target="_blank" rel="noopener">前往机地站内搜 ↗</a>
    </div>`;
    body.innerHTML = html;
    bindSmRows();
  } catch (e) {
    body.innerHTML = `<div class="sm-empty"><div class="big">⚠️</div>实时搜索失败：${esc(e.message)}</div>`;
  } finally { liveSearching = false; }
}
/* 偏好：本地 0 命中是否自动实时查源站（localStorage 'ghAutoLive'，默认关=手动） */
function toggleAutoLive(el) {
  localStorage.setItem('ghAutoLive', el.checked ? '1' : '0');
  toast(el.checked ? '已开启：本地搜不到时自动实时查源站' : '已关闭自动查源站（恢复手动）');
  if (el.checked && lastQ) searchLive(lastQ);
}
function bindRowCards(root) {
  $$('.row-card', root || document).forEach(c => c.addEventListener('click', () => openDetail(c.dataset.url, c.dataset.fb)));
}

/* ============ 键盘 ←/→ 切换详情 / Esc 关闭 ============ */
let keyRows = [];     // 当前可见行卡数组
let keyIdx = -1;
/* 当前可切换的条目集：搜索进入 → 弹窗结果行；列表进入 → 主列行卡 */
function collectRows() { keyRows = $$(detailFromSearch ? '#smBody .sm-row' : '#colMain .row-card'); }
/* 详情切换共用：dir=+1 下一款 / -1 上一款（键盘 ←/→ 与移动端抽屉横滑共用） */
function switchDetail(dir) {
  if (!$('#drawer').classList.contains('show')) return false;
  if (drawerMode !== 'game') return false;   // 配置面板（bh / pc）不支持左右切换
  if (!keyRows.length) collectRows();
  const cur = document.querySelector('.on-drawer') || keyRows[keyIdx >= 0 ? keyIdx : 0];
  keyIdx = Math.max(0, keyRows.indexOf(cur));
  const next = keyRows[keyIdx + dir];
  if (next) {
    keyIdx = keyRows.indexOf(next);
    next.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    openDetail(next.dataset.url, next.dataset.fb, detailFromSearch);
    return true;
  }
  return false;
}
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    if (smOpen) { closeSearch(); return; }   // 搜索弹窗优先关闭
    closeDetail();
    return;
  }
  if (!$('#drawer').classList.contains('show')) return;
  if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
  e.preventDefault();
  if (!switchDetail(e.key === 'ArrowRight' ? 1 : -1)) toast('已是列表边缘，没有更多条目');
});
/* 移动端抽屉横滑：左滑=下一款 / 右滑=上一款（桌面另有 ←/→ 键） */
(function bindSwipe() {
  const el = $('#drawer');
  let x0 = null, y0 = null;
  el.addEventListener('touchstart', (e) => { const t = e.touches[0]; x0 = t.clientX; y0 = t.clientY; }, { passive: true });
  el.addEventListener('touchend', (e) => {
    if (x0 == null) return;
    const t = e.changedTouches[0];
    const dx = t.clientX - x0, dy = t.clientY - y0;
    x0 = null; y0 = null;
    if (Math.abs(dx) < 60 || Math.abs(dy) > Math.abs(dx) * 1.2) return; // 需明显横向
    switchDetail(dx < 0 ? 1 : -1);
  }, { passive: true });
})();

/* ================= 联想（弹窗内本地库秒搜，↑/↓ 选择 + 回车直达） ================= */
function sugItems() { return $$('#smBody .sm-row'); }
function moveSug(dir) {
  const items = sugItems();
  if (!items.length) return;
  sugIdx = (sugIdx + dir + items.length) % items.length;
  items.forEach((x, i) => x.classList.toggle('on', i === sugIdx));
  const cur = items[sugIdx]; if (cur) cur.scrollIntoView({ block: 'nearest' });
}
function pickSug() {
  const items = sugItems();
  const el = sugIdx >= 0 ? items[sugIdx] : null;
  if (!el) return false;
  openDetailFromSearch(el);
  return true;
}
/* 联想渲染：输入停顿 180ms 后拉本地库前 8 条，直接铺进弹窗 */
function showSug(items) {
  if (!items.length) {
    sugIdx = -1;
    $('#smBody').innerHTML = `<div class="sm-empty" style="padding:22px 16px"><div class="big">🔍</div>没有匹配的联想<br><span style="font-size:11.5px">按 <b>Enter</b> 搜索本地库</span></div>`;
    return;
  }
  sugIdx = -1;
  /* ★ v10.25：同款聚拢后显示「款数」而不是「条目数」—— 6 条里其实只有 3 款，
   *   写 6 款会让用户以为丢数据（所以并了多少条也一并说明）。 */
  const hit = items.slice(0, 8);
  const gs = smGroup(hit);
  const cntTxt = gs.length + ' 款' + (gs.length < hit.length ? ` · 合并 ${hit.length} 条` : '');
  $('#smBody').innerHTML = `<div class="sm-sec">本地库联想<span class="tag local">SUGGEST</span><span class="cnt">${cntTxt}</span></div>` + smRows(hit);
  bindSmRows();
  const its = sugItems();
  its.forEach((x, i) => x.addEventListener('mousemove', () => {
    if (sugIdx !== i) { sugIdx = i; its.forEach((y, k) => y.classList.toggle('on', k === i)); }
  }));
}
$('#searchInput').addEventListener('input', () => {
  clearTimeout(sugTimer);
  const q = $('#searchInput').value.trim();
  $('#smClear').classList.toggle('hidden', !q);
  if (!q) { paintSearchHome(); return; }
  sugTimer = setTimeout(async () => {
    try {
      const j = await fetch(api('/api/library?q=' + encodeURIComponent(q) + '&limit=8')).then(r => r.json());
      showSug(j.items || []);
    } catch (e) { /* 联想失败保持现状 */ }
  }, 180);
});
$('#searchInput').addEventListener('keydown', e => {
  if (e.key === 'ArrowDown') { e.preventDefault(); moveSug(1); }
  else if (e.key === 'ArrowUp') { e.preventDefault(); moveSug(-1); }
  else if (e.key === 'Enter') {
    e.preventDefault();
    if (!pickSug()) doSearch(); // 未用键盘选择过 → 回车=搜本地库
  }
});
$('#smClear').addEventListener('click', () => {
  const inp = $('#searchInput'); inp.value = ''; inp.focus();
  $('#smClear').classList.add('hidden');
  sugIdx = -1;
  paintSearchHome();
});
$('#smask').addEventListener('click', closeSearch);
/* 全局快捷键：Ctrl/Cmd+K 唤起（或关闭）搜索弹窗；「/」在非输入态唤起 */
document.addEventListener('keydown', (e) => {
  const typing = /^(INPUT|TEXTAREA|SELECT)$/.test((e.target && e.target.tagName) || '');
  if ((e.ctrlKey || e.metaKey) && (e.key === 'k' || e.key === 'K')) {
    e.preventDefault();
    if ($('#drawer').classList.contains('show')) { closeDetail(); if (!smOpen) openSearch(); return; } // 详情态：先关闭（来自搜索会自动还原弹窗）
    smOpen ? closeSearch() : openSearch();
    return;
  }
  if (e.key === '/' && !typing && !smOpen && !$('#drawer').classList.contains('show')) { e.preventDefault(); openSearch(); }
});

/* ================= 移动端底部 Tab 导航（<=760px 显示） ================= */
$('#tabbar').addEventListener('click', (e) => {
  const a = e.target.closest('a[data-tab]'); if (!a) return;
  e.preventDefault();
  $$('#tabbar a').forEach(x => x.classList.toggle('on', x === a));
  const t = a.dataset.tab;
  if (t === 'rank') {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  } else if (t === 'latest') {
    const el = $('#latest'); if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  } else if (t === 'search') {
    openSearch();
  } else if (t === 'emu' || t === 'pc' || t === 'eg') {
    // 手机三个入口 = 跳到独立专区页的对应子页签
    goEmuPage(t);
  } else if (t === 'about') {
    const el = document.querySelector('footer'); if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
});
/* 桌面顶栏导航。
   首页：热榜 + 最新收录本就是首页的两个分区，点击回顶部即自然看到热榜，
   往下滚就是最新收录，不必再占一个顶栏位（v9.1）。
   ★ v10.2：独立页（手机专区 /emulator.html）上「🏠 首页」必须是**真跳转回聚合首页**
     —— 那里没有 #rankStage，若也拦成「回顶部」就等于点了没反应。历史上正是因为这个，
     页内又塞了一个「← 返回聚合首页」按钮，同一个出口在屏幕上出现两次。
     这里用 body 上的页面标记区分两页语义，而不是各写一份脚本。 */
/* ★ v10.44：独立页不再只有「手机专区」—— 端游资源(/resources.html) 与
   解包匹配同样没有 #rankStage，点「🏠 首页」必须是真跳转回 `/`。
   判据由「等于 emulator」放宽为「任何带 data-page 标记的都不是首页」。 */
const IS_SUB_PAGE = (document.body.getAttribute('data-page') || '') !== '';
$('#navHome').addEventListener('click', (e) => {
  if (IS_SUB_PAGE) return;              // 独立页：交回 href="/" 正常跳转
  e.preventDefault();
  window.scrollTo({ top: 0, behavior: 'smooth' });
});
/* 三个手机分区已拆到独立页 /emulator.html，点击 = 页面跳转（见下方专区跳转块） */


/* ================= 📱 手机专区三分区驱动（独立页专用） =================
 *
 * 为什么单独一份：
 *   这三个分区原先内联在 index.html，随「拆独立页」一起被移除。
 *   独立页需要它们自己的数据加载 / 渲染 / 筛选 / 懒加载逻辑。
 *
 * 分区与接口对应：
 *   #emulator  手游中心（社区库 + 实测库 **合并成一张表**）
 *              → /api/mobilehub/stats、/api/mobilehub/list、/api/mobilehub/match
 *   #emuguide  模拟器指南 → /api/emuguide、/api/emuguide/chip
 *   #devmatch  机型兼容 → /api/device/*
 *
 * 懒加载：每个分区首次被切到时才发请求（inited 标记），避免一次性打满接口。
 */

/* ---------------- 通用小工具（若主脚本已定义则复用） ---------------- */
if (typeof window.esc !== 'function') {
  window.esc = (s) => String(s == null ? '' : s)
    .replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
const EMU_PAGE_SIZE = 24;

/* ================= ① 手游中心（社区库 + 实测库 合并） =================
 *
 * ★ v9.3 改造（用户诉求：「先将手游已有的配置+实测汇总，再将已收录的游戏对应电脑的进行匹配，
 *   手游默认显示跟端游匹配的游戏」）：
 *   原本这里是「手游可玩」（社区库）一个页签，隔壁还有「实测配置」（实测库）一个页签。
 *   同一款游戏（GTA V）在两个页签各出现一次，用户要来回切，也看不出
 *   「这款到底有几套配置可抄 + 实测跑多少帧」。
 *
 *   现在统一走 /api/mobilehub/*，后端已把两个库按名字/端游库 id 归并：
 *     · 同款只占一条，配置数累加（社区 N 套 + 实测 M 条）
 *     · 卡片同时显示「N 套配置」「M 条实测」「实测 XX 帧」
 *     · **默认只显示能对上端游库的**（matched）—— 有封面、点得进详情
 *     · **默认「双料优先」排序**：帧率数据与社区配置数几乎不重叠（详见 mobilehub.js 注释），
 *       纯按配置数排首屏看不到任何帧率卡，所以默认把「两类信息都有」的顶上来
 */
const emuState = { q: '', gpu: '', tier: '', sort: 'both', matched: true, both: false, tr: false, sv: false, offset: 0, total: 0, items: [], inited: false, loading: false };

/** 帧率档 → 徽标配色类 */
const TIER_CLS = { '流畅': 'smooth', '可玩': 'ok', '勉强': 'low', '卡顿': 'bad' };

/** 合并卡片：封面（命中端游库则铺图）+ 配置数 + 实测帧率 + GPU/机型标签 */
function emuCard(it) {
  const title = it.name || it.libTitle || '?';
  const cov = it.libCover
    ? `<div class="cov"><img src="${esc(it.libCover)}" alt="" loading="lazy" referrerpolicy="no-referrer">
         ${it.libId ? `<button class="cov-btn" data-lib="${esc(it.libId)}" data-title="${esc(it.libTitle || title)}" type="button">查看游戏详情</button>` : ''}</div>`
    : `<div class="cov noimg"><span>${esc(String(title).slice(0, 2).toUpperCase())}</span></div>`;

  /* 数据来源徽标：一眼看出「这条是社区抄的配置 / 还是本站实测的」 */
  const srcs = it.sources || [];
  const srcTag = (srcs.indexOf('bh') >= 0 && srcs.indexOf('pc') >= 0)
    ? `<span class="tg src both">社区+实测</span>`
    : srcs.indexOf('pc') >= 0 ? `<span class="tg src pc">本站实测</span>`
      : `<span class="tg src bh">社区配置</span>`;

  const cfg = it.configs || 0;
  const rec = it.records || 0;
  const fps = it.bestLabel || (it.bestMid ? it.bestMid + ' 帧' : '');

  const gpus = (it.gpus || []).slice(0, 3).map((g) => `<span class="tg">${esc(g)}</span>`).join('');
  const more = (it.gpus || []).length > 3 ? `<span class="tg dim">+${it.gpus.length - 3}</span>` : '';

  /* ★ v10.5：把「有修改器 / 有云存档」这层交叉信息露在卡面上 ——
   *   否则用户点了筛选、却说不出这些卡为什么被留下。 */
  const xrefTag = (it.hasTr ? '<span class="tg has-tr" title="修改器库收录了这款">🛠 有修改器</span>' : '')
    + (it.hasSv ? '<span class="tg has-sv" title="云存档库有这款的存档位置">💾 有存档</span>' : '');

  /* 别名提示：社区库是英文名、实测库是中文名，让用户看到两面 */
  const alt = (it.alt || []).filter((a) => a && a !== title)[0] || '';
  const altHtml = alt ? `<div class="alt" title="${esc(alt)}">${esc(String(alt).slice(0, 40))}</div>` : '';

  /* ★ v10.5：社区配置入口从「整卡点击」降级为卡上一个次级按钮 ——
   *   原因：「有社区配置键(bhKeys) 且 命中端游库(libId)」的卡片，旧逻辑让 bhk 优先，
   *   于是点正文进的是社区配置面板，用户反馈「点了不是游戏详情页」。
   *   现在正文一律进详情（有 libId 时），配置面板走这个明确的按钮。 */
  /* ★ v10.13：把**全部**候选仓库键带上（逗号分隔），不再只给第一个。
   *   同一款游戏在社区仓库里常有多个别名目录，份数差很多（如 PES2013 只有 2 份，
   *   Pro_Evolution_Soccer_2013 有 2773 份）。后端会挑份数最多的那个。 */
  const bhKeyList = (it.bhKeys || []).join(',');
  const cfgBtn = (it.bhKeys || []).length
    ? `<button class="cfg-btn" data-bhk="${esc(bhKeyList)}" data-nm="${esc(title)}" type="button" title="看这台设备上逐条跑通的模拟器配置">📋 社区配置</button>`
    : '';

  return `<article class="emu-card${it.libCover ? ' has-cov' : ''}" data-name="${esc(title)}" data-lib="${esc(it.libId || '')}" data-libt="${esc(it.libTitle || '')}" data-bhk="${esc(bhKeyList)}">
    ${cov}
    <div class="bd">
      <h4 title="${esc(title)}">${esc(title)}</h4>
      ${altHtml}
      <div class="meta">
        ${cfg ? `<span class="pill hot">${cfg} 套配置</span>` : ''}
        ${rec ? `<span class="pill rec">${rec} 条实测</span>` : ''}
        ${fps ? `<span class="pill fps ${TIER_CLS[it.tier] || ''}">${esc(String(fps))}</span>` : ''}
      </div>
      <div class="tgs">${srcTag}${gpus}${more}${xrefTag}${cfgBtn}</div>
    </div>
  </article>`;
}

/** 卡片点击分流（v10.5 统一语义：**有端游库命中就进详情页**）
 *   · 点「📋 社区配置」按钮 → 社区配置面板
 *   · 点「查看游戏详情」按钮 / 卡片正文（有 libId）→ 游戏详情抽屉
 *   · 没对上端游库但社区库有键 → 社区配置面板（此时没有详情可去，整卡开面板）
 *   · 都没有 → 提示未收录
 */
function bindEmuCards() {
  const g = document.getElementById('emuGrid'); if (!g || g.dataset.bound) return;
  g.dataset.bound = '1';
  g.addEventListener('click', (e) => {
    const card = e.target.closest('.emu-card'); if (!card) return;
    const cfg = e.target.closest('.cfg-btn');
    if (cfg && cfg.dataset.bhk && typeof openBhPanel === 'function') {
      e.stopPropagation();
      openBhPanel(cfg.dataset.bhk, cfg.dataset.nm || card.dataset.name);
      return;
    }
    const btn = e.target.closest('.cov-btn');
    const lib = (btn && btn.dataset.lib) || card.dataset.lib;
    if (lib && typeof openDetailById === 'function') {
      openDetailById(lib, (btn && btn.dataset.title) || card.dataset.libt || card.dataset.name);
      return;
    }
    if (card.dataset.bhk && typeof openBhPanel === 'function') {
      openBhPanel(card.dataset.bhk, card.dataset.name);
      return;
    }
    if (typeof toast === 'function') toast('这款未收录进本地端游库，暂无详情页');
  });
}

async function loadEmu(more) {
  if (emuState.loading) return;
  emuState.loading = true;
  const grid = document.getElementById('emuGrid');
  if (!more) { emuState.offset = 0; if (grid) grid.innerHTML = '<div class="emu-loading">正在拉取手游中心数据…</div>'; }
  try {
    const qs = new URLSearchParams({
      q: emuState.q, gpu: emuState.gpu, tier: emuState.tier, sort: emuState.sort,
      limit: EMU_PAGE_SIZE, offset: emuState.offset,
    });
    /* ★ 默认只显示匹配端游库的；关掉开关时传 stats=all 看全量 */
    if (!emuState.matched) qs.set('stats', 'all');
    /* ★ v10.1「只看双料」：与 stats 是 AND 关系（两个都开 = 双料且对上端游库 = 85 条） */
    if (emuState.both) qs.set('only', 'both');
    /* ★ v10.5 横切筛选：有修改器 / 有云存档（同样与上面各条件 AND） */
    if (emuState.tr) qs.set('tr', '1');
    if (emuState.sv) qs.set('sv', '1');
    const j = await fetch(api('/api/mobilehub/list?' + qs)).then((r) => r.json());
    emuState.total = j.total || 0;
    const items = j.items || [];
    emuState.items = more ? emuState.items.concat(items) : items;
    emuState.offset = emuState.items.length;
    if (grid) grid.innerHTML = emuState.items.length ? emuState.items.map(emuCard).join('') : '<div class="emu-empty">没有匹配的游戏，换个关键词试试</div>';
    const cnt = document.getElementById('emuCount'); if (cnt) cnt.textContent = `共 ${emuState.total.toLocaleString()} 款`;
    const mo = document.getElementById('emuMore');
    if (mo) mo.style.display = emuState.items.length < emuState.total ? '' : 'none';
  } catch (e) {
    if (grid) grid.innerHTML = '<div class="emu-empty">拉取失败，请稍后重试</div>';
  } finally { emuState.loading = false; }
}

async function initEmu() {
  if (emuState.inited) return; emuState.inited = true;
  bindEmuCards();
  // 顶部概览数字（合并口径）
  try {
    const s = await fetch(api('/api/mobilehub/stats')).then((r) => r.json());
    const box = document.getElementById('emuStats');
    if (box) {
      box.innerHTML = [
        ['合并游戏', s.total], ['匹配端游', s.matched], ['配置总数', s.configs], ['实测记录', s.records],
      ].map(([k, v]) => `<div class="st"><b>${v == null ? '—' : (typeof v === 'number' ? v.toLocaleString() : esc(v))}</b><span>${k}</span></div>`).join('');
    }
    const built = document.getElementById('emuBuilt');
    if (built && s.builtAt) built.textContent = `（索引更新于 ${new Date(s.builtAt).toLocaleString('zh-CN', { hour12: false })}，匹配率 ${s.matchedRate}%）`;
    // GPU / 机型 下拉
    const sel = document.getElementById('emuGpu');
    if (sel && s.gpus) {
      sel.innerHTML = '<option value="">全部 GPU / 机型</option>' + s.gpus.map((g) => `<option value="${esc(g)}">${esc(g)}</option>`).join('');
    }
  } catch (e) {}
  // 工具条事件
  const si = document.getElementById('emuSearch');
  if (si && !si.dataset.bound) {
    si.dataset.bound = '1';
    let t;
    si.addEventListener('input', () => { clearTimeout(t); t = setTimeout(() => { emuState.q = si.value.trim(); loadEmu(false); }, 260); });
  }
  const gpu = document.getElementById('emuGpu');
  if (gpu && !gpu.dataset.bound) { gpu.dataset.bound = '1'; gpu.addEventListener('change', () => { emuState.gpu = gpu.value; loadEmu(false); }); }
  const tier = document.getElementById('emuTier');
  if (tier && !tier.dataset.bound) { tier.dataset.bound = '1'; tier.addEventListener('change', () => { emuState.tier = tier.value; loadEmu(false); }); }
  const sorts = document.getElementById('emuSorts');
  if (sorts && !sorts.dataset.bound) {
    sorts.dataset.bound = '1';
    sorts.addEventListener('click', (e) => {
      const b = e.target.closest('.emu-sort'); if (!b) return;
      sorts.querySelectorAll('.emu-sort').forEach((x) => x.classList.toggle('on', x === b));
      emuState.sort = b.dataset.s; loadEmu(false);
    });
  }
  const mo = document.getElementById('emuMore');
  if (mo && !mo.dataset.bound) { mo.dataset.bound = '1'; mo.addEventListener('click', () => loadEmu(true)); }
  /* ---- 筛选开关统一装配（v10.5）----
   *   ★ 状态**完全不碰文案**：文字恒定，只在 .on 之间切换；
   *     左侧的「○ / ✓」由 CSS 定宽伪元素 .em-tg::before 提供。
   *     踩过两次坑：① 旧版把文案改成「…（已开）」→ 按钮宽 +28px → 后面的开关被挤换行；
   *     ② 把 ✓/○ 写进文案 → 两个字形宽度差 1.6px → 浏览器实测宽度仍在变。
   *     定宽伪元素是唯一能保证「盒宽逐像素不变」的写法。 */
  const bindToggle = (id, key, storeKey) => {
    const el = document.getElementById(id);
    if (!el) return;
    if (storeKey) { try { emuState[key] = localStorage.getItem(storeKey) === '1'; } catch (e) {} }
    const paint = () => el.classList.toggle('on', !!emuState[key]);
    paint();
    if (el.dataset.bound) return;
    el.dataset.bound = '1';
    el.addEventListener('click', () => {
      emuState[key] = !emuState[key];
      if (storeKey) { try { localStorage.setItem(storeKey, emuState[key] ? '1' : '0'); } catch (e) {} }
      paint();
      loadEmu(false);
    });
  };
  /* 「仅看匹配端游」**默认开**（用户诉求：手游默认显示跟端游匹配的游戏） */
  bindToggle('emuToggleLib', 'matched');
  /* 「只看双料」：社区配置库(bh) 与 机型实测库(pc) 都有记录 —— 全量 3161 条里只有 88 条。
   *   正因为稀缺，它才最能体现「两库合并」的价值：既有玩家跑通的配置，又有本站实测帧率。 */
  bindToggle('emuToggleBoth', 'both', 'ghEmuBoth');
  /* ★ v10.5 新增：按「修改器 / 云存档」索引是否收录来筛（两条数据都挂端游库 id） */
  bindToggle('emuToggleTr', 'tr', 'ghEmuTr');
  bindToggle('emuToggleSv', 'sv', 'ghEmuSv');
  const rf = document.getElementById('emuRefresh');
  if (rf && !rf.dataset.bound) {
    rf.dataset.bound = '1';
    rf.addEventListener('click', async () => {
      if (typeof toast === 'function') toast('正在刷新社区配置库…');
      try { await fetch(api('/api/bh/refresh'), { method: 'POST' }); } catch (e) {}
      setTimeout(() => loadEmu(false), 1500);
    });
  }
  await loadEmu(false);
}


/* ================= ③ 模拟器指南 ================= */
const egState = { inited: false };

/* ★ v10.19 修「模拟器指南太乱」——
   本函数原来渲染的类名（.eg-n / .eg-tx / .eg-sub / .eg-key / .eg-ch-h / .eg-tier /
   .eg-ch-b / .eg-ch-note / .eg-list）在 CSS 里**一个都不存在**：
   数据全都渲染出来了，样式却全部落空 —— ④优化 / ⑥版本 / ⑦帧率 直接退化成
   浏览器默认的圆点列表，五层技术栈与芯片卡只剩外框、内部文字全裸。
   现在一律改用 CSS 里**已经定义好**的类名（.no/.bd/.nm/.sb/.ds/.flag、
   .hd/.gen/.tag/.soc/.drv/.nt、.eg-tbl.w2c、.eg-tune、.eg-av）。
   改这条时务必对照 public/index.html 的「第五分区」CSS，别再造新类名。 */
async function initEg() {
  if (egState.inited) return; egState.inited = true;
  try {
    const g = await fetch(api('/api/emuguide')).then((r) => r.json());

    /* ① 五层技术栈 —— CSS: .eg-ly[.key] > .no + .bd(.nm/.sb/.ds) + .flag */
    const st = document.getElementById('egStack');
    if (st && g.stack) {
      st.innerHTML = g.stack.map((x) => `<div class="eg-ly${x.key ? ' key' : ''}">
        <div class="no">${x.n}</div>
        <div class="bd">
          <div class="nm">${esc(x.name)}</div>
          <div class="sb">${esc(x.sub || '')}</div>
          <div class="ds">${esc(x.desc || '')}</div>
        </div>
        ${x.key ? '<span class="flag">关键</span>' : ''}
      </div>`).join('');
    }

    /* ② 芯片卡 —— CSS: .eg-chip > .hd(.gen/.tag) + .soc + .drv(.ln/.ln.alt) + .nt */
    const ch = document.getElementById('egChips');
    if (ch && g.chips) {
      ch.innerHTML = g.chips.map((c) => `<div class="eg-chip">
        <div class="hd">
          <span class="gen">${esc(c.gen || '')}</span>
          <span class="tag ${esc(c.tone || '')}">${esc(c.tier || '')}</span>
        </div>
        <div class="soc">${esc(c.soc || '')}</div>
        <div class="drv">
          <div class="ln">推荐驱动 <b>${esc(c.driver || '—')}</b></div>
          ${c.alt ? `<div class="ln alt">备选 <b>${esc(c.alt)}</b></div>` : ''}
          ${c.build ? `<div class="ln">构建 <b>${esc(c.build)}</b></div>` : ''}
        </div>
        ${c.note ? `<div class="nt">${esc(c.note)}</div>` : ''}
      </div>`).join('');
    }

    /* ③⑥⑦ 两列表 —— CSS: .eg-tbl.w2c（带表头，可扫读） */
    const tbl = (id, arr, k1, k2) => {
      const el = document.getElementById(id);
      if (!el || !arr) return;
      el.innerHTML =
        `<div class="tr hd"><div class="c1">${k1}</div><div class="c3">${k2}</div></div>` +
        arr.map((x) => `<div class="tr">
          <div class="c1">${esc(x.name || '')}</div>
          <div class="c3">${esc(x.desc || '')}</div>
        </div>`).join('');
    };
    tbl('egWrap', g.wrappers, 'DirectX 版本', '用哪个包装器 · 要注意什么');
    tbl('egVer', g.versions, '组件', '当前该用的版本 · 怎么选');
    tbl('egBench', g.bench, '游戏', '实测表现 · 条件');

    /* ④ 优化清单 —— CSS: .eg-tune（ol + CSS counter 自动编号） */
    const tn = document.getElementById('egTune');
    if (tn && g.tuning) {
      tn.innerHTML = g.tuning.map((x) => `<li>
        <b>${esc(x.name || '')}</b><span>${esc(x.desc || '')}</span>
      </li>`).join('');
    }

    /* ⑤ 避坑 —— CSS: .eg-avoid(grid) > .eg-av(.nm/.wy) */
    const av = document.getElementById('egAvoid');
    if (av && g.avoid) {
      av.innerHTML = g.avoid.map((x) => `<div class="eg-av">
        <div class="nm">${esc(x.name || '')}</div>
        <div class="wy">${esc(x.desc || '')}</div>
      </div>`).join('');
    }

    const s = document.getElementById('egSrc');
    if (s) s.textContent = '经验参考 · 非官方';

    egBindNav();
  } catch (e) {}
}

/* 模块导航：点击跳转 + 滚动联动高亮（scroll spy）。
   ★ v10.19 实拍踩到的坑：最初用 IntersectionObserver 做 spy，**点击后高亮不跟随**。
     rootMargin 的收缩语义 + 回调只给「状态变化的元素」，导致滚到第 5 节时
     第 4 节仍是负 top、判定与直觉不一致，调试成本高。
     改成 rAF 节流的 scroll spy：判据只有一条 ——「最后一个 top 已越过吸顶导航下沿的模块」，
     直观、可断言、不依赖 IO 的边界语义。scroll 回调里只置一个 rAF 标记，不掉帧。 */
function egBindNav() {
  const nav = document.getElementById('egNav');
  if (!nav || nav.dataset.bound) return;
  nav.dataset.bound = '1';
  const links = [].slice.call(nav.querySelectorAll('a'));
  const pairs = links
    .map((a) => ({ a, el: document.querySelector(a.getAttribute('href')) }))
    .filter((p) => p.el);
  if (!pairs.length) return;

  let cur = null;
  const paint = (el) => {
    if (cur === el) return;
    cur = el;
    pairs.forEach((p) => p.a.classList.toggle('on', p.el === el));
  };

  links.forEach((a) => a.addEventListener('click', (ev) => {
    ev.preventDefault();
    const p = pairs.find((x) => x.a === a);
    if (!p) return;
    paint(p.el);
    /* ★ 自己算目标位置再 scrollTo，不用 scrollIntoView。
       实拍踩到：`scrollIntoView({behavior:'smooth'})` 在 headless 下出现
       「高亮切了、页面纹丝不动（scrollY 0 → 0）」的静默失效。
       偏移量取元素自身的 scroll-margin-top（CSS 里已按 --topbar-h 算好），
       保证落点不被顶栏 + 模块导航遮住。 */
    const off = parseFloat(getComputedStyle(p.el).scrollMarginTop) || 0;
    const y = Math.max(0, p.el.getBoundingClientRect().top + window.pageYOffset - off);
    try { window.scrollTo({ top: y, behavior: 'smooth' }); }
    catch (e) { window.scrollTo(0, y); }
  }));

  /* 基准取**导航条自身的下沿**（它是 sticky，吸顶后 bottom 就是可视下沿）+ 8px 容差。
     不硬编码顶栏高度 —— 桌面 60px / 窄屏 54px（CSS 变量 --topbar-h）会变。 */
  let raf = 0;
  const spy = () => {
    raf = 0;
    /* ⚠️ 容差必须 > 0 且留够余量（实拍抓到的边界 bug）：
       点击导航后模块**正好停在 scroll-margin-top = --topbar-h + 62 = 122px** 处，
       而 nav 吸顶后下沿 = 61 + 53 = 114，114 + 8 = 122 —— 两者恰好相等，
       浮点误差让 `top <= line` 判成 false，高亮就抖回上一节（停在 #egS4）。
       留 16px 余量后落点稳定命中本节，同时离下一节（约 465px）还远，不会提前点亮。 */
    const line = nav.getBoundingClientRect().bottom + 16;
    let best = pairs[0].el;
    for (const p of pairs) if (p.el.getBoundingClientRect().top <= line) best = p.el;
    paint(best);
  };
  window.addEventListener('scroll', () => { if (!raf) raf = requestAnimationFrame(spy); }, { passive: true });
  spy();
}

/* ================= ④ 机型兼容查询 =================
 * 「选品牌 + 型号 → 能跑哪些 PC 游戏」。
 * 数据：/api/device/brands、/api/device/models、/api/device/match、/api/device/turnip
 * 判定：机型 → GPU → 性能档；游戏被「性能 ≤ 用户档」的 GPU 跑过即算可跑（向下兼容）。
 */
const dmState = {
  inited: false,
  brand: '',
  model: '',
  gpu: '',
  score: null,
  list: [],
  total: 0,
  summary: null,
  verdict: '',     // '' | smooth | ok | maybe
  q: '',
  offset: 0,
};

/* ★ v10.24：档位徽标必须复用手机专区那套 `.pill.fps.*`。
   从前写的是 `cls: 'ok' | 'mid' | 'low'` ⇒ 拼出 `class="pill ok"` / `pill mid` / `pill low`，
   而共享 CSS 里只有 `.pill.fps.smooth|ok|low|bad` —— 三个类**一个都不存在**
   ⇒ 「流畅 / 可玩 / 勉强」是最重要的信号，却全是灰底默认色（和旁边没有颜色的 pill 长得一样）。
   这类「类名拼错→静默无样式」不报错、测试也只断言类名在不在，只能靠对着共享 CSS 核。 */
const DM_TIER = {
  smooth: { txt: '流畅', cls: 'fps smooth' },
  ok: { txt: '可玩', cls: 'fps ok' },
  maybe: { txt: '勉强', cls: 'fps low' },
};

function dmFmtScore(s) {
  return s == null ? '—' : Math.round(s);
}

/** 机型卡片
 *  ★ v10.24：正文与手机专区**同构**的五块 —— `.cov` / `.bd > h4` / `.meta > .pill` / `.tgs > .tg`。
 *  从前「最低参考」单起一行 `.dm-need`，而那行是手机专区没有的第六块 ⇒ 骨架不一致。
 *  现在折算成 `.tgs` 里的一枚 `.tg`，与手机专区的「最低 Mali-G52 MC2」同位同款。
 *
 *  无封面时用 `.cov.ph`（同尺寸占位块，缩写走共用的 covAbbr），**不用**手机专区的
 *  `.cov.noimg`（把封面区收起）：手机专区能 100% 有图是因为它按「有库内条目」过滤过，
 *  本专区不能过滤（那会把真正能跑、只是库里没收录的冷门游戏藏掉，实测约占 48%）。
 */
function dmCard(g) {
  const t = DM_TIER[g.verdict] || { txt: '—', cls: '' };
  const cov = g.libCover
    ? `<div class="cov"><img src="${esc(g.libCover)}" alt="" loading="lazy" referrerpolicy="no-referrer" onerror="covErr(this,'${esc(covAbbr(g.name))}')"></div>`
    : `<div class="cov ph"><span>${esc(covAbbr(g.name))}</span></div>`;
  return `<article class="emu-card${g.libCover ? ' has-cov' : ''}" data-k="${esc(g.k)}" data-p="${esc(g.name || '')}">
    ${cov}
    <div class="bd">
      <h4 title="${esc(g.name || '')}">${esc(g.name || g.k || '')}</h4>
      <div class="meta">
        <span class="pill ${t.cls}">${t.txt}</span>
        <span class="pill">${g.configs || 0} 套配置</span>
        ${g.devices ? `<span class="pill">${g.devices} 机型</span>` : ''}
      </div>
      <div class="tgs"><span class="tg" title="这款游戏被跑通过的最弱 GPU —— 比它强的机型都能跑">最低 <code>${esc(g.minGpu || '—')}</code></span></div>
    </div>
  </article>`;
}

/** 渲染结果网格（支持分页） */
function dmRender() {
  const box = document.getElementById('dmGrid');
  if (!box) return;
  let list = dmState.list;
  if (dmState.verdict) list = list.filter((g) => g.verdict === dmState.verdict);
  if (dmState.q) {
    const k = dmState.q.toLowerCase();
    list = list.filter((g) => String(g.name || '').toLowerCase().includes(k));
  }
  dmState.filtered = list;
  const page = list.slice(dmState.offset, dmState.offset + EMU_PAGE_SIZE);
  box.innerHTML = page.length
    ? page.map(dmCard).join('')
    : '<p class="dm-empty">没有符合条件的游戏。</p>';

  const cnt = document.getElementById('dmCount');
  if (cnt) cnt.textContent = `共 ${list.length} 款`;

  const more = document.getElementById('dmMore');
  if (more) more.style.display = list.length > dmState.offset + EMU_PAGE_SIZE ? '' : 'none';
}

/** 执行一次匹配查询 */
async function dmQuery(model) {
  if (!model) return;
  dmState.model = model;
  dmState.offset = 0;
  const grid = document.getElementById('dmGrid');
  if (grid) grid.innerHTML = '<p class="dm-empty">匹配中…</p>';
  try {
    const r = await fetch(api('/api/device/match?limit=1000&model=' + encodeURIComponent(model))).then((x) => x.json());
    if (!r.ok) {
      const msg = r.error === 'notfound' ? '未找到该机型，试试下拉列表里的写法。'
        : r.error === 'nogpu' ? '这台机型在库里还没记录到 GPU 信息。' : '查询失败。';
      if (grid) grid.innerHTML = `<p class="dm-empty">${msg}</p>`;
      return;
    }
    dmState.gpu = r.device.gpu;
    dmState.score = r.device.score;
    dmState.list = r.games || [];
    dmState.total = r.total;
    dmState.summary = r.summary;
    dmState.filtered = dmState.list;

    // 结果区从隐藏 → 显示
    /* ★ dmResultSec 的隐藏是**内联** style="display:none"，置空即可；
       dmInfo 的隐藏却写在 CSS 规则里（.dm-info 的默认 display 就是 none），
       置空只是删掉内联样式、CSS 照样赢 → 机型卡永远不显示。
       必须显式给一个非 none 的值。（截图体检才发现的）
       注：注释里不要写「选择器 + 花括号」的完整形式，否则会被
       test-emulator-page 的「裸 CSS 文本」断言误判为 CSS 泄漏。 */
    const sec = document.getElementById('dmResultSec');
    if (sec) sec.style.display = '';

    const info = document.getElementById('dmInfo');
    if (info) {
      info.style.display = 'block';   // 不能用 ''：.dm-info 的 CSS 默认就是 display:none
      /* ★ v10.11/v10.12 机型「转译」：把 `SM S938B` / `Xiaomi 24115RA8EG` 这类内部代号，
         翻成人看得懂的 GPU → SoC → CPU 三级。
           · GPU：来自 bannerhub-files.json 的**逐条配对**（机型与 GPU 本来就成对，覆盖 95.6%）
           · SoC：由 data/gpu-soc.json 的 GPU→SoC 表反查（覆盖 92.9% 记录）
           · CPU：data/soc-cpu.json（tools/fetch-soc-cpu.js 从 nanoreview 抓的核簇描述，
                  343 条 = 246 市场名 + 97 芯片编号别名），覆盖 92.4% 机型；
                  device-board.json 只作兜底（它只有 200 条主板，且实测有脏值）
         旧实现的 GPU 是 `gps[0]`（该游戏第一个 GPU），与本机型无关，配错很多。 */
      const dv = r.device || {};
      const socTxt = dv.soc ? (dv.socVendor ? dv.socVendor + ' ' + dv.soc : dv.soc) : '';
      /* ★ v10.16：抬头优先显示译出的「品牌 + 型号」；内部代号退到小字（对得上原输入）。
         译不出（disp 为空）就照旧显示 model，不编造。 */
      info.innerHTML = `
        <div class="dm-info-h">
          <b>${esc(dv.disp || dv.model)}</b>
          <span class="dm-brand">${esc(dv.brand || '')}</span>
          ${dv.disp && dv.disp !== dv.model ? `<span class="dm-code">${esc(dv.model)}</span>` : ''}
        </div>
        <div class="dm-info-r">
          ${socTxt
            ? `<span>芯片 <b>${esc(socTxt)}</b></span>`
            : '<span class="dm-nosoc">芯片 未收录</span>'}
          <span>GPU <code>${esc(dv.gpu || '未知')}</code></span>
          <span>性能档 <b>${dmFmtScore(dv.score)}</b></span>
        </div>
        ${dv.cpu ? `<div class="dm-info-cpu"><i>CPU</i><code>${esc(dv.cpu)}</code></div>` : ''}
        <div class="dm-sum">
          <span class="pill ok">流畅 ${r.summary.smooth}</span>
          <span class="pill mid">可玩 ${r.summary.ok}</span>
          <span class="pill low">勉强 ${r.summary.maybe}</span>
          <span class="pill dim">合计 ${r.total}</span>
        </div>`;
    }
    dmRender();
    dmLoadTurnip();
  } catch (e) {
    if (grid) grid.innerHTML = '<p class="dm-empty">网络错误，请稍后重试。</p>';
  }
}

/** 加载 Turnip 驱动看板（顺带展示，不阻塞主查询） */
async function dmLoadTurnip() {
  const box = document.getElementById('dmTurnip');
  if (!box || box.dataset.done) return;
  box.dataset.done = '1';
  try {
    const t = await fetch(api('/api/device/turnip')).then((r) => r.json());
    if (!t.ok) throw 0;
    const L = t.latest || {};
    box.innerHTML = `
      <div class="dm-tp-h"><b>Turnip 驱动最新构建</b><span class="dm-tp-a">${esc(L.buildDate || '')}</span></div>
      <div class="dm-tp-r">
        <span>Mesa <code>${esc(L.mesa || '—')}</code></span>
        <span>Vulkan <code>${esc(L.vulkan || '—')}</code></span>
      </div>
      <div class="dm-tp-v">
        ${(t.variants || []).map((v) => `<div class="dm-var">
          <b>${esc(v.name)}</b>
          <span class="dm-var-g">${esc(v.gpus)}</span>
          ${v.note ? `<span class="dm-var-n">${esc(v.note)}</span>` : ''}
        </div>`).join('')}
      </div>
      <a class="dm-tp-link" href="${esc(t.site || '#')}" target="_blank" rel="noopener">前往下载 ↓</a>`;
  } catch (e) {
    box.innerHTML = '';
  }
}

/** 初始化机型查询分区 */
async function initDm() {
  dmLoadTurnip();
  if (dmState.inited) return;
  dmState.inited = true;

  // 品牌下拉
  try {
    const b = await fetch(api('/api/device/brands')).then((r) => r.json());
    const sel = document.getElementById('dmBrand');
    if (sel && b.ok) {
      sel.innerHTML = '<option value="">选择品牌…</option>' +
        b.brands.map((x) => `<option value="${esc(x.name)}">${esc(x.name)}（${x.n}）</option>`).join('');
    }
  } catch (e) {}

  // 型号搜索建议（输入即查）
  const inp = document.getElementById('dmInput');
  const box = document.getElementById('dmSug');
  if (inp) {
    let timer = null;
    inp.addEventListener('input', () => {
      clearTimeout(timer);
      const q = inp.value.trim();
      if (q.length < 1) { if (box) box.style.display = 'none'; return; }
      timer = setTimeout(async () => {
        try {
          const r = await fetch(api('/api/device/models?limit=12&q=' + encodeURIComponent(q))).then((x) => x.json());
          if (!r.ok || !r.models.length) { if (box) box.style.display = 'none'; return; }
          /* ★ v10.16：与下面「品牌切换」那段**必须同款**——两处都是机型建议列表。
             这里原先漏了 `disp`，于是「输入即查」铺出来的还是内部代号（`Xiaomi 2412DPC0AG`），
             同一个下拉两副面孔。改动时两处一起改。 */
          box.innerHTML = r.models.map((m) => {
            const title = m.disp || m.model;
            const sub = (m.disp && m.disp !== m.model ? m.model + ' · ' : '') + m.brand;
            return `<button type="button" class="dm-sug-i" data-m="${esc(m.model)}">
              <b>${esc(title)}</b>
              <span>${esc(sub)}${m.gpu ? ' · ' + esc(m.gpu) : ''}</span>
            </button>`;
          }).join('');
          box.style.display = '';
          box.querySelectorAll('[data-m]').forEach((el) => {
            el.addEventListener('click', () => {
              inp.value = el.dataset.m;
              box.style.display = 'none';
              dmQuery(el.dataset.m);
            });
          });
        } catch (e) {}
      }, 180);
    });
    inp.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { if (box) box.style.display = 'none'; dmQuery(inp.value.trim()); }
    });
    document.addEventListener('click', (e) => {
      if (box && !box.contains(e.target) && e.target !== inp) box.style.display = 'none';
    });
  }

  // 查询按钮
  const go = document.getElementById('dmGo');
  if (go) {
    go.addEventListener('click', () => {
      const v = inp ? inp.value.trim() : '';
      if (!v) { if (inp) inp.focus(); return; }
      if (box) box.style.display = 'none';
      dmQuery(v);
    });
  }

  // 品牌切换 → 列出该品牌机型
  const brand = document.getElementById('dmBrand');
  if (brand) {
    brand.addEventListener('change', async () => {
      const bv = brand.value;
      if (!bv) return;
      try {
        const r = await fetch(api('/api/device/models?limit=200&brand=' + encodeURIComponent(bv))).then((x) => x.json());
        if (!r.ok) return;
        if (box) {
          /* ★ v10.16：`m.model` 常是内部代号（`Xiaomi 2412DPC0AG`），列表里直接铺出来认不出是哪台手机。
             服务端顺带返回 `disp`（品牌 + 型号），有就显示它；回填与查询仍用 `m.model`。 */
          box.innerHTML = r.models.map((m) =>
            `<button type="button" class="dm-sug-i" data-m="${esc(m.model)}">
              <b>${esc(m.disp || m.model)}</b>
              <span>${m.gpu ? esc(m.gpu) : ''}${m.games ? ' · ' + m.games + ' 款可玩' : ''}</span>
            </button>`).join('');
          box.style.display = '';
          box.querySelectorAll('[data-m]').forEach((el) => {
            el.addEventListener('click', () => {
              if (inp) inp.value = el.dataset.m;
              box.style.display = 'none';
              dmQuery(el.dataset.m);
            });
          });
        }
      } catch (e) {}
    });
  }

  // 档位筛选
  document.querySelectorAll('[data-dmv]').forEach((el) => {
    el.addEventListener('click', () => {
      document.querySelectorAll('[data-dmv]').forEach((x) => x.classList.remove('on'));
      el.classList.add('on');
      dmState.verdict = el.dataset.dmv;
      dmState.offset = 0;
      dmRender();
    });
  });

  // 结果内搜索
  const s = document.getElementById('dmSearch');
  if (s) {
    s.addEventListener('input', () => {
      dmState.q = s.value.trim();
      dmState.offset = 0;
      dmRender();
    });
  }

  // 加载更多
  const more = document.getElementById('dmMore');
  if (more) {
    more.addEventListener('click', () => {
      dmState.offset += EMU_PAGE_SIZE;
      const list = dmState.filtered || dmState.list;
      const page = list.slice(dmState.offset, dmState.offset + EMU_PAGE_SIZE);
      const g = document.getElementById('dmGrid');
      if (g) g.insertAdjacentHTML('beforeend', page.map(dmCard).join(''));
      if (list.length <= dmState.offset + EMU_PAGE_SIZE) more.style.display = 'none';
    });
  }
}

/* ================= ⑤ 两个配置面板（抽屉内） =================
 * 卡片本体点击 → 打开配置面板（而非游戏详情）。
 * 面板复用全局 #drawer / #drawerBody / lockBody / closeDetail，
 * 通过 drawerMode='bh' | 'pc' 让 closeDetail 知道「关掉即回页面」。
 */
function panelShell(title, sub, body) {
  return `<div class="cf-head">
      ${closeBtnHtml()}
      <h3>${esc(title)}</h3>
      <div class="cf-sub">${sub}</div>
    </div>
    <div class="cf-body">${body}</div>`;
}

/* ---- 社区配置面板（BannerHub）：机型 / GPU / 日期 / 配置直链 ----
 *  ★ v10.13：新增「逐条游玩参数」区（驱动 / DXVK / 容器 / 翻译层 / 分辨率…）。
 *    原先面板只有一张 [机型 | GPU | 日期 | 下载 JSON] 表 —— 用户要抄的**参数**全在
 *    那份 JSON 里，必须点下载才知道内容。现在服务端解析后直接铺出来，
 *    完整清单（最多 200 条文件名）仍保留在下面，供精确下载。
 */
async function openBhPanel(k, p) {
  if (!k) return;
  drawerMode = 'bh';
  $('#drawer').classList.add('show'); $('#mask').classList.add('show');
  lockBody();
  $('#drawerBody').innerHTML = panelShell(p || k, '正在读取社区配置…', '<div class="cf-loading">加载中…</div>');
  try {
    const [cj, pj] = await Promise.all([
      fetch(api('/api/bh/configs?k=' + encodeURIComponent(k))).then((r) => r.json()),
      fetch(api('/api/bh/params?k=' + encodeURIComponent(k) + '&limit=6')).then((r) => r.json()).catch(() => null),
    ]);
    const j = cj;
    if (!j.ok) throw new Error(j.error || '读取失败');
    const g = j.game || {};
    const items = j.items || [];
    const gpus = [...new Set(items.map((x) => x.gpu).filter(Boolean))];
    const phones = [...new Set(items.map((x) => x.phone).filter(Boolean))];
    const params = (pj && pj.items) || [];
    const rows = items.map((x) => `<tr>
        <td>${esc(x.phone || '—')}</td>
        <td><span class="tg">${esc(x.gpu || '—')}</span></td>
        <td>${esc(x.date || '—')}</td>
        <td><a class="cf-dl" href="${esc(x.url)}" target="_blank" rel="noopener">下载 JSON</a></td>
      </tr>`).join('');
    const paramHtml = params.length
      ? `<div class="cf-sec-t">逐条游玩参数<span class="n">最近 ${params.length} 份</span></div>
         <div class="cf-params">${params.map(cfParamCard).join('')}</div>`
      : `<div class="cf-note">这款暂无可解析的逐条参数（配置文件尚未收录或读取失败），可按下表下载原始 JSON 查看。</div>`;
    $('#drawerBody').innerHTML = panelShell(p || k, '', `
      <div class="cf-stats">
        <div class="st"><b>${items.length}</b><span>份配置</span></div>
        <div class="st"><b>${gpus.length}</b><span>种 GPU</span></div>
        <div class="st"><b>${phones.length}</b><span>款机型</span></div>
      </div>
      <div class="cf-note">数据来自 <b>BannerHub</b> 社区共享仓库（GitHub）。配置为玩家手动导出，
        跑通与否取决于机型与驱动版本；建议先看下面的逐条参数，挑与自己机型最接近的那份照搬。</div>
      ${paramHtml}
      <div class="cf-sec-t">全部配置清单<span class="n">${items.length} 条</span></div>
      <div class="cf-scroll"><table class="cf-table">
        <thead><tr><th>机型</th><th>GPU</th><th>上传日期</th><th>配置</th></tr></thead>
        <tbody>${rows || '<tr><td colspan="4">暂无逐条配置</td></tr>'}</tbody>
      </table></div>
      <div class="cf-foot"><a class="cf-btn" href="${esc(j.repo || '#')}" target="_blank" rel="noopener">在 GitHub 查看仓库 →</a></div>
    `);
  } catch (e) {
    $('#drawerBody').innerHTML = panelShell(p || k, '', '<div class="cf-empty">读取失败，请稍后重试</div>');
  }
}

/** 一条逐条参数 → 面板内的卡片（与详情抽屉里的芯片行同一份信息，版式更宽） */
function cfParamCard(p) {
  const chips = [];
  const add = (label, val, cls) => { if (val) chips.push(`<span class="kv ${cls || ''}"><b>${esc(label)}</b>${esc(String(val))}</span>`); };
  add('驱动', p.driver, 'hot');
  add('DXVK', p.dxvk, 'hot');
  add('VKD3D', p.vkd3d);
  add('容器', p.container);
  add('翻译层', p.translator, 'ok');
  add('分辨率', p.resolution);
  add('内存', p.maxMem);
  add('核心', p.cores);
  add('FEX', p.fexBuild);
  if (p.vibration) add('振动', '开');
  (p.translatorFlags || []).slice(0, 4).forEach((f) => add('', f));
  /* ★ v10.14：机型代号 → 芯片规格（与详情抽屉同源，都由 /api/bh/params 的 spec 提供） */
  const sp = p.spec;
  const specRow = (sp && (sp.soc || sp.gpu))
    ? `<div class="spec">
        ${sp.soc ? `<span class="sp soc"><b>${sp.approx ? '≈' : ''}${esc(sp.soc)}</b></span>` : ''}
        ${sp.brand ? `<span class="sp">${esc(sp.brand)}</span>` : ''}
        ${sp.cpu ? `<span class="sp cpu">${esc(sp.cpu)}</span>` : ''}
        ${sp.score ? `<span class="sp">性能分 <b>${esc(String(Math.round(sp.score)))}</b></span>` : ''}
      </div>`
    : '';
  return `<div class="cf-param">
    <div class="hd"><b>${esc(p.device || '未知机型')}</b><span class="gp">${esc(p.gpu || '')}</span>
      <span class="dt">${esc(p.date || '')}${p.ver ? ' · BH ' + esc(p.ver) : ''}</span>
      ${p.url ? `<a class="dl" href="${esc(p.url)}" target="_blank" rel="noopener">原始 JSON</a>` : ''}</div>
    ${specRow}
    <div class="kvs">${chips.join('') || '<span class="kv">该份配置未记录可解析参数</span>'}</div>
  </div>`;
}

/* ---- 实测配置面板（本项目自建）：逐条机型 / 兼容层 / 驱动 / 帧率 / 备注 ---- */
async function openPcPanel(title) {
  if (!title) return;
  drawerMode = 'pc';
  $('#drawer').classList.add('show'); $('#mask').classList.add('show');
  lockBody();
  $('#drawerBody').innerHTML = panelShell(title, '正在读取实测记录…', '<div class="cf-loading">加载中…</div>');
  try {
    const j = await fetch(api('/api/pc/records?k=' + encodeURIComponent(title))).then((r) => r.json());
    if (!j.ok) throw new Error(j.error || '读取失败');
    const cm = j.chipMap || {};
    const items = j.items || [];
    const lib = j.lib;
    const rows = items.map((x) => `<div class="cf-rec ${x.ok ? 'ok' : 'no'}">
        <div class="cf-rec-h">
          <span class="pill ${x.ok ? 'ok' : 't-bad'}">${x.ok ? '可玩' : '不可玩'}</span>
          <b>${esc(cm[x.chip] || x.chipName || x.chip || '—')}</b>
          <span class="pill t-mid">${esc(x.fpsTier || '—')} ${esc(x.fpsLabel || '')}</span>
        </div>
        <div class="cf-kv">
          <div><i>兼容层</i><code>${esc(x.layer || '—')}</code></div>
          <div><i>运行模式</i><code>${esc(x.mode || '—')}</code></div>
          <div><i>驱动 GPU</i><code>${esc(x.gpu || '—')}</code></div>
          <div><i>DXVK</i><code>${esc(x.dxvk || '—')}</code></div>
          ${x.vkd3d ? `<div><i>vkd3d</i><code>${esc(x.vkd3d)}</code></div>` : ''}
          <div><i>运行库</i><code>${esc(x.runtime || '—')}</code></div>
          ${x.exe ? `<div><i>主程序</i><code>${esc(x.exe)}</code></div>` : ''}
        </div>
        ${x.note ? `<div class="cf-note-inline">💡 ${esc(x.note)}</div>` : ''}
      </div>`).join('');
    $('#drawerBody').innerHTML = panelShell(title, '', `
      ${lib ? `<div class="cf-lib"><img src="${esc(lib.cover)}" alt="" referrerpolicy="no-referrer" loading="lazy">
        <div class="cf-lib-tx"><b>${esc(lib.title || '')}</b>
        <button class="cf-btn" onclick="closeDetail();openDetailById('${esc(lib.id)}','${esc(lib.title || '')}')" type="button">查看游戏详情</button></div></div>` : ''}
      <div class="cf-stats">
        <div class="st"><b>${items.length}</b><span>条实测</span></div>
        <div class="st"><b>${items.filter((x) => x.ok).length}</b><span>可玩</span></div>
        <div class="st"><b>${[...new Set(items.map((x) => x.chip))].length}</b><span>款机型</span></div>
      </div>
      <div class="cf-scroll">${rows || '<div class="cf-empty">暂无实测记录</div>'}</div>
    `);
  } catch (e) {
    $('#drawerBody').innerHTML = panelShell(title, '', '<div class="cf-empty">读取失败，请稍后重试</div>');
  }
}


/* ================= 📱 手机专区 · 子页签（独立页） =================
   v9.1 改版：**只有一条切换条**，4 个平级页签 —— 不再有"二级切换条"。
     手游中心(#emulator) / 模拟器指南(#emuguide) / 机型兼容(#devmatch)

   为什么去掉二级：v9.0 的「3 主页签 + 1 二级条」在非"兼容·指南"页签上
   仍常驻显示那条二级条，点它却什么也看不到（目标分区还是 et-hide）——
   看起来能点其实没反应。现在四个页面平级，点哪个切哪个，所见即所得。

   ★ v9.3：原「手游可玩(#emulator)」与「实测配置(#phonecfg)」**合并为「手游中心」**，
          实测库视角并入合并索引（见 SECTIONS 注释）。页签由 4 个减为 3 个，
          #pc 路由保留为**兼容别名**（旧链接 #pc 会落到 #emu，不会白屏）。

   ★ v10.44：**修改器(#trainers) / 云存档(#saves) 迁出**到独立页 /resources.html，
            本页回到 **3 个平级页签**：手游中心 / 机型兼容 / 模拟器指南。

   URL hash 同步：/emulator.html#emu / #dm / #eg（#pc 归一为 #emu）
*/
const ET_MAP = { emu: '#emulator', dm: '#devmatch', eg: '#emuguide' };
let etCur = 'emu';

/* ★ v10.2 修的孤儿调用：主脚本（两页共用）里底部 Tab 的 emu/pc/eg 分支会调 goEmuPage()，
   但那个函数定义在「独立页跳转块」里，派生页把整块换掉了 —— 于是这里只剩调用点，
   每点一次底部「手机专区」就抛一次 ReferenceError（页面勉强还能用，控制台一直报）。
   本页已经在专区里，正确语义是**切页签**而不是再跳一次。 */
function goEmuPage(t) { switchEmuTab(t === 'pc' ? 'emu' : t); }

/** 各分区懒加载入口（在 initXxx 声明之后调用，避免 TDZ） */
function etInit(t) {
  if (t === 'emu') return initEmu();
  if (t === 'eg') return initEg();
  if (t === 'dm') return initDm();
}

function switchEmuTab(t, opts) {
  if (!ET_MAP[t]) return;
  etCur = t;
  /* 四个分区平级：只留目标那个可见 */
  for (const [k, sel] of Object.entries(ET_MAP)) {
    const el = document.querySelector(sel);
    if (el) el.classList.toggle('et-hide', k !== t);
  }
  document.querySelectorAll('#emuTabs .emu-tab').forEach((b) => b.classList.toggle('on', b.dataset.et === t));
  /* 懒加载：首次切到才拉数据（各 init 内部有 inited 标记，重复切不会重复请求） */
  try { etInit(t); } catch (e) {}
  if (opts && opts.scroll !== false) window.scrollTo({ top: 0, behavior: 'smooth' });
}
/* 顶栏「手机专区」入口：本页已在专区，改为切「手游中心」 */
(function bindNavEmu() {
  const el = document.getElementById('navEmu'); if (!el) return;
  el.setAttribute('href', '#emu');
  el.addEventListener('click', (e) => { e.preventDefault(); switchEmuTab('emu'); });
})();
/** 子页签数字回填（手游中心合并游戏数 / 机型库条目数） */
async function fillTabNums() {
  const set = (id, v) => { const el = document.getElementById(id); if (el && v != null) el.textContent = Number(v).toLocaleString(); };
  try { const s = await fetch(api('/api/mobilehub/stats')).then((r) => r.json()); if (s && s.total != null) set('tabNumEmu', s.total); } catch (e) {}
  try { const s = await fetch(api('/api/device/stats')).then((r) => r.json()); if (s && s.devices != null) set('tabNumDm', s.devices); } catch (e) {}
}
/* 底部 Tab 同款处理（底部「手机专区」直接落 手游中心） */
const tb = document.getElementById('tabbar');
if (tb) tb.addEventListener('click', (e) => {
  const a = e.target.closest('a[data-tab]'); if (!a) return;
  const t = a.dataset.tab;
  if (t === 'emu') { e.preventDefault(); switchEmuTab('emu'); }
  else if (ET_MAP[t]) { e.preventDefault(); switchEmuTab(t); }
});
/* 切换条点击 */
document.getElementById('emuTabs').addEventListener('click', (e) => {
  const b = e.target.closest('.emu-tab'); if (!b) return;
  switchEmuTab(b.dataset.et);
});
/* 首屏：按 hash 决定进哪个页签，默认手游中心
 * ★ v9.3：#pc 是旧链接的兼容别名，归一为 #emu（老书签不会白屏） */
(function bootTab() {
  let t = location.hash.slice(1);
  if (t === 'pc') t = 'emu';
  switchEmuTab(ET_MAP[t] ? t : 'emu', { scroll: false });
  fillTabNums();
})();

/* ================= 详情抽屉 ================= */
let drawerMode = 'game';   // 'game'=游戏详情 | 'bh'=BannerHub 社区配置面板 | 'pc'=实测配置面板
/* 关闭详情抽屉（✕ / 遮罩 / Esc 共用）—— 原先缺失导致关闭报错且滚动被锁 */
function closeDetail() {
  const d = $('#drawer');
  if (!d.classList.contains('show')) return;
  d.classList.remove('show');
  $('#mask').classList.remove('show');
  const rail = $('#dRail'); if (rail) rail.hidden = true;   // ★ v10.25 定位条随详情页收起
  $$('.on-drawer').forEach(x => x.classList.remove('on-drawer'));
  if (drawerMode !== 'game') { drawerMode = 'game'; unlockBody(); return; }  // 配置面板：关掉即回页面
  if (detailFromSearch) restoreSearch(); // 从搜索进入 → 原样回到搜索结果
  else unlockBody();
}
/* 详情抽屉关闭键：来自搜索时显示「← 返回搜索」，否则显示「✕ 关闭」 */
function closeBtnHtml() {
  return detailFromSearch
    ? `<button class="d-close d-back" onclick="closeDetail()" title="返回搜索结果"><span class="ar">←</span>返回搜索</button>`
    : `<button class="d-close" onclick="closeDetail()" title="关闭 (Esc)">✕</button>`;
}
/* 从手机两库（社区配置 / 实测配置）的卡片直达游戏详情。
   卡片只持有匹配到的本地库 id → 先按 id 取本地库条目，再走统一详情链路。
   fb 兜底数据一次性给全（title/cover/score/size/genres/dateLabel），
   这样源站抓取慢或失败时抽屉里也有完整信息，不会白屏。 */
async function openDetailById(id, fallbackTitle) {
  if (!id) return;
  let it = null;
  try {
    const j = await fetch(api('/api/library/item?id=' + encodeURIComponent(id))).then(r => r.json());
    if (j && j.ok) it = j.item;
  } catch (e) { /* 取不到就用本地卡片已有的标题兜底 */ }
  if (!it) { toast('本地库未收录该游戏'); return; }
  const fb = {
    id: it.id || '',
    title: it.title || fallbackTitle || '',
    cover: it.cover || '',
    score: it.score || '',
    size: it.size || '',
    genres: it.genres || [],
    dateLabel: it.dateLabel || '',
    jidiUrl: it.jidiUrl || '',    /* v10.22：手机专区卡片直达详情后，下载弹窗也能取双源 */
  };
  openDetail(it.url, encodeURIComponent(JSON.stringify(fb)), false);
}

function openDetail(url, fbEnc, fromSearch) {
  if (!url) return;
  drawerMode = 'game';
  detailFromSearch = !!fromSearch; // 记录来路：true=详情关闭后回到搜索弹窗
  lastDetailUrl = url;
  let fb = {};
  try { fb = JSON.parse(decodeURIComponent(fbEnc || '{}')); } catch (e) {}
  // 高亮当前行卡 + 记录键盘索引
  collectRows();
  const cur = keyRows.find(r => r.dataset.url === url);
  if (cur) { keyIdx = keyRows.indexOf(cur); $$('.on-drawer').forEach(x => x.classList.remove('on-drawer')); cur.classList.add('on-drawer'); }
  rankMark(url); // 热榜同步高亮（若该游戏在榜）
  const body = $('#drawerBody');
  $('#drawer').classList.add('show'); $('#mask').classList.add('show');
  lockBody();
  // 先用库内记录渲染基础信息（秒开），源站详情返回后补全
  const pre = fb.title ? splitName(fb.title) : null;
  const preChip = [fb.size && `容量 ${esc(fb.size)}`, okScoreV(fb.score) && `评分 ${fb.score}`, (fb.genres || []).length && `类型 ${esc(fb.genres.join('/'))}`].filter(Boolean).join(' · ');
  body.innerHTML = `
    ${fb.cover ? `<div class="d-hero"><div class="d-top">${closeBtnHtml()}<span class="src-badge xd" style="color:#fff;background:rgba(11,123,255,.8);align-self:center">XDGAME · 本地库</span></div>
      <img src="${esc(fb.cover)}" onerror="this.remove()"><div class="d-title"><h2>${pre ? esc(pre.zh) : ''}</h2>${pre && pre.en ? `<div class="en">${esc(pre.en)}</div>` : ''}</div></div>` : ''}
    <div class="d-body">
      ${pre ? `<div class="d-hint" style="margin-top:${fb.cover ? '0' : '16px'}"><b>${esc(pre.zh)}</b>${fb.cover ? ' · ' : ''}本地库记录${preChip ? '：' + preChip : '已就绪'} · 正在同步源站最新详情…</div>` : `<div class="d-hint">正在抓取源站详情…</div>`}
      <div class="d-load"><div class="spin"></div></div>
    </div>`;
  /* ★ v10.25：改打 /api/detail/merged —— 它在服务端把「另一源同名条目」的
     **截图去重相加 + 版本介绍 + 游戏介绍**并进同一份 detail，并回一个 `merge` 溯源块。
     为什么不在前端拿两份 detail 自己拼：
       ① 去重口径必须与 fetchers/shots.js 的 idOf 同一份（铁律 10），前端拿不到那个模块；
       ② 前端「先渲染再打补丁」要防「等待期间用户点了下一款游戏」的竞态。
     `merge` 作为**第三个参数**单独传下去，不塞进 fb —— fb 是库内记录，
     混进合并溯源信息后，下次有人读 fb.xxx 会以为那是库字段。 */
  fetch(api('/api/detail/merged?url=' + encodeURIComponent(url)))
    .then(r => r.json())
    .then(j => { if (!j.ok) throw new Error(j.error || '解析失败'); paintDetail(j.detail, fb, j.merge || null); })
    .catch(e => {
      body.innerHTML = `<div class="d-err"><div style="font-size:30px;margin-bottom:10px">⚠️</div><p>详情抓取失败</p><p style="font-size:12px;margin:6px 0 14px">${esc(e.message)}</p><a class="go xd" href="${esc(url)}" target="_blank" rel="noopener">前往源站查看完整详情 ↗</a></div>`;
    });
}
/* ================= 🖼 游戏预览画廊（v10.25） =================
 * 用户口径：「游戏截图应该是（参考站那种）大图 + 左右翻页 + 计数器 + 缩略图条」。
 *
 * ★ 为什么用**事件委托**而不是给每个按钮绑一次：
 *   `paintDetail` 每次打开详情都会整段替换 #drawerBody 的 innerHTML。
 *   逐个 addEventListener 的话，旧节点被回收、新节点根本没绑上 ——
 *   表现为「第一次打开能点、第二次点不动」，而且**不报任何错**。
 *   委托挂在 document 上只绑一次，与节点生命周期彻底解耦。
 *
 * ★ 键盘：只在「灯箱打开时」接管 ←/→。
 *   详情页本来就用 ←/→ 切「上一款 / 下一款游戏」（switchDetail），
 *   无条件下接管会把翻游戏变成翻截图 —— 那是功能退化，不是新功能。
 */
function galGo(root, i) {
  const n = +(root.dataset.n || 0);
  if (!n) return;
  const k = Math.max(0, Math.min(n - 1, i));
  root.dataset.i = String(k);
  const trk = root.querySelector('.gal-trk');
  if (trk) trk.style.transform = 'translateX(' + (-k * 100) + '%)';
  root.querySelectorAll('.gal-sld').forEach((el, j) => el.setAttribute('aria-hidden', j === k ? 'false' : 'true'));
  root.querySelectorAll('.gal-th').forEach((el, j) => el.classList.toggle('is-on', j === k));
  const num = root.querySelector('.gal-num');
  if (num) num.textContent = (k + 1) + ' / ' + n;
  const p = root.querySelector('.gal-nav.prev'), x = root.querySelector('.gal-nav.next');
  if (p) p.disabled = k === 0;
  if (x) x.disabled = k === n - 1;
  const on = root.querySelector('.gal-th.is-on');
  if (on && on.scrollIntoView) on.scrollIntoView({ block: 'nearest', inline: 'nearest' });
  /* ★ 只靠 `loading="lazy"` 不够：slide 是横向位移的，浏览器视口判定不到那几张，
   *   实测 9 张里只有 2 张真加载 ⇒ 用户点「下一张」会先看到一片空白底。
   *   这里把「当前 + 下一张」显式改成 eager（改属性会立刻触发加载）。
   *   ★ 也不能全设 eager：单张大图 573KB，12 张就是 6.9MB，首屏会被拖死。
   *   ⇒ 只预载一张，兼顾「不白屏」与「不拖慢」。 */
  root.querySelectorAll('.gal-sld img').forEach((im, j) => {
    if (j <= k + 1 && im.getAttribute('loading') !== 'eager') im.setAttribute('loading', 'eager');
  });
}

let galLbEl = null;
let galLbImgs = [];
let galLbI = 0;
function galLbPaint() {
  if (!galLbEl) return;
  const im = galLbEl.querySelector('img');
  if (im) im.src = galLbImgs[galLbI] || '';
  const n = galLbEl.querySelector('.n');
  if (n) n.textContent = (galLbI + 1) + ' / ' + galLbImgs.length;
}
function galLbClose() {
  if (galLbEl && galLbEl.parentNode) galLbEl.parentNode.removeChild(galLbEl);
  galLbImgs = [];
}
/* ★ v10.29：灯箱翻页收成一个出口（用户口径「点击大图左右可以切换图片」）。
   ★ 为什么不让 click 与 keydown 各写一遍取模：两处写法的边界处理极易分叉
     （左翻到第 0 张时一个用 `+len` 兜、另一个忘了，就从「最后一张」变成「第 -1 张」）。
     取模前先 `+d+len` 保证被除数非负 —— JS 的 `%` 对负数返回负值，`-1 % 7 === -1`。 */
function galLbStep(d) {
  if (!galLbImgs.length) return;
  galLbI = (galLbI + d + galLbImgs.length) % galLbImgs.length;
  galLbPaint();
}
function galLbOpen(root, i) {
  galLbImgs = Array.prototype.slice.call(root.querySelectorAll('.gal-sld img'))
    .map((im) => im.getAttribute('src')).filter(Boolean);
  if (!galLbImgs.length) return;
  galLbI = Math.max(0, Math.min(galLbImgs.length - 1, i));
  if (!galLbEl) {
    galLbEl = document.createElement('div');
    galLbEl.className = 'gal-lb';
    /* ⚠️ 箭头必须在 `<img>` 前后各一个、且靠 CSS 的 absolute 定位 ——
       它们与 ✕ / 计数 .n 同处一个 flex column 里（见 .gal-lb-nav 的注释）。 */
    galLbEl.innerHTML = '<button type="button" class="gal-lb-x" aria-label="关闭大图">✕</button>'
      + '<button type="button" class="gal-lb-nav prev" data-lb-step="-1" aria-label="上一张">❮</button>'
      + '<img alt="游戏截图">'
      + '<button type="button" class="gal-lb-nav next" data-lb-step="1" aria-label="下一张">❯</button>'
      + '<div class="n"></div>';
  }
  document.body.appendChild(galLbEl);
  /* 只有一张图时左右按钮没有意义 —— 藏掉，别给一个点了不动的控件（同「宁可少一个按钮」的既有口径）。 */
  const multi = galLbImgs.length > 1;
  galLbEl.querySelectorAll('.gal-lb-nav').forEach((b) => { b.hidden = !multi; });
  galLbPaint();
}
document.addEventListener('click', (e) => {
  const go = e.target.closest && e.target.closest('[data-gal-go]');
  if (go) { const r = go.closest('[data-gal]'); if (r) galGo(r, +go.dataset.galGo); return; }
  const st = e.target.closest && e.target.closest('[data-gal-step]');
  if (st) { const r = st.closest('[data-gal]'); if (r) galGo(r, (+r.dataset.i || 0) + (+st.dataset.galStep)); return; }
  if (galLbEl && galLbEl.contains(e.target)) {            // 灯箱内：点箭头翻页、点图翻下一张、点空白/✕ 关闭
    /* ★ v10.28 修：这里原先只判了「点背景」与「点图翻页」，**漏了右上角的 ✕ 按钮** ——
       注释写的是「点空白 / ✕ 关闭」，但点 ✕ 会落进最后一个 return、什么都不做。
       用户视角就是「打开大图后点关闭没反应，只能按 Esc」（实拍确认：点 ✕ 后灯箱仍在）。
       回归判据在 tools/preview-v1028.js：「点 ✕ → 灯箱消失」。 */
    if (e.target === galLbEl || (e.target.closest && e.target.closest('.gal-lb-x'))) { galLbClose(); return; }
    /* ★ v10.29：左右箭头（用户口径「点击大图左右可以切换图片」）。
       ⚠️ 必须排在「点图翻下一张」**之前**：箭头是 `<button>`，若先判 IMG 分支也没关系，
          但它自己不是 IMG；真正要防的是反过来 —— 把 `data-lb-step` 判在最后，
          点「上一张」时会先命中 `tagName === 'IMG'`（button 里没有 img 子节点，所以其实不会），
          留在这里只是为了顺序直观：先处理「明确的翻页意图」，再兜「点图」。 */
    const st = e.target.closest && e.target.closest('[data-lb-step]');
    if (st) { galLbStep(Number(st.dataset.lbStep) || 1); return; }
    if (e.target.tagName === 'IMG') { galLbStep(1); }
    return;
  }
  const im = e.target.closest && e.target.closest('.gal-sld img');
  if (im) {
    const r = im.closest('[data-gal]');
    if (r) galLbOpen(r, +r.dataset.i || 0);
  }
});
document.addEventListener('keydown', (e) => {
  if (!galLbEl || !galLbEl.parentNode) return;            // 只在灯箱打开时接管
  if (e.key === 'Escape') { galLbClose(); e.stopPropagation(); }
  else if (e.key === 'ArrowRight') { galLbStep(1); e.stopPropagation(); }
  else if (e.key === 'ArrowLeft') { galLbStep(-1); e.stopPropagation(); }
}, true);

function paintDetail(d, fb, merge) {
  fb = fb || {};
  merge = merge || null;
  /* ★ v10.25：换一款游戏 → 上一份的「查看全部」载荷全部作废。
     不清空的话，旧 token 会指向**上一款游戏**的源存档路径 / 机型清单，
     点开会串台（而且看起来完全正常，最危险的那种 bug）。 */
  dFullStore = Object.create(null);
  const body = $('#drawerBody');
  // 库内字段兜底：源站解析缺 cover/score/size/genres/dateLabel 时用本地库记录补全
  const okScore = (v) => v != null && v > 0 && v <= 10;
  const score = okScore(d.score) ? d.score : (okScore(fb.score) ? fb.score : null);
  /* ★ v10.31：**库内封面优先**（用户口径「我想要的置顶图是跟前端页面展示时一样的，
     不是「不知道哪里的图」」）。
     实测（xd-38 终结者莉莉）两边的图**根本不是一张**：
       · 列表在用的封面（`fb.cover`）= `shared.cdn.queniuqe.com/store_item_assets/
         steam/apps/1369630/header.jpg` —— Steam 官方 header，460×215；
       · 详情页大图原来取的 `d.cover`（XDGAME 详情）= `www.xdgame.com/uploads/
         allimg/...png` —— **128×128 的一张方形小图**，被 `object-fit:cover`
         铺进 720×250 的顶图里 ⇒ 放大 5.6 倍 + 裁掉大半，糊成一片色块。
         用户截图里那块「不知道哪里的图」就是它。
     所以把优先级翻过来：库内封面 = 用户在列表上看到的那张 = 他要的那张。
     · `d.cover` 仍作兜底：从源站链接直接开详情（没有 fb）时只有它可用；
     · 顺带修掉一处「图会变」：搜索结果的**预览抽屉**本来就用 `fb.cover`
       （见本文件另一处模板），详情加载完却换成 `d.cover` —— 同一张封面在两三秒内
       自己换一次。现在两边同源，不再跳。 */
  const cover = fb.cover || d.cover || '';
  const genres = (d.genres && d.genres.length) ? d.genres : (fb.genres || []);
  const size = d.size || fb.size || '';
  const title = d.title || fb.title || '';
  const n = splitName(title);
  const s = SRC[d.source] || { nm: 'XDGAME', cls: 'xd' };
  const kv = [];
  if (d.source === 'jidi') {
    if (d.releaseDate) kv.push(['发行日期', d.releaseDate]);
    if (d.updateLabel) kv.push(['最近更新', d.updateLabel]);
  } else {
    /* ★ v10.5：XD 详情改版适配后，厂商/发行日期/标签都能从源站取到了 */
    if (d.publisher) kv.push(['游戏厂商', d.publisher]);
    if (d.releaseDate) kv.push(['发行日期', d.releaseDate]);
    if (d.updateLabel) kv.push(['更新时间', d.updateLabel]);
    else if (d.dateLabel) kv.push(['更新日期', d.dateLabel]);
    else if (fb.dateLabel) kv.push(['更新日期', fb.dateLabel]);
  }
  if (size) kv.push(['游戏大小', size]);
  if (genres.length) kv.push(['游戏类型', genres.join(' / ')]);
  if ((d.tags || []).length) kv.push(['游戏标签', d.tags.slice(0, 8).join(' / ')]);
  /* ★ v10.15：原先这里还有一行 `kv.push(['玩家评分', score + ' / 10（Steam 好评率 …）'])`。
   *   同一页里评分因此出现两次（上方 .score-line 的大号分 + 这张表里的「玩家评分 8.6 / 10」），
   *   用户口径「评分重复了，可以减少一个」→ 删掉这里，保留上方那个视觉锚点。
   *   ⚠️ Steam 好评率是**另一条信息**，不跟着删，挪到大号分旁边（见下面 .score-line）。 */
  /* ★ v10.13：不再在这里内联「最低配置要求」。
   *   原因：源站自带的 requirements **只有机地有**，XD 详情页改版后完全没有；
   *   内联写法是「没有就不渲染」→ XD 的 15,302 款游戏那块信息永久空白，
   *   而用户看到的是「详情页的游玩配置没了」。
   *   现在统一交给 #reqSlot 的 loadReqBlock()：源站有就用源站的，
   *   没有就去 Steam 官方接口补（本库 97.2% 的封面带 Steam appid）。
   *   位置也从「版本介绍之后」提到抽屉前段 —— 能不能跑是打开详情页最先想知道的事。 */
  /* ★ v10.25：版本介绍 / 游戏介绍可能是**另一源补来的**（机地页面本来没有版本介绍，
     XD 页面没有源站配置要求）。补来的必须在标题上标出来源 ——
     否则用户无法判断这段文案是哪个站的口径。 */
  const fromTag = (src) => {
    if (!src) return '';
    const m = SRC[src] || { nm: '另一源', cls: 'xd' };
    return `<span class="src-mini ${m.cls}">来自${m.nm}</span>`;
  };
  const versionHtml = d.version ? `<div class="block"><h4><span class="ic"></span>版本介绍${fromTag(d.versionFrom)}</h4><p>${esc(d.version)}</p></div>` : '';
  const descHtml = d.desc || d.description ? `<div class="block"><h4><span class="ic"></span>游戏介绍${fromTag(d.descFrom)}</h4><p>${esc(d.desc || d.description)}</p></div>` : '';
  /* ★ v10.25：游戏预览由「三列小图网格」改成**画廊**（大图 + 左右翻页 + 计数 + 缩略图条）。
   *   旧版 `.shots` 把截图压到 1/3 宽、一张 16:9 只占 90px 高，等于看不清；
   *   而且没有「点开看大图」的路径。新结构对齐用户给的参考站语义：
   *   viewport + track + slide / prev-next / counter / thumbs，外加点图放大（灯箱）。
   *   ★ 数据形态同时变了：`shots` 从 `['url']` 变成 `[{t,f}]`（缩略图/大图两个尺寸），
   *     所以这里**不再做任何 URL 改写** —— 尺寸规则只存在于服务端 fetchers/shots.js。 */
  const shotsHtml = (() => {
    const list = (d.shots || [])
      .map((s) => (typeof s === 'string' ? { t: s, f: s } : s))     // 兼容旧形态
      .filter((s) => s && s.t && s.f);
    if (!list.length) return '';                                    // 没图就整块不占版面
    const slides = list.map((s, i) =>
      `<div class="gal-sld" aria-hidden="${i ? 'true' : 'false'}"><img src="${esc(s.f)}" alt="游戏截图 ${i + 1}" loading="${i ? 'lazy' : 'eager'}" decoding="async" referrerpolicy="no-referrer"></div>`).join('');
    const thumbs = list.map((s, i) =>
      `<button type="button" class="gal-th${i ? '' : ' is-on'}" data-gal-go="${i}" aria-label="查看第 ${i + 1} 张截图"><img src="${esc(s.t)}" alt="" loading="lazy" referrerpolicy="no-referrer"></button>`).join('');
    /* ★ v10.25：并进来的张数如实标注（「双源有则合并去重显示」的可见凭证）——
       不标的话用户只会觉得「图怎么变多了」，不知道多出来的来自另一源。 */
    const mg = (merge && merge.shotsAdded > 0 && merge.twin) ? merge.twin : null;
    const ms = mg ? (SRC[mg.source] || { nm: '另一源', cls: 'xd' }) : null;
    const mergeTag = ms ? `<span class="src-mini ${ms.cls}">含${ms.nm} ${merge.shotsAdded} 张</span>` : '';
    return `<div class="block gal" data-gal data-n="${list.length}" data-i="0">
      <h4><span class="ic"></span>游戏预览${mergeTag}<span class="cnt">${list.length} 张</span></h4>
      <div class="gal-vp">
        <div class="gal-trk">${slides}</div>
        <button type="button" class="gal-nav prev" data-gal-step="-1" aria-label="上一张截图" disabled>❮</button>
        <button type="button" class="gal-nav next" data-gal-step="1" aria-label="下一张截图">❯</button>
        <div class="gal-num" aria-live="polite">1 / ${list.length}</div>
      </div>
      <div class="gal-thumbs">${thumbs}</div>
    </div>`;
  })();
  body.innerHTML = `
    <!-- ★ v10.28：整页顺序按用户给的版式重排 ——
         ① 封面+标题(吸顶,合并游戏预览) ② 评分+参数表 ③ 介绍/版本 ④ 配置要求
         ⑤ 手机模拟器配置 ⑥ 修改器+云存档 ⑦ 同分类更多 ⑧ 本体/修改器/Mod ⑨ 其他；
         操作按钮组移出正文流，固定在抽屉底部（见文末 .d-dock）。
         ⚠️ 改造前的顺序是「手机配置 → 配置要求 → 修改器 → 云存档 → 跨源 → 评分 → 参数表 →
            介绍 → 预览 → 同分类 → 下载」—— 用户打开详情先看到的是「别人总结的配置」，
            自己的评分 / 厂商 / 日期 / 大小要翻到第 5 屏，这正是他要重排的原因。 -->
    <div class="d-hero" id="dHero">
      <div class="d-top">${closeBtnHtml()}<span class="src-badge ${s.cls}" style="color:#fff;background:${s.cls === 'jidi' ? 'rgba(230,65,93,.8)' : 'rgba(11,123,255,.8)'};align-self:center">${s.nm} 来源</span></div>
      ${cover ? `<img src="${esc(cover)}" alt="${esc(n.zh)}" onerror="this.remove()">` : ''}
      <div class="d-title"><h2>${esc(n.zh)}</h2>${n.en ? `<div class="en">${esc(n.en)}</div>` : ''}</div>
    </div>
    <!-- ★ v10.30：常驻小标题条 —— 滚过大图后显形（v10.31 去掉了滑入位移，见 .d-mini 注释）。
         ⚠️ 关闭键必须**再给一份**：大图滚走时原关闭键跟着走了，没有它用户就关不掉抽屉。
         ⚠️ 缩略图带 onerror 移除自身 + 外层 .ph 文字兜底，图挂了也不塌版。
         ⚠️ 本段是模板字符串的正文，注释里**不许出现反引号** ——
            反引号会提前终结模板字符串，整段脚本连语法都过不了（本次就踩了）。 -->
    <div class="d-mini" id="dMini">
      ${closeBtnHtml()}
      ${cover ? `<span class="th"><img src="${esc(cover)}" alt="" onerror="this.remove()"></span>` : `<span class="th ph">${esc(String(n.zh || '?').slice(0, 2))}</span>`}
      <span class="tt"><b>${esc(n.zh)}</b>${n.en ? `<i>${esc(n.en)}</i>` : ''}</span>
      <span class="sb ${s.cls}">${s.nm}</span>
    </div>
    <div class="d-body">
      <div class="d-hint"><b>GameHub 仅为信息聚合站：</b>以下为源站实时抓取的详情与更新信息，本站不提供下载资源。完整内容请前往源站。</div>
      <!-- ① 玩家评分 + 参数表（厂商 / 发行日期 / 游戏大小 …） -->
      ${score ? `<div class="score-line"><span class="score-big">${score}</span><span class="score-meta">玩家评分 · 满分 10${d.steamRate ? `<i>Steam 好评率 ${esc(String(d.steamRate))}</i>` : ''}</span></div>` : ''}
      <div class="kv">${kv.map(([k, v]) => `<div class="it"><div class="k">${esc(k)}</div><div class="v">${esc(v)}</div></div>`).join('')}</div>
      <!-- ② 游戏介绍 / 版本介绍 -->
      ${descHtml}${versionHtml}
      <!-- ③ 游戏预览（★ v10.29：从封面之后移到**介绍块之后** —— 用户口径「游戏预览放在游戏介绍下」）。
           截图是对介绍文字的补充说明：先读「这游戏是什么」，再往下看「它长什么样」。
           ⚠️ v10.28 曾把它提到封面之后（当时的理由是「截图和封面是同一件事」）——
              那是把「吸引眼球」当成了首要目的；用户在真实浏览里是**读完介绍才想看图**的。
              两版都只动这一处顺序，区块本身与懒加载逻辑没变。 -->
      ${shotsHtml}
      <!-- ④ 配置要求（源站有就用源站的，没有去 Steam 官方接口补 ★ v10.13） -->
      <div id="reqSlot"></div>
      <!-- ⑤ 手机模拟器配置（★ v10.28 合一：机型清单为主，点击看品牌/型号/硬件配置） -->
      <div id="bhSlot"></div>
      <!-- ⑥ 修改器 + 云存档：两套数据（Game Cheats Manager / Ludusavi）各渲染各的，
           这里只负责让它们挨在一起（用户版式里这是一行）。 -->
      <div class="d-pair" id="trSvSlot"><div id="trBlock"></div><div id="svBlock"></div></div>
      <!-- ★ v10.7：「同分类更多」挪到本块信息之后。
           原先它挂在 #crossSrc 之后（第 6 位），用户一打开抽屉先看到的是**别人的推荐**，
           自己的评分 / 参数 / 介绍反而要往下翻 —— 推荐位不该抢本体的位置。 -->
      <div id="relSlot"></div>
      <!-- ★ v10.11：下载入口放在**最后**（用户口径：「给下载链接的详情页跳转即可（在后面）」）。
           这里只给「跳转到源站帖子」的入口，不铺正文、不复制网盘直链 ——
           本站仍定位信息聚合站，资源与文件都在源站社区帖内。 -->
      <div id="dlSlot"></div>
      <!-- ⑨ 其他：另一源收录卡片（linkCounterpart 异步回填）+ 免责声明 -->
      <div id="crossSrc"></div>
      <div class="no-dl">🚫 仅聚合 <b>详情页与更新内容</b>，不含任何下载资源</div>
      <!-- ★ v10.25：下载动作条 —— 三个并排按钮（下载本体 / 修改器 / Mod）。
           用户口径：「我需要你将下载按钮优化（①下载本体，②下载修改器，③下载Mod）」。
           ⚠️ 修改器 / Mod 的**条数**来自 /api/mods/match 的 counts（下面 loadDlBlock 回填），
              未知期间保持 hidden；回填后条数为 0 也保持 hidden —— 宁可少一个按钮，
              也不给一个点开是空列表的按钮（同 PITFALLS：#11 宁可退回未收录）。
           ★ 「下载本体」故意不带数字：/api/download 要跟随 302 逐个解析（XD 约 3-8 秒），
              不能在打开详情页时就预取，所以它的条数只能点开才知道。 -->
    </div>
    <!-- ⑩ 操作按钮组：**固定在详情页底部**（用户口径「我的意思是固定在详情页下面（移动也可查看）」）。
         ⚠️ 必须在 .d-body **之外** —— .d-body 有 padding-bottom，放里面 sticky 会被那段
            内边距垫起来，滚到底时底栏与内容之间留一条白缝；放在 #drawerBody 的末尾
            则与内容区边界完全对齐，也让 .d-body 的 padding 只作用于正文。
         ⚠️ 本段位于模板字符串内部：注释里**不能出现反引号**，否则会提前终止模板串
            （v10.28 实测踩到：写成 markdown 行内代码，整段变成裸 JS，报 Unexpected identifier）。 -->
    <div class="d-dock">
      <div class="dl-strip" id="dlStrip">
        <!-- ★ v10.45：三个按钮（下载本体 / 修改器 / Mod）合并成**一个入口**。
             ★ 为什么**不再带 hidden**：旧实现在「既无 d.url 又无 fb.jidiUrl」时整条收起 ——
               可 Mod / 存档 与 XD 有没有详情页无关（Skyrim SE 就是 XD 有详情页、
               但盘口要登录；而它的 Mod 有 60 条）。入口的可见性不该由「本体能不能取到」
               决定。所以无条件渲染，四模块在弹窗里各自取数、各自给空态说明。
             ⚠️ 本段在模板串内部：注释里**不能出现反引号**（会把模板串提前闭合）。 -->
        <button class="ds ds-all" type="button" id="dlBtn" data-dl-open
          data-dl-title="${esc(title)}" data-dl-sub="${esc(n.en || '')}"
          data-dl-url="${esc(d.url || '')}" data-dl-jidi="${esc(fb.jidiUrl || '')}"
          data-dl-id="${esc(fb.id || d.id || '')}">⬇ <em>下载与资源</em></button>
      </div>
      <div class="d-actions">
        <!-- ★ v10.22：「前往源站详情」**仍然保留** ——
               更新日志 / 版本介绍 / 评论只在源站有，删掉会丢信息。
               v10.25 把下载从这块挪到上面的 .dl-strip（三个下载动作归一条，
               与「看信息」的跳转动作分开，避免「资源」和「信息」两个动作长得一样）。 -->
        ${d.url ? `<a class="go ${s.cls}" href="${esc(d.url)}" target="_blank" rel="noopener">前往${s.nm}详情 ↗</a>` : ''}
        <!-- ★ v10.15：跨源按钮**默认隐藏**，只有 linkCounterpart() 查到「这款游戏在另一源的详情页」
             时才显形；查不到就保持不显示。
             用户口径：「详情页中，机地无详情页链接跳转，则不显示」——
             v10.14 那版是「查不到就退到站内搜索结果页」，但一个只能跳到搜索列表的按钮
             和一个跳首页的按钮，对用户来说差别不大（都到不了这款游戏）——不如不显示。
             注意：这里连 href 都不再预置搜索页，避免任何「看起来能点、点过去找不到」的中间态。 -->
        <a class="go ${s.cls === 'jidi' ? 'xd' : 'jidi'}" id="crossGo" hidden
           target="_blank" rel="noopener">${s.cls === 'jidi' ? 'XDGAME' : '机地'}找同名 ↗</a>
      </div>
    </div>`;
  linkCounterpart(d, fb);    // 异步检测另一源同名收录 → 一键互跳 + 决定底部跨源按钮显不显示（★ v10.23 带上 fb：fb.id 是精确孪生键）
  syncDActions();            // ★ v10.15：先按「当前可见按钮数」定列数（跨源按钮默认隐藏，查到详情页才显形）
  loadBhBlock(d, title, fb); // 📱 手机模拟器配置（命中则给逐条参数，未命中给入口）
  loadReqBlock(d, fb);       // 🖥 PC 配置要求（源站优先，缺则 Steam 官方接口补）★ v10.13
  loadTrBlock(d, title);     // 🛠 修改器（v10.1）
  loadSvBlock(d, title);     // 💾 云存档位置（v10.1）
  loadRelated(d, fb);        // 同分类推荐（库内数据 · 多因子打分）
  loadDlBlock(d, fb, title); // 📥 下载入口（机地社区 MOD / 修改器帖）
  /* ★ v10.25：先按「此刻已经渲染出来的区块」建一次定位条；
     后面那些懒加载分区（配置要求 / 修改器 / 云存档 / 下载条）靠 MutationObserver 补。 */
  railSync();
  /* ★ v10.28：新渲染的顶图按**当前** scrollTop 定初态 —— 抽屉是复用节点，
     换一款游戏时滚动位置不一定在顶部，不初始化会出现「已经滚到中间、顶图却还是大图」的错位。 */
  dHeroSpy();
}
/* ★ v10.1：端游详情抽屉的三个「外部资源」区块（懒加载 —— 抽屉打开后才请求，不进首包）
 *
 *   🛠 修改器   → /api/trainers/match   风灵月影 / CE 修改表 / 社区贡献 / 小幸 / GCM
 *   💾 云存档   → /api/saves/match      真实落地路径（占位符已人性化）+ 注册表项
 *   📱 手机配置 → /api/mobilehub/match  安卓机上跑通本作的配置数 / 实测帧率
 *
 *   ★ 顺带修掉一个 v9.3 拆独立页时遗留的 bug：loadBhBlock 当时只留下了调用点，
 *     函数定义被删掉了。paintDetail 执行到那一行会抛 ReferenceError，
 *     导致其后的 linkCounterpart() 与 loadRelated() **从未执行** ——
 *     表现为详情里的「另一源也有收录」「同分类更多」两个区块永远不显示。
 *     这里把 loadBhBlock 补回实现，并顺手接上修改器 / 云存档两块。
 *
 *   三个接口都自带**子串检索兜底**（精确名不中时退化为子串匹配），
 *   所以详情标题即使是「中文/English」拼接串也可整体传参 —— 实测两种写法都命中。
 */
const D_TR_SRC = {
  fling: '风灵月影', cheat_table: 'CE 修改表', community: '社区贡献',
  xiaoxing: '小幸修改器', gcm: 'GCM 精选',
};
const D_GCM_URL = 'https://github.com/dyang886/Game-Cheats-Manager/releases';

/* ================= 📱 手机模拟器配置（v10.13 重写） =================
 *
 * 两处改动，都来自用户口径「详情页的游玩配置没有了」：
 *   ① **常显**：原来「匹配不到就整个区块不渲染」。用户打开详情页看到的是「什么都没有」，
 *      分不清是「这游戏没人跑通」还是「这个功能没了」。现在没命中也给区块 +
 *      说明 + 去手机专区的入口（明确告诉用户「是没人跑过，不是没这功能」）。
 *   ② **铺开逐条参数**：原来只有 [机型 | GPU | 日期 | 下载 JSON] ——
 *      真正的玩法参数（Turnip 驱动版本 / DXVK / 容器 / Box64 预设 / 分辨率 / 内存上限）
 *      全在那份 JSON 里，等于「答案在附件中」。现在服务端解析后直接铺在卡上。
 */
const BH_EMU_URL = '/emulator.html#emu';
const BH_DM_URL = '/emulator.html#dm';
/* ★ v10.28：详情页里**默认露几台机型**（用户口径「默认展示5个，然后有个更多，点击弹窗可以查看全部」）。
   其余在「查看全部」弹窗里给全量 —— 那里按 40 台一批分块取规格（URL 太长会 414）。 */
const DL_DEV_SHOW = 5;
/* ★ v10.31：详情页「同分类更多」展示张数（用户口径「最好是显示8个」，原为 6）。
   放在这里而不是 CSS 变量里，是因为它决定的是**取几条数据、渲染几个 DOM**，
   属于 JS 的职责；写成 `--cd-cols` 那种「只定义不引用」的变量才是假接口
   （v10.30 的 `:root` 断言正是在防这个：「只定义不用 = 规范没生效」）。 */
const REL_SHOW = 8;

/** 一条社区配置 → 参数芯片行（抽屉与完整面板共用同一份渲染，避免两处漂移）
 *  ★ v10.14：新增「机型 → 芯片规格」行（SoC / 品牌 / CPU 核簇 / 性能分）。
 *   p.spec 由服务端 /api/bh/params 注入（服务端一次算完，避免前端 N+1）。 */
function bhParamCard(p) {
  const chips = [];
  const add = (label, val, cls) => { if (val) chips.push(`<span class="kv ${cls || ''}"><b>${esc(label)}</b>${esc(String(val))}</span>`); };
  add('驱动', p.driver, 'hot');
  add('DXVK', p.dxvk, 'hot');
  add('VKD3D', p.vkd3d);
  add('容器', p.container);
  add('翻译层', p.translator, 'ok');
  add('分辨率', p.resolution);
  add('内存', p.maxMem);
  add('核心', p.cores);
  add('FEX', p.fexBuild);
  if (p.vibration) add('振动', '开');
  (p.translatorFlags || []).slice(0, 3).forEach((f) => add('', f));
  const sp = p.spec;
  const specRow = (sp && (sp.soc || sp.gpu))
    ? `<div class="spec">
        ${sp.soc ? `<span class="sp soc"><b>${sp.approx ? '≈' : ''}${esc(sp.soc)}</b></span>` : ''}
        ${sp.brand ? `<span class="sp">${esc(sp.brand)}</span>` : ''}
        ${sp.cpu ? `<span class="sp cpu">${esc(sp.cpu)}</span>` : ''}
        ${sp.score ? `<span class="sp">性能分 <b>${esc(String(Math.round(sp.score)))}</b></span>` : ''}
        ${!sp.soc && sp.gpu ? `<span class="sp">GPU <b>${esc(sp.gpu)}</b></span>` : ''}
      </div>`
    : `<div class="spec"><span class="sp none">该机型代号暂无芯片规格</span></div>`;
  return `<div class="d-param">
    <div class="ph"><span>${esc(p.device || '未知机型')}</span><span class="gpu">${esc(p.gpu || '')}</span>
      <span class="dt">${esc(p.date || '')}</span></div>
    ${specRow}
    <div class="pb">${chips.join('') || '<span class="kv">该份配置未记录可解析参数</span>'}</div>
  </div>`;
}

/** 一条「本站实测记录」→ 抽屉里的紧凑卡片（★ v10.15 新增）
 *  与手游专区「实测配置」面板（openPcPanel）同源同义，这里只是压到抽屉的宽度。
 *  信息优先级按用户抄参数的习惯排：能不能跑 → 什么芯片 → 什么帧率 → 怎么配的。 */
function bhRecRow(x) {
  const kv = [];
  const add = (k, v) => { if (v) kv.push(`<span class="kv-i"><b>${esc(k)}</b>${esc(String(v))}</span>`); };
  add('兼容层', x.layer);
  add('运行模式', x.mode);
  add('驱动', x.gpu);
  add('DXVK', x.dxvk);
  add('vkd3d', x.vkd3d);
  add('运行库', x.runtime);
  add('主程序', x.exe);
  const fps = [x.fpsTier, x.fpsLabel].filter(Boolean).join(' · ');
  return `<div class="r">
    <div class="hd"><span class="pill ${x.ok ? 'ok' : 'no'}">${x.ok ? '可玩' : '不可玩'}</span>
      <span class="dev">${esc(x.chipName || x.chip || '—')}</span>
      ${fps ? `<span class="fps">${esc(fps)}</span>` : ''}</div>
    <div class="kv">${kv.join('') || '<span class="kv-i">这条记录没留下可解析参数</span>'}</div>
    ${x.note ? `<div class="nt">💡 ${esc(x.note)}</div>` : ''}
  </div>`;
}

/* ================= 📱 机型硬件参数面板（★ v10.16 新增） =================
 *  用户口径：「前端显示品牌+型号 如 Xiaomi 25053PC47G → xiaomi Poco F7，
 *            点击可以查看对应手机的硬件配置参数」。
 *
 *  两条数据源分工（实测确认，别搞混）：
 *    · 「内部代号 → 品牌 + 型号」= `data/device-market.json`（MobileModels，离线）
 *    · 「型号名 → 硬件参数」      = `/api/device/hardware`（kalvo，未命中时实时抓 + 落盘）
 *  ⚠️ kalvo 只按**营销名**搜（`POCO F7` 命中、`25053PC47G` 搜不到），
 *     所以按钮上带的是 `data-hw`（译出的型号名），不是 `data-m`（原始代号）。
 *
 *  交互：再点同一台 = 收起；点另一台 = 换成那一台。一次只开一个，避免抽屉越撑越长。 */
let _hwOpen = '';                         // 当前展开的机型（原始名），用于「再点收起」与互斥
/* ★ v10.28：面板只保留「品牌 / 型号 / 硬件配置」三项（用户口径：「点击后我只需要品牌，
   型号，硬件配置」）。
   改造前会铺「基本信息 / 硬件配置 / 屏幕 / 电池」4 节 + 一个「展开全部参数（还有 8 节）按钮」——
   12 节合计 1800+px，而用户要回答的是「这台机器什么芯片」，不是拿一份完整规格书。
   品牌 / 型号取自 kalvo 的「基本信息」组（实测：品牌=Xiaomi、型号=Poco F7）；
   取不到就退回列表里那个译名 —— 面板不该因为少一个字段就空掉。 */
const HW_INFO_G = '基本信息', HW_HW_G = '硬件配置';
function hwPanelHtml(r) {
  const shortRaw = String(r.name || '').split(' - ')[0];
  const src = r.url ? `<a href="${esc(r.url)}" target="_blank" rel="noopener">kalvo ↗</a>` : '';
  const all = r.groups || [];
  const info = all.find((g) => String(g.name).indexOf(HW_INFO_G) >= 0);
  const pick = (k) => {
    const it = info && (info.items || []).find((x) => x.k === k);
    return (it && it.value) || '';
  };
  const brand = pick('品牌');
  const model = pick('型号') || shortRaw;
  const grp = all.find((g) => String(g.name).indexOf(HW_HW_G) >= 0);
  const rows = grp
    ? `<div class="grp"><h4>${esc(grp.name)}</h4>
      <div class="kvs2">${grp.items.map((it) => `<div><span title="${esc(it.k)}">${esc(it.k)}</span><b>${esc(it.v)}</b></div>`).join('')}</div>
    </div>`
    : '<div class="load">这台机型在 kalvo 没有「硬件配置」分节，可点右上角去源站核对。</div>';
  return `<div class="d-hw"><div class="hw-hd"><b>${esc(model)}</b>
      ${brand ? `<span class="tag">品牌 ${esc(brand)}</span>` : ''}
      ${r.cached ? '' : '<span class="tag more-tag">刚抓取</span>'}
      <span class="src">${src}</span></div>
    ${rows}</div>`;
}
async function toggleDevHardware(btn) {
  const slot = $('#bhHwSlot');
  if (!slot) return;
  const raw = btn.getAttribute('data-m') || '';
  const q = btn.getAttribute('data-hw') || raw;
  const list = btn.closest('.d-devlist');

  /* 再点同一台 → 收起 */
  if (_hwOpen === raw && slot.innerHTML) {
    _hwOpen = ''; slot.innerHTML = '';
    btn.classList.remove('on'); btn.setAttribute('aria-expanded', 'false');
    return;
  }
  if (list) list.querySelectorAll('.dv.on').forEach((b) => { b.classList.remove('on'); b.setAttribute('aria-expanded', 'false'); });
  btn.classList.add('on'); btn.setAttribute('aria-expanded', 'true');
  _hwOpen = raw;

  slot.innerHTML = `<div class="d-hw"><div class="hw-hd"><b>${esc(btn.querySelector('.hd b') ? btn.querySelector('.hd b').textContent : q)}</b>
      <span class="tag">硬件参数</span><span class="src">正在读取…</span></div>
    <div class="load">正在从 kalvo 读取该机型参数…</div></div>`;

  let r = null;
  try {
    r = await fetch(api('/api/device/hardware?m=' + encodeURIComponent(q))).then((x) => x.json());
  } catch (e) { r = null; }
  if (_hwOpen !== raw) return;                    // 期间用户点了别的机型，丢弃这次结果
  if (!r || !r.ok) {
    /* 未收录就如实说「没查到」，不去猜、也不显示空壳面板 */
    slot.innerHTML = `<div class="d-hw"><div class="hw-hd">
        <b>${esc(btn.querySelector('.hd b') ? btn.querySelector('.hd b').textContent : q)}</b>
        <span class="tag">硬件参数</span></div>
      <div class="load">没查到这台机型的参数（kalvo 只按营销名收录，内部代号搜不到）。
        ${r && r.reason === 'not-found' ? '' : '可到 '}<a href="https://zh.kalvo.com/" target="_blank" rel="noopener">kalvo</a> 自行搜索核对。</div></div>`;
    return;
  }
  slot.innerHTML = hwPanelHtml(r);
}

/* ================= 🔗 跨源解析（★ v10.14 新增） =================
 *  用户口径：「机地是跳转到首页，而不是详情页」。
 *  现场：抽屉底部第二个按钮是 `href="https://jidiyouxi.com/"`（**写死的站点根**），
 *        XD 源的游戏点过去就是机地首页，跟这款游戏毫无关系。
 *
 *  修法：跨源要跳「这款游戏在另一源的**详情页**」——
 *    ① 另一源有同名收录（且那条带详情页 url）→ 直接跳该详情页；
 *    ② 没有 → **不显示这个按钮**。
 *
 *  ★ v10.15 补：②原本是「退到该站站内搜索结果页」（jidiyouxi.com/search?keyword=…）。
 *    用户口径变成「机地无详情页链接跳转，则不显示」—— 想通了也对：
 *    一个只能落到搜索列表的按钮，和 v10.14 之前那个落首页的按钮，对用户是同一件事
 *    （都到不了这款游戏），只是体面一点。所以现在查不到就不显示，连带那两个
 *    搜索 URL 构造器（JIDI_SEARCH / XD_SEARCH）也一并删掉，不留没人用的出口。
 *
 *  「另一源是否收录了同款」这件事同时被两个区块需要，所以只查一次（cpCache 按抽屉条目缓存）：
 *    · linkCounterpart() → 渲染「另一源也有收录」卡片 + 决定底部跨源按钮显不显示
 *    · loadBhBlock()     → 把另一源的 libId / 标题（常含英文名）传给 /api/mobilehub/match 做跨中英桥接
 */
let cpCache = { key: '', p: null };

function resolveCounterpart(d, fb) {
  const key = String((d && (d.url || d.id || d.title)) || '');
  if (cpCache.key === key && cpCache.p) return cpCache.p;
  const p = (async () => {
    if (!d || (!d.title && !(fb && fb.id))) return null;
    /* ★ v10.23：改问后端 /api/library/twin —— 跨源对齐用**精确键**，不再按名字猜。
     *
     *   旧实现（v10.15~v10.22）在这里发 `/api/library?q=<中文名>` 再用本地 sameGame() 过滤。
     *   v10.22 之前这还能用（机地条目都是独立条目）；v10.22 把 13,448 条机地话题
     *   **合并进 XD 条目**（机地信息挂在 jidiUrl / jidiId 上）之后，库里独立的 jidi 条目
     *   只剩 3,609 条 —— 实测 15,352 条 XD 记录按名只命中 535 条（3.5%），
     *   于是「机地找同名」按钮几乎永远不显示，用户看到的正是「连按钮都点击不了」。
     *
     *   现在这件事交给后端 data/twin.js：先按 jidiUrl / jidiId 精确取（覆盖率 90.1%），
     *   名称匹配只作兜底且必须过防误配闸门；前端只负责显示。
     *   ★ 同一个语义（两个标题是不是同一款）只留一份实现 —— 原先它在本文件里，
     *     现在收到后端，前端不再自己判（项目铁律 10）。 */
    const qs = new URLSearchParams();
    const id = (fb && fb.id) || d.id || '';
    if (id) qs.set('id', id);
    const t = d.title || (fb && fb.title) || '';
    if (t) qs.set('t', t);
    if (d.source) qs.set('src', d.source);
    try {
      const j = await fetch(api('/api/library/twin?' + qs.toString())).then((r) => r.json());
      return (j && j.ok && j.twin) ? j.twin : null;
    } catch (e) { return null; }
  })();
  cpCache = { key, p };
  return p;
}

/* ★ v10.23 移除：`hasDetailUrl` / `normGameTitle` / `sameGame` 三个函数。
 *
 * 它们负责「另一源有没有这款的同款、且那条带详情页」，原先只在本文件里用。
 * 现在这套判定整体搬到后端 `data/twin.js`（那里还要被 /api/library/twin 用），
 * 前端留一份副本就等于有两个「同款判定」实现 —— 改一处忘一处时，
 * 详情页的跨源按钮会与接口给出的结论不一致（项目铁律 10：同一语义只留一种写法）。 */

/* 机型 → 展示字段的唯一映射（★ v10.25 抽出来：详情页清单与「查看全部」弹窗
 * 必须给出**同一台机器同一个名字**，两处各写一遍必然漂移 —— 本项目 PITFALLS #10）。
 * @param {string} m 机型串（可能带内部编号，如 `HONOR MTN-NX3`）
 * @param {object|null} s /api/device/specs 的该条记录 */
function bhDevRow(m, s) {
  const mk = (s && s.mkt) || null;
  const disp = (mk && mk.display) || '';
  const w0 = disp.split(' ')[0] || '';
  const codeShort = (w0 && m.toLowerCase().startsWith(w0.toLowerCase() + ' ')) ? m.slice(w0.length + 1).trim() : m;
  return {
    m,
    name: disp || m,
    code: (mk && mk.resolved && disp && disp.toLowerCase() !== m.toLowerCase()) ? codeShort : '',
    hwq: (mk && (mk.market || mk.display)) || m,
    /* ★ v10.18：芯片由服务端三级降级的**本地两级**给出（配对索引 → 串内芯片号），
       拿不到就是空 —— 空的那批下面会自动联网补（fillMissingDevChips）。 */
    chip: (s && s.chip) || '',
    chipSrc: (s && s.chipSrc) || '',
    score: (s && s.score) || 0,
    approx: !!(s && s.approx),
  };
}
async function loadBhBlock(d, title, fb) {
  const slot = $('#bhSlot');
  if (!slot) return;
  const t = String(title || (d && d.title) || '').trim();
  if (t.length < 2) return;
  try {
    /* ★ v10.14：把「另一源的同款条目」一起带上 —— 它的 libId 与标题（常含英文名）用于跨中英桥接。
       不这么做的话，机地源的中文标题（「生化危机4重置版」）对不上 mobilehub 的英文名（`Resident Evil 4`），
       会显示「暂无记录」的**假阴性**（同一款游戏从 XD 入口看却有 63 套配置）。 */
    const cp = await resolveCounterpart(d, fb);
    const qs = new URLSearchParams({ t });
    const ownId = String((d && d.id) || '').trim();
    if (ownId) qs.set('id', ownId);
    if (cp) {
      if (cp.id) qs.set('id', cp.id);
      const altNames = [cp.title, splitName(cp.title).en].filter(Boolean);
      if (altNames.length) qs.set('alts', altNames.join(','));
    }
    const j = await fetch(api('/api/mobilehub/match?' + qs.toString())).then(r => r.json());
    const h = j && j.hit;
    /* ---- 未命中：也给区块，明确「是没人跑过」而不是「功能没了」 ---- */
    if (!h) {
      slot.innerHTML = `<div class="d-blk"><h4><span class="ic"></span>手机模拟器配置<span class="cnt">暂无记录</span></h4>
        <div class="d-req-empty">社区配置库与本站实测库里<b>还没有这款游戏</b>的跑通记录 ——
          意味着暂时没有「照着抄就能用」的参数可参考，不代表手机上一定跑不了。</div>
        <div class="d-hint2">可去 <a href="${BH_DM_URL}">手机专区 · 机型兼容</a> 查你的机型能跑哪些游戏，
          或到 <a href="${BH_EMU_URL}">手游中心</a> 看同类游戏的配置（同引擎的作品参数往往通用）。</div></div>`;
      return;
    }
    const tags = [];
    if (h.configs) tags.push(`<span class="d-tg community">社区配置 ${h.configs} 套</span>`);
    if (h.records) tags.push(`<span class="d-tg gcm">本站实测 ${h.records} 条</span>`);
    if (h.bestLabel) tags.push(`<span class="d-tg cloud">最佳 ${esc(String(h.bestLabel))}</span>`);
    if (h.tier) tags.push(`<span class="d-tg phone">档位 ${esc(h.tier)}</span>`);
    /* ★ v10.14：计数改用「机型」为主 —— 用户想知道的是「哪些机型能跑」，
       而 GPU 一列在清洗脏值后信息量本来就更少（942 条只剩机型可依据）。 */
    const devCnt = (h.devices || []).length;
    const gpuCnt = (h.gpus || []).length;
    const cntTxt = [devCnt ? `${devCnt} 款机型` : '', gpuCnt ? `${gpuCnt} 种 GPU` : ''].filter(Boolean).join(' · ');
    _hwOpen = '';                     // 换了一款游戏 → 硬件面板的「已展开」状态一并作废
    /* ★ v10.28：这一节从「四个子块并列」收成**一块**（用户口径：「详情页中的手机配置只需要
       手机模拟器配置，不要多个显示」）。默认只看到机型清单（前 5 台）—— 点机型看
       品牌 / 型号 / 硬件配置；「查看全部」进弹窗。原先铺在外面的「本站实测记录」与
       「逐条游玩参数」也一并收进那个弹窗（用户已确认：收进弹窗，不删数据）。 */
    slot.innerHTML = `<div class="d-blk"><h4><span class="ic"></span>手机模拟器配置<span class="cnt">${cntTxt}</span></h4>
      <div class="d-tg-row">${tags.join('')}</div>
      <div id="bhDevSlot"></div>
      <div id="bhHwSlot"></div>
      <div id="bhMoreSlot"></div>
      <div class="d-hint2">点机型看该机的<b>品牌 / 型号 / 硬件配置</b>；参数为玩家在安卓机上跑通本作后导出的实际配置（驱动 / DXVK / 容器 / 翻译层）。
        完整清单见 <a href="${BH_EMU_URL}">手机专区 · 手游中心</a>。</div></div>`;

    /* ---- ① 机型清单：按「性能分」从弱到强排，并标出**门槛机型** ----
     *   ★ v10.15：看这一块的人真正的问题是「我的手机能不能跑」。
     *   旧的平铺 chips 只回答「谁跑过」，还得自己一台台去认型号。现在：
     *     · 有性能分的按分**升序**排（同分保持原顺序，V8 稳定排序）—— 门槛低的排前面
     *     · 最弱那台标「门槛」：它跑通过，比它强的机型基本也能跑
     *     · 每台补一个性能分数字，跨品牌（Adreno / Mali / PowerVR）可以直接比大小 */
    /* ★ v10.17：`h.devices` 现在是「社区库聚合摘要（上游只有 6 格）+ 逐条配置里的机型」合并后的全量，
       服务端已去重并对齐了写法（`MTN NX3` 与 `HONOR MTN-NX3` 视为同一台）。这里只负责截断展示。 */
    const allDevs = h.devices || [];
    /* ★ v10.28：默认只露 **5** 台（用户口径「默认展示5个，然后有个更多，点击弹窗可以查看全部」）。
       原来是 24 台平铺 —— 在抽屉里那是整整一屏半的按钮墙，而用户想先回答的是
       「这几台能不能跑」，不是「一共多少台」。 */
    const devs = allDevs.slice(0, DL_DEV_SHOW);
    const ds = $('#bhDevSlot');
    if (devs.length && ds) {
      let specs = {};
      try {
        const sr = await fetch(api('/api/device/specs?models=' + encodeURIComponent(devs.join('|')))).then((r) => r.json());
        specs = (sr && sr.specs) || {};
      } catch (e) { specs = {}; }
      const arr = devs.map((m) => bhDevRow(m, specs[m] || null));
      const sorted = arr.slice().sort((a, b) => (a.score || 1e9) - (b.score || 1e9));
      const gate = sorted.find((x) => x.score > 0) || null;   // 有性能分的最弱一台 = 门槛
      /* ★ v10.18：门槛不再单起一行摘要（那行与清单首行是同一台，读起来像重复）。
         改成两条：① 那台机型上加橙色「门槛」徽标 ② 表头补一格图例说明含义。 */
      const cntEl = slot.querySelector('.d-blk .cnt');
      if (cntEl && gate) {
        cntEl.innerHTML = esc(cntTxt)
          + `<span class="d-devlist-lg" title="橙色那台是实测跑通过的最弱机型 —— 比它强的机型基本也能跑">门槛机型</span>`;
      }
      /* 芯片名太长（如 `Dimensity 8350 (MT6897 MT6897Z_B/ZA MT8792Z/NA)`、
         `Samsung Exynos 2200 (国际版本) / Qualcomm Snapdragon 8 Gen 1 (美国)`）徽标里放不下，
         只留**主名**（第一个 `(` 或第一个 ` / ` 之前），完整值挂在 title 上、详情面板里也有。 */
      const chipFull = (s) => String(s || '').trim();
      const chipShort = (s) => {
        const t = chipFull(s);
        const cut = [t.indexOf('（'), t.indexOf('('), t.indexOf(' / '), t.indexOf('/')]
          .filter((i) => i > 0).sort((a, b) => a - b)[0];
        return (cut ? t.slice(0, cut) : t).trim() || t;
      };
      /* 芯片来源标记：只标「非默认路径」的两种，默认（本地配对）不加标记降低噪音 */
      const chipTag = (src) => (src === 'kalvo'
        ? '<u title="本地库没有 → 已联网（kalvo）自动补全">网</u>'
        : (src === 'token' ? '<u title="芯片号直接写在机型串里，本地解析得到">串</u>' : ''));
      const chipHtml = (x, extraCls) => {
        if (!x.chip) return `<i class="chip none${extraCls || ''}" title="本地库与联网都查不到 —— 如实标注，未编造">未收录</i>`;
        const cls = 'chip' + (x.chipSrc === 'kalvo' ? ' ol' : '') + (extraCls || '');
        const full = chipFull(x.chip);
        const t = (x.approx ? '≈' : '') + chipShort(x.chip);
        return `<i class="${cls}" title="${esc(full)}">${chipTag(x.chipSrc)}${esc(t)}</i>`;
      };
      const devRow = (x) => {
        const isGate = !!(gate && x.m === gate.m);
        return `<button type="button" class="dv${isGate ? ' gate' : ''}"
          data-m="${esc(x.m)}" data-hw="${esc(x.hwq)}" aria-expanded="false">
          <span class="hd"><b>${esc(x.name)}</b>${isGate ? '<u class="gtag" title="橙色：实测跑通过的最弱机型 —— 比它强的机型基本也能跑">门槛</u>' : ''}${x.score ? `<em>${esc(String(Math.round(x.score)))}</em>` : ''}<u class="chev">▼</u></span>
          <span class="sub">${chipHtml(x)}${x.code ? `<s>${esc(x.code)}</s>` : ''}</span>
        </button>`;
      };
      /* ★ v10.28：清单里不再挂「查看全部」按钮 —— 它移到 `#bhMoreSlot`（独立一块）。
         留在 `.d-devlist` 里的话，按钮会跟着清单一起被 `ds.onclick` 的机型委托吃掉，
         而且 5 台机型的清单只有 5 行，「按钮夹在机型中间」读起来像是第 6 台机型。 */
      ds.innerHTML = `<div class="d-devlist">${sorted.map(devRow).join('')}</div>`;
      ds.onclick = (ev) => {
        const b = ev.target.closest && ev.target.closest('.dv[data-hw]');
        if (b) toggleDevHardware(b);
      };

      /* ---- ★ v10.18 ③：未收录的机型**自动联网补全** ----
       *   本地两级解决不了的（如 `Honor MTN-NX3` → 本地无芯片，但 kalvo 有 `Honor Magic8 Lite`），
       *   这里异步补：先把待补的标成「联网查询中…」，回来后**原地替换**那枚徽标 ——
       *   不重渲染整个清单（重渲染会把用户已经展开的硬件面板一起收掉）。
       *   补不到就保持「未收录」，联网失败也不假装成功。 */
      const pending = sorted.filter((x) => !x.chip).map((x) => x.m);
      if (pending.length) {
        const btnOf = (m) => {
          for (const el of ds.querySelectorAll('.dv[data-m]')) if (el.getAttribute('data-m') === m) return el;
          return null;
        };
        const paint = (m, html) => {
          const el = btnOf(m);
          const box = el && el.querySelector('.sub .chip');
          if (box) box.outerHTML = html;
        };
        for (const m of pending) paint(m, '<i class="chip wait">联网查询中…</i>');
        (async () => {
          let fills = {};
          try {
            const fr = await fetch(api('/api/device/fill?models=' + encodeURIComponent(pending.join('|')))).then((r) => r.json());
            fills = (fr && fr.fills) || {};
          } catch (e) { fills = {}; }
          for (const m of pending) {
            const f = fills[m] || null;
            if (f && f.chip) {
              paint(m, chipHtml({ chip: f.chip, chipSrc: f.chipSrc, approx: false }));
            } else {
              paint(m, chipHtml({ chip: '', chipSrc: '' }));
            }
          }
        })();
      }
    }

    /* ★ v10.28：「其余机型 + 本站实测 + 逐条参数」全部收进**同一个**「查看全部」弹窗
       （用户口径「默认展示5个，然后有个更多，点击弹窗可以查看全部」；
        实测记录与逐条参数按他的选择「收进弹窗」而**不是删掉**）。
       三份数据都在**点击时**才取 —— 详情页打开就拉 100 台机型的规格 + 100 份配置，
       对绝大多数「只是看看」的用户是纯浪费。
       ⚠️ 机型规格必须**分块**发：/api/device/specs 的机型是塞在 URL 查询串里的，
          全量一次性发有 414（URI Too Long）风险，所以按 40 台一批串行。
       ⚠️ 这一段必须留在 if (devs.length && ds) 块**外面**。库里存在「机型清单为空、
          但有实测记录 / 逐条配置」的游戏（h.devices 上游摘要只有 6 格且逐条配置也可能空），
          嵌进那个 if 里就等于连入口一起吞掉 —— 用户既看不到机型，也拿不到本该有的实测与参数。
          这一条靠 tools/test-v1028-detail.js 守着。 */
    const hiddenDev = allDevs.length - devs.length;
    const moreSlot = $('#bhMoreSlot');
    if (moreSlot) {
      const hasAny = hiddenDev > 0 || h.records > 0 || h.configs > 0;
      const label = hiddenDev > 0
        ? `查看全部 ${allDevs.length} 台机型` + ((h.records || h.configs) ? ' 与实测参数' : '')
        : '查看实测记录与逐条配置';
      moreSlot.innerHTML = hasAny ? dFullBtn(dFullPut({
        type: 'dv', title: '手机模拟器配置 · 全部', sub: t,
        total: allDevs.length, recsOn: h.records > 0, paramsOn: h.configs > 0,
        load: async () => {
          /* ① 全部机型（分块取规格） */
          const out = [];
          for (let i = 0; i < allDevs.length; i += 40) {
            const chunk = allDevs.slice(i, i + 40);
            let sp = {};
            try {
              sp = ((await fetch(api('/api/device/specs?models=' + encodeURIComponent(chunk.join('|')))).then((r) => r.json())) || {}).specs || {};
            } catch (e) { sp = {}; }
            for (const m of chunk) out.push(bhDevRow(m, sp[m] || null));
          }
          /* ② 本站实测记录（跑通后的兼容层 / 驱动 / 帧率） */
          let recs = [];
          if (h.records > 0) {
            try {
              const rj = await fetch(api('/api/pc/records?k=' + encodeURIComponent(t))).then((r) => r.json());
              recs = (rj && rj.items) || [];
            } catch (e) { recs = []; }
          }
          /* ③ 逐条游玩参数（社区库；候选仓库键一起传，服务端挑份数最多的那个） */
          let params = [];
          const keys = (h.bhKeys || []).join(',');
          if (keys && h.configs > 0) {
            try {
              const pj = await fetch(api('/api/bh/params?k=' + encodeURIComponent(keys) + '&limit=100')).then((r) => r.json());
              params = (pj && pj.items) || [];
            } catch (e) { params = []; }
          }
          return { items: out, recs, params };
        },
      }), label) : '';
    }

    /* ★ v10.28：原先这里**当场铺两块内容** ——
       「② 本站实测记录」（`/api/pc/records` 全量）与「③ 逐条游玩参数」
       （`/api/bh/params?limit=3` + 一个「查看全部 N 份配置」按钮）。
       现在两块都**不在详情页默认铺开**（用户口径：「只需要手机模拟器配置，不要多个显示」），
       而是收进上面那个「查看全部」弹窗（用户已确认：收进弹窗、不删数据）。
       取数与版式**原样搬进该弹窗的 load()**，`bhRecRow` / `bhParamCard` 两个渲染器继续复用 ——
       同一个语义只留一份实现，不再有「详情页一套、弹窗另一套」的漂移风险。 */
  } catch (e) { /* 静默：区块是锦上添花，失败不打扰用户 */ }
}

/* ================= 🖥 PC 配置要求（v10.13 新增） =================
 *
 * 用户口径：「详情页的游玩配置没有了」。
 * 根因：XDGAME 详情页改版后**本身就没有配置要求数据**，而老代码是
 *       `d.requirements ? 渲染 : ''` —— XD 来源的 15,302 款游戏这块**永久空白**。
 * 补法：源站有（机地）直接用；没有就走 /api/pcreq（Steam 官方接口，
 *       本库 97.2% 的封面里带 Steam appid，能拿到官方简体中文的配置）。
 * 位置：放在「手机模拟器配置」之后、「修改器」之前 —— 「能不能跑」是打开详情页最先想知道的事。
 */
const REQ_LABEL = { os: '系统', cpu: 'CPU', ram: '内存', gpu: '显卡', dx: 'DirectX', net: '网络', storage: '存储', note: '附注' };
const REQ_ORDER = ['os', 'cpu', 'ram', 'gpu', 'dx', 'net', 'storage', 'note'];

/** 一组配置字段 → 一栏 */
function reqCol(title, req, cls) {
  const rows = REQ_ORDER.filter((k) => req && req[k])
    .map((k) => `<div class="rr"><i>${REQ_LABEL[k]}</i><span>${esc(req[k])}</span></div>`).join('');
  if (!rows) return '';
  return `<div class="rc ${cls || ''}"><div class="rc-h">${title}</div>${rows}</div>`;
}

async function loadReqBlock(d, fb) {
  const slot = $('#reqSlot');
  if (!slot) return;
  const title = String(d.title || (fb && fb.title) || '').trim();
  /* ① 源站自带（机地详情页有 game_sys_reqs）—— 不再等到网络回包，立刻渲染 */
  if (d.requirements && Object.keys(d.requirements).length) {
    /* ★ v10.25 双源合并：机地给的是**一整组**最低配置（`{os,cpu,ram,gpu,storage}`，
       没有「推荐配置」这一栏），而 Steam 官方接口能给推荐配置。
       原先这里直接 return —— 于是机地来源的约 3,600 款游戏**永远只有一栏配置**。
       现在并行问一次 Steam，只为补第二栏；Steam 也没有就照旧一栏（那确实是没有）。
       ⚠️ 表格结构不动：最低配置永远来自源站那份，Steam **只补「推荐配置」这一栏**，
          不做逐字段混搭 —— 两套口径混进一张表，用户没法判断哪一行可信。 */
    slot.innerHTML = `<div class="d-blk"><h4><span class="ic"></span>配置要求<span class="cnt">源站提供</span></h4>
      <div class="d-req">${reqCol('最低配置', d.requirements)}</div>
      <div class="d-hint2">来自源站详情页的最低配置要求，供参考；实际体验受画质设置与驱动影响。</div></div>`;
    (async () => {
      try {
        const id = (fb && fb.id) || d.id || '';
        const t = String(d.title || (fb && fb.title) || '').trim();
        /* ★ cover 要挑**带 Steam appid 的那张**：机地详情页的 cover 是
           `img2.52jidi.com/topic/cover/...`，里面没有 appid，直接用会命中不到 Steam 接口。
           库内封面（fb.cover）才是带 appid 的那份（PITFALLS #7 同款坑）。 */
        const cov = [d.cover, (fb && fb.cover)]
          .find((u) => /\/steam\/apps\/\d+\//.test(String(u || ''))) || d.cover || (fb && fb.cover) || '';
        const qs = '?t=' + encodeURIComponent(t) + (id ? '&id=' + encodeURIComponent(id) : '') + (cov ? '&cover=' + encodeURIComponent(cov) : '');
        const j = await fetch(api('/api/pcreq' + qs)).then((r) => r.json());
        const rec = j && j.hit && (j.rec || (j.hit && j.hit.rec));
        if (!rec || !Object.keys(rec).length) return;
        /* ★ 二次校验「还是同一份详情页」：用户可能已经换到别的游戏了。
           抽屉重渲染会把旧节点摘出文档 ⇒ contains() 为假，此时**绝不能**再写进去。 */
        const box = slot.querySelector('.d-req');
        if (!box || !document.body.contains(box)) return;
        box.insertAdjacentHTML('beforeend', reqCol('推荐配置', rec, 'rec'));
        const hint = slot.querySelector('.d-hint2');
        if (hint) hint.insertAdjacentHTML('afterbegin', '<span class="src-mini xd" style="margin-left:0">推荐配置来自 Steam 官方</span><br>');
        const cnt = slot.querySelector('.d-blk .cnt');
        if (cnt) cnt.textContent = '源站 + Steam 官方';
      } catch (e) { /* 补不到就维持一栏 —— 不报错、不占版面 */ }
    })();
    return;
  }
  const id = (fb && fb.id) || d.id || '';
  const cover = d.cover || (fb && fb.cover) || '';
  if (!id && !title && !cover) return;
  slot.innerHTML = `<div class="d-blk"><h4><span class="ic"></span>配置要求<span class="cnt">查询中…</span></h4>
    <div class="d-req-empty">源站详情页未提供配置要求，正在从 Steam 官方接口查询…</div></div>`;
  try {
    const qs = '?t=' + encodeURIComponent(title) + (id ? '&id=' + encodeURIComponent(id) : '') + (cover ? '&cover=' + encodeURIComponent(cover) : '');
    const j = await fetch(api('/api/pcreq' + qs)).then((r) => r.json());
    if (!j || !j.hit) {
      slot.innerHTML = `<div class="d-blk"><h4><span class="ic"></span>配置要求<span class="cnt">暂无数据</span></h4>
        <div class="d-req-empty">源站与 Steam 官方接口都<b>没有这款游戏的配置要求</b>（多为独立小游戏 / 未上架 Steam 的作品）。</div>
        <div class="d-hint2">多为独立小游戏 / 未上架 Steam 的作品。可到
          <a href="${esc(d.url || '#')}" target="_blank" rel="noopener">源站详情页</a> 或
          <a href="https://store.steampowered.com/search/?term=${encodeURIComponent(String(d.title || '').split('/')[0])}" target="_blank" rel="noopener">Steam 商店</a> 自行核对。</div></div>`;
      return;
    }
    const srcLabel = j.src === 'jidi' ? '机地' : 'Steam 官方';
    const cols = reqCol('最低配置', j.min) + reqCol('推荐配置', j.rec, 'rec');
    slot.innerHTML = `<div class="d-blk"><h4><span class="ic"></span>配置要求<span class="cnt">${srcLabel}</span></h4>
      <div class="d-req">${cols}</div>
      <div class="d-hint2">数据来自 <b>${srcLabel}</b>${j.name ? '（' + esc(j.name) + '）' : ''}，为 <b>PC(Windows)</b> 端配置；
        想在<b>手机</b>上跑请看上一块「手机模拟器配置」。</div></div>`;
  } catch (e) {
    slot.innerHTML = '';
  }
}

/* ★ v10.29：「修改器 + 云存档」在详情页里是**并排两块**（`#trSvSlot` 两列 grid）。
 *  两块由各自独立的请求回填，谁先回来不确定 ⇒ 每次回填完都调一次本函数。
 *  只有一块有内容时给容器加 `.solo` 收成单列：否则空的那一侧会留出一整列空白，
 *  用户会读成「这块坏了/没数据但还占着位置」。
 *  ⚠️ 判据是 `children.length`（有没有真渲染出 `.d-blk`），不是「#trBlock 存不存在」——
 *     两个槽位节点是 paintDetail 里就写死的，永远存在。 */
function syncPair() {
  const w = $('#trSvSlot');
  if (!w) return;
  const n = [$('#trBlock'), $('#svBlock')].filter((el) => el && el.children.length).length;
  w.classList.toggle('solo', n <= 1);
}

/* 🛠 修改器：这款有没有修改器、来自哪个来源、什么版本 */
async function loadTrBlock(d, title) {
  const slot = $('#trBlock');
  if (!slot) return;
  const t = String(title || (d && d.title) || '').trim();
  if (t.length < 2) return;
  try {
    const j = await fetch(api('/api/trainers/match?t=' + encodeURIComponent(t))).then(r => r.json());
    const items = (j && j.items) || [];
    if (!items.length) { slot.innerHTML = ''; return; }             // 无收录就不占版面
    /* ★ v10.29：上限 8 → 5（用户口径「修改器和云存档同行固定最多5行」）。
       两块的卡头在同一横线上，行数不等会让「最多 5 行」这句话在视觉上不成立。
       ★ v10.31：行外面**套一层 `.d-rows`** —— 只有 1 条来源时，靠它的
       `min-height:calc(var(--d-row-h) * var(--d-rows))` 把卡片撑到五行的高度，
       否则 1 条的卡片会缩成一小块（用户口径「如果一边只有一个那个卡片大小就变小了」）。
       云存档那边同样是 `.d-rows`（它本来就有容器 `.d-sv`，加个类即可）。 */
    const MAXTR = 5;
    const rows = items.slice(0, MAXTR).map((it) => {
      const src = it.source || 'gcm';
      const nm = it.zh || it.name || '';
      return `<div class="d-tr-it"><span class="d-tg ${esc(src)}">${esc(D_TR_SRC[src] || src)}</span>
        <span class="nm" title="${esc(it.name || nm)}">${esc(nm)}</span>
        ${it.version ? `<span class="ver">v ${esc(it.version)}</span>` : ''}</div>`;
    }).join('');
    /* ★ v10.25：原来这里是一句「另有 N 个来源未展示，去手机专区「修改器」页看全部」——
       数据就在**当前这个响应**里（/api/trainers/match 返回全量，没截断），
       直接把整份存进 dFullStore，按钮只带 token。
       ★ v10.29：按钮从「整行」挪到**卡头右上角**（用户口径「其他则为卡片右上角更多按钮查看全部」），
       条数写进按钮（`全部 N`），不必再写「查看全部 N 个来源」那么长。 */
    const more = items.length > MAXTR
      ? dMoreHd(dFullPut({ type: 'tr', title: '修改器 · 全部来源', sub: t, items }), `全部 ${items.length}`)
      : '';
    /* ★ v10.32（第 4 条）：底部提示文案改成**显式三行**。
       用户口径：「修改器跟云存档的底部都预留三行」→ 追问后澄清
       「就是底部文案优化下，我需要他们同高，不是说真预留」。
       ⇒ 要的不是加空白槽位，是**两块底部文案排布一致**。
       实测（xd-692，探针 `_probe-v1032-hint.js`）：两卡已同高（330.4 = 330.4），
       但 hint 一个 **4 行 77.3px**、一个 **3 行 59.9px**，**差 17.3px 正好一整行** ——
       根因是这段比云存档多排了一行，且只有它用 `<br>`、云存档靠自动折行。
       ⇒ 两段统一为「用法 → 注意 → 来源」三行骨架，各 2 个 `<br>`；
         每行控制在 ~25 个全角宽以内（hint 宽 306px ÷ 10.5px ≈ 29 全角），
         保证 306px（最窄的两列）下**每行不折行** ⇒ 两块 hint 恒为 3 行 = 51.975px 文字高，
         上下边同时对齐（`.d-pair .d-hint2{margin-top:auto}` 已把它沉到卡底）。
       ⚠️ 文案长度是**布局约束**，不是随手删字：改长一行 = 那侧变 4 行 = 高度差又回来，
         所以静态断言守 `<br>` 条数、实拍断言守**渲染行数 === 3**（两处都要，缺一处会漏）。 */
    slot.innerHTML = `<div class="d-blk"><h4><span class="ic"></span>修改器<span class="cnt">${items.length} 个来源</span>${more}</h4>
      <div class="d-rows">${rows}</div>
      <div class="d-hint2">文件放到<b>游戏安装根目录</b>（与主程序 .exe 同级）。<br>
        启动前先运行 Cheat Engine，再加载 CE 表格。<br>
        数据来自 Game Cheats Manager，<a href="${D_GCM_URL}" target="_blank" rel="noopener">打开 GCM 下载页 ↗</a></div></div>`;
  } catch (e) {} finally { syncPair(); }
}

/* 💾 云存档：存档文件放哪（用户最想要的答案），路径不截断，直接给可抄的完整串 */
async function loadSvBlock(d, title) {
  const slot = $('#svBlock');
  if (!slot) return;
  const t = String(title || (d && d.title) || '').trim();
  if (t.length < 2) return;
  try {
    const j = await fetch(api('/api/saves/match?t=' + encodeURIComponent(t))).then(r => r.json());
    const h = j && j.hit;
    if (!h) { slot.innerHTML = ''; return; }
    const paths = h.paths || [], regs = h.regs || [];
    if (!paths.length && !regs.length) { slot.innerHTML = ''; return; }
    /* ★ v10.29：行数上限从「路径 3 + 注册表 2」改成**合计最多 5 行**（用户口径
       「修改器和云存档同行固定最多5行，其他则为卡片右上角更多按钮查看全部」）。
       为什么不是继续写死 3+2：路径条数少时会白白空出额度（1 条路径 + 5 条注册表
       照样只显示 3 行）。改成「先给路径、余额给注册表」——
       既守住 5 行上限，也不会浪费；路径优先是因为用户打开这块多半是来抄存档路径的。 */
    const MAXROWS = 5;
    const pTake = Math.min(paths.length, MAXROWS);
    const rTake = Math.min(regs.length, MAXROWS - pTake);
    const rows = [];
    for (const p of paths.slice(0, pTake)) {
      const tg = (p.tags && p.tags.length) ? String(p.tags[0]) : 'save';
      const label = tg === 'save' ? '存档' : (tg === 'config' ? '配置' : tg);
      rows.push(`<div class="p"><i>${esc(label)}</i><span>${esc(p.shown || p.raw)}</span></div>`);
    }
    for (const r of regs.slice(0, rTake)) rows.push(`<div class="p reg"><i>注册表</i><span>${esc(r.raw)}</span></div>`);
    const hidden = (paths.length - pTake) + (regs.length - rTake);
    /* ★ v10.25：同上 —— /api/saves/match 返回的 hit 就是全量，直接整份存进 store。
       ★ v10.29：按钮从「整行」挪到卡头右上角（同 loadTrBlock）。 */
    const more = hidden > 0
      ? dMoreHd(dFullPut({ type: 'sv', title: '云存档位置 · 全部记录', sub: t, hit: h }),
        `全部 ${paths.length + regs.length}`)
      : '';
    const tags = [];
    (h.cloud || []).forEach(c => tags.push(`<span class="d-tg cloud">☁ ${esc(String(c).toUpperCase())}</span>`));
    if (h.phone) tags.push('<span class="d-tg phone">手机能玩</span>');
    if (h.installDir) tags.push(`<span class="d-tg dim">安装目录 ${esc(h.installDir)}</span>`);
    /* ★ v10.32（第 4 条）：与上面「修改器」那段**同骨架的三行**（用法 → 注意 → 来源）。
       原来它是**靠自动折行**排到 3 行的 ⇒ 宽度一变行数就变，两块底部立刻不齐；
       现在显式两个 `<br>` 钉死三行，两块 hint 高度永远相等（各 51.975px 文字高）。 */
    slot.innerHTML = `<div class="d-blk"><h4><span class="ic"></span>云存档位置<span class="cnt">${paths.length + regs.length} 条记录</span>${more}</h4>
      ${tags.length ? `<div class="d-tg-row" style="margin-bottom:6px">${tags.join('')}</div>` : ''}
      <div class="d-rows d-sv">${rows.join('')}</div>
      <div class="d-hint2">路径中的 <code>&lt;用户名&gt;</code> / <code>&lt;平台账号ID&gt;</code> 是占位符。<br>
        按你自己的账号替换；<b>存档前先退出游戏</b>，避免被覆盖。<br>
        数据来自 Ludusavi 开源清单（MIT）。</div></div>`;
  } catch (e) {} finally { syncPair(); }
}

/* 详情内双源互链：机地话题 ↔ XD 版本
 *
 *  ★ v10.14 两处改动：
 *   ① 匹配改用 sameGame()（版本词收敛 + 去标点）—— 旧实现直接比原文，
 *      机地「生化危机4重置版」对不上 XD「生化危机4：重制版」，所以这个区块**几乎总是空的**。
 *   ② 顺带修正底部那个跨源按钮的落点：查到同名 → 指向该条详情页；
 *      查不到 → 保持站内搜索页（渲染时已给），**不再**是写死的站点首页。
 *   匹配结果与 loadBhBlock 共用（resolveCounterpart 只查一次）。
 *
 *  ★ v10.23：取数改走 `/api/library/twin`（精确键），并且**只有真的查到详情页才显示按钮**。
 *    用户口径：「机地找同名 ↗ 我的要求是直接链接到游戏详情页，现在连按钮都点击不了」。
 *    查下来是两个 bug 叠加，都在这一处汇合：
 *      · 取数：按名模糊匹配命中率 3.5%（详见 resolveCounterpart 的注释）
 *      · 显示：`hidden` 属性被 `.go{display:flex}` 压过去 → 按钮一直可见但 href 为空
 *        ⇒ 「点了没反应」。CSS 侧已在全局补 `[hidden]{display:none!important}`。
 *    这条链路补了浏览器实拍断言：按钮**要么不显示，要么 href 必须是指向详情页的绝对地址**。 */
async function linkCounterpart(d, fb) {
  const slot = $('#crossSrc');
  if (!slot || !d || !d.title || !d.source) return;
  const go = $('#crossGo');
  try {
    slot.innerHTML = '<div class="x-none">正在检查另一源收录…</div>';
    /* ★ v10.15：resolveCounterpart 现在只认「另一源**有详情页**」的命中（见那里的注释），
       所以这里不必再区分「详情页 / 搜索页」—— 有 hit 就是详情页，没有就保持按钮隐藏。 */
    const hit = await resolveCounterpart(d, fb);
    if (!hit || !hit.url) {
      slot.innerHTML = '';
      if (go) go.hidden = true;          // 无详情页可跳 → 不显示（用户口径）
      syncDActions();
      return;
    }
    /* ★ v10.23：源名与配色跟着**命中结果**走，不再按当前源反推。
       twin 是后端按精确键算出来的，`hit.source` 就是它的真实归属；
       反推在「当前源判定不准」时会显示成另一个源的名字。 */
    const hitSource = hit.source === 'jidi' ? 'jidi' : 'xdgamer';
    const s = SRC[hitSource] || { nm: 'XDGAME', cls: 'xd' };
    /* 底部按钮改指「这款游戏在另一源的详情页」 */
    if (go) {
      go.setAttribute('href', hit.url);
      go.className = 'go ' + s.cls;
      go.textContent = `前往${s.nm}详情 ↗`;
      go.hidden = false;
    }
    syncDActions();
    /* ⚠️ 这个变量原名就叫 `fb`，与本函数的参数 `fb` 撞名 ——
       `const` 重复声明会直接 SyntaxError，整段脚本不执行（详情页连基础渲染都没了）。
       改名为 cpFb：它是「跳过去的那个条目」的回传快照，与进入本页时的 fb 不是一回事。 */
    const cpFb = encodeURIComponent(JSON.stringify({
      id: hit.id || '', title: hit.title, cover: hit.cover || '', score: okScoreV(hit.score) ? hit.score : null,
      size: hit.size || '', genres: (hit.genres || []).slice(0, 4), dateLabel: hit.dateLabel || '',
      /* v10.22：跨源跳转进详情后，下载弹窗也要能取双源。
         ★ v10.23 修正取值口径：目标是机地 → 机地详情页就是 hit.url；
           目标是 XD → 机地详情页是**当前这一页**（d.url 本来就是机地详情页）。 */
      jidiUrl: hitSource === 'jidi' ? hit.url : (d.source === 'jidi' ? d.url : ''),
    }));
    slot.innerHTML = `<div class="block" style="margin-bottom:12px"><h4><span class="ic" style="background:linear-gradient(135deg,#E6415D,#0B7BFF)"></span>另一源也有收录
        <a href="${esc(hit.url || '#')}" target="_blank" rel="noopener" style="margin-left:auto;font-size:11px;font-weight:700;color:var(--c-t3);text-decoration:none">去源站 ↗</a></h4>
      <div class="x-src"><button class="x-it" onclick="openDetail('${esc(hit.url)}','${cpFb}',detailFromSearch)">
        <span class="src-badge ${s.cls}">${s.nm}</span><span class="bd"><span class="t">${esc(hit.title)}</span></span>
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
      </button></div></div>`;
  } catch (e) { slot.innerHTML = ''; if (go) go.hidden = true; syncDActions(); }
}
/** 底部动作区：列数与显隐跟着「实际可见的按钮数」走。
 *  ★ v10.15 为什么必须有它：跨源按钮要等另一源查完才知道显不显示，
 *    而 .d-actions 是 2 列网格 —— 只剩一个按钮时会空掉右半边。
 *    同时兜住「本条目没有 d.url」的情况：两个按钮都不可见时整块收起，
 *    不留一条空的分隔线。 */
function syncDActions() {
  const box = $('.d-actions');
  if (!box) return;
  const n = $$('.d-actions > a.go').filter((a) => !a.hasAttribute('hidden')).length;
  box.classList.toggle('one', n <= 1);
  box.style.display = n ? '' : 'none';
}
/* ================= 📥 合并下载弹窗（v10.45 新增） =================
 * 用户口径：
 *   ①「部分游戏并未匹配：比如 The Elder Scrolls V: Skyrim Special Edition，他有 Mod/存档等，
 *      但是在手机专区中点击查看游戏详情页并没有下载存档/修改器/Mod 等功能」
 *   ②「我认为可以将下载弹窗合并成一个，并分模块展示即可（本体/mod/修改器/存档）」
 *   ③ 追问后拍板：底部只留一个「⬇ 下载与资源」按钮；存档卡片留按钮、点开合并弹窗的「存档」模块
 *
 * ★ 根因（不是版式问题，是**取数路径**问题）：
 *   旧版的底部按钮条把「修改器 / Mod」的**条数**当作 `hidden` 的开关，而那份条数
 *   **只从 /api/download 的 dlSecs 推**。XD 对部分游戏要求登录才给网盘地址
 *   （实测 Skyrim SE `id=2765` 的 8 个盘口全返回「源站要求登录 / 权限」，`real:0`）
 *   ⇒ `dlSecs` 为空 ⇒ 三个按钮全 hidden ⇒ 用户**连「这款游戏有 60 条 Mod」都看不到**。
 *   而数据一直在：`/api/mods/match?t=…` 返回 60 条、`/api/saves/match` 有命中。
 *   ⇒ 修法是**把入口与条数解耦**：入口无条件可见；四个模块各自取数、各自计数、
 *     各自给空态说明（XD 需登录只影响「本体」一块，不再连坐其它三块）。
 *
 * ★ 四个模块**不是四个数据源的一一映射**，是「用户想拿什么」的四类：
 *   本体    → /api/download（XD 官方盘口 + 机地「本体」专区的社区帖，要跟随 302 解析）
 *   Mod     → /api/mods/match?kind=mod        （机地社区帖，带网盘直链）
 *   修改器  → /api/mods/match?kind=modifier   （社区帖，能取件）
 *             + /api/trainers/match            （GCM 元数据，**没有下载地址**，单独一段）
 *   存档    → /api/saves-yx/match             （游侠存档区，**可下载的存档包**：真直链 + 网盘 + eD2K）
 *             + /api/saves/match               （Ludusavi 路径库，给的是「放哪」不是「下什么」）
 *   ★ v10.46 用户口径：「存档我需要的是文件，而不是文件位置，位置则在存档的右上角点击弹窗查看」。
 *     所以**两条线都取，但只把「文件」铺在主区**；「位置」降级为右上角按钮 → #svLoc 二级弹窗。
 *     两条线必须分别请求、分别判空 —— 位置拿不到 ≠ 文件拿不到，空态文案完全不同。
 *   ⚠️「修改器」模块里两段数据的性质完全不同（一个能点、一个不能），所以视觉上必须分开，
 *      否则用户会把 GCM 的来源名当成下载按钮（旧版 `#trBlock` 就是纯文字列表，不带链接）。
 *
 * ★ 惰性加载：只加载**当前页签**。但 Mod / 修改器 / 存档三个走本地索引（毫秒级），
 *   所以在打开的瞬间就并行发出去，让页签上的条数尽快填上 —— 最贵的 `/api/download`
 *   （XD 逐个跟随 302，3-8 秒）留给「本体」页签按需取。
 *   页签条数未回来时显示 `·` 而不是 `0`：`0` 是结论，`·` 是「还不知道」，不能混。
 */
const DL_UNI = [
  { k: 'body', nm: '本体', ic: '📦' },
  { k: 'mod', nm: 'Mod', ic: '🧩' },
  { k: 'modifier', nm: '修改器', ic: '🛠' },
  { k: 'save', nm: '存档', ic: '💾' },
];
const DL_UNI_KEYS = DL_UNI.map((m) => m.k);
/** 当前合并弹窗的会话状态。`null` = 弹窗不是合并模式（查看全部 / 三专区全部）。
 *  换游戏 / 关弹窗都会作废 —— 否则会出现「新游戏点开看到上一款的 Mod 清单」。 */
let dlUni = null;

/** 页签条（只有合并模式才有内容；其它复用 #dlPop 外壳的弹窗保持隐藏） */
function dlUniTabs() {
  const box = $('#dlModTabs');
  if (!box) return;
  if (!dlUni) { box.hidden = true; box.innerHTML = ''; return; }
  box.hidden = false;
  box.innerHTML = DL_UNI.map((m) => {
    const n = dlUni.cnt[m.k];
    /* 未回来给 `·`，回来了才给数字 —— `0` 是结论（真的没有），`·` 是还不知道 */
    const badge = (n === undefined || n === null) ? '·' : String(n);
    return `<button type="button" class="dlm${dlUni.tab === m.k ? ' on' : ''}" data-dlm="${m.k}">` +
      `${m.ic} ${m.nm}<i>${esc(badge)}</i></button>`;
  }).join('');
}

/** 切模块：只改状态再重绘（数据已缓存在 dlUni.data 里，不重复取数） */
function dlGoModule(k) {
  if (!dlUni || !DL_UNI_KEYS.includes(k) || dlUni.tab === k) return;
  dlUni.tab = k;
  dlUniTabs();
  dlUniPane();
}

/** 画当前模块：先出加载态（或缓存内容），再按需取数 */
function dlUniPane() {
  if (!dlUni) return;
  const k = dlUni.tab;
  const st = dlUni;
  const d = st.data[k];
  /* ★ v10.46：`#dlFoot` 是所有模块共用的页脚节点，每次换页签先清空 ——
     否则「存档」页脚那句「其中 N 条没能解析出下载通道」会跟到「本体」页签上，
     变成一条和当前内容无关的提示（共享节点必须先清后写）。 */
  $('#dlFoot').innerHTML = '';
  if (d === undefined) {
    $('#dlBody').innerHTML = '<div class="emu-loading">正在读取' +
      DL_UNI.find((m) => m.k === k).nm + '…</div>';
    dlUniLoad(k);
    return;
  }
  if (k === 'body') { dlUniPaintBody(d); return; }
  if (k === 'mod' || k === 'modifier') { dlUniPaintMod(d, k); return; }
  dlUniPaintSave(d);
}

/** 取数（每个模块只取一次；失败也记进 data，切回来能看到原因而不是无限转圈） */
async function dlUniLoad(k) {
  const st = dlUni;
  if (!st || st.data[k] !== undefined || st.busy[k]) return;
  st.busy[k] = true;
  try {
    if (k === 'body') {
      const d = await dlUniFetchBody(st.ctx);
      st.data.body = d;
      st.cnt.body = d.links;
    } else if (k === 'mod' || k === 'modifier') {
      const [community, gcm] = await Promise.all([
        dlUniFetchMods(st.ctx, k),
        k === 'modifier' ? dlUniFetchGcm(st.ctx) : Promise.resolve([]),
      ]);
      st.data[k] = { community, gcm };
      st.cnt[k] = community.count + gcm.length;
    } else {
      /* ★ v10.46：存档 = 两条线并行取（文件 / 位置），互不阻塞 ——
         某一条挂了另一条照样能画，不会出现「文件接口慢就把整页卡在加载态」。 */
      const [files, loc] = await Promise.all([
        dlUniFetchSaveFiles(st.ctx),
        dlUniFetchSaveLoc(st.ctx),
      ]);
      st.data.save = { files, loc };
      /* 页签角标只认**文件数**：模块主区就是文件，把位置条数加进来会 over-claim
         （用户看到「12」点进去只有 2 个能下载，剩下 10 条是路径） */
      st.cnt.save = files.count;
    }
  } catch (e) {
    st.data[k] = { error: String((e && e.message) || e) };
  } finally {
    st.busy[k] = false;
  }
  /* 只在「还是同一次会话」且「用户没切走」时才重绘 —— 否则会把用户刚切的页签覆盖掉 */
  if (dlUni === st) { dlUniTabs(); if (st.tab === k) dlUniPane(); }
}

/** 反查端游库条目（只有 libId / 标题时用）—— 从存档卡片进来时 ctx 里没有 url。
 *  ⚠️ 必须做这一步：否则「本体」页签会把「我们没查」显示成「这条没有源站详情页」，
 *     同一个空态背后是两件完全不同的事（有详情页但没查 vs 真的没有）。 */
async function dlUniResolveItem(ctx) {
  if (ctx.id) {
    try {
      const j = await fetch(api('/api/library/item?id=' + encodeURIComponent(ctx.id))).then((r) => r.json());
      if (j && j.ok && j.item) return j.item;
    } catch (e) { /* 落到按名检索 */ }
  }
  if (ctx.title) {
    try {
      const j = await fetch(api('/api/library?q=' + encodeURIComponent(ctx.title) + '&limit=1')).then((r) => r.json());
      if (j && j.ok && (j.items || []).length) return j.items[0];
    } catch (e) { /* 放弃，退回空态 */ }
  }
  return null;
}

/** ① 本体：`/api/download`。只保留「本体」专区 —— Mod / 修改器有自己的模块，
 *  且那边走 /api/mods/match（本地索引，覆盖更全），没必要把同一批帖渲染两遍。 */
async function dlUniFetchBody(ctx) {
  if (!ctx.url) {
    const it = await dlUniResolveItem(ctx);
    if (it) { ctx.url = it.url || ''; ctx.jidi = it.jidiUrl || ctx.jidi; }
  }
  const isJidi = (u) => /jidiyouxi\.com/.test(String(u || ''));
  const jobs = [];
  if (ctx.url) jobs.push({ tag: isJidi(ctx.url) ? 'jidi' : 'xd', u: ctx.url });
  if (ctx.jidi && ctx.jidi !== ctx.url && !jobs.some((j) => j.u === ctx.jidi)) jobs.push({ tag: 'jidi', u: ctx.jidi });
  if (!jobs.length) return { links: 0, posts: 0, xdItems: [], secs: [], noSrc: true, blocked: {} };
  const res = await Promise.all(jobs.map((j) => {
    /* 详情页打开时 loadDlBlock 已经把这份取回来了 → 秒开，不必再跑一次 302 解析。
       ⚠️ 必须比 url：换一款游戏后 dlPre 指向上一款，用错会把别人的资源帖画进来。 */
    if (dlPre && dlPre.url === j.u && dlPre.data && dlPre.data.ok) {
      return Promise.resolve({ tag: j.tag, d: dlPre.data });
    }
    return fetch(api('/api/download?url=' + encodeURIComponent(j.u)))
      .then((r) => r.json()).then((d) => ({ tag: j.tag, d }))
      .catch((e) => ({ tag: j.tag, d: { ok: false, error: e.message } }));
  }));
  const good = res.filter((x) => x.d && x.d.ok);
  const xd = good.find((x) => x.tag === 'xd');
  const ji = good.find((x) => x.tag === 'jidi');
  const xdItems = xd ? (xd.d.items || []).filter((i) => i.real) : [];
  const jiAll = ji ? (ji.d.items || []).filter((i) => i.real) : [];
  /* 服务端给 sections 就是权威分区；没有 sections（老服务）时把条目当「本体」一块，
     行为与改造前一致 —— 不能让新增的模块划分把「本来能显示的链接」变成空白。 */
  const rawSecs = (ji && Array.isArray(ji.d.sections) ? ji.d.sections.filter((s) => s && s.key) : []);
  let secs = [];
  if (rawSecs.length) {
    secs = rawSecs.filter((s) => s.key === 'body')
      .map((s) => ({ ...s, items: jiAll.filter((i) => i.section === s.key) }))
      .filter((s) => s.items.length);
  } else if (jiAll.length) {
    secs = [{ key: 'body', name: '本体', count: jiAll.length, returned: jiAll.length, merged: false, items: jiAll }];
  }
  const links = xdItems.length + secs.reduce((n, s) => n + s.items.length, 0);
  return {
    links,
    posts: secs.reduce((n, s) => n + dlGroupByPost(s.items).length, 0),
    xdItems, secs,
    head: good.map((x) => x.d.title).filter(Boolean)[0] || '',
    sub: good.map((x) => x.d.version || x.d.subtitle).filter(Boolean)[0] || '',
    topicUrl: (ji && ji.d.url) || 'https://jidiyouxi.com/',
    /* 全军覆没时要把「为什么」带出来（源站要登录 / 解析失败是两种完全不同的处置） */
    blocked: {
      xd: (xd && !xdItems.length) ? xd.d : null,
      ji: (ji && !jiAll.length) ? ji.d : null,
    },
    noGood: !good.length,
  };
}

/** ② Mod / 修改器：`/api/mods/match`（机地社区帖，带网盘直链） */
async function dlUniFetchMods(ctx, kind) {
  const qs = [];
  if (ctx.id) qs.push('id=' + encodeURIComponent(ctx.id));
  if (ctx.title) qs.push('t=' + encodeURIComponent(ctx.title));
  qs.push('kind=' + kind, 'limit=' + D_MOD_CAP);
  const j = await fetch(api('/api/mods/match?' + qs.join('&'))).then((r) => r.json());
  const items = (j && j.items) || [];
  return { items, count: (j && j.count) || items.length, error: (j && j.error) || null };
}

/** ②b 修改器模块的第三方段落：Game Cheats Manager 元数据（**没有下载地址**） */
async function dlUniFetchGcm(ctx) {
  const t = String(ctx.title || '').trim();
  if (t.length < 2) return [];
  try {
    const j = await fetch(api('/api/trainers/match?t=' + encodeURIComponent(t))).then((r) => r.json());
    return (j && j.items) || [];
  } catch (e) { return []; }
}

/** ③a 存档**文件**：`/api/saves-yx/match`（游侠补丁网存档区）
 *  回的是 `{count, items[]}`，每条带 `files.direct / netdisk[] / ed2k / thunder`。
 *  ★ 与 ③b 的位置是**两个源、两个口径**，后端也没合并（见 server.js 注释），前端同样分开取。 */
async function dlUniFetchSaveFiles(ctx) {
  const t = String(ctx.title || '').trim();
  const id = String(ctx.id || '').trim();
  if (!t && !id) return { count: 0, items: [] };
  try {
    const j = await fetch(api('/api/saves-yx/match?t=' + encodeURIComponent(t) +
      '&id=' + encodeURIComponent(id))).then((r) => r.json());
    return { count: (j && j.count) || 0, items: (j && j.items) || [] };
  } catch (e) {
    /* 失败要如实回给画布（`error`）——否则会退化成「这款游戏没有存档」这种假结论 */
    return { count: 0, items: [], error: String((e && e.message) || e) };
  }
}

/** ③b 存档**位置**：`/api/saves/match`（哨兵：给的是「放哪」，不是「下什么」）
 *  只喂给右上角的 #svLoc 弹窗，不进主区。 */
async function dlUniFetchSaveLoc(ctx) {
  const t = String(ctx.title || '').trim();
  if (t.length < 2) return null;
  try {
    const j = await fetch(api('/api/saves/match?t=' + encodeURIComponent(t))).then((r) => r.json());
    return (j && j.hit) || null;
  } catch (e) { return null; }
}

/** 打开合并下载弹窗。
 *  @param {{title?:string, sub?:string, url?:string, jidi?:string, id?:string, tab?:string}} ctx
 *    tab —— 直接落到哪个模块（存档卡片进来时给 'save'） */
function openUniDownload(ctx) {
  const pop = $('#dlPop');
  if (!pop) return;
  const o = ctx || {};
  const tab = DL_UNI_KEYS.includes(o.tab) ? o.tab : 'body';
  dlUni = {
    ctx: {
      title: String(o.title || '').trim(),
      sub: String(o.sub || '').trim(),
      url: String(o.url || '').trim(),
      jidi: String(o.jidi || '').trim(),
      id: String(o.id || '').trim(),
    },
    tab, cnt: {}, data: {}, busy: {},
    /* ★ v10.46：存档文件列表的展开态（默认截断到 SVF_CAP 条）。
       挂在会话对象上 ⇒ 换游戏 / 关弹窗自动重置，不会「上一款展开过、这一款也全铺」。
       注意各模块自带的展开态位置不同：本体在 `dlView.all`（那是 paintDownload 的状态）。 */
    svfAll: false,
  };
  const nm = splitName(dlUni.ctx.title);
  $('#dlTitle').textContent = nm.zh || dlUni.ctx.title || '下载与资源';
  $('#dlSub').textContent = dlUni.ctx.sub || '本体 / Mod / 修改器 / 存档';
  pop.hidden = false;
  requestAnimationFrame(() => pop.classList.add('on'));
  dlUniTabs();
  dlUniPane();
  /* 便宜的三个先并行发出（本地索引，毫秒级）—— 页签上的数字尽早填上。
     最贵的 /api/download 交给「本体」页签按需取。 */
  for (const k of ['mod', 'modifier', 'save']) dlUniLoad(k);
}

/* ---------- 各模块的正文渲染 ---------- */
/** 本体：整块复用现有 `dlView` + `paintDownload()` —— 排序 / 盘口筛选 / 展开全部
 *  那套交互一行都不用重写，只是把 `secs` 限制在「本体」一块。 */
function dlUniPaintBody(d) {
  const body = $('#dlBody');
  if (!d || d.error) {
    body.innerHTML = '<div class="dlpop-empty">读取失败：' + esc((d && d.error) || '未知错误') +
      '<br><span style="font-size:11.5px">稍后重试</span></div>';
    return;
  }
  if (d.noSrc) {
    body.innerHTML = '<div class="dlpop-empty">这一条没有源站详情页<br>' +
      '<span style="font-size:11.5px">本体下载要跟着源站页面解析，没有详情页就没有出口；' +
      'Mod / 修改器 / 存档 不受影响，点上面的页签看</span></div>';
    return;
  }
  if (!d.xdItems.length && !d.secs.length) {
    const blocks = [];
    if (d.blocked.xd) blocks.push(dlBlocked('XDGAME 官方盘口', 'xd', 'XD', d.blocked.xd));
    if (d.blocked.ji) blocks.push(dlBlocked('机地社区分享', 'jidi', '机地', d.blocked.ji));
    body.innerHTML = '<div class="dl-note">这款游戏暂时<b>没有可直接打开的网盘地址</b>，下面是原因与出口</div>' +
      (blocks.length ? blocks.join('')
        : '<div class="dlpop-empty">这些条目在源站也可能只是话题、尚无资源帖' +
          '<br><span style="font-size:11.5px">Mod / 修改器 / 存档 请点上面的页签</span></div>');
    return;
  }
  const sec = {};
  for (const s of d.secs) sec[s.key] = { all: false };
  if (d.xdItems.length) sec.xd = { all: false };
  const jiItems = d.secs.reduce((a, s) => a.concat(s.items), []);
  dlView = {
    sort: 'hot', filt: '',
    tab: d.secs.some((s) => s.key === 'body') ? 'body' : (d.xdItems.length ? 'xd' : ''),
    xdItems: d.xdItems, jiItems,
    items: d.xdItems.concat(jiItems),
    secs: d.secs, sec,
    topicUrl: d.topicUrl,
  };
  paintDownload();
}

/** 社区帖行（Mod / 修改器共用；与旧 openModList 的行版式一致） */
function dlModRowsHtml(items, kind) {
  const M = D_MOD_META[kind];
  return items.map((it) => {
    const nets = [...new Set((it.links || []).map((l) => l.kind).filter(Boolean))].slice(0, 3).join(' / ');
    const cn = (it.links || []).length;
    const when = it.ut ? new Date(it.ut * 1000).toISOString().slice(0, 10) : '';
    const meta = [nets || '', cn ? cn + ' 个直链' : '未见直链', when].filter(Boolean).join(' · ');
    return '<a class="d-dl-it" href="' + esc(it.url || D_JIDI_MODS) + '" target="_blank" rel="noopener">' +
      '<span class="k' + (kind === 'modifier' ? ' mf' : '') + '">' + esc(M.nm) + '</span>' +
      '<span class="bd"><span class="t" title="' + esc(it.title || '') + '">' + esc(it.title || '') + '</span>' +
      '<span class="m">' + esc(meta) + '</span></span>' +
      '<span class="go">打开帖子 ↗</span></a>';
  }).join('');
}

function dlUniPaintMod(d, kind) {
  const body = $('#dlBody');
  const M = D_MOD_META[kind];
  const nm = splitName(dlUni.ctx.title).zh || dlUni.ctx.title || '';
  if (!d || d.error) {
    body.innerHTML = '<div class="dlpop-empty">读取失败：' + esc((d && d.error) || '未知错误') + '</div>';
    return;
  }
  const c = d.community || { items: [], count: 0 };
  const out = [];
  /* 模块说明先摆出来：「修改器」与「Mod」的风险差异是用户决策要用到的信息 */
  if (M.hint) out.push('<div class="dl-note" style="margin:0 0 8px">' + esc(M.hint) + '</div>');
  if (!c.items.length) {
    out.push('<div class="dlpop-empty">这款游戏在机地社区没有收录 ' + M.nm +
      '<br><span style="font-size:11.5px">可以点下面的按钮到机地 MOD / 修改器区自己搜</span></div>');
  } else {
    out.push('<div class="dl-note">机地社区共 <b>' + c.count + '</b> 条 ' + M.nm +
      ' 帖（本页铺 ' + c.items.length + ' 条）· 点任意一条去源站帖子取件</div>');
    out.push(dlModRowsHtml(c.items, kind));
    if (c.count > c.items.length) {
      out.push('<div class="dl-note" style="margin:10px 0 0">另有 ' + (c.count - c.items.length) +
        ' 条未展示，去机地搜「' + esc(nm) + '」看全部</div>');
    }
  }
  /* 修改器模块的第三方段落：GCM 元数据**没有下载地址**，与「能点开的社区帖」视觉上必须分开 */
  if (kind === 'modifier' && (d.gcm || []).length) {
    out.push('<div class="dl-gcm"><div class="dl-note">另有 <b>' + d.gcm.length +
      '</b> 个第三方修改器来源（Game Cheats Manager 元数据，<b>不含下载地址</b>，仅供确认「有没有 / 什么版本」）' +
      ' · <a href="' + D_GCM_URL + '" target="_blank" rel="noopener">打开 GCM 下载页 ↗</a></div>' +
      d.gcm.map((it) => {
        const src = it.source || 'gcm';
        const nmz = it.zh || it.name || '';
        const en = (it.name && it.name !== nmz) ? it.name : '';
        const meta = [en, it.version ? 'v ' + it.version : ''].filter(Boolean).join(' · ');
        return '<div class="df-row"><span class="ix">·</span><span class="bd">' +
          '<span class="t"><span class="tagx">' + esc(D_TR_SRC[src] || src) + '</span>' + esc(nmz) + '</span>' +
          (meta ? '<span class="m">' + esc(meta) + '</span>' : '') + '</span></div>';
      }).join('') + '</div>');
  }
  out.push('<div class="d-dl-links">' + dModLinks() + '</div>');
  body.innerHTML = out.join('');
}

/** 存档文件一次最多铺几张。
 *  ★ 为什么必须截断：实测单款最多 **215 条**（鬼谷八荒 —— 这游戏存档区就是火，全是真命中，
 *    不是误配），全铺的话光 DOM 就 150KB+。与「本体」模块的 `D_MOD_CAP = 60` 同一套思路。
 *  ★ 截断必须**明说并给出口**（本项目铁律：不许静默丢条）—— 页面顶部仍显示真实总数。 */
const SVF_CAP = 20;

/** 网盘通道的显示名。**顺序即优先级**（`netdisk` 数组本身已按源站给的顺序），
 *  未登记的 kind 不丢 —— 退回「<kind> 网盘」，避免新通道静默消失。 */
const SVF_ND = {
  xunlei: '迅雷云盘', thunder_pan: '迅雷云盘', quark: '夸克网盘', baidu: '百度网盘',
  aliyun: '阿里云盘', aliyundrive: '阿里云盘', uc: 'UC 网盘', '123pan': '123 云盘', lanzou: '蓝奏云',
};
/** 源站标题里的运营后缀，展示时剥掉（「…下载_游侠网」→「…」）—— 只用于显示，不改数据 */
const svfTitle = (x) => String(x.title || x.game || '').replace(/_游侠网$/, '').replace(/下载$/, '').trim();

/** 单条存档**文件**卡：标题 + 大小 + 通道按钮组。
 *  ★ 通道按钮里**必须有一个主按钮**（直链优先），否则用户在 5 个网盘里挑不出该点哪个。
 *  ★ 全部通道都没有时给「去源站页面取」出口 —— 不静默丢条（文件解析失败的那批就靠这条兜）。 */
function svfCard(x) {
  const f = x.files || {};
  const ks = [];
  if (f.direct) ks.push('<a class="pri" href="' + esc(f.direct) + '" target="_blank" rel="noopener">⬇ 直接下载</a>');
  (f.netdisk || []).forEach((n) => {
    ks.push('<a href="' + esc(n.url) + '" target="_blank" rel="noopener">' +
      esc(SVF_ND[n.kind] || (String(n.kind || '') + ' 网盘')) + ' ↗</a>');
  });
  if (f.thunder) ks.push('<a href="' + esc(f.thunder) + '">迅雷链接</a>');
  if (f.ed2k) ks.push('<a href="' + esc(f.ed2k) + '">eD2K 链接</a>');
  if (!ks.length) ks.push('<a class="pri" href="' + esc(x.sourceUrl || '') + '" target="_blank" rel="noopener">去源站页面取 ↗</a>');
  const meta = [x.date, x.matchHow === 'bracket' ? '书名号匹配' : (x.matchHow === 'prefix' ? '前缀匹配' : '')]
    .filter(Boolean).join(' · ');
  return '<div class="svf"><div class="h"><span class="nm">' + esc(svfTitle(x) || '存档文件') + '</span>' +
    (x.size ? '<span class="sz">' + esc(x.size) + '</span>' : '') + '</div>' +
    (f.fileName ? '<div class="m">文件 <code>' + esc(f.fileName) + '</code></div>' : '') +
    '<div class="m">' + esc(meta) + (x.id ? ' · 源站条目 #' + esc(x.id) : '') + '</div>' +
    '<div class="k">' + ks.join('') + '</div></div>';
}

/** 存档模块：主区 = **可下载的文件**（v10.46 起）。
 *  位置不再铺在这里 —— 收进右上角「📍 存档位置」按钮 → #svLoc 弹窗（可复制）。
 *  ★ 位置入口**无论有没有文件都要在**：反过来的话，没文件的游戏上「位置」会凭空消失，
 *    而用户恰恰是在「下不到文件」时最想去看本机存档在哪。 */
function dlUniPaintSave(d) {
  const body = $('#dlBody');
  const files = (d && d.files) || { count: 0, items: [] };
  const loc = (d && d.loc) || null;
  const items = files.items || [];
  const locN = loc ? ((loc.paths || []).length + (loc.regs || []).length) : 0;
  const out = [];
  out.push('<div class="dl-sv-head"><span class="t">💾 存档文件 <b>' + items.length + '</b> 个</span>' +
    '<button class="dl-sv-loc" type="button" data-dl-svloc="1">📍 存档位置' +
    (locN ? '（' + locN + '）' : '') + '</button></div>');
  if (!items.length) {
    out.push('<div class="dlpop-empty">' +
      (files.error ? '存档文件索引读取失败：' + esc(files.error)
        : '游侠补丁网的存档区里没有这款游戏的可下载存档') +
      '<br><span style="font-size:11.5px">存档区按游戏名匹配，冷门 / 新发售的游戏可能还没人上传；' +
      '也可以点右上角看<b>本机存档位置</b>，或去存档库按名搜</span></div>');
    out.push('<div class="d-dl-links">' +
      '<a href="https://patch.ali213.net/showclass/class5_1.html" target="_blank" rel="noopener">游侠存档区 ↗</a>' +
      '<a href="/resources.html#sv">存档库</a></div>');
    body.innerHTML = out.join('');
    return;
  }
  out.push('<div class="dl-note">来源 <b>游侠补丁网 · 存档区</b>。' +
    '「直接下载」是源站文件直链，<b>免登录、免网盘客户端</b>；网盘 / 迅雷 / eD2K 是同一份文件的备用通道，' +
    '哪个通用哪个。<b>覆盖前先退出游戏并备份原存档</b>。</div>');
  const all = !!(dlUni && dlUni.svfAll);
  const shown = all ? items : items.slice(0, SVF_CAP);
  out.push('<div class="dl-svf-list">' + shown.map((x) => svfCard(x)).join('') + '</div>');
  /* 展开 / 收起（与「本体」模块的 `data-dl-all` 同款交互：数据已在手上，不再发请求） */
  if (items.length > SVF_CAP) {
    out.push('<div class="d-dl-links">' + (all
      ? '<button type="button" class="dl-more" data-dl-svf="less">收起，只看前 ' + SVF_CAP + ' 条</button>'
      : '<button type="button" class="dl-more" data-dl-svf="all">展开全部 ' + items.length +
        ' 条（已显示前 ' + SVF_CAP + ' 条）</button>') + '</div>');
  }
  /* 页脚只在这一屏有额外信息时才写 —— 空话不写（`.dlpop-f` 是共享节点，
     不主动清空会把上一次「本体」模块的页脚留在存档页上） */
  const noFile = items.filter((x) => !(x.files && (x.files.direct || (x.files.netdisk || []).length ||
    x.files.ed2k || x.files.thunder))).length;
  $('#dlFoot').innerHTML = noFile
    ? '其中 <b>' + noFile + '</b> 条没能解析出下载通道（源站改版或着陆页异常），已给出「去源站页面取」出口，未丢弃。'
    : '';
  body.innerHTML = out.join('');
}

/** 位置弹窗正文：路径 / 注册表逐条给「复制」。
 *  这一版把原来的 `dlUniPaintSave` 路径渲染整段搬过来 —— 视觉与旧版一致
 *  （`.dl-sv-row` + `.dl-cp`，用户已经认这个版式），只是换了容器。 */
function svLocHtml(h) {
  if (!h) {
    return '<div class="dlpop-empty">Ludusavi 存档清单里没有这款游戏的记录<br>' +
      '<span style="font-size:11.5px">清单只覆盖有公开存档目录约定的游戏；也可能是名称没对上</span></div>' +
      '<div class="d-dl-links"><a href="/resources.html#sv">去存档库按名搜 ↗</a></div>';
  }
  const paths = h.paths || [], regs = h.regs || [];
  const tagOf = (t) => (t === 'config' ? '配置' : (t === 'save' ? '存档' : (t || '存档')));
  const out = [];
  const tags = [];
  (h.cloud || []).forEach((c) => tags.push('<span class="d-tg cloud">☁ ' + esc(String(c).toUpperCase()) + '</span>'));
  if (h.phone) tags.push('<span class="d-tg phone">手机能玩</span>');
  if (h.installDir) tags.push('<span class="d-tg dim">安装目录 ' + esc(h.installDir) + '</span>');
  out.push('<div class="dl-note">共 <b>' + (paths.length + regs.length) + '</b> 条记录 · ' +
    '数据来自 Ludusavi 开源清单（MIT）。路径里的 <code>&lt;用户名&gt;</code> / ' +
    '<code>&lt;平台账号ID&gt;</code> 是占位符，按自己的账号替换；<b>存档前请先退出游戏</b>。</div>');
  if (tags.length) out.push('<div class="d-tg-row" style="margin:8px 0 2px">' + tags.join('') + '</div>');
  const rows = [];
  paths.forEach((p, i) => {
    const full = p.shown || p.raw || '';
    rows.push('<div class="dl-sv-row"><span class="ix">' + (i + 1) + '</span><span class="bd">' +
      '<span class="tg">' + esc(tagOf((p.tags || [])[0])) + '</span>' +
      '<code>' + esc(full) + '</code></span>' +
      '<button class="dl-cp" type="button" data-dl-copy="' + esc(full) + '">复制</button></div>');
  });
  regs.forEach((r, i) => {
    rows.push('<div class="dl-sv-row"><span class="ix">R' + (i + 1) + '</span><span class="bd">' +
      '<span class="tg">注册表</span><code>' + esc(r.raw || '') + '</code></span>' +
      '<button class="dl-cp" type="button" data-dl-copy="' + esc(r.raw || '') + '">复制</button></div>');
  });
  out.push(rows.length ? '<div class="dl-sv-list">' + rows.join('') + '</div>'
    : '<div class="dlpop-empty">这份记录里只有游戏条目，没有具体的路径</div>');
  return out.join('');
}

/** 打开位置弹窗。数据从 `dlUni.data.save.loc` 取 —— **不在这里重新发请求**，
 *  否则会出现「主区已加载完、位置按钮转圈」这种两套加载态。
 *  ★ 若 `loc` 还没回来（用户点得快），给一次兜底加载并等它。 */
async function openSvLoc() {
  const pop = $('#svLoc');
  if (!pop) return;
  const st = dlUni;
  const nm = (st && st.ctx && st.ctx.title) || '';
  $('#svLocSub').textContent = nm ? (splitName(nm).zh || nm) : '';
  pop.hidden = false;
  requestAnimationFrame(() => pop.classList.add('on'));
  const d = st && st.data && st.data.save;
  if (d === undefined || d === null) {
    $('#svLocBody').innerHTML = '<div class="dlpop-load"><i></i>正在读取存档位置…</div>';
    if (st) {
      await dlUniLoad('save');
      /* ⚠️ dlUniLoad 在「已在加载中」时是**直接 return** 的，不能只 await 它一次就往下画 ——
         那样会把「还在读」误画成「Ludusavi 里没有这款游戏」（假空态，比转圈更糟）。
         所以再显式等 busy 落下（上限约 4.8s，超时就按当前数据画，不无限转）。 */
      for (let i = 0; i < 40 && dlUni === st && st.busy.save; i++) {
        await new Promise((r) => setTimeout(r, 120));
      }
    }
  }
  const now = dlUni === st ? (st.data.save || {}) : {};
  $('#svLocBody').innerHTML = svLocHtml(now.loc || null);
  $('#svLocBody').scrollTop = 0;
}

function closeSvLoc() {
  const pop = $('#svLoc');
  if (!pop || pop.hidden) return;
  pop.classList.remove('on');
  /* 等过渡结束再 hidden，否则 0.2s 的退场动画看不到（与 closeDownload 同款处理） */
  setTimeout(() => { if (!pop.classList.contains('on')) pop.hidden = true; }, 200);
  $('#svLocBody').innerHTML = '';
}
/* 同分类推荐 ★ v10.11：改走后端多因子打分（类型 IDF + 系列名 + 评分接近度 + 容量接近度）
 *
 *  旧做法：取 genres[0] → /api/library/browse?g=…&sort=score → 取 100 条随机洗牌 6 条。
 *  两个致命问题（用户反馈「同分类更多里的游戏不太适配」）：
 *    ① 库里每款游戏**只有一个类型标签**，而「动作冒险」独占 36.8%（5,627 条）
 *       —— 按它取高分再洗牌 = 抽卡，跟当前游戏毫无关系；
 *    ② 标签里混着 `免费专区` / `联机整合` / `模拟器整合` 这类**运营标签**，
 *       它们描述「怎么玩/收不收费」而不是「玩什么」，参与推荐会把风马牛不相及的游戏凑一桌。
 *  现由 /api/library/related 统一打分并返回 why 标签（同系列 / 同类型）。 */
async function loadRelated(d, fb) {
  const slot = $('#relSlot');
  if (!slot || !d) return;
  const g = (d.genres && d.genres.length) ? d.genres[0] : ((fb && fb.genres && fb.genres[0]) || '');
  const t = String(d.title || (fb && fb.title) || '').trim();
  const id = (fb && fb.id) || d.id || '';
  if (!g && !t) { slot.innerHTML = ''; return; }
  try {
    /* ★ v10.31：取 12 条、展示 REL_SHOW 条（用户口径「最好是显示8个」）。
      为什么取数要比展示多：`limit` 是**后端打分返回的条数**，下面还要
      ① 滤掉没有详情页 url 的、② 滤掉与本条同 url 的自身回环；
      只取 8 会让过滤后的实际张数在 5~7 之间跳（实测先前的 6 就是这样来的）。
      ⚠️ 展示数只认 `REL_SHOW` 这一个常量，别再写成裸字面量。 */
    const qs = 'limit=12'
      + (id ? '&id=' + encodeURIComponent(id) : '')
      + (t ? '&t=' + encodeURIComponent(t) : '')
      + (g ? '&g=' + encodeURIComponent(g) : '');
    const j = await fetch(api('/api/library/related?' + qs)).then(r => r.json());
    if (!j || !j.ok) { slot.innerHTML = ''; return; }
    const picks = (j.items || [])
      .filter(it => it && it.url && it.url !== d.url)
      .slice(0, REL_SHOW);
    if (!picks.length) { slot.innerHTML = ''; return; }
    const head = j.genre ? `同分类更多 · ${esc(j.genre)}` : '相似推荐';
    slot.innerHTML = `<div class="block" style="margin-bottom:12px"><h4><span class="ic" style="background:linear-gradient(135deg,#0B7BFF,#6366F1)"></span>${head}</h4>
      <div class="rel-row">${picks.map(it => {
        const fb2 = encodeURIComponent(JSON.stringify({ id: it.id || '', title: it.title, cover: it.cover || '', score: okScoreV(it.score) ? it.score : null, size: it.size || '', genres: (it.genres || []).slice(0, 4), dateLabel: it.dateLabel || '' }));
        const why = (it.why && it.why.length) ? `<span class="why">${esc(it.why[0])}</span>` : '';
        return `<button class="rel-it" onclick="openDetail('${esc(it.url)}','${fb2}',detailFromSearch)">
          ${it.cover ? `<img src="${esc(it.cover)}" loading="lazy" alt="" onerror="this.remove()">` : '<span class="noimg"></span>'}
          <span class="bd"><span class="t">${esc(splitName(it.title).zh)}</span><span class="s">${okScoreV(it.score) ? `<b>★${it.score}</b>` : ''}${why}</span></span>
        </button>`;
      }).join('')}</div></div>`;
  } catch (e) { slot.innerHTML = ''; }
}

/* 📥 下载入口 ★ v10.11 新增 —— 详情页里「云存档等下载链接」缺失的补位
 *
 *  用户口径：「给下载链接的详情页跳转即可（在后面）」→ 只做**跳转入口**：
 *  帖子标题 + 网盘类型 + 直链条数 + 时间，点一下去源站帖子取件。
 *  不铺正文、不复制网盘直链 —— 本站继续是信息聚合站，文件都在源站社区帖里。
 *
 *  ★ 查询必须**同时传 t 与 id**：机地的话题游戏名与端游库标题是两套命名，
 *    只传 id 会漏（同一款游戏的话题可能挂在别的 libId 上），只传名称遇到
 *    「中文/English」拼接串或别名时也会漏。后端 /api/mods/match 做 id ∪ 名称 联合兜底。
 *    另注意：这一块与上面的「🛠 修改器」是**两套数据**，互不替代 ——
 *    上面的 trainers 来自 Game Cheats Manager（英文站元数据，没有下载地址），
 *    这里的 mods 来自机地社区帖（99.9% 带网盘直链，是真能拿到东西的那一套）。 */
const D_JIDI_MODS = 'https://jidiyouxi.com/modify/list';
/* ★ v10.28：详情页的下载区，从「4 条帖子 + 一个『查看全部』弹窗」改成
 *   **三专区预览**（本体 / Mod / 修改器，每块只露前 3 帖），每块的「全部 N 帖」进弹窗按 10 帖/页翻。
 *   用户口径：「本体，修改器，Mod我需要放在最下面，且每个均只展示前三个，
 *             点击全部后弹窗显示全部，弹窗显示十个其他的翻页」。
 *
 *   ★ 数据源随之换了：原来走 `/api/mods/match`（只有 Mod / 修改器两类，**没有本体**），
 *     现在走 `/api/download` —— 它按源站话题专区返回 `items[].section`（body / mod / modifier）
 *     与 `sections[].count`（源站帖数）。顺带把结果缓存进 `dlPre`：点底部「下载本体」按钮时**秒开**，
 *     不必把同一套 XD 302 解析流程再跑一遍（那一次要 3-8 秒）。
 *
 *   ⚠️ 与上面的「🛠 修改器」仍是**两套数据**，别混淆：
 *      #trBlock（/api/trainers/match）= Game Cheats Manager 元数据，**没有下载地址**；
 *      本区块（/api/download）        = 源站社区帖，99.9% 带网盘直链，真能取件。 */
const DL_PREV_CAP = 3;     // ★ v10.28：详情页每个专区只露前 3 帖（预览上限，不是专区上限）
let dlSecs = [];           // 当前详情页的三专区（已归帖）—— 「全部」弹窗直接复用这份
let dlSecTitle = '';
let dlPre = null;          // ★ v10.28：/api/download 的预取结果（供「下载本体」秒开）

/** 把 /api/download 的返回切成「本体 / Mod / 修改器」三专区（每块都已归帖）。
 *  · `sections[].count` 是**源站帖子数**（权威口径，写在标头上 —— 用户看的是「源站有多少帖」）
 *  · `items[].section` 是每条地址的归属（用来分组 —— 本次真正取回多少）
 *  两个都要用；混用会让「22 帖 / 60 个地址」读起来自相矛盾（v10.27 已记过这条）。
 *  ⚠️ XD 源没有专区概念（`kind:'downbtn'`、无 section）⇒ 退成一块，行为与改造前一致 ——
 *     不能让一个新增的分区逻辑，把「本来能显示的链接」变成空白。 */
function dlSecsOf(j) {
  const items = ((j && j.items) || []).filter((i) => i && i.real);
  const raw = Array.isArray(j && j.sections) ? j.sections.filter((s) => s && s.key) : [];
  if (!raw.length) {
    if (!items.length) return [];
    const posts = dlGroupByPost(items);
    return [{
      key: 'all',
      name: (j && j.source === 'xd') ? 'XDGAME 官方盘口' : '下载资源',
      count: posts.length, returned: posts.length, links: items.length, posts, merged: false,
    }];
  }
  const order = ['body', 'mod', 'modifier'];
  const rank = (k) => { const i = order.indexOf(k); return i < 0 ? 99 : i; };
  return raw
    .map((s) => {
      const own = items.filter((i) => i.section === s.key);
      const posts = dlGroupByPost(own);
      return {
        key: s.key, name: s.name || s.key,
        count: Number(s.count) || posts.length,
        returned: Number(s.returned) || posts.length,
        links: own.length,
        merged: !!s.merged,
        posts,
      };
    })
    .filter((s) => s.posts.length)
    .sort((a, b) => rank(a.key) - rank(b.key));   // 固定「本体 → Mod → 修改器」，不依赖服务端顺序
}

/** 一个专区的预览块：标头（名字 + 帖数/地址数）+ 前 DL_PREV_CAP 帖 + 「全部 N 帖 →」。
 *  ⚠️ 帖数不足 cap 时**不给**「全部」按钮 —— 一个点开跟外面一模一样的按钮不如没有。 */
function dlPrevBlock(s) {
  const rows = s.posts.slice(0, DL_PREV_CAP);
  const more = s.posts.length > DL_PREV_CAP;
  const extra = [s.links > s.posts.length ? s.links + ' 地址' : '', s.merged ? '含最近发布' : '']
    .filter(Boolean).join(' · ');
  return `<div class="dl-prev" data-sec="${esc(s.key)}">
    <div class="h"><b>${esc(s.name)}</b><span class="c">${s.posts.length} 帖${extra ? ' · ' + esc(extra) : ''}</span>
      ${more ? `<button type="button" class="dl-all" data-df-open="${esc(s.key)}">全部 ${s.posts.length} 帖 →</button>` : ''}
    </div>
    <div class="l">${rows.map(dlRow).join('')}</div>
  </div>`;
}

async function loadDlBlock(d, fb, title) {
  const slot = $('#dlSlot');
  if (!slot) return;
  const t = String(title || (d && d.title) || (fb && fb.title) || '').trim();
  const u = String((d && d.url) || (fb && fb.jidiUrl) || '').trim();
  dlSecs = []; dlSecTitle = t; dlPre = null;
  /* ★ v10.45：没有源站详情页 ≠ 没有资源 —— Mod / 修改器 / 存档 都不依赖它。
     所以这里给一句说明而不是清空（清空会让整块消失，正是用户反馈的那个观感）。 */
  if (!u) {
    slot.innerHTML = `<div class="d-blk"><h4><span class="ic"></span>下载资源<span class="cnt">无源站页</span></h4>
      <div class="d-hint2" style="border:0;padding-top:2px">这条没有源站详情页，<b>本体</b>取不到；
        但 <b>Mod / 修改器 / 存档</b> 仍可查 —— 点底部「⬇ 下载与资源」。</div></div>`;
    return;
  }
  /* 先占位：/api/download 要跟随 302 逐个解析（XD 约 3-8 秒）。不能什么都不显示 ——
     空白会被读成「这一块功能没了」（v10.13 在手机配置上踩过同款坑）。 */
  slot.innerHTML = `<div class="d-blk"><h4><span class="ic"></span>下载资源（本体 / Mod / 修改器）<span class="cnt">解析中</span></h4>
    <div class="d-hint2" style="border:0;padding-top:2px">正在解析源站网盘地址（需逐个跟随跳转，约 3-8 秒）…</div></div>`;
  let j = null;
  try {
    j = await fetch(api('/api/download?url=' + encodeURIComponent(u))).then((r) => r.json());
  } catch (e) { j = null; }
  if (!j || !j.ok) {
    slot.innerHTML = `<div class="d-blk"><h4><span class="ic"></span>下载资源<span class="cnt">未取到</span></h4>
      <div class="d-hint2">没能解析出网盘地址${(j && j.error) ? '（' + esc(String(j.error)) + '）' : ''}。
        可直接去 <a href="${esc(u)}" target="_blank" rel="noopener">源站帖子</a> 看看。</div></div>`;
    return;
  }
  dlPre = { url: u, data: j };            // 缓存：弹窗「本体」模块秒开，不再解析第二遍
  dlSecs = dlSecsOf(j);
  /* ★ v10.45：整组取不到时**不再 `slot.innerHTML=''` 一走了之**。
     旧写法让整块下载区凭空消失 —— XD 对部分游戏（实测 Skyrim SE id=2765）要求登录，
     8 个盘口全 `real:0` ⇒ dlSecs 为空 ⇒ 用户以为「这款游戏没有下载」，
     而它的 Mod / 存档其实都在。现在给一句实话 + 指出真正的出口。 */
  if (!dlSecs.length) {
    /* ⚠️ 徽标必须跟着**真实原因**走：`items: []`（源站这次没给）与 `needAuth`（要登录）
     *   是两件不同的事，写死成「需登录源站」就是 over-claim ——
     *   用户去登录后照样没有，会以为是站点坏了。 */
    const needAuth = (j.items || []).some((i) => i.needAuth);
    const why = needAuth
      ? '源站要求<b>登录 / 权限</b>才给网盘地址'
      : '源站这次没有返回可直接打开的网盘地址';
    slot.innerHTML = `<div class="d-blk"><h4><span class="ic"></span>下载资源<span class="cnt">${needAuth ? '需登录源站' : '无可用地址'}</span></h4>
      <div class="d-hint2" style="border:0;padding-top:2px">${why} —— <b>只影响「本体」</b>；
        <b>Mod / 修改器 / 存档</b> 与它无关，点底部「⬇ 下载与资源」逐模块看。
        也可以直接去 <a href="${esc(u)}" target="_blank" rel="noopener">源站帖子</a>${needAuth ? ' 登录后取件' : ' 看看'}。</div></div>`;
    return;
  }
  const totalPosts = dlSecs.reduce((n, s) => n + s.posts.length, 0);
  const totalLinks = dlSecs.reduce((n, s) => n + s.links, 0);
  slot.innerHTML = `<div class="d-blk"><h4><span class="ic"></span>下载资源<span class="cnt">${dlSecs.map((s) => esc(s.name) + ' ' + s.posts.length).join(' · ')}</span></h4>
    <div class="d-hint2" style="border:0;padding-top:0">共 <b>${totalPosts}</b> 个资源帖 · <b>${totalLinks}</b> 个网盘地址；每块只露前 ${DL_PREV_CAP} 帖，
      点「全部」看完整清单。网盘按钮直接去源站取件 —— 本站只聚合与跳转，<b>不转存、不提供文件</b>。</div>
    ${dlSecs.map(dlPrevBlock).join('')}
    <div class="d-dl-links">
      <a href="${esc(u)}" target="_blank" rel="noopener">源站帖子 ↗</a>
      <a href="/resources.html#sv">云存档位置库</a>
      <a href="${D_JIDI_MODS}" target="_blank" rel="noopener">机地 MOD / 修改器区 ↗</a>
    </div></div>`;
}
$('#mask').addEventListener('click', closeDetail);

/* ================= 启动 ================= */
async function init() {
  /* bindRankUI：独立页无榜单 UI，跳过 */
  /* renderSide：独立页无右栏，跳过 */
  /* renderCats：独立页无分类行，跳过 */
  /* renderList：独立页无最新收录列表，跳过 */
  refreshRank(false); // 首页主体：热榜（缓存秒显 / 首次拉取）
  // 手机三个分区（社区配置 / 实测配置 / 指南）已拆到 /emulator.html，
  // 首页只保留入口卡（数字由上面的专区跳转块异步回填），此处不再初始化。
  loadStats().then((j) => { if (j && j.ok && j.running) { setBtnsDisabled(true); pollIdx(); } });
  // 离线快照(双击 HTML / 无后端)时降级展示
  try {
    const r = await fetch(api('/api/health'), { signal: AbortSignal.timeout(3500) });
    if (!r.ok) throw 0;
  } catch (e) {
    const snap = window.__SNAPSHOT__;
    if (snap && snap.feedItems) {
      const items = snap.feedItems.filter(i => i.source === 'xdgamer');
      const lib = $('#libList');
      if (lib) lib.innerHTML = items.map(rowCard).join('') || '<div class="empty">快照无 XD 数据</div>';
      bindRowCards(lib);
      const c = $('#listCount'); if (c) c.textContent = `离线快照 · ${items.length} 条`;
    }
    $('#liveTxt').textContent = '快照';
  }
  // URL 直达：?q= 搜索 / ?c= 分类 / ?sort=
  const sp = new URLSearchParams(location.search);
  const qp = sp.get('q'); if (qp && qp.trim()) openSearch(qp.trim()); // 直达：自动打开搜索弹窗并出结果
  const cp = sp.get('c'); if (cp && CATS.includes(cp)) { curCat = cp; renderCats(); renderList(true); }
  const sp2 = sp.get('sort'); if (sp2 && SORTS.some(s => s.k === sp2)) { curSort = sp2; renderCats(); renderList(true); }
  document.documentElement.setAttribute('data-ready', '1');
}
/* ================= 📥 网盘下载弹窗（v10.22 新增） =================
 * 用户口径：「将游戏详情页的跳转链接变成获取到对应游戏的下载链接（弹窗展示，
 *            大部分 XD 都是有多个下载链接，最好是获取到完整的标题）」。
 *
 * 链路：前端 → GET /api/download → fetchers/download.js
 *   · XD   解析详情页 .article-down 的 a.downbtn，再跟随 /plus/download.php 的 302
 *          拿真实网盘地址（实测 6 个盘口全部可解）
 *   · 机地 解析详情页 SSR 的 ssrData.postsMap，抽社区帖正文里的网盘直链
 *   ★ 必须走服务端：这两个源站都没有 CORS 头，前端直连必被浏览器拦；
 *     而且它们对浏览器指纹敏感（见项目抓取经验，node fetch 正常、浏览器会被 403）。
 *
 * ★ 为什么允许「一次取两源」：
 *   同一款游戏在 XD 与机地**不是同一批链接**（XD 是官方盘口，机地是社区分享帖）。
 *   库里 13,448 条 XD 条目已与机地同款合并（带 jidiUrl），所以「⬇ 网盘下载」能
 *   把两侧一起取回来、分两组展示。两个 URL 相同时自动去重，不会重复请求。
 *
 * ★ 不用 Promise.all 直接并发两源也无所谓，但**单个源失败不能拖垮另一个**：
 *   用 allSettled 语义（.catch 成 {ok:false}），一个挂掉另一个照常显示。
 */
const DL_BRAND = [
  [/百度/, 'baidu', '度'], [/天翼|189/, '189', '翼'], [/迅雷/, 'xunlei', '雷'],
  [/夸克|quark/i, 'quark', '夸'], [/移动|139/, '139', '移'], [/阿里|ali/i, 'ali', '阿'],
  [/123/, '123', '12'], [/蓝奏|lanzou/i, 'lanzou', '蓝'], [/pikpak/i, 'pikpak', 'P'],
  [/steam|正版/i, 'steam', '正'], [/uc/i, 'other', 'U'],
];
function dlBrand(s) {
  const t = String(s == null ? '' : s);
  for (const [re, cls, ab] of DL_BRAND) if (re.test(t)) return { cls, ab };
  return { cls: 'other', ab: t.slice(0, 1) || '?' };
}
/** 盘口筛选用的中文名（键与 dlBrand 的 cls 一一对应，别各写一套） */
const DL_BRAND_NAME = {
  baidu: '百度', xunlei: '迅雷', quark: '夸克', '189': '天翼', '139': '移动', ali: '阿里',
  '123': '123', lanzou: '蓝奏', pikpak: 'PikPak', steam: 'Steam', other: '其他',
};
/** 展开态默认铺几行，其余靠「展开全部」（数据已在手上，不再发请求） */
const DL_CAP = 12;
/** 「最热 / 最近发布」—— 与源站话题页右上角那两个排序同名同义 */
const DL_SORTS = [['hot', '最热'], ['new', '最近发布']];

/**
 * 发布时间：近期说相对量，久了给日期。
 * ★ 不复用 humanAgo()：那个是给「上次同步」用的，对半年前的帖子会写出「400 天前」，
 *   放进列表里既占宽又读不出到底是哪个月。
 */
function dlWhen(ts) {
  const n = Number(ts);
  if (!n || !isFinite(n)) return null;
  const d = new Date(n);
  if (isNaN(d.getTime())) return null;
  const mins = Math.round((Date.now() - n) / 60000);
  if (mins < 1) return '刚刚';
  if (mins < 60) return mins + ' 分钟前';
  if (mins < 1440) return Math.round(mins / 60) + ' 小时前';
  const days = Math.round(mins / 1440);
  if (days <= 6) return days + ' 天前';
  const y = d.getFullYear();
  return (y === new Date().getFullYear() ? '' : y + '年') + (d.getMonth() + 1) + '月' + d.getDate() + '日';
}
/** 浏览量：5 位以上折成「5.1万」，否则数字本身 */
function dlNum(n) {
  const v = Number(n) || 0;
  return v >= 10000 ? (v / 10000).toFixed(1).replace(/\.0$/, '') + '万' : String(v);
}

/**
 * **把「一行一个网盘地址」归成「一行一个帖子」**：同一帖的多个盘口并成右侧的按钮组。
 *
 * ★ 为什么非归不可（实测剑星「本体」首屏）：12 个地址其实只来自 **4 个帖子** ——
 *   一帖带 2~3 个盘口。不归的话用户在屏幕上看到的是同一个标题**重复 5 遍**
 *   （「已测试丨风灵月影丨v1.4.1」× 迅雷/百度/夸克/UC/移动），每行只差一个徽标，
 *   这正是他说的「分不清」；而源站话题页本来就是一帖一行、右侧挂三个盘口按钮。
 *
 * ★ 键取 `postId`；XD 那侧没有帖子概念（`kind:'downbtn'` 无 postId）⇒
 *   退到地址本身，一个盘口一行，与改造前一致。
 */
function dlGroupByPost(items) {
  const m = new Map();
  for (const it of items) {
    const k = it.postId || it.postUrl || ('u:' + it.real);
    let g = m.get(k);
    if (!g) {
      g = {
        key: k, title: it.postTitle || null, postUrl: it.postUrl || null,
        author: it.author || null, ct: it.ct || null, ut: it.ut || null, dpv: Number(it.dpv) || 0,
        section: it.section || null, links: [],
      };
      m.set(k, g);
    }
    g.links.push({ server: it.server, real: it.real, pwd: it.pwd });
    /* 同帖多条地址时取信息最全的那份做主（有的行没带作者或时间） */
    if (!g.title && it.postTitle) g.title = it.postTitle;
    if (!g.author && it.author) g.author = it.author;
    if (!g.ct && it.ct) g.ct = it.ct;
    if (!g.ut && it.ut) g.ut = it.ut;
    if ((Number(it.dpv) || 0) > g.dpv) g.dpv = Number(it.dpv) || 0;
  }
  return [...m.values()];
}

/**
 * 单帖行：标题 + 副信息（作者 / 时间 / 浏览 / 提取码 / 源帖）+ 右侧盘口按钮组。
 * ★ 提取码按盘口分别写（同一帖不同盘口的码可能不同，混着写会让人抄错码）。
 */
function dlRow(g) {
  const mt = [];
  if (g.author) mt.push('<i>@' + esc(g.author) + '</i>');
  const when = dlWhen(g.ct || g.ut);
  if (when) mt.push('<i>' + esc(when) + '</i>');
  if (g.dpv) mt.push('<i class="dpv">' + esc(dlNum(g.dpv)) + ' 浏览</i>');
  const pwds = [];
  const seenPwd = new Set();
  for (const l of g.links) {
    if (!l.pwd) continue;
    const code = String(l.pwd).replace(/^访问码[：:]\s*/, '');
    const tag = (g.links.length === 1 ? '' : (DL_BRAND_NAME[dlBrand(l.server).cls] || l.server) + ' ');
    const k = tag + code;
    if (seenPwd.has(k)) continue;
    seenPwd.add(k);
    pwds.push(tag + code);
  }
  if (pwds.length) mt.push('<i class="pw">提取码 ' + esc(pwds.join(' / ')) + '</i>');
  if (g.postUrl) mt.push('<a href="' + esc(g.postUrl) + '" target="_blank" rel="noopener">源帖 ↗</a>');

  const links = g.links.map((l) => {
    const b = dlBrand(l.server);
    const code = l.pwd ? String(l.pwd).replace(/^访问码[：:]\s*/, '') : '';
    const tip = (l.server || '网盘') + (code ? ' · 提取码 ' + code : '') + ' · 打开';
    return l.real
      ? '<a class="lk bd-' + b.cls + '" href="' + esc(l.real) + '" target="_blank" rel="noopener" title="' + esc(tip) + '">' +
        esc(DL_BRAND_NAME[b.cls] || l.server || '网盘') + '</a>'
      : '<span class="lk bd-other" title="' + esc((l.server || '网盘') + ' · 这条没解析出地址') + '">' +
        esc(DL_BRAND_NAME[b.cls] || l.server || '网盘') + '</span>';
  }).join('');
  const first = g.links.find((l) => l.real);
  const copy = first
    ? '<button class="act" type="button" data-dl-copy="' + esc(first.real) + '" title="复制' +
      esc(first.server || '首个') + '链接">复制</button>' : '';

  return '<div class="dl-it">' +
    '<span class="bd bd-' + (first ? dlBrand(first.server).cls : 'other') + '">' +
      esc(first ? dlBrand(first.server).ab : '?') + '</span>' +
    '<div class="tx"><b title="' + esc(g.title || '') + '">' + esc(g.title || '（无标题资源帖）') + '</b>' +
    '<div class="mt">' + mt.join('') + '</div></div>' +
    '<div class="acts">' + links + copy + '</div></div>';
}
/* ============ 下载弹窗的视图状态（v10.27） ============
 * 用户口径：「还需要优化下下载的弹窗」（并给了源站话题页的 tab 与排序结构）。
 *
 * ★ 为什么要有 dlView 这一层：弹窗里现在有**三个会改变输出的开关** ——
 *   排序（最热 / 最近发布）、盘口筛选、每个专区的展开/收起。任何一个变化都要整块重渲染。
 *   把「用户选了什么」（dlView）与「怎么渲染」（paintDownload 一个出口）分开，
 *   就不必在三个地方各写一遍 innerHTML —— 本项目踩过「同一份 UI 有两个独立渲染分支、
 *   只改了其中一个，界面自相矛盾」的坑（PITFALLS 16）。
 * ★ 每次打开弹窗都会重置：上一款游戏的选择不能带到下一款。
 * ★ v10.45：它现在只服务**合并弹窗的「本体」页签**（`dlUniPaintBody` 每次重建它），
 *   其它三个模块不读它。所以事件委托里那批开关都加了 `dlUni.tab === 'body'` 的判定。
 */
let dlView = null;

/** 按盘口统计**帖数**（筛选 chip 上的数字）。★ 用帖数而不是地址数：
 *  列表一行就是一帖，chip 写着 25 却点出 12 行会让人以为丢数据。 */
function dlBrandCounts(items) {
  const m = new Map();
  for (const g of dlGroupByPost(items)) {
    for (const cls of new Set(g.links.map((l) => dlBrand(l.server).cls))) {
      m.set(cls, (m.get(cls) || 0) + 1);
    }
  }
  return [...m.entries()].map(([cls, n]) => ({ cls, n })).sort((a, b) => b.n - a.n);
}

/**
 * 组内排序（作用在**帖子**上）。**与后端 jidiPosts.sortPosts 同规则**：有标题的优先，再按主键降序。
 * ★ 无标题的那批是 `resource_type=0` 混进来的帖子（源站自己也有），不删 —— 它确实带链接；
 *   但也不许排在有名字的资源前面，否则第一屏全是「没有名字的下载」。
 * ★ XD 那些条目没有 dpv/ct（都是 0）⇒ 全部并列 ⇒ 保持源站给的原顺序（Array.sort 稳定）。
 */
function dlSorted(items, sort) {
  const key = sort === 'new' ? 'ct' : 'dpv';
  return items.slice().sort((a, b) => {
    const at = a.title ? 1 : 0, bt = b.title ? 1 : 0;
    if (at !== bt) return bt - at;
    return (Number(b[key]) || 0) - (Number(a[key]) || 0);
  });
}
function dlFiltered(items, filt) {
  return filt ? items.filter((i) => dlBrand(i.server).cls === filt) : items;
}
/** 过滤 + 归帖 + 排序 —— 从「地址列表」到「可渲染的帖子列表」的唯一一条路 */
function dlPosts(items, filt, sort) {
  return dlSorted(dlGroupByPost(dlFiltered(items, filt)), sort);
}
/* ★ v10.29：把「XD 盘口 + 机地三个专区」摊成一份 tab 列表。
 *  工具条的签与正文的面板**都从它取数** —— 两处各算一遍必然漂移
 *  （本项目踩过「chip 写 25 帖、点开只有 12 行」这类数字对不上）。
 *  `count` / `ret` / `merged` 只在机地那侧有（服务端 sections 的口径），
 *  XD 没有专区概念 ⇒ 只给 name + items，其余字段留空由调用方兜。 */
function dlTabList(v) {
  const out = [];
  if (v.xdItems.length) out.push({ key: 'xd', name: 'XDGAME 盘口', items: v.xdItems });
  for (const s of v.secs) {
    out.push({ key: s.key, name: s.name, items: s.items, count: s.count, ret: s.returned, merged: s.merged });
  }
  return out;
}

/**
 * **当前分区**的内容面板（★ v10.29：语义从「可折叠专区」改成「当前分区」）。
 *
 * ★ 为什么不再折叠（这是用户口径「就分开显示，而不是本体下面还有 Mod 或者修改器」的落点）：
 *   折叠时其余专区仍以自己的标题行留在页面上 —— 用户在「本体」列表下面照样看得见
 *   「mod 2 帖」「修改器 2 帖」两块，观感就是「本体下面还压着两个东西」。
 *   换成 tab 后一次只渲染一个分区，其余分区**一个节点都不在 DOM 里**
 *   （比 display:none 更彻底：不会被辅助技术读到，也不占任何版面）。
 *   ⚠️ 折叠态的 `.off` 类与 `.dl-tg` 按钮因此一并消失 —— 不要再往回加，
 *      否则「本体下面还有 Mod」会立刻复现（反证用例已钉住「非当前分区零节点」）。
 * ★ `rows` 由调用方算好传入（截断策略集中在 paintDownload 一处）；
 *   不传时按 `all` 兜底，老调用方仍能拿到一份完整面板。
 * ★ 单位仍然分开写：「N 帖」是源站的帖子数，「M 个地址」是本次真正能点开的链接数
 *   （一帖常带 2~3 个盘口，混用会让「22 帖 / 60 个地址」读起来自相矛盾）。
 */
function dlBlock(o) {
  const cap = o.cap || DL_CAP;
  const rows = Array.isArray(o.rows) ? o.rows : (o.all ? o.items : o.items.slice(0, cap));
  const rest = o.items.length - rows.length;
  const foot = [];
  if (rows.length) {
    if (o.all && o.items.length > cap) {
      foot.push('<button type="button" class="dl-more" data-dl-all="' + esc(o.key) + '">收起，只看前 ' + cap + ' 帖</button>');
    } else if (rest > 0) {
      foot.push('<button type="button" class="dl-more" data-dl-all="' + esc(o.key) + '">展开全部 ' +
        o.items.length + ' 帖（还有 ' + rest + ' 帖）</button>');
    }
  }
  if (o.tail) foot.push('<div class="dl-note" style="margin:7px 0 0">' + esc(o.tail) + '</div>');
  const head = '<div class="sh"><b>' + esc(o.name) + '</b>' +
    '<span class="c">' + esc(o.countLabel) + '</span>' +
    (o.metaLabel ? '<span class="m">' + esc(o.metaLabel) + '</span>' : '') +
    (o.url ? '<a class="go" href="' + esc(o.url) + '" target="_blank" rel="noopener">' +
      esc(o.urlLabel || '源站 ↗') + '</a>' : '') +
    '</div>';
  return '<div class="dl-sec" data-sec="' + esc(o.key) + '">' + head +
    (rows.length ? '<div class="l">' + rows.map(dlRow).join('') + '</div>' : '') +
    (foot.length ? '<div class="ft">' + foot.join('') + '</div>' : '') + '</div>';
}

/** 顶部工具条：分区签（tab）+ 排序 + 盘口筛选（sticky —— 滚到第 40 条也能换盘口）。
 *  ★ 签上的数字一律是**帖数**（列表一行就是一帖），不是地址数。
 *  ★ v10.29：签从「可折叠专区的锚点」升级成**真正的 tab**（点它 = 只显示那一块）。
 *    只有一个分区时不摆签 —— 一个签排在那里既不切换信息、也白占一行。
 *  ★ 排序只对机地那侧有效（XD 条目没有 dpv/ct）—— 只有 XD 时不摆这个开关，别给无效控件。 */
function dlBarHtml() {
  const v = dlView;
  const cnt = (arr) => dlGroupByPost(dlFiltered(arr, v.filt)).length;
  const tabs = dlTabList(v);
  const tabRow = tabs.length > 1
    ? tabs.map((t) => '<button type="button" class="dl-an' + (v.tab === t.key ? ' on' : '') +
      '" data-dl-go="' + esc(t.key) + '">' + esc(t.name) + ' <i>' + cnt(t.items) + '</i></button>').join('')
    : '';
  const sorts = v.secs.length
    ? '<span class="dl-sp"></span><span class="dl-lb">排序</span>' + DL_SORTS.map(([k, label]) =>
      '<button type="button" class="dl-tab' + (v.sort === k ? ' on' : '') + '" data-dl-sort="' + k + '">' +
      esc(label) + '</button>').join('')
    : '';
  const chips = ['<button type="button" class="dl-chip' + (v.filt === '' ? ' on' : '') +
    '" data-dl-filt="">全部<i>' + cnt(v.items) + '</i></button>']
    .concat(dlBrandCounts(v.items).map((b) => '<button type="button" class="dl-chip' +
      (v.filt === b.cls ? ' on' : '') + '" data-dl-filt="' + esc(b.cls) + '">' +
      esc(DL_BRAND_NAME[b.cls] || b.cls) + '<i>' + b.n + '</i></button>')).join('');
  const row1 = (tabRow || sorts) ? '<div class="rw">' + tabRow + sorts + '</div>' : '';
  return '<div class="dl-bar">' + row1 +
    '<div class="rw"><span class="dl-lb">盘口</span>' + chips + '</div></div>';
}

/** 唯一渲染出口：把 dlView 画进 #dlBody（★ v10.29：一次只画**一个分区**） */
function paintDownload() {
  const body = $('#dlBody');
  if (!body || !dlView) return;
  const v = dlView;
  const keep = body.scrollTop;

  /* 筛选键失效（换了游戏 / 该盘口这次一条都没有）→ 回到「全部」，
     否则会渲染出一片「当前筛选下没有地址」，看着像坏了。 */
  if (v.filt && !dlBrandCounts(v.items).some((b) => b.cls === v.filt)) v.filt = '';

  const tabs = dlTabList(v);
  if (!tabs.length) {
    body.innerHTML = '<div class="dlpop-empty">这款游戏没有可展示的网盘地址</div>';
    return;
  }
  /* 当前分区可能因为换游戏 / 换筛选而消失 → 退回第一个有内容的分区。
     ⚠️ 这里**不要**因为「本分区筛完是空的」就跳到别的分区：
        用户会以为「点了筛选结果跳到另一个专区」。空结果的提示由下面给。 */
  if (!tabs.some((t) => t.key === v.tab)) v.tab = tabs[0].key;
  const cur = tabs.find((t) => t.key === v.tab);
  const items = dlPosts(cur.items, v.filt, v.sort);
  const st = v.sec[cur.key] || (v.sec[cur.key] = { all: false });
  const rows = st.all ? items : items.slice(0, DL_CAP);

  const panel = dlBlock({
    key: cur.key, name: cur.name, items, rows, all: !!st.all,
    countLabel: (cur.count || cur.items.length) + ' 帖',
    metaLabel: cur.items.length + ' 个地址' + (cur.merged ? '（含最近发布）' : ''),
    /* XD 条目不是机地话题，没有「源站专区」可跳 —— 给一个会 404 的出口不如不给 */
    url: cur.key === 'xd' ? '' : v.topicUrl,
    urlLabel: '源站专区 ↗',
    tail: (cur.count > cur.ret)
      ? '源站该专区共 ' + cur.count + ' 帖，本次取回 ' + cur.ret + ' 帖' +
        (cur.merged ? '（已并入「最近发布」那批）' : '') + '，其余请去源站专区看'
      : '',
  });

  const usable = items.length;
  const note = '<div class="dl-note">共 <b>' + v.items.length + '</b> 个可直接打开的网盘地址（来自 <b>' +
    dlGroupByPost(v.items).length + '</b> 个资源帖）' +
    (v.filt ? '，筛选 <b>' + esc(DL_BRAND_NAME[v.filt] || v.filt) + '</b> 后本分区剩 <b>' + usable + '</b> 帖' : '') +
    ' · 链接均为源站实时解析</div>';
  body.innerHTML = dlBarHtml() + note +
    (usable ? panel : '<div class="dlpop-empty">本分区在当前筛选下没有可用的网盘地址<br>' +
      '<span style="font-size:11.5px">点上面的「全部」看所有盘口，或换个分区</span></div>');
  body.scrollTop = keep;
}

/**
 * ★ v10.29：切换到某个分区（原 `dlOpenSec(key, jump)` 的「展开 + 锚点跳转」不再需要 ——
 *   tab 语义下**点签就是切块**，没有「折叠着但看得见标题」的中间态）。
 *
 * ★ 为什么切块后把滚动位置清零：两块内容完全不重叠，停在上一块的滚动位置上，
 *   用户看到的是新分区的中段（开头被卷走了），会误以为「这块只有这么几条」。
 */
function dlGoTab(key) {
  if (!dlView) return;
  if (dlView.tab === key) return;
  dlView.tab = key;
  paintDownload();
  const b = $('#dlBody');
  if (b) b.scrollTop = 0;
}
/**
 * 一整组都取不到地址时的说明块。
 * ★ 为什么必须区分「源站要权限」与「解析失败」：前者是源站策略，重试一万次也没用 ——
 *   用户看到的如果是「稍后重试」，他会一直重试；告诉他「去源站登录后获取」才是对的。
 *   实测样本：XD `钢铁雄心4`（id=3967）的 10 个盘口全部返回
 *   `HTTP 200 + 你没有权限下载：钢铁雄心4！`（没有 Location、也没有跳转脚本）。
 */
function dlBlocked(title, srcCls, srcName, d) {
  const n = (d.items || []).length;
  const why = d.needAuth
    ? '源站对这款游戏要求<b>登录 / 权限</b>才能取到网盘地址（返回「你没有权限下载」）。' +
      '这不是本站抓取失败 —— <b>去源站页面登录后即可获取</b>。'
    : '源站这次没有返回可用的跳转地址（可能是改版或临时故障）。可以稍后重试，或直接去源站页面取。';
  const go = d.url
    ? '<a class="dl-go" href="' + esc(d.url) + '" target="_blank" rel="noopener">前往源站页面 ↗</a>' : '';
  return '<div class="dl-grp"><div class="h"><b>' + esc(title) + '</b>' +
    '<span class="src ' + srcCls + '">' + esc(srcName) + '</span>' +
    '<span class="n">0 / ' + n + ' 条可用</span></div>' +
    '<div class="dl-blocked">' + why + '</div>' + go + '</div>';
}
function dlCopy(el) {
  const txt = el.dataset.dlCopy || '';
  const back = el.textContent;
  const done = () => {
    el.textContent = '已复制 ✓';
    el.classList.add('done');
    setTimeout(() => { el.textContent = back; el.classList.remove('done'); }, 1400);
  };
  const fallback = () => {
    try {
      const ta = document.createElement('textarea');
      ta.value = txt;
      ta.style.cssText = 'position:fixed;left:-9999px;top:0';
      document.body.appendChild(ta); ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta); done();
    } catch (e) { toast('复制失败，请手动选中链接'); }
  };
  if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(txt).then(done, fallback);
  else fallback();
}
function closeDownload() {
  const pop = $('#dlPop');
  if (!pop || pop.hidden) return;
  pop.classList.remove('on');
  /* ★ 关掉就丢状态：否则「查看全部」那类弹窗复用 #dlBody 时，上一次的排序/筛选还在 */
  dlView = null;
  /* ★ v10.28：翻页状态一并作废 —— 留着的话下次打开会先按旧页码画一帧，
     而那时 `dFullCur.p` 指向的仍是**上一次**那份载荷（数据已经不对了）。 */
  dFullCur = null;
  /* ★ v10.45：合并弹窗的会话状态同样作废（否则换一款游戏点开会看到上一款的 Mod / 存档）。
     模块页签条也要一起藏掉 —— 其它复用 #dlPop 外壳的弹窗不该带这排签。 */
  dlUni = null;
  const mt = $('#dlModTabs');
  if (mt) { mt.hidden = true; mt.innerHTML = ''; }
  /* ★ v10.46：位置弹窗是压在下载弹窗**之上**的一层，父层关掉时它必须跟着关 ——
     否则会留下一张「浮在空页面上、背景全透明」的孤零零位置卡，且 z-index 更高点不到别处。 */
  closeSvLoc();
  setTimeout(() => { pop.hidden = true; const b = $('#dlBody'); if (b) b.innerHTML = ''; }, 180);
}
/* ★ v10.45：原 openDownload()（异步解析 + 一次性铺全部专区的网盘弹窗）**已删除**。
   它被 openUniDownload() 取代 —— 后者把「本体 / Mod / 修改器 / 存档」拆成四个模块页签，
   并且不再把「入口是否可见」绑在 /api/download 的成败上
   （那是 Skyrim SE 详情页看不到 Mod / 存档的根因）。
   ⚠️ 旧函数里的取数逻辑**不是丢掉**，而是原样搬进了 dlUniFetchBody() —— 改那块前先读上面的注释。 */
/* ============ 📚 「查看全部」弹窗（v10.25 新增） ============
 * 用户口径：「详情页中如果数量较大，则增加一个按钮（更多）查看该专区的全部内容弹窗」。
 *
 * 五个专区都会截断展示（都是实测出来的上限）：
 *   🛠 修改器 #trBlock        8 个来源 / 共 N
 *   💾 云存档 #svBlock        3 条路径 + 2 条注册表 / 共 N
 *   📱 机型清单 #bhDevSlot    24 台 / 共 N
 *   📋 逐条参数 #bhParamSlot  3 份 / 共 N
 *   📥 下载入口 #dlSlot       4 条 / 共 N
 * ★ 实测（2026-09-20，全库离线统计）：**当前真正会触发按钮的只有三个** ——
 *     云存档（6,604 条里 1,019 条超过 3+2）、逐条参数、下载入口；
 *   另外两个是**守卫**，现状下不会出现，但保留（不是死代码，是阈值保护）：
 *     · 修改器：全库单款最多 **4** 个来源 < 上限 8
 *     · 机型清单：全库单款最多 **22** 台 < 上限 24（另有 1 条脏数据 35 台，name 为 `+`）
 *   要激活它们只需下调对应上限；本次**不动上限**（改了会缩短默认展示，属于用户没要求的退化）。
 * 改之前这些位置各写一句「另有 N 条未展示，去手机专区「xx」页看全部」——
 * 把用户赶去另一个页面自己找。而数据**本来就在手上**：前两个就在当前响应里，
 * 后三个只是把请求的 limit 放大一次。
 *
 * ★ 做法：把「完整载荷」按 token 存进 dFullStore，按钮上只带 token。
 *   为什么用 token 而不是把参数写进 data-*：
 *     弹窗之间要展示的东西差别很大（来源清单 / 路径 / 机型 / 卡片式配置 / 帖子），
 *     统一成一个「载荷 + 渲染器」的入口，就不用每个按钮各写一遍取数逻辑 ——
 *     也不会出现「按钮写着 24 台、弹窗里 20 台」这种数字对不上。
 *   ⚠️ token 只在**当前这一份详情页渲染**内有效：paintDetail 会把 store 清空。
 *      所以绝不能让 token 跨详情页复用（换一款游戏后旧 token 必须失效）。
 * ★ 载荷可以带 `load()`：需要二次请求的（参数 / 机型 / 下载入口）在点击时才发，
 *   不在打开详情页时就预取（下载入口一次要跟随 302 解析，最贵）。
 * ★ 复用 #dlPop 外壳，理由同下（三页共享资产，不抄第二份样式）。
 */
let dFullStore = Object.create(null);
let dFullSeq = 0;
function dFullPut(p) { const k = 'f' + (++dFullSeq); dFullStore[k] = p; return k; }
/** 「查看全部」按钮（整行）。label 里自带条数，避免和载荷里的数字两处维护。 */
function dFullBtn(k, label) {
  return '<button type="button" class="d-more-btn" data-full="' + esc(k) + '">' +
    esc(label) + ' <span class="ar">→</span></button>';
}
/** ★ v10.29：卡片**右上角**的「更多」小按钮（用户口径「其他则为卡片右上角更多按钮查看全部」）。
 *  与 dFullBtn 共用同一套 token + `data-full` 委托 ⇒ 弹窗侧一行都不用改。
 *  只是版式不同（塞进卡头而不是独占一行），所以另开一个产出函数而不是给 dFullBtn 加参数 ——
 *  两个版式的差别是**结构性**的（在 h4 里 vs 在正文流里），一个参数说不清，
 *  以后还会长出第三个版式（比如列表行内的「更多」）。 */
function dMoreHd(k, label) {
  return '<button type="button" class="d-more-hd" data-full="' + esc(k) + '">' + esc(label) +
    '<span class="ar">→</span></button>';
}
/* ★ v10.28：弹窗里每页帖数（用户口径「弹窗显示十个其他的翻页」）。
   取 10 是「一屏能扫完、又不用一直翻」的折中：`.dl-it` 一行约 64px，
   10 行 ≈ 640px，正好落在 `.dlpop-box` 的 80vh 可视区里 —— 翻页后不必再滚动就能看全。 */
const DF_PAGE = 10;
const D_FULL_RENDER = {
  /* 🛠 修改器（Game Cheats Manager 公开数据，没有下载地址，只给来源与版本） */
  tr(p) {
    const items = p.items || [];
    return '<div class="df-note">共 <b>' + items.length + '</b> 个来源 · 清单聚合自 Game Cheats Manager 公开数据，' +
      '本站不提供文件；<a href="' + D_GCM_URL + '" target="_blank" rel="noopener">打开 GCM 下载页 ↗</a></div>' +
      items.map((it, i) => {
        const src = it.source || 'gcm';
        const nm = it.zh || it.name || '';
        const en = (it.name && it.name !== nm) ? it.name : '';
        const meta = [en, it.version ? 'v ' + it.version : ''].filter(Boolean).join(' · ');
        return '<div class="df-row"><span class="ix">' + (i + 1) + '</span><span class="bd">' +
          '<span class="t"><span class="tagx">' + esc(D_TR_SRC[src] || src) + '</span>' + esc(nm) + '</span>' +
          (meta ? '<span class="m">' + esc(meta) + '</span>' : '') + '</span></div>';
      }).join('');
  },
  /* 💾 云存档：路径**不截断**（这是用户真正要抄的东西），注册表单列一组 */
  sv(p) {
    const h = p.hit || {};
    const paths = h.paths || [], regs = h.regs || [];
    const out = ['<div class="df-note">共 <b>' + (paths.length + regs.length) + '</b> 条记录 · 数据来自 ' +
      'Ludusavi 开源清单（MIT）。路径里的 <code>&lt;用户名&gt;</code> / <code>&lt;平台账号ID&gt;</code> ' +
      '是占位符，按自己的账号替换；<b>存档前请先退出游戏</b>。</div>'];
    const tagOf = (t) => (t === 'config' ? '配置' : (t === 'save' ? '存档' : (t || '存档')));
    if (paths.length) {
      out.push('<div class="df-sect">存档 / 配置路径（' + paths.length + '）</div>');
      paths.forEach((x, i) => out.push('<div class="df-row"><span class="ix">' + (i + 1) + '</span><span class="bd">' +
        '<span class="t">' + esc(tagOf((x.tags || [])[0])) + '</span>' +
        '<span class="m"><code>' + esc(x.shown || x.raw || '') + '</code></span></span></div>'));
    }
    if (regs.length) {
      out.push('<div class="df-sect">注册表项（' + regs.length + '）</div>');
      regs.forEach((x, i) => out.push('<div class="df-row"><span class="ix">R' + (i + 1) + '</span><span class="bd">' +
        '<span class="m"><code>' + esc(x.raw || '') + '</code></span></span></div>'));
    }
    return out.join('');
  },
  /* ★ v10.28：原先这里还有两个渲染器 ——
     `md`（下载入口 · 全部资源帖）与 `bp`（逐条游玩参数 · 全部配置）。
     两者的入口按钮都随本次详情页改版消失了：`md` 的宿主 `#dlSlot` 改成三专区预览
     （改走 `dlsec`，一页 10 帖可翻页）；`bp` 的宿主 `#bhParamSlot` 收进了
     「查看全部机型」弹窗（`dv` 里带 `params` 那一节）。
     按项目铁律「删掉没人用的出口」一并清掉，连同只服务 `md` 的 `D_DF_KIND` 配色表 ——
     留着会让人以为还有第三条路能走到这两块。 */
  /* 📱 手机模拟器配置：全量机型 + 性能分 + 芯片，★ v10.28 起后面再接两节 ——
     「本站实测记录」与「逐条游玩参数」。用户口径是「只需要手机模拟器配置，不要多个显示」，
     所以详情页里这三块默认都不铺开，统一进这一个弹窗（他确认过：收进弹窗、不删数据）。
     ★ 此处仍不做「点开硬件面板」—— 那个交互要按机型再发一次 /api/device/hardware，
       放进弹窗会与抽屉里的面板状态打架；弹窗只回答「哪些机型跑过、各自多强」，
       要看品牌 / 型号 / 硬件配置，回抽屉里点同一台。 */
  dv(p) {
    const items = p.items || [];
    const out = ['<div class="df-note">共 <b>' + (p.total || items.length) + '</b> 台机型跑通过本作（按性能分从弱到强）· ' +
      '点机型展开完整硬件参数请在详情页「手机模拟器配置」里操作。</div>'];
    /* 机型行正常是 bhDevRow() 产出的**数据对象**；万一拿到的是已经成型的 HTML 串
       （旧载荷 / 别的调用方），直接放行而不是去读 `x.name` —— 那会渲染出一片空白行。 */
    out.push(items.map((x, i) => typeof x === 'string' ? x : '<div class="df-row"><span class="ix">' + (i + 1) + '</span><span class="bd">' +
      '<span class="t">' + esc(x.name) + (x.score ? ' <span class="tagx dim">' + Math.round(x.score) + '</span>' : '') + '</span>' +
      '<span class="m">' + (x.code ? esc(x.code) + ' · ' : '') + (x.chip ? esc(x.chip) : '芯片未收录') + '</span></span></div>').join(''));
    /* 本站实测记录：`.pc-rec` 是这套数据的既有版式（手游专区的实测面板用的就是它） */
    const recs = p.recs || [];
    if (recs.length) {
      out.push('<div class="df-sect">本站实测记录（' + recs.length + '）</div>');
      out.push('<div class="pc-rec">' + recs.map(bhRecRow).join('') + '</div>');
    }
    /* 逐条游玩参数：直接复用详情页那张卡片（bhParamCard），不另做一套版式 */
    const params = p.params || [];
    if (params.length) {
      out.push('<div class="df-sect">逐条游玩参数（' + params.length + '）</div>');
      out.push(params.map(bhParamCard).join(''));
    }
    return out.join('');
  },
  /* 📥 三专区（本体 / Mod / 修改器）· ★ v10.28 新增。
     详情页每块只露 3 帖，这里是「全部」的落点：每页 DF_PAGE 帖 + 上/下页；
     多专区时顶部给切换标签（从哪块点进来就停在哪块，也能直接换块看）。
     ⚠️ 行渲染继续用 `dlRow` —— 与详情页预览**同一个函数**，两处各写一套必然漂移。 */
  dlsec(p, page, secKey) {
    const secs = p.secs || [];
    if (!secs.length) return '<div class="dlpop-empty">这款游戏没有可展示的资源帖</div>';
    const per = p.pageSize || DF_PAGE;
    const cur = secs.some((s) => s.key === secKey) ? secKey : secs[0].key;
    const s = secs.find((x) => x.key === cur) || secs[0];
    const total = s.posts.length;
    const pages = Math.max(1, Math.ceil(total / per));
    const pg = Math.min(Math.max(1, Number(page) || 1), pages);
    const rows = s.posts.slice((pg - 1) * per, pg * per);
    const out = [];
    /* 多专区时才给切换标签 —— 只有一块时排一个单标签纯属噪音 */
    if (secs.length > 1) {
      out.push('<div class="df-tabs">' + secs.map((x) =>
        '<button type="button" class="df-tab' + (x.key === cur ? ' on' : '') + '" data-df-sec="' + esc(x.key) + '">' +
        esc(x.name) + '<i>' + x.posts.length + '</i></button>').join('') + '</div>');
    }
    out.push('<div class="df-note">' + esc(s.name) + ' 共 <b>' + total + '</b> 帖 · 每页 ' + per +
      ' 帖，第 <b>' + pg + '</b> / ' + pages + ' 页 · 点盘口按钮直接去源站取件（本站不转存、不提供文件）' +
      (s.count > total ? '；源站该专区共 ' + s.count + ' 帖' + (s.merged ? '（已并入「最近发布」那批）' : '') : '') +
      '</div>');
    out.push('<div class="df-list">' + rows.map(dlRow).join('') + '</div>');
    if (pages > 1) {
      out.push('<div class="df-pager">' +
        '<button type="button" class="df-pg" data-df-page="' + (pg - 1) + '"' + (pg <= 1 ? ' disabled' : '') + '>‹ 上一页</button>' +
        '<span class="df-pg-n">' + pg + ' / ' + pages + '</span>' +
        '<button type="button" class="df-pg" data-df-page="' + (pg + 1) + '"' + (pg >= pages ? ' disabled' : '') + '>下一页 ›</button>' +
        '</div>');
    }
    return out.join('');
  },
};
/* ★ v10.28：把「当前弹窗的可翻页状态」提出来 —— 翻页 / 切专区要能**重渲染同一份载荷**，
   而载荷是点击时才异步取回的（`src.load()`），不存下来第二页就没数据可画。
   ⚠️ 只在弹窗打开期间有效：`closeDownload()` 与换一款游戏（paintDetail 清 dFullStore）都会作废，
      否则会出现「翻页翻出上一款游戏的资源帖」这种看起来完全正常的串台。 */
let dFullCur = null;      // { p, page, sec }
function paintFull() {
  const body = $('#dlBody');
  if (!body || !dFullCur) return;
  const R = D_FULL_RENDER[dFullCur.p.type];
  if (!R) return;
  body.innerHTML = R(dFullCur.p, dFullCur.page, dFullCur.sec) ||
    '<div class="dlpop-empty">没有可展示的内容</div>';
}
/** ★ v10.28：打开三专区里某一块的「全部」弹窗。
 *  载荷直接复用 `dlSecs`（`loadDlBlock` 已经归好帖），所以这里是**同步**的 —— 不必再等网络。 */
function openDlSecPop(key) {
  if (!dlSecs.length) return;
  const token = dFullPut({
    type: 'dlsec',
    title: dlSecTitle ? dlSecTitle + ' · 下载资源' : '下载资源 · 全部',
    sub: '本体 / Mod / 修改器 · 每页 ' + DF_PAGE + ' 帖',
    secs: dlSecs, sec: key || '', pageSize: DF_PAGE,
  });
  openFullPop(token);
}
async function openFullPop(token) {
  const pop = $('#dlPop');
  const src = dFullStore[token];
  if (!pop || !src) return;
  const R = D_FULL_RENDER[src.type];
  if (!R) return;
  $('#dlTitle').textContent = src.title || '全部内容';
  $('#dlSub').textContent = src.sub || '';
  $('#dlFoot').innerHTML = src.foot || '';
  pop.hidden = false;
  requestAnimationFrame(() => pop.classList.add('on'));
  dFullCur = null;
  /* ★ v10.45：这不是合并弹窗（是「查看全部 / 三专区全部」这类子视图）——
     把模块页签藏掉，否则会出现「点了『全部 N 帖』却还留着一排模块签」的两套导航并存。
     同时作废 dlUni：子视图里没有模块语境，留着会让 dlGoModule 作用到一份看不见的状态上。 */
  dlUni = null;
  const mt = $('#dlModTabs');
  if (mt) { mt.hidden = true; mt.innerHTML = ''; }
  const needLoad = typeof src.load === 'function';
  $('#dlBody').innerHTML = '<div class="dlpop-load"><i></i><span>正在读取全部内容…</span></div>';
  let p = src;
  try {
    if (needLoad) p = Object.assign({}, src, (await src.load()) || {});
    dFullCur = { p, page: 1, sec: src.sec || '' };
    paintFull();
  } catch (e) {
    dFullCur = null;
    $('#dlBody').innerHTML = '<div class="dlpop-empty">读取失败：' + esc(e.message) +
      '<br><span style="font-size:11.5px">稍后重试</span></div>';
  }
}

/* ============ 🛠 修改器 / 🧩 Mod 下载弹窗（v10.25 新增） ============
 * 用户口径：「我需要你将下载按钮优化（①下载本体，②下载修改器，③下载Mod）」。
 *
 * ★ 为什么复用 #dlPop 外壳而不是新开一个弹层：
 *   两个弹层结构完全一样（标题 + 副标题 + 可滚列表 + 脚注），新开一个就要把
 *   `.dlpop-*` 那十几条样式再抄一遍 —— 而 #dlPop 是**三页共享资产**（index /
 *   emulator / unpack 三页同一份），抄第二份必然样式漂移。复用后只有渲染分支不同。
 *
 * ★ 与详情页里那个「🛠 修改器」区块是**两套数据**，别混淆（loadDlBlock 上方注释已记）：
 *     #trBlock（/api/trainers/match）= Game Cheats Manager 元数据，**没有下载地址**；
 *     本弹窗（/api/mods/match?kind=）      = 机地社区帖，99.9% 带网盘直链，真能取件。
 *
 * ★ 检索词必须和 loadDlBlock 的 counts **同源**：按钮上的数字是 loadDlBlock 用
 *   `title`（完整标题，可能含「中文/English」拼接串）查出来的，这里也用同一个 `title`。
 *   若这里改用简体中文名去查，就会出现「按钮写着 97 条、点开说 0 条」——
 *   数字对不上比没有数字更糟。
 */
const D_MOD_META = {
  mod: { nm: 'Mod', hint: '社区自制内容：模型 / 皮肤 / 玩法扩展等，安装方式见源站帖子' },
  modifier: { nm: '修改器', hint: '内存修改 / 训练器；单机可用，联机使用有封号风险' },
};
const D_MOD_CAP = 60;
function dModLinks() {
  return '<a href="' + D_JIDI_MODS + '" target="_blank" rel="noopener">机地 MOD / 修改器区 ↗</a>' +
    '<a href="/resources.html#tr">修改器库</a><a href="/resources.html#sv">云存档位置</a>';
}
/* 绑定一次（弹层与 Toggle 都是共享资产的常驻节点）。
   ★ 用**事件委托**而不是给每个按钮绑：解包匹配页的卡片是动态重绘的，
     逐个绑定会在重绘后全部失效（本项目在机型清单上踩过同类坑）。 */
(function bindDownloadPopup() {
  const pop = $('#dlPop');
  if (!pop) return;
  pop.addEventListener('click', (e) => {
    if (e.target.closest('[data-dl="close"]')) { closeDownload(); return; }
    /* ★ v10.46：存档模块右上角的「📍 存档位置」→ 开二级弹窗。
       同一个委托里处理，因为它也在 #dlBody 内（会被整块重建，直接绑必掉）。 */
    if (e.target.closest('[data-dl-svloc]')) { openSvLoc(); return; }
    /* ★ v10.46：存档文件列表的展开 / 收起（数据已在手上，只改状态重绘，不再打请求） */
    const sfv = e.target.closest('[data-dl-svf]');
    if (sfv) { if (dlUni) { dlUni.svfAll = sfv.dataset.dlSvf === 'all'; dlUniPane(); } return; }
    const cp = e.target.closest('[data-dl-copy]');
    if (cp) dlCopy(cp);
  });
  /* ★ v10.46：位置弹窗是**独立浮层**（#svLoc 与 #dlPop 是兄弟节点，冒泡到不了上面那个委托），
     所以复制 / 关闭要自己接一遍。
     ⚠️ 这里的 `[data-dl-copy]` 与下载弹窗里的是同一套（dlCopy 也是同一个）——
        不要以为「弹窗里的复制已经能用」就把这块省掉：省掉后按钮长得一模一样但点了没反应。 */
  const sv = $('#svLoc');
  if (sv) {
    sv.addEventListener('click', (e) => {
      if (e.target.closest('[data-svloc="close"]')) { closeSvLoc(); return; }
      const cp = e.target.closest('[data-dl-copy]');
      if (cp) dlCopy(cp);
    });
  }
  /* ESC 关弹窗：用捕获阶段并截断 —— 搜索弹窗也监听 ESC，
     不截断会出现「一下 ESC 把两个都关掉」。只在弹窗真的开着时才抢。
     ★ v10.46：位置弹窗叠在下载弹窗**之上**，ESC 必须先关最上面那一层 ——
        否则用户在位置弹窗上按 ESC，会看到下面那层也一起没了（「一下关两层」）。 */
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    if (sv && !sv.hidden) { e.stopPropagation(); closeSvLoc(); return; }
    if (pop.hidden) return;
    e.stopPropagation();
    closeDownload();
  }, true);
  document.addEventListener('click', (e) => {
    /* ★ v10.27：下载弹窗内部的开关（分区签 / 排序 / 盘口筛选 / 展开全部）全部走委托。
       为什么必须委托：#dlBody 每次都是整块 innerHTML 重建，直接绑在按钮上的监听会全掉
       （v10.25 已记过这条）。这里先判，命中就 return，不再往下走下载入口的分支。
       ★ v10.29：原来的「折叠 / 展开专区」开关（data-dl-sec）随 tab 化一起删了 ——
          现在没有「折叠着但标题仍留在页面上」的中间态。
       ★ v10.45：加 `dlView && dlUni && dlUni.tab === 'body'` 的三段判 ——
          `dlView` 现在只是**合并弹窗「本体」页签**的子状态；用户在 Mod / 存档 页签时
          它仍然留着上一次的排序/筛选，不判就会让那几个开关作用到看不见的画布上。 */
    if (dlView && dlUni && dlUni.tab === 'body') {
      const go = e.target.closest('[data-dl-go]');
      if (go) { dlGoTab(go.dataset.dlGo); return; }
      const st = e.target.closest('[data-dl-sort]');
      if (st) { dlView.sort = st.dataset.dlSort || 'hot'; paintDownload(); return; }
      const fl = e.target.closest('[data-dl-filt]');
      if (fl) { dlView.filt = fl.dataset.dlFilt || ''; paintDownload(); return; }
      const al = e.target.closest('[data-dl-all]');
      if (al) {
        const s = dlView.sec[al.dataset.dlAll];
        if (s) { s.all = !s.all; paintDownload(); }
        return;
      }
    }
    /* ★ v10.25：「查看全部」按钮 —— 与下面两个下载按钮共用同一个 #dlPop 外壳，
       所以绑在同一处委托里（分散绑三处，改一次外壳要改三处）。 */
    const fb = e.target.closest('[data-full]');
    if (fb) {
      e.preventDefault();
      e.stopPropagation();
      openFullPop(fb.dataset.full);
      return;
    }
    /* ★ v10.28：三专区预览的「全部 N 帖 →」——
       载荷**不必重新请求**：`loadDlBlock` 已把三专区（已归帖）存在 `dlSecs` 里，
       这里只把它包成一个 token 交给同一套弹窗外壳。 */
    const dfo = e.target.closest('[data-df-open]');
    if (dfo) {
      e.preventDefault();
      e.stopPropagation();
      openDlSecPop(dfo.dataset.dfOpen);
      return;
    }
    /* ★ v10.28：弹窗内翻页 / 切换专区 —— 只改状态再重渲染，不重新取数。
       重新取数不仅慢，还会因为服务端每次给的顺序不同而「翻页翻出重复条目」。 */
    const dfp = e.target.closest('[data-df-page]');
    if (dfp && dFullCur) {
      e.preventDefault();
      dFullCur.page = Number(dfp.dataset.dfPage) || 1;
      paintFull();
      $('#dlBody').scrollTop = 0;         // 翻页后回列表顶部，否则会停在上一页的滚动位置
      return;
    }
    const dfs = e.target.closest('[data-df-sec]');
    if (dfs && dFullCur) {
      e.preventDefault();
      dFullCur.sec = dfs.dataset.dfSec;   // 换专区 → 页码必须归 1，否则会落在空页上
      dFullCur.page = 1;
      paintFull();
      $('#dlBody').scrollTop = 0;
      return;
    }
    /* ★ v10.45：合并弹窗的**模块页签**切换。放在最前面判 ——
       它挂在 `#dlModTabs`（`#dlBody` 之外），与下面那批只有正文里才有的
       `data-dl-*` 控件不重叠，但先判能省掉一串 closest()。 */
    const dm = e.target.closest('[data-dlm]');
    if (dm && dlUni) { e.preventDefault(); e.stopPropagation(); dlGoModule(dm.dataset.dlm); return; }
    const b = e.target.closest('[data-dl-open]');
    if (!b) return;
    e.preventDefault();
    e.stopPropagation();
    openUniDownload({
      title: b.dataset.dlTitle || '',
      sub: b.dataset.dlSub || '',
      url: b.dataset.dlUrl || '',
      jidi: b.dataset.dlJidi || '',
      id: b.dataset.dlId || '',
    });
  });
})();

/* ================= 🧭 详情页竖向定位条（v10.25 新增） =================
 * 用户口径：「我希望游戏详情页弹窗能有个定位条（竖着的）」；
 *           位置选定「右侧固定」，收录项选定「8 项，按可信度排序」。
 *
 * 「按可信度排序」的落地方式：**选**的是实测存在率最高、最常被找的 9 个分区；
 *   但它们在条上的**排列顺序按正文顺序**（不是按我写的顺序）—— 见 railSync 里的排序
 *   （★ v10.29：改用 `compareDocumentPosition`，不再按视口坐标，原因见那里）。
 *   定位条的顺序与正文不一致时，滚动高亮会来回跳，那比少一项更难受。
 *
 * ★ 为什么用 MutationObserver 重扫，而不是在 paintDetail 里扫一次就完事：
 *   详情页分区是**懒加载**的（#reqSlot / #trBlock / #svBlock / #dlStrip 都是异步回填），
 *   paintDetail 渲染那一刻它们还是空的。只扫一次的话定位条会永远缺几项。
 *   观察 #drawerBody 子树 + rAF 去抖，任何回填都会自动重扫。
 *   ⚠️ 所以定位条**不能**放在 #drawerBody 里，否则重扫会触发自己 → 死循环。
 *   ⚠️ 也不能靠 Promise.all 等那 6 个 loadXxx：它们内部有各自的 try/catch 与提前 return，
 *      有的还不返回 promise，用「等所有懒加载完成」来定时机一定会漏。
 */
const D_RAIL = [
  /* ★ v10.29：评分 + 参数表（厂商 / 发行日期 / 大小）。
     用户反馈「右侧悬浮定位条好像没更新」—— 根因就在这里：
     v10.28 把「评分 + 参数表」排到了正文最前（封面之后第一块），
     但 D_RAIL 里**从来没有这一项** ⇒ 滚到参数表时条上高亮的仍是上一区，
     点回这一块也没有入口，看起来就像定位条还停在旧版式上。
     （只加这一项就够：其余顺序是 railSync **按 DOM 顺序重排**出来的，不靠这里的书写顺序。） */
  { k: 'kv', nm: '评分参数', sel: ['#drawerBody .d-body > .kv'] },
  /* ⚠️ `.block` 同时被「版本介绍」用着 → 必须按标题文字过滤，否则会定位到版本介绍 */
  { k: 'desc', nm: '游戏介绍', sel: ['#drawerBody .block'], txt: '游戏介绍' },
  /* ★ v10.29：游戏预览挪到介绍块之后（与正文一致，由 railSync 的 DOM 排序兜住） */
  { k: 'shot', nm: '游戏预览', sel: ['#drawerBody .gal'] },
  { k: 'req', nm: '配置要求', sel: ['#reqSlot'] },
  { k: 'bh', nm: '手机配置', sel: ['#bhSlot'] },
  /* ★ v10.32：修改器 / 云存档在条上**合并成一项**。
     用户口径：「修改器和存档现在是一行了，所以只需要一个」——
     两块既然在同一行并排（`.d-pair` 两列），它们的 `rect.top` 只差几像素，
     滚到这一行时两项**永远同时越过高亮线**，两个序号一起变蓝。
     视觉上那是「同时选中两项」，读起来像坏了；点哪一个也都跳到同一行。
     ⚠️ v10.29 曾特意保留两项（理由写在上一条注释里），那条理由已被用户口径否定：
        两块内容不同 ≠ 需要两个入口 —— 定位条是按**屏幕位置**切的，不是按内容切的。 */
  { k: 'trsv', nm: '修改器/云存档', sel: ['#trSvSlot'] },
  { k: 'rel', nm: '同分类', sel: ['#relSlot'] },
  /* ★ v10.28：优先指向正文里的三专区区块（`#dlSlot`）—— 它在文档流里，滚动定位准确；
     `#dlStrip` 现在躺在 sticky 的 `.d-dock` 里（视觉位置恒在视口底部），
     拿它当定位目标会让这一项几乎永远不高亮。它只在三专区没内容时兜底。 */
  { k: 'dl', nm: '下载', sel: ['#dlSlot', '#dlStrip'] },
];
let dRailItems = [];
let dRailScrollPend = 0;
/** 解析一个定位项对应的**真实可见**目标节点；不可见（存在但没内容）一律当没有。 */
function railTarget(spec) {
  const body = $('#drawerBody');
  if (!body) return null;
  for (const s of spec.sel) {
    for (const el of $$(s)) {
      if (!body.contains(el)) continue;
      if (spec.txt && !String(el.textContent || '').includes(spec.txt)) continue;
      if (el.offsetWidth > 0 && el.offsetHeight > 0) return el;
    }
  }
  return null;
}
/** 定位条横向让位：抽屉贴右，且抽屉自己有竖向滚动条 → 右偏移要算上滚动条宽度。 */
function railPos() {
  const rail = $('#dRail'), dr = $('#drawer');
  if (!rail || rail.hidden || !dr) return;
  const r = dr.getBoundingClientRect();
  const sb = dr.offsetWidth - dr.clientWidth;      // 抽屉自己的滚动条宽度（叠加滚动条时为 0）
  const gap = Math.round(window.innerWidth - r.right + sb + 12);
  rail.style.right = Math.max(4, gap) + 'px';
}
/** 滚动高亮：以「滚动视口顶部往下 90px」为判据，取最后一个越过该线的分区。 */
function railSpy() {
  const rail = $('#dRail'), dr = $('#drawer');
  if (!rail || rail.hidden || !dr || !dRailItems.length) return;
  const line = dr.getBoundingClientRect().top + 90;
  let cur = 0;
  dRailItems.forEach((it, i) => { if (it.el.getBoundingClientRect().top <= line) cur = i; });
  /* ★ 滚到底时**强制高亮最后一项**（实测踩到：艾尔登法环的「同分类」与「下载」
     都挤在最后一屏里，滚动被 `scrollHeight - clientHeight` 夹住，怎么也顶不到
     那条线 —— 不给这个兜底，最后两项点了等于没反馈）。 */
  if (dr.scrollTop + dr.clientHeight >= dr.scrollHeight - 4) cur = dRailItems.length - 1;
  rail.querySelectorAll('.dr-it').forEach((b, i) => b.classList.toggle('on', i === cur));
}
/** 重建定位条。可反复调用（paintDetail 后一次 / MutationObserver 每次回填后一次）。 */
function railSync() {
  const rail = $('#dRail'), dr = $('#drawer');
  if (!rail || !dr) return;
  if (!dr.classList.contains('show')) { rail.hidden = true; dRailItems = []; return; }
  const found = [];
  for (const spec of D_RAIL) {
    const el = railTarget(spec);
    if (el) found.push({ nm: spec.nm, el });
  }
  /* ★ v10.29 修：排序键从「视口 rect.top」换成**文档顺序**。
     为什么必须换：`.d-dock` 里的 `#dlStrip` 是 `position:sticky`，它的
     `getBoundingClientRect().top` 反映的是「此刻吸在视口底部」的位置（≈ 视口高度），
     于是它只比「首屏之内」的元素靠后、比所有「首屏之外」的元素靠前。
     XD 源的游戏三专区没有内容 ⇒ 兜底命中 `#dlStrip` ⇒ 「下载」被排到第 3 位，
     而正文里它在倒数第 3。定位条顺序与正文不一致，用户会读成「这条还是旧的」。
     实测样本：博德之门3（xd-419），条上顺序曾是
     评分参数 → 游戏介绍 → **下载** → 游戏预览 → 配置要求 → …
     `compareDocumentPosition` 直接给文档顺序，不受 sticky / fixed / transform 影响，
     也正好就是注释里那句「排列顺序按正文顺序」的原意。 */
  found.sort((a, b) => (a.el.compareDocumentPosition(b.el) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1));
  if (!found.length) {
    /* 一个分区都没渲染出来（比如详情抓取失败只剩错误页）→ 整条收起，不留空壳 */
    rail.hidden = true; rail.innerHTML = ''; dRailItems = [];
    return;
  }
  rail.innerHTML = found.map((it, i) =>
    '<button type="button" class="dr-it" data-rail="' + i + '" title="' + esc(it.nm) + '">' +
    '<span class="dr-n">' + (i + 1) + '</span>' +
    '<span class="dr-t">' + esc(it.nm) + '</span></button>').join('');
  dRailItems = found;
  rail.hidden = false;
  railPos();
  railSpy();
}
/** 一次性启动：观察 #drawerBody + 抽屉滚动 + 窗口尺寸。 */
function railBoot() {
  const body = $('#drawerBody'), dr = $('#drawer');
  if (!body || !dr || !window.MutationObserver) return;
  let pend = 0;
  new MutationObserver(() => {
    if (pend) return;
    pend = requestAnimationFrame(() => { pend = 0; railSync(); });
  }).observe(body, { childList: true, subtree: true });
  dr.addEventListener('scroll', () => {
    if (dRailScrollPend) return;
    dRailScrollPend = requestAnimationFrame(() => {
      dRailScrollPend = 0;
      railSpy();
      dHeroSpy();   // ★ v10.28：同一个 rAF 里顺带收窄顶图（不另起一个 scroll 监听）
    });
  }, { passive: true });
  window.addEventListener('resize', () => { railPos(); railSpy(); });
  /* 点击跳转：用 document 级委托（与下载弹窗同理 —— #dRail 的 innerHTML 每次重扫
     都会整体替换，逐个 addEventListener 会在第二次重扫后全部失效且不报错）。 */
  document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-rail]');
    if (!b) return;
    const it = dRailItems[+b.dataset.rail];
    if (!it) return;
    e.preventDefault();
    const land = () => {
      const el = it.el;
      /* 重扫会整体替换 `.dr-it`，但 `dRailItems[i].el` 是**正文里的分区节点**，
         详情页重渲染后它可能已经脱离文档 —— 那时 getBoundingClientRect 会全为 0，
         `dy` 变成 -dr.top，一滚就跳到顶部。所以先确认它还在文档里。 */
      if (!el || !el.isConnected) return;
      /* ★ v10.32：余量必须把**常驻小标题条的遮挡**算进去（用户口径：「定位的时候
         顶部会遮挡部分，应该优化下」）。根因：`.d-mini` 是
         `position:sticky;top:0;height:62px` + `margin-bottom:-62px`（**不占布局高度**），
         它显形后恒覆盖在抽屉内容最上方 62px；而这里原来只留 14px 余量
         ⇒ 跳转后目标分区的标题正好落进小条底下（被盖约 48px）。
         ⚠️ 不能无条件减 62：小条只在 `scrollTop >= 大图高` 时才显形
           （见 dHeroSpy），而「评分参数」这类紧跟大图的分区跳过去后可能还没过阈值 ——
           那时多减 62 会把目标顶到半空。所以先算**不含余量**的落点，再按它判。
         ⚠️ `hero` 用 offsetHeight 而不是常量：大图高是布局算出来的（250），
           写死的话换机型 / 换字号就会错位 —— 与 dHeroSpy 用同一个来源。 */
      const mini = $('#dMini'), hero = $('#dHero');
      const miniH = mini ? mini.offsetHeight : 0;     // 62：小条自身高度
      const heroH = hero ? hero.offsetHeight : 0;     // 250：小条显形阈值
      const dy = el.getBoundingClientRect().top - dr.getBoundingClientRect().top;
      const raw = dr.scrollTop + dy;                  // 目标落点（不含任何余量）
      const cover = raw >= heroH ? miniH : 0;         // 跳过去时小条会不会显形
      const gap = cover ? 10 : 14;                    // 小条下方留 10，否则照旧 14
      dr.scrollTo({ top: Math.max(0, raw - cover - gap), behavior: 'smooth' });
    };
    land();
    /* ★ v10.29 修，v10.30 保留双趟作为保险。
       当时的根因：`.d-hero` 是 `position:sticky` 的，滚过 90px 会从 250px 收成 62px ——
       正文整体上移 188px。只算一趟的话，`dy` 是用「收窄前」的布局量的，
       落点会少一个顶图收窄量；相邻很近的两个分区之间还会出现
       **「点靠下的分区反而往上滚」**（实测：评分参数 371 → 游戏介绍 318，
       而两者在正文里的间距只有 ~130px < 188px）。
       ⚠️ v10.30 起顶图**高度恒定 250px 且不再 sticky**（见下面 dHeroSpy 的注释），
       这条一阶误差的根已经不存在了。双趟**保留**：第二趟只多量一次、代价可忽略，
       而它挡住的是「将来又有人在顶图高度上做文章」这类回归。 */
    setTimeout(land, 460);
  });
  railSync();
}
/* ★ v10.30：详情页顶图改成「大图随滚动滚走 + 常驻小标题条显形」。
 *  （v10.28 是「250px sticky 大图滚过 90px 收窄成 62px」，用户口径：「往下拉的时候，
 *   置顶切换会一直闪（大小切换问题）」）
 *
 *  旧实现的三个毛病（都是浏览器**实拍量出来的**，不是读代码推测的）：
 *   ① **单阈值抖动**：在 90px 附近来回滚 14 次 ⇒ `.mini` class 翻转 **21 次**；
 *   ② **滚动锚定自激**：大图 250→62 让文档少 188px 高，浏览器为「保住视觉位置」
 *      自动改写 scrollTop（实测：设 200，700ms 后成 71）⇒ 又越过阈值 ⇒ 再翻转，
 *      **不需要任何用户操作也会自己振** —— 这才是「一直闪」的主因；
 *   ③ **内容瞬变**：+40ms 中途采样，高度还在 247.8px（过渡才走 2px），
 *      而图片亮度 / 字号 / 标题位置 / 渐变方向**已全部到位** ⇒ 观感是「抽一下」而不是缩放。
 *  新结构从**结构层**消掉这三条：`.d-hero` 高度恒定 250px 且不再 sticky
 *  ⇒ 布局不再反过来影响 scrollTop（②消失）。剩下的 ① 用「双阈值滞后 + rAF 合帧 +
 *  只在跨越时才算」兜住手抖。
 *
 *  ★ v10.31 又改了两处（用户口径：「详情页的顶部图不要动画了，现在还是会在一定的位置
 *    游戏名忽大忽小的闪」）—— v10.30 的「小条滑入」本身就是残余的动画，且阈值取早了：
 *    · 动画侧：`.d-mini` 的 `transform:translateY(-102%)` + 260ms 过渡**整条删掉**，
 *      只切 `visibility`（见 CSS 里那段注释）。v10.30 说「只做 transform 不触发布局」
 *      是对的，但**不触发布局 ≠ 没有动画** —— 用户要的是不动。
 *    · 阈值侧：`heroH - 62 + 12` → `heroH`，让「大图离开」与「小条贴顶」同帧发生。
 *  ⚠️ 状态以 **DOM 上的 class** 为唯一事实来源（不另存模块变量）：抽屉是复用节点、
 *     换游戏时 `#dMini` 会整块重建 —— 读 class 才能天然复位。存变量的话，
 *     「上一款滚到一半、下一款打开还停在收窄态」这类错位得单独写代码去清。
 *  ⚠️ 为什么不用纯 CSS：CSS 选不了「滚动位置」，`animation-timeline:scroll()` 兼容性不够。 */
const MINI_GAP = 24;   // 双阈值之间的滞后带（专治触控板/滚轮在临界点的手抖）
let miniPend = 0;      // rAF 句柄：滚动事件再密，一帧也只结算一次
function dHeroSpy() {
  if (miniPend) return;
  miniPend = requestAnimationFrame(() => {
    miniPend = 0;
    const dr = $('#drawer'), h = $('#dMini'), hero = $('#dHero');
    if (!dr || !h || !hero) return;
    const y = dr.scrollTop;
    /* ★ v10.31：阈值 = **大图的实际高度**（不再减 62 加 12）。
       旧式 `heroH - 62 + 12` 的用意是「大图底边收到小条下沿时开始滑入」，
       但实拍证明它**早于大图离开视口**：抽屉 720 / 大图 250 时阈值只有 200，
       而 `.d-title` 占 186.8~236 —— 滚到 210 时大标题还剩 26px 在屏上，
       小条已显形 ⇒ 一大一小两个游戏名同屏，正是用户说的「忽大忽小」。
       改成 `heroH` 后：小条的静态位就在内容偏移 250（= 紧随大图之后），
       所以「大图整块滚出视口」与「小条正好贴顶」是**同一个瞬间**，
       `visibility` 一切就是无缝衔接，不需要任何过渡动画。
       阈值仍跟着 `offsetHeight` 算，窄屏（≤760px，大图 190px）自动跟随。 */
    const on = Math.max(60, hero.offsetHeight);
    const off = Math.max(24, on - MINI_GAP);
    const cur = h.classList.contains('on');
    let next = cur;
    /* ⚠️ 上侧必须用 `>=`（实测：写 `>` 时 y=250 不激活、y=260 才激活 ——
       阈值恰好等于大图高，`>` 会把「大图刚离开」那一帧漏掉，多出 1~10px 的空档）。 */
    if (!cur && y >= on) next = true;
    else if (cur && y < off) next = false;
    if (next === cur) return;    // 没跨越阈值 ⇒ 一个字节的 DOM 都不碰
    h.classList.toggle('on', next);
  });
}
railBoot();   // 定位条：绑一次观察器/滚动监听（常驻节点，不进 #drawerBody）

init();
