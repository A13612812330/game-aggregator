/* 探测 fearlessrevolution.com 在 headless Edge 下能否穿过 Cloudflare 挑战
 * 目的：决定该源是否可作为「存档/修改器」的新数据源（用户口径：原链可直接获取）。
 * 只读探测，不写任何 data/。 */
const puppeteer = require('puppeteer-core');

const EDGE = 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';
const URL = process.argv[2] || 'https://fearlessrevolution.com/';

(async () => {
  const t0 = Date.now();
  let browser;
  try {
    browser = await puppeteer.launch({
      executablePath: EDGE,
      headless: 'new',
      args: ['--no-sandbox', '--disable-blink-features=AutomationControlled'],
    });
    const page = await browser.newPage();
    await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36');
    await page.setViewport({ width: 1366, height: 900 });

    const resp = await page.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 });
    console.log('HTTP', resp && resp.status(), '耗时', Date.now() - t0, 'ms');

    // CF 挑战页通常几秒后自动跳转；给它时间
    for (const wait of [3000, 5000, 7000]) {
      await new Promise((r) => setTimeout(r, wait));
      const info = await page.evaluate(() => ({
        title: document.title,
        url: location.href,
        len: document.body ? document.body.innerText.length : 0,
        head: (document.body ? document.body.innerText : '').slice(0, 260).replace(/\s+/g, ' '),
      }));
      console.log(`  [${Date.now() - t0}ms] title="${info.title}" len=${info.len}`);
      if (!/Just a moment|Attention Required|Checking your browser/i.test(info.title) && info.len > 800) {
        console.log('  ✔ 已穿过挑战');
        console.log('  正文:', info.head);
        break;
      }
    }
  } catch (e) {
    console.log('ERR', e.code || '', String(e.message).slice(0, 200));
  } finally {
    if (browser) await browser.close().catch(() => {});
  }
})();
