#!/usr/bin/env node
/**
 * _ab-bak.js — 从「收口前」的落盘备份里，取那 114 条被代际护栏拒掉的 id，
 *             看它们当时记的 matchHow / matchKey 到底是什么。
 *
 * 这一步的用途：A/B 已证明「收口前后逐条相同」，所以 2066→1952 的差异
 * 一定来自**另一个变量**。备份里的 stats + 这 114 条的 matchKey 是唯一的事实来源。
 */
'use strict';
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const bak = path.join(ROOT, '_bak/saves-youxia.json.before-normalize-unify');
const B = JSON.parse(fs.readFileSync(bak, 'utf8'));
console.log('备份 stats：' + JSON.stringify(B.stats));
console.log('备份 items：' + B.items.length + ' 条');

const newRows = JSON.parse(fs.readFileSync(path.join(__dirname, 'ab-new.json'), 'utf8')).rows;
const rejIds = newRows.filter((r) => r.gen).map((r) => r.id);
console.log('\n新代码里被代际拒绝：' + rejIds.length + ' 条');

const byId = new Map(B.items.map((x) => [x.id, x]));
let inBak = 0, bakHow = {};
const samples = [];
for (const id of rejIds) {
  const it = byId.get(id);
  if (!it) continue;
  inBak++;
  bakHow[it.matchHow || '(空)'] = (bakHow[it.matchHow || '(空)'] || 0) + 1;
  if (samples.length < 10) samples.push({ id, title: it.title, game: it.game, how: it.matchHow, key: it.matchKey, lib: it.libTitle });
}
console.log('其中在旧备份里**存在**（即当时被判为匹配）的：' + inBak + ' / ' + rejIds.length);
console.log('它们在旧备份里的 matchHow 分布：' + JSON.stringify(bakHow));
console.log('\n样本：');
for (const s of samples) {
  console.log('  [' + s.how + '] key=「' + s.key + '」');
  console.log('     列表标题「' + s.title + '」');
  console.log('     落盘 game=「' + s.game + '」 → 库「' + s.lib + '」');
}
