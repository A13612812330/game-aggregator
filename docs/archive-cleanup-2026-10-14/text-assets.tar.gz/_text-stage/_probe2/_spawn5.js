/* 定向隔离：到底哪个 option 决定 EBUSY */
'use strict';
const cp = require('child_process');
const path = require('path');
const ROOT = path.resolve(__dirname, '..');
const SCRIPT = path.join(ROOT, 'tools', 'check-card-rules.js');

function run(label, opts) {
  try {
    const out = cp.execFileSync(process.execPath, [SCRIPT], opts);
    return label.padEnd(44) + ' OK   (' + String(out).length + ' 字节输出)';
  } catch (e) {
    return label.padEnd(44) + ' ' + (e.status == null ? 'THROW ' : 'EXIT' + e.status + ' ') + (e.code || '') + '/' + (e.errno || '');
  }
}

console.log(run('1 无任何 options', {}));
console.log(run('2 encoding only', { encoding: 'utf8' }));
console.log(run('3 cwd only', { cwd: ROOT }));
console.log(run('4 cwd + encoding', { cwd: ROOT, encoding: 'utf8' }));
console.log(run('5 cwd + encoding + timeout', { cwd: ROOT, encoding: 'utf8', timeout: 300000 }));
console.log(run('6 timeout only', { timeout: 300000 }));
console.log(run('7 maxBuffer only', { encoding: 'utf8', maxBuffer: 1 << 22 }));
console.log(run('8 cwd + encoding + timeout + maxBuffer', { cwd: ROOT, encoding: 'utf8', timeout: 60000, maxBuffer: 1 << 22 }));
console.log(run('9 stdio ignore + cwd + timeout', { cwd: ROOT, encoding: 'utf8', timeout: 60000, stdio: ['ignore', 'pipe', 'pipe'] }));
