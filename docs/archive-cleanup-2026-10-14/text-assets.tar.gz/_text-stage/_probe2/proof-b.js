/* 反证 B：把 .gl-i .t 的 `title` 属性删掉 ⇒ 「单行省略后悬停仍能读全文」那条 DOM 断言必须变红。
   改的是真源 tools/resource-sections.js（不是产物），再走正常 build ⇒ 等价于真实退化路径。 */
const fs = require('fs');
const p = 'tools/resource-sections.js';
const s = fs.readFileSync(p, 'utf8');
const from = `    + '<span class="t' + mute + '" title="' + esc(title) + '">' + esc(title) + '</span>'`;
const to = `    + '<span class="t' + mute + '">' + esc(title) + '</span>'`;
if (!s.includes(from)) { console.log('❌ 未找到锚点 B'); process.exit(1); }
fs.writeFileSync('_probe2/bak-sections.js', s);
fs.writeFileSync(p, s.replace(from, to));
console.log('✅ 反证 B 已注入（条目标题不再带 title）');
