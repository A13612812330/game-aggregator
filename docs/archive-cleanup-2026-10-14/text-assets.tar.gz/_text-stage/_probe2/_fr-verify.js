const fs = require('fs');
const fr = require('../fetchers/frCheat');
const h = fs.readFileSync('_probe2/fr-topic.html', 'utf8');
const d = fr.parseTopic(h);
console.log('topic title:', JSON.stringify(d.title), '| f=', d.f, 't=', d.t);
console.log('附件数:', d.attachments.length);
for (const a of d.attachments.slice(0, 4)) console.log('  ', JSON.stringify(a));
console.log('\n游戏名候选:');
for (const t of ['z Xenonauts 2', "Dragon's Dogma 2", "Clive Barker's Hellraiser: Revival (Demo)", 'ELDEN RING v1.12 +22 TRAINER', 'Game Name (v1.0) [Steam]', 'F.E.A.R.']) {
  console.log('  ' + JSON.stringify(t) + ' → ' + JSON.stringify(fr.gameCandidates(t)));
}
