/* 探测 EBUSY 的真实触发面：哪些子进程能起、哪些不能 */
'use strict';
const cp = require('child_process');
const cases = [
  ['spawnSync process.execPath -v', () => cp.spawnSync(process.execPath, ['-v'], { encoding: 'utf8' })],
  ['spawnSync node -v', () => cp.spawnSync('node', ['-v'], { encoding: 'utf8' })],
  ['spawnSync git --version', () => cp.spawnSync('git', ['--version'], { encoding: 'utf8' })],
  ['execFileSync git --version', () => ({ stdout: cp.execFileSync('git', ['--version'], { encoding: 'utf8' }) })],
  ['execSync echo hi', () => ({ stdout: cp.execSync('echo hi', { encoding: 'utf8' }) })],
  ['spawnSync git shell:true', () => cp.spawnSync('git --version', { shell: true, encoding: 'utf8' })],
  ['spawnSync whoami', () => cp.spawnSync('whoami', { encoding: 'utf8' })],
];
console.log('NODE_OPTIONS =', process.env.NODE_OPTIONS || '(空)');
console.log('execPath     =', process.execPath);
for (const [n, f] of cases) {
  let line;
  try {
    const r = f();
    line = r.error ? 'ERR ' + r.error.code + '/' + r.error.errno : 'OK  ' + String(r.stdout || '').trim().slice(0, 40);
  } catch (e) {
    line = 'THROW ' + e.code + '/' + e.errno;
  }
  console.log(String(n).padEnd(32), line);
}
