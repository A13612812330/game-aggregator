/* 统计 mods / saves-youxia 按「游戏」聚合后的分布 —— 为「MOD 按游戏做卡片」定可行性 */
const fs = require('fs');
const m = JSON.parse(fs.readFileSync('data/mods.json', 'utf8'));
const mods = (m.items || []).filter((x) => x.kind === 'mod');
const byLib = new Map(), byName = new Map();
for (const x of mods) {
  const k = x.libId ? 'lib:' + x.libId : 'nm:' + String(x.game || x.title || '').trim();
  if (!byLib.has(k)) byLib.set(k, []);
  byLib.get(k).push(x);
  const n = String(x.game || '').trim();
  byName.set(n, (byName.get(n) || 0) + 1);
}
const groups = [...byLib.values()].sort((a, b) => b.length - a.length);
const cnt = groups.map((g) => g.length);
const dist = { '=1': 0, '2-3': 0, '4-9': 0, '10-29': 0, '>=30': 0 };
for (const c of cnt) dist[c === 1 ? '=1' : c <= 3 ? '2-3' : c <= 9 ? '4-9' : c <= 29 ? '10-29' : '>=30']++;
console.log('=== MOD（kind=mod）===');
console.log('总数', mods.length, '| 聚合组数（按 libId 或游戏名）', groups.length, '| 覆盖游戏名', byName.size);
console.log('组大小分布', JSON.stringify(dist));
console.log('最大 5 组:');
for (const g of groups.slice(0, 5)) {
  const t = g[0].libTitle || g[0].game || g[0].title;
  console.log('   ' + String(g.length).padStart(4) + ' 条  ' + String(t).slice(0, 40) + (g[0].libId ? '  [' + g[0].libId + ']' : '  (无libId)'));
}
console.log('有 libId 的条目', mods.filter((x) => x.libId).length, '/', mods.length);

const s = JSON.parse(fs.readFileSync('data/saves-youxia.json', 'utf8'));
const sv = s.items || [];
console.log('\n=== 存档文件（游侠 saves-youxia）===');
console.log('总条目', sv.length, '| stats', JSON.stringify(s.stats || {}));
const byLib2 = new Map();
for (const x of sv) {
  const k = x.libId ? 'lib:' + x.libId : 'nm:' + String(x.game || '').trim();
  byLib2.set(k, (byLib2.get(k) || 0) + 1);
}
console.log('聚合组数', byLib2.size, '| 有 libId', sv.filter((x) => x.libId).length);
const g2 = [...byLib2.values()].sort((a, b) => b - a);
console.log('最大 5 组:', g2.slice(0, 5).join(', '));
