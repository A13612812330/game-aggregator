#!/usr/bin/env node
/**
 * _guard-ab.js — 反推「代际护栏」在 2066 那次运行里的**查询参数口径**
 *
 * 为什么需要这一步：
 *   A/B 已证明 normKey 收口后逐条 3581/3581 完全相同 ⇒ 收口无罪。
 *   差异只可能出在 `matchYxEntry` 里 `numMismatchByTitle(<什么>, lib)` 的**第一个参数**。
 *   而 fetchers/youxiaSave.js 尚未纳入 git（无历史可比），所以只能**用旧备份的结果反推**。
 *
 * 判据（强判据，不是只看总数）：
 *   对 3581 条列表条目逐条重放，要求
 *     ① 备份里存在的 id → 重放出的 (how, libId, matchKey) 与备份**逐字段相等**
 *     ② 备份里不存在的 id → 重放必须是 none
 *   全部满足才算「复现旧语义」。只看总数相等不算（本项目铁律：判据不许 over-claim）。
 *
 * 候选口径：
 *   Q1 整条列表标题（= 现行代码）
 *   Q2 抽取出的游戏名 item.game
 *   Q3 标题首个空格前那一段 first
 *   Q4 实际命中的那个候选键 c
 *   Q5 详情页标题（仅备份内条目可得）
 */
'use strict';
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const { normKey, numMismatchByTitle } = require(path.join(ROOT, 'data/name-normalize'));
const { keyUsable, buildLibIndex } = require(path.join(ROOT, 'data/mod-match'));
const yx = require(path.join(ROOT, 'fetchers/youxiaSave'));
const gamesDb = require(path.join(ROOT, 'data/gamesDb'));

const list = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/_yx-list-raw.json'), 'utf8')).items || [];
const bak = JSON.parse(fs.readFileSync(path.join(ROOT, '_bak/saves-youxia.json.before-normalize-unify'), 'utf8'));
const bakById = new Map(bak.items.map((x) => [x.id, x]));

gamesDb.load();
const all = gamesDb.all();
const { byName } = buildLibIndex(all);

/** 参数化重放：与 fetchers/youxiaSave.js 的 matchYxEntry 逐分支同形，只把护栏的第一个参数抽出来 */
function replay(item, qKind) {
  const none = { how: 'none', key: '', libId: '', gen: 0 };
  const detailTitle = (bakById.get(item.id) || {}).title || '';

  if (item.game) {
    const k = normKey(item.game);
    const lib = keyUsable(k) ? byName.get(k) : null;
    if (!lib) return none;
    if (numMismatchByTitle(item.game, lib)) return Object.assign({}, none, { gen: 1 });
    return { how: 'bracket', key: item.game, libId: lib.id || '', gen: 0 };
  }

  const first = String(item.title || '').trim().split(/\s+/)[0] || '';
  const firstKey = normKey(first);
  const q = (c) => (qKind === 'Q1' ? item.title
    : qKind === 'Q2' ? item.game
      : qKind === 'Q3' ? first
        : qKind === 'Q4' ? c
          : detailTitle);

  if (keyUsable(firstKey) && byName.has(firstKey)) {
    const lib = byName.get(firstKey);
    if (!numMismatchByTitle(q(first), lib)) return { how: 'prefix', key: first, libId: lib.id || '', gen: 0 };
    return Object.assign({}, none, { gen: 1 });
  }
  for (const c of yx.shrinkCandidates(item.title)) {
    const k = normKey(c);
    if (!keyUsable(k) || k.length < 3) continue;
    if (!byName.has(k)) continue;
    const lib = byName.get(k);
    if (numMismatchByTitle(q(c), lib)) return Object.assign({}, none, { gen: 1 });
    return { how: 'prefix', key: c, libId: lib.id || '', gen: 0 };
  }
  return none;
}

for (const qKind of ['Q1', 'Q2', 'Q3', 'Q4', 'Q5']) {
  let matched = 0, bracket = 0, prefix = 0;
  let okBak = 0, badBak = 0, okAbsent = 0, badAbsent = 0, gen = 0;
  const bad = [];
  for (const it of list) {
    const r = replay(it, qKind);
    if (r.gen) gen++;
    if (r.how !== 'none') { matched++; if (r.how === 'bracket') bracket++; else prefix++; }
    const b = bakById.get(it.id);
    if (b) {
      const same = ((b.matchHow || 'none') === r.how)
        && ((b.libId || '') === r.libId)
        && ((b.matchKey || '') === r.key);
      if (same) okBak++; else { badBak++; if (bad.length < 6) bad.push({ id: it.id, bak: b.matchHow + '/' + b.matchKey, got: r.how + '/' + r.key }); }
    } else if (r.how === 'none') okAbsent++;
    else badAbsent++;
  }
  const perfect = badBak === 0 && badAbsent === 0;
  console.log(qKind + ' ｜ 匹配 ' + matched + '（括 ' + bracket + ' · 前 ' + prefix + '）｜ 护栏拒 ' + gen
    + ' ｜ 备份内逐字段相符 ' + okBak + ' 不符 ' + badBak
    + ' ｜ 备份外判 none ' + okAbsent + ' 误配 ' + badAbsent
    + (perfect ? '   ★ 完全复现旧语义' : ''));
  bad.forEach((x) => console.log('     ✗ ' + x.id + ' 备份=' + x.bak + ' 重放=' + x.got));
}
console.log('\n旧备份基准：matched ' + bak.stats.matched + '（括 ' + bak.stats.matchBracket + ' · 前 ' + bak.stats.matchPrefix + '）覆盖库 ' + bak.stats.libCovered + ' 款');
