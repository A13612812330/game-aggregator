/* 严格验证假设：node 内起子进程时 stdin 若是 pipe ⇒ EBUSY；改 ignore ⇒ OK */
'use strict';
const cp = require('child_process');
const path = require('path');
const ROOT = path.resolve(__dirname, '..');

function m(file, args, opts) {
  try { const r = cp.spawnSync(file, args, Object.assign({ encoding: 'utf8' }, opts)); 
        return r.error ? 'ERR ' + r.error.code : 'OK  ' + String(r.stdout || '').trim().slice(0, 24); }
  catch (e) { return 'THROW ' + e.code; }
}
const N = process.execPath, G = 'git';

console.log('假设：stdin=pipe ⇒ EBUSY，stdin=ignore ⇒ OK\n');
const variants = [
  ['默认（三路 pipe）', undefined],
  ["stdio:'pipe' 显式", { stdio: 'pipe' }],
  ["stdio:'ignore'", { stdio: 'ignore' }],
  ["['ignore','pipe','pipe']", { stdio: ['ignore', 'pipe', 'pipe'] }],
  ["['inherit','pipe','pipe']", { stdio: ['inherit', 'pipe', 'pipe'] }],
  ["['pipe','pipe','pipe'] 显式", { stdio: ['pipe', 'pipe', 'pipe'] }],
  ["['ignore','ignore','pipe']", { stdio: ['ignore', 'ignore', 'pipe'] }],
];
for (const [label, opts] of variants) {
  console.log(String(label).padEnd(28), 'node -v:', m(N, ['-v'], opts).padEnd(12), ' git --version:', m(G, ['--version'], opts));
}

console.log('\n=== 真实调用：test-report.js 里那种（git rev-parse）===');
for (const [label, opts] of [['默认', undefined], ["['ignore','pipe','pipe']", { stdio: ['ignore', 'pipe', 'pipe'] }]]) {
  console.log(String(label).padEnd(28), m(G, ['rev-parse', '--short', 'HEAD'], Object.assign({ cwd: ROOT }, opts)));
}
