/* 探测 fearlessrevolution.com 在 headless Chrome（CDP 连法）下能否穿过 Cloudflare 挑战
 * 用 tools/browser.js 的 launchBrowser（本机 Edge 被沙箱拦、puppeteer.launch 链走不通）。
 * 只读探测，不写 data/。 */
const { launchBrowser } = require('../tools/browser');

const URL = process.argv[2] || 'https://fearlessrevolution.com/';

(async () => {
  const t0 = Date.now();
  let b;
  try {
    b = await launchBrowser();
    console.log('浏览器已连上，耗时', Date.now() - t0, 'ms');
    const page = await b.newPage();
    await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36');
    const resp = await page.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 });
    console.log('HTTP', resp && resp.status());

    for (const wait of [2500, 4000, 6000, 8000]) {
      await new Promise((r) => setTimeout(r, wait));
      const info = await page.evaluate(() => ({
        title: document.title,
        url: location.href,
        len: document.body ? document.body.innerText.length : 0,
        head: (document.body ? document.body.innerText : '').slice(0, 300).replace(/\s+/g, ' '),
      }));
      console.log(`  [${Date.now() - t0}ms] title="${info.title}" len=${info.len} url=${info.url.slice(0, 60)}`);
      if (!/Just a moment|Attention Required|Checking your browser|moment/i.test(info.title) && info.len > 800) {
        console.log('  ✔ 已穿过挑战');
        console.log('  正文:', info.head);
        break;
      }
    }
  } catch (e) {
    console.log('ERR', String(e.message).slice(0, 200));
  } finally {
    if (b) await b.close().catch(() => {});
  }
})();
