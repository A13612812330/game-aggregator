#!/usr/bin/env node
/**
 * _drop-v1041.js — 把 README 的 v10.41 摘要块移出，使「最近 5 版」惯例维持
 * （v10.46 新增一块 ⇒ 挤掉最旧的 v10.41；正文仍完整保存在 docs/versions/v10.41.md 与 git 里）
 *
 * ★ 先备份再改；改完打印「剩余版本块」与行数，便于核对。
 * ★ 只按**标题行索引**定位，不靠手抄长文本（抄错一个字就静默改坏文档）。
 */
'use strict';
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..');
const F = path.join(ROOT, 'README.md');

const before = fs.readFileSync(F, 'utf8');
const bak = path.join(ROOT, '_bak', 'README.md.pre-v1046-drop-v1041');
fs.mkdirSync(path.dirname(bak), { recursive: true });
fs.writeFileSync(bak, before, 'utf8');

const H = '### ★ v10.41 增量';
const SUB = '<sub>更早 ';
const s = before.indexOf(H);
const t = before.indexOf(SUB, s);
if (s < 0 || t < 0 || t <= s) {
  console.log('❌ 定位失败：v10.41 块起点=' + s + ' 结尾哨兵=' + t + ' ⇒ 未改动');
  process.exit(2);
}
let after = before.slice(0, s) + before.slice(t);
after = after.replace('<sub>更早 39 版（v10.1 → v10.39）的摘要已收敛',
  '<sub>更早 40 版（v10.1 → v10.41）的摘要已收敛');
fs.writeFileSync(F, after, 'utf8');

const heads = (txt) => (txt.match(/^### ★ v\d+\.\d+ 增量.*$/gm) || []);
console.log('已备份 → _bak/' + path.basename(bak));
console.log('行数 ' + before.split('\n').length + ' → ' + after.split('\n').length
  + '（移除 ' + (before.length - after.length) + ' 字符）');
console.log('剩余版本块 ' + heads(after).length + ' 个：');
heads(after).forEach((h) => console.log('   ' + h.slice(0, 46)));
console.log('v10.41 残留检查：' + (after.includes(H) ? '❌ 仍在' : '✅ 已移除'));
console.log('脚注：' + (after.match(/<sub>更早 [^<]*<\/sub>/) || ['(缺)'])[0]);
