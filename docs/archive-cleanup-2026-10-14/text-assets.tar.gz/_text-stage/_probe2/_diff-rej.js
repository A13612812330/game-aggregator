#!/usr/bin/env node
/** _diff-rej.js — 比两份 ab-*.json，列出「新增的拒绝」及其标题/命中库条目 */
'use strict';
const fs = require('fs');
const path = require('path');
const P = __dirname;
const A = JSON.parse(fs.readFileSync(path.join(P, process.argv[2]), 'utf8'));
const B = JSON.parse(fs.readFileSync(path.join(P, process.argv[3]), 'utf8'));
const ga = new Map(A.rows.map((r) => [r.id, r]));
const gb = new Map(B.rows.map((r) => [r.id, r]));
console.log(A.tag + ' 匹配 ' + A.matched + '（拒 ' + A.genRej + '） → ' + B.tag + ' 匹配 ' + B.matched + '（拒 ' + B.genRej + '）');
const newly = [];
for (const r of B.rows) {
  const o = ga.get(r.id);
  if (o && !o.gen && r.gen) newly.push({ b: r, o });
}
console.log('\n新增拒绝 ' + newly.length + ' 条：');
for (const x of newly) {
  console.log('  ✗ 「' + x.b.title + '」');
  console.log('      旧: ' + x.o.how + ' key=「' + x.o.key + '」 → 库「' + x.o.lib + '」');
  console.log('      新: 拒（紧贴位数字触发）');
}
const recovered = [];
for (const r of B.rows) {
  const o = ga.get(r.id);
  if (o && o.gen && !r.gen) recovered.push({ b: r, o });
}
console.log('\n新增放行 ' + recovered.length + ' 条：');
recovered.slice(0, 20).forEach((x) => console.log('  + 「' + x.b.title + '」 → 库「' + x.b.lib + '」'));
