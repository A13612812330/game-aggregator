#!/usr/bin/env node
/**
 * _ab-diff.js — 比对 ab-old.json 与 ab-new.json 的**逐条匹配结果**
 *
 * 目的不是「总数是否相等」（那是弱判据，铁律「比字节不比关键词」的同类精神），
 * 而是**逐条**比 how/key/klen/gen/libId —— 只要有 1 条不同就说明收口有影响面。
 *
 * 同时输出：新旧各自「代际拒绝」的 114 条明细（title / game / 命中库条目），
 * 用来定位护栏为什么在这里开火。
 */
'use strict';
const fs = require('fs');
const path = require('path');

const P = path.join(__dirname);
const A = JSON.parse(fs.readFileSync(path.join(P, 'ab-old.json'), 'utf8'));
const B = JSON.parse(fs.readFileSync(path.join(P, 'ab-new.json'), 'utf8'));

console.log('索引键：old ' + A.indexKeys + ' ｜ new ' + B.indexKeys);
console.log('库款数：old ' + A.libTotal + ' ｜ new ' + B.libTotal);
console.log('汇总：old ' + JSON.stringify(A.how) + ' gen ' + A.genRej);
console.log('      new ' + JSON.stringify(B.how) + ' gen ' + B.genRej);

const kf = (r) => r.id + '|' + r.how + '|' + r.key + '|' + r.klen + '|' + r.gen + '|' + r.libId;
let same = 0;
const diffs = [];
for (let i = 0; i < Math.max(A.rows.length, B.rows.length); i++) {
  const a = A.rows[i], b = B.rows[i];
  if (!a || !b) { diffs.push({ i, why: '长度不等' }); continue; }
  if (kf(a) === kf(b)) same++;
  else diffs.push({ i, id: a.id, old: kf(a), new: kf(b) });
}
console.log('\n逐条比对：相同 ' + same + ' / ' + A.rows.length + ' ｜ 不同 ' + diffs.length);
diffs.slice(0, 12).forEach((d) => {
  console.log('  ✗ ' + (d.id || '?'));
  console.log('     old ' + d.old);
  console.log('     new ' + d.new);
});

/* ── 代际拒绝明细（用 new 组的行，取 title 与命中库条目） ── */
const rej = B.rows.filter((r) => r.gen);
console.log('\n代际拒绝 ' + rej.length + ' 条，前 12 条：');
for (const r of rej.slice(0, 12)) {
  console.log('  「' + r.title + '」');
  console.log('     game=「' + r.game + '」 → 库「' + r.lib + '」');
}
