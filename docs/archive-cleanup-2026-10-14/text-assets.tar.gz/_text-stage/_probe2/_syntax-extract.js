#!/usr/bin/env node
/** _syntax-extract.js — 把四页的内联 <script> 抽成独立文件，便于用 `node --check` 逐个验语法 */
'use strict';
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..');
const OUT = path.join(__dirname, '_syntax');
fs.mkdirSync(OUT, { recursive: true });
for (const p of ['index', 'emulator', 'resources', 'unpack']) {
  const html = fs.readFileSync(path.join(ROOT, 'public', p + '.html'), 'utf8');
  const re = /<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/gi;
  const parts = [];
  for (const m of html.matchAll(re)) parts.push(m[1]);
  const body = parts.join('\n;\n');
  const f = path.join(OUT, p + '.js');
  fs.writeFileSync(f, body, 'utf8');
  console.log(p.padEnd(10) + parts.length + ' 个 script 块  → ' + body.split('\n').length + ' 行 / '
    + Buffer.byteLength(body, 'utf8') + ' 字节');
}
