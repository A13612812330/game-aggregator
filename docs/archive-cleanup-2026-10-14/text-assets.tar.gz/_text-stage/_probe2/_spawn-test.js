#!/usr/bin/env node
/** _spawn-test.js — 探测「进程内 spawn」在本机是否可用（用于判断沙箱假红） */
'use strict';
const { execFileSync, spawnSync } = require('child_process');
console.log('execPath =', process.execPath);
console.log('NODE_OPTIONS =', JSON.stringify(process.env.NODE_OPTIONS || ''));
console.log('--require 注入 =', process.execArgv.join(' '));
try {
  const o = execFileSync(process.execPath, ['-v'], { encoding: 'utf8' });
  console.log('execFileSync 自身 node -v =>', o.trim(), '⇒ spawn 可用');
} catch (e) {
  console.log('execFileSync 失败 =>', String((e && e.code) || e.message));
}
try {
  const r = spawnSync('git', ['--version'], { encoding: 'utf8' });
  console.log('spawnSync git =>', r.error ? ('error ' + r.error.code) : String(r.stdout || '').trim());
} catch (e) {
  console.log('spawnSync git 抛错 =>', String((e && e.code) || e.message));
}
