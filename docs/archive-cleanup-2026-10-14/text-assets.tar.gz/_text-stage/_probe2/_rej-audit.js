#!/usr/bin/env node
/**
 * _rej-audit.js — 复核 Q7 拒掉的那 23 条：库里到底有没有「正确那一代」的条目？
 *
 * 为什么要核：如果不只是「拒了一个错匹配」，而是「库里本来有对的那一款、我们没找到」，
 *   那就不是护栏问题而是索引/归一化问题，处置方式完全不同。
 */
'use strict';
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..');
const gamesDb = require(path.join(ROOT, 'data/gamesDb'));
gamesDb.load();
const all = gamesDb.all();

const targets = ['仙剑奇侠传', '三位一体', '进击的巨人', '永恒之柱', '三维弹球', '英雄传说', '横冲直撞', '丧尸围城'];
for (const name of targets) {
  const hits = all.filter((x) => String(x.title || '').includes(name));
  console.log('\n【库内含「' + name + '」的条目 ' + hits.length + ' 款】');
  hits.slice(0, 14).forEach((x) => console.log('   ' + x.title));
  if (hits.length > 14) console.log('   … 其余 ' + (hits.length - 14) + ' 款');
}
