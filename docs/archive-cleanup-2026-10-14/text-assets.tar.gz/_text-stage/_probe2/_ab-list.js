#!/usr/bin/env node
/**
 * _ab-list.js — 阶段①「列表条目 × 端游库」匹配的 A/B 复现（只跑匹配，不抓详情）
 *
 * 背景：normKey 收口后真实重跑 matched 2066 → 1952。上一轮探针用「落盘 item」重放，
 *   但落盘 item 的 game 字段已被**详情页覆盖**（tools/fetch-saves-youxia.js L169
 *   `game: d.game || it.game`），而匹配发生在**阶段①**、用的是列表页条目 ⇒ 输入本身就错。
 *   本脚本直接读 data/_yx-list-raw.json（阶段①的原始输入），走真模块。
 *
 * 用法：node _probe2/_ab-list.js <标签>   # 标签用于输出文件名，如 old / new
 * 产出：_probe2/ab-<标签>.json  { keys, how, rows[] }
 *
 * ★ 自检：先断言「本脚本用到的模块确实是它自称的那一份」——
 *   打印 data/mod-match.js 与 fetchers/youxiaSave.js 的 md5，避免换错文件还以为在比 A/B。
 */
'use strict';
const fs = require('fs');
const path = require('path');
const cp = require('crypto');

const ROOT = path.join(__dirname, '..');
const tag = process.argv[2] || 'x';

const md5 = (p) => cp.createHash('md5').update(fs.readFileSync(p)).digest('hex').slice(0, 10);

const { buildLibIndex } = require(path.join(ROOT, 'data/mod-match'));
const yx = require(path.join(ROOT, 'fetchers/youxiaSave'));
const gamesDb = require(path.join(ROOT, 'data/gamesDb'));

const list = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/_yx-list-raw.json'), 'utf8')).items || [];

gamesDb.load();
const all = gamesDb.all();
const { byName } = buildLibIndex(all);

const how = { bracket: 0, prefix: 0, none: 0 };
const genRej = { n: 0 };
const rows = [];
for (const it of list) {
  const m = yx.matchYxEntry(it, byName);
  how[m.how]++;
  if (m.genReject) genRej.n++;
  rows.push({
    id: it.id,
    title: it.title,
    game: it.game || '',
    how: m.how,
    key: m.key,
    klen: m.klen,
    gen: m.genReject ? 1 : 0,
    lib: m.lib ? (m.lib.title || '') : '',
    libId: m.lib ? (m.lib.id || '') : '',
  });
}

const out = {
  tag,
  files: {
    modMatch: md5(path.join(ROOT, 'data/mod-match.js')),
    youxiaSave: md5(path.join(ROOT, 'fetchers/youxiaSave.js')),
    nameNormalize: md5(path.join(ROOT, 'data/name-normalize.js')),
  },
  libTotal: all.length,
  indexKeys: byName.size,
  listTotal: list.length,
  how, genRej: genRej.n,
  matched: how.bracket + how.prefix,
  rows,
};
fs.writeFileSync(path.join(__dirname, 'ab-' + tag + '.json'), JSON.stringify(out));
console.log(JSON.stringify(out.files));
console.log('库 ' + out.libTotal + ' 款 ⇒ 索引键 ' + out.indexKeys
  + ' ｜ 列表 ' + out.listTotal
  + ' ｜ 匹配 ' + out.matched
  + '（书名号 ' + how.bracket + ' · 前缀 ' + how.prefix + ' · 未匹配 ' + how.none + '）'
  + ' ｜ 代际拒绝 ' + genRej.n);
