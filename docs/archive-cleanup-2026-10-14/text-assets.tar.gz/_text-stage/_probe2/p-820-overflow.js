/* 探针：820px 视口下 documentElement.scrollWidth = 845 —— 到底是谁溢出？
 * 跑法：node _probe2/p-820-overflow.js */
const { connectBrowser, newPage, sleep } = require('../tools/browser');
const BASE = 'http://127.0.0.1:8123';
(async () => {
  const h = await connectBrowser();
  const p = await newPage(h.browser, { width: 1440, height: 1000 });
  p.on('pageerror', (e) => console.log('pageerror: ' + e.message));
  await p.goto(BASE + '/index.html', { waitUntil: 'networkidle2', timeout: 60000 });
  await p.waitForSelector('#colMain .row-card', { timeout: 30000 });
  await sleep(1200);
  // 复刻 test-search-ui 的做法：打开搜索 → 点一条 → 开抽屉
  await p.evaluate(() => { const b = document.querySelector('#searchBtn, .search-btn, #navSearch'); if (b) b.click(); });
  await sleep(800);
  await p.evaluate(() => { const i = document.querySelector('#searchInput'); if (i) { i.value = '赛博朋克'; i.dispatchEvent(new Event('input', { bubbles: true })); } });
  await sleep(1500);
  const opened = await p.evaluate(() => {
    const c = document.querySelector('#colMain .row-card');
    if (c) { c.click(); return true; }
    return false;
  });
  await sleep(2000);
  await p.setViewport({ width: 820, height: 900, deviceScaleFactor: 1 });
  await sleep(500);
  const r = await p.evaluate(() => {
    const vw = window.innerWidth;
    const bad = [];
    document.querySelectorAll('*').forEach((el) => {
      const b = el.getBoundingClientRect();
      if (b.width < 2 || b.height < 2) return;
      if (b.right > vw + 1) {
        bad.push({
          sel: el.tagName.toLowerCase() + (el.id ? '#' + el.id : '') + (el.className && typeof el.className === 'string' ? '.' + el.className.trim().split(/\s+/).slice(0, 3).join('.') : ''),
          right: Math.round(b.right), w: Math.round(b.width),
          parent: (el.parentElement ? el.parentElement.tagName.toLowerCase() + (el.parentElement.id ? '#' + el.parentElement.id : '') : ''),
        });
      }
    });
    // 去重：只留最外层 30 条
    return { vw, doc: document.documentElement.scrollWidth, body: document.body.scrollWidth, count: bad.length, bad: bad.slice(0, 30) };
  });
  console.log('opened drawer =', opened);
  console.log('viewport=' + r.vw + '  doc.scrollWidth=' + r.doc + '  body.scrollWidth=' + r.body + '  溢出元素 ' + r.count + ' 个');
  for (const b of r.bad) console.log(`  right=${b.right} w=${b.w}  ${b.sel}   (parent ${b.parent})`);
  await p.screenshot({ path: require('path').join(__dirname, 'p-820.png') });
  await h.browser.close();
})().catch((e) => { console.error('FATAL', e.message); process.exit(2); });
