/* 验证 FR 附件在**未登录**状态下能否直接下载（决定它能否给出真实下载链） */
const http = require('http');
const path = require('path');
const fs = require('fs');
const { spawn, execFileSync } = require('child_process');
const puppeteer = require('puppeteer-core');

const CAND = ['C:/Users/komo/AppData/Local/Google/Chrome/Application/chrome.exe', 'C:/Program Files/Google/Chrome/Application/chrome.exe'];
const PORT = 9339;
const BASE = 'https://fearlessrevolution.com';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const cdpUp = (port) => new Promise((res) => {
  const r = http.get(`http://127.0.0.1:${port}/json/version`, (x) => { x.resume(); res(x.statusCode === 200); });
  r.on('error', () => res(false)); r.setTimeout(1200, () => { r.destroy(); res(false); });
});

(async () => {
  const exe = CAND.find((p) => fs.existsSync(p));
  const profile = path.join(__dirname, '..', '.cache', 'chrome-headed');
  fs.mkdirSync(profile, { recursive: true });
  const child = spawn(exe, ['--no-first-run', '--no-default-browser-check',
    `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`, '--window-size=1280,900', 'about:blank'],
    { detached: true, stdio: 'ignore' });
  child.unref();
  let ok = false;
  for (let i = 0; i < 30 && !(ok = await cdpUp(PORT)); i++) await sleep(500);
  if (!ok) { console.log('CDP 未就绪'); return; }
  const b = await puppeteer.connect({ browserURL: `http://127.0.0.1:${PORT}` });
  const page = await b.newPage();
  try {
    await page.goto(BASE + '/', { waitUntil: 'domcontentloaded', timeout: 60000 }).catch(() => {});
    for (let i = 0; i < 20; i++) { const t = await page.title().catch(() => ''); if (!/moment|稍候/i.test(t)) break; await sleep(4000); }
    console.log('已过挑战:', await page.title());

    const html = (await page.evaluate(async () => (await fetch('/viewtopic.php?f=4&t=25220', { credentials: 'include' })).text()));
    const ids = [...new Set([...html.matchAll(/download\/file\.php\?id=(\d+)/g)].map((m) => m[1]))];
    console.log('该帖附件 id:', ids.slice(0, 8).join(', '), '共', ids.length);

    for (const id of ids.slice(0, 3)) {
      const r = await page.evaluate(async (i) => {
        try {
          const res = await fetch('/download/file.php?id=' + i, {
            credentials: 'include',
            headers: { Range: 'bytes=0-63' },
          });
          const buf = new Uint8Array(await res.arrayBuffer());
          const magic = [...buf.slice(0, 4)].map((x) => x.toString(16).padStart(2, '0')).join(' ');
          return {
            status: res.status, type: res.headers.get('content-type'),
            len: res.headers.get('content-length'), cdisp: res.headers.get('content-disposition'),
            magic, url: res.url,
            text: new TextDecoder().decode(buf.slice(0, 40)),
          };
        } catch (e) { return { err: String(e.message).slice(0, 100) }; }
      }, id);
      console.log(`  id=${id} =>`, JSON.stringify(r));
    }
  } catch (e) { console.log('ERR', String(e.message).slice(0, 200)); }
  finally {
    try { await b.disconnect(); } catch (e) {}
    try { execFileSync('taskkill', ['/PID', String(child.pid), '/T', '/F'], { stdio: 'ignore' }); } catch (e) {}
  }
})();
