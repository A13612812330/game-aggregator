/* 临时：解析 run-all 输出，逐套求和并交叉核验（只读） */
const fs = require('fs');
const file = process.argv[2] || 'C:/Users/komo/AppData/Local/Temp/runall.txt';
const s = fs.readFileSync(file, 'utf8');
const lines = s.split(/\r?\n/);
const re = /^ {2}(\S+\.js) {2}exit=(\d+) {2}(\d+)\/(\d+)$/;
const rows = [];
let sumP = 0, sumT = 0;
for (const l of lines) {
  const m = re.exec(l);
  if (m) { rows.push(m); sumP += Number(m[3]); sumT += Number(m[4]); }
}
console.log('套件成绩行数 =', rows.length);
console.log('逐套求和 =', sumP + ' / ' + sumT);
const bad = rows.filter((m) => m[2] !== '0' || m[3] !== m[4]);
console.log('非全绿行 =', bad.length, bad.map((m) => m[1]).join(',') || '(无)');
console.log('--- 明细 ---');
for (const m of rows) console.log(m[1].padEnd(34), m[3] + '/' + m[4]);
