#!/usr/bin/env node
/**
 * _guard-q6.js — 候选口径 Q6：「紧贴匹配键的数字才算代际」
 *
 * 动机（Q1~Q5 的实测结果）：
 *   Q1 整条标题      匹配 1952 · 拒 114  ← 现行代码；把「v1.2 / 80级 / 2号升级档」当成了代际
 *   Q2 item.game     匹配 2066 · 拒   0  ← 旧运行的口径；但 game 在**前缀通道上恒为空** ⇒ 护栏等于失效
 *   Q3 首段          匹配 2039 · 拒  27
 *   Q4 命中候选      匹配 2066 · 拒   0  ← 同样失效（候选已被收缩掉数字，等于查无数字）
 *   Q5 详情标题      匹配 1951 · 拒 115
 *
 * Q6 的设计意图：护栏要看的是「**代际数字**」，而代际数字在真实标题里有个共同形态 ——
 *   **紧贴游戏名**（黑道圣徒3 / 三位一体2 / 仙剑奇侠传3外传 / 英雄传说6）；
 *   而版本号、等级、序号是**隔着空格或字母**的（泰拉瑞亚 地图存档v1.2 / 龙珠：超宇宙 80级 /
 *   厕所穿越记 v1.47 / 愤怒的小鸟季节版V2.4 / 特殊行动：一线生机 2号升级档）。
 *   ⇒ 只取「紧跟匹配键那一位数字」当代际，其余数字一概不参与代际判定。
 *
 * 判据同 _guard-ab.js：逐条 (how, libId, matchKey) 与旧备份比对，且备份外必须 none。
 */
'use strict';
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const { normKey, numMismatchByTitle, genNums } = require(path.join(ROOT, 'data/name-normalize'));
const { keyUsable, buildLibIndex } = require(path.join(ROOT, 'data/mod-match'));
const yx = require(path.join(ROOT, 'fetchers/youxiaSave'));
const gamesDb = require(path.join(ROOT, 'data/gamesDb'));

const list = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/_yx-list-raw.json'), 'utf8')).items || [];
const bak = JSON.parse(fs.readFileSync(path.join(ROOT, '_bak/saves-youxia.json.before-normalize-unify'), 'utf8'));
const bakById = new Map(bak.items.map((x) => [x.id, x]));

gamesDb.load();
const all = gamesDb.all();
const { byName } = buildLibIndex(all);

/** ★ Q6 核心：紧贴匹配键的数字 → 当作代际；命中库条目通篇没有 ⇒ 拒绝 */
function adjGenReject(rawTitle, matchedRaw, lib) {
  const i = String(rawTitle || '').indexOf(String(matchedRaw || ''));
  if (i < 0 || !matchedRaw) return false;
  const rest = String(rawTitle).slice(i + String(matchedRaw).length);
  const m = rest.match(/^(\d{1,2})(?![0-9])/);
  if (!m) return false;
  const tn = genNums(lib.title || '');
  return !tn.includes(m[1]);
}

function replay(item, useQ6) {
  const none = { how: 'none', key: '', libId: '', gen: 0 };
  if (item.game) {   /* 精确通道：两种口径一致（实测 bracket 恒 1211） */
    const k = normKey(item.game);
    const lib = keyUsable(k) ? byName.get(k) : null;
    if (!lib) return none;
    if (numMismatchByTitle(item.game, lib)) return Object.assign({}, none, { gen: 1 });
    return { how: 'bracket', key: item.game, libId: lib.id || '', gen: 0 };
  }
  const first = String(item.title || '').trim().split(/\s+/)[0] || '';
  const firstKey = normKey(first);
  const guard = (matchedRaw, lib) => (useQ6 ? adjGenReject(item.title, matchedRaw, lib)
    : numMismatchByTitle(item.title, lib));

  if (keyUsable(firstKey) && byName.has(firstKey)) {
    const lib = byName.get(firstKey);
    if (!guard(first, lib)) return { how: 'prefix', key: first, libId: lib.id || '', gen: 0 };
    return Object.assign({}, none, { gen: 1 });
  }
  for (const c of yx.shrinkCandidates(item.title)) {
    const k = normKey(c);
    if (!keyUsable(k) || k.length < 3) continue;
    if (!byName.has(k)) continue;
    const lib = byName.get(k);
    if (guard(c, lib)) return Object.assign({}, none, { gen: 1 });
    return { how: 'prefix', key: c, libId: lib.id || '', gen: 0 };
  }
  return none;
}

for (const [name, useQ6] of [['Q1 整条标题（现行）', false], ['Q6 紧贴匹配键', true]]) {
  let matched = 0, bracket = 0, prefix = 0, gen = 0, okBak = 0, badBak = 0, okAbsent = 0, badAbsent = 0;
  const bad = [];
  for (const it of list) {
    const r = replay(it, useQ6);
    if (r.gen) gen++;
    if (r.how !== 'none') { matched++; if (r.how === 'bracket') bracket++; else prefix++; }
    const b = bakById.get(it.id);
    if (b) {
      const same = ((b.matchHow || 'none') === r.how) && ((b.libId || '') === r.libId) && ((b.matchKey || '') === r.key);
      if (same) okBak++; else { badBak++; if (bad.length < 10) bad.push({ id: it.id, title: it.title, bak: b.matchHow + '/' + b.matchKey, got: r.how + '/' + r.key }); }
    } else if (r.how === 'none') okAbsent++; else badAbsent++;
  }
  console.log('\n【' + name + '】匹配 ' + matched + '（括 ' + bracket + ' · 前 ' + prefix + '）｜护栏拒 ' + gen
    + ' ｜备份内相符 ' + okBak + '/不符 ' + badBak + ' ｜备份外 none ' + okAbsent + '/误配 ' + badAbsent);
  bad.forEach((x) => console.log('   ✗ ' + x.id + ' 「' + x.title + '」\n       备份 ' + x.bak + ' → 重放 ' + x.got));
}
console.log('\n旧备份基准：matched ' + bak.stats.matched + '（括 ' + bak.stats.matchBracket + ' · 前 ' + bak.stats.matchPrefix + '）');
