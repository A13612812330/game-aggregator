#!/usr/bin/env node
/**
 * _guard-q7.js — 三个口径并排 + 全部拒绝条目明细（带命中库条目，便于逐条人工核对）
 *
 *   Q1  整条标题                     （现行代码）
 *   Q6  紧贴匹配键的 1~2 位数字
 *   Q7  紧贴匹配键的 1 位数字        （更严：把「50级」这类两位量词挡在门外）
 *
 * 输出同时落 _probe2/guard-report.txt，便于留档。
 */
'use strict';
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const { normKey, numMismatchByTitle, genNums } = require(path.join(ROOT, 'data/name-normalize'));
const { keyUsable, buildLibIndex } = require(path.join(ROOT, 'data/mod-match'));
const yx = require(path.join(ROOT, 'fetchers/youxiaSave'));
const gamesDb = require(path.join(ROOT, 'data/gamesDb'));

const list = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/_yx-list-raw.json'), 'utf8')).items || [];
const bak = JSON.parse(fs.readFileSync(path.join(ROOT, '_bak/saves-youxia.json.before-normalize-unify'), 'utf8'));
const bakById = new Map(bak.items.map((x) => [x.id, x]));

gamesDb.load();
const all = gamesDb.all();
const { byName } = buildLibIndex(all);

/** 紧贴匹配键的数字当代际；mode='1' 只认 1 位，mode='12' 认 1~2 位 */
function adjGen(rawTitle, matchedRaw, lib, mode) {
  const i = String(rawTitle || '').indexOf(String(matchedRaw || ''));
  if (i < 0 || !matchedRaw) return null;
  const rest = String(rawTitle).slice(i + String(matchedRaw).length);
  const re = mode === '1' ? /^(\d)(?![0-9])/ : /^(\d{1,2})(?![0-9])/;
  const m = rest.match(re);
  if (!m) return null;
  const tn = genNums(lib.title || '');
  return { digit: m[1], libHas: tn.includes(m[1]), tn };
}

function replay(item, mode) {
  const none = { how: 'none', key: '', libId: '', libTitle: '', gen: 0, why: '', digit: '' };
  if (item.game) {
    const k = normKey(item.game);
    const lib = keyUsable(k) ? byName.get(k) : null;
    if (!lib) return none;
    if (numMismatchByTitle(item.game, lib)) return Object.assign({}, none, { gen: 1, why: '精确通道-整名护栏' });
    return { how: 'bracket', key: item.game, libId: lib.id || '', libTitle: lib.title || '', gen: 0, why: '', digit: '' };
  }
  const first = String(item.title || '').trim().split(/\s+/)[0] || '';
  const firstKey = normKey(first);

  const hit = (matchedRaw, lib) => {
    if (mode === 'Q1') return numMismatchByTitle(item.title, lib)
      ? { rej: 1, why: '整条标题带数字且库条目没有', digit: genNums(item.title).join(',') } : null;
    const a = adjGen(item.title, matchedRaw, lib, mode === 'Q6' ? '12' : '1');
    return a && !a.libHas ? { rej: 1, why: '紧贴键的《' + a.digit + '》库条目没有（库数字 ' + JSON.stringify(a.tn) + '）', digit: a.digit } : null;
  };

  if (keyUsable(firstKey) && byName.has(firstKey)) {
    const lib = byName.get(firstKey);
    const r = hit(first, lib);
    if (r) return Object.assign({}, none, r, { gen: 1, libTitle: lib.title || '' });
    return { how: 'prefix', key: first, libId: lib.id || '', libTitle: lib.title || '', gen: 0, why: '', digit: '' };
  }
  for (const c of yx.shrinkCandidates(item.title)) {
    const k = normKey(c);
    if (!keyUsable(k) || k.length < 3) continue;
    if (!byName.has(k)) continue;
    const lib = byName.get(k);
    const r = hit(c, lib);
    if (r) return Object.assign({}, none, r, { gen: 1, libTitle: lib.title || '' });
    return { how: 'prefix', key: c, libId: lib.id || '', libTitle: lib.title || '', gen: 0, why: '', digit: '' };
  }
  return none;
}

const lines = [];
const out = (s) => { lines.push(s); console.log(s); };

for (const mode of ['Q1', 'Q6', 'Q7']) {
  let matched = 0, bracket = 0, prefix = 0, okBak = 0, badBak = 0, badAbsent = 0;
  const rejs = [];
  for (const it of list) {
    const r = replay(it, mode);
    if (r.how !== 'none') { matched++; r.how === 'bracket' ? bracket++ : prefix++; }
    const b = bakById.get(it.id);
    if (b) {
      const same = ((b.matchHow || 'none') === r.how) && ((b.libId || '') === r.libId) && ((b.matchKey || '') === r.key);
      if (same) okBak++; else { badBak++; if (r.gen) rejs.push({ it, r, bak: b }); }
    } else if (r.how !== 'none') badAbsent++;
  }
  out('\n════ ' + mode + ' ════  匹配 ' + matched + '（括 ' + bracket + ' · 前 ' + prefix + '）'
    + ' ｜ 与旧备份不符 ' + badBak + '（其中判 none 的 = 护栏拒 ' + rejs.length + '）'
    + ' ｜ 备份外新增误配 ' + badAbsent);
  for (const x of rejs) {
    out('   ✗ ' + x.it.id + ' 「' + x.it.title + '」');
    out('        命中库条「' + x.r.libTitle + '」');
    out('        护栏拒绝理由：' + x.r.why);
    out('        旧备份记的是：' + x.bak.matchHow + ' / key=「' + x.bak.matchKey + '」');
  }
}
out('\n旧备份基准：matched ' + bak.stats.matched + '（括 ' + bak.stats.matchBracket + ' · 前 ' + bak.stats.matchPrefix + '）覆盖库 ' + bak.stats.libCovered + ' 款');
fs.writeFileSync(path.join(__dirname, 'guard-report.txt'), lines.join('\n'));
console.log('\n已落盘 → _probe2/guard-report.txt');
