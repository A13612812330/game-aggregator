#!/usr/bin/env node
/** _eng-audit.js — 工程底座现测（ROADMAP §1.5 的数字来源） */
'use strict';
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..');

const srv = fs.readFileSync(path.join(ROOT, 'server.js'), 'utf8');
const routes = srv.match(/app\.(?:get|post|put|delete)\s*\(/g) || [];
const apiRoutes = srv.match(/app\.(get|post|put|delete)\s*\(\s*'\/api\//g) || [];
console.log('server.js 行数 = ' + srv.split('\n').length + ' ｜ 路由 ' + routes.length + ' 条（/api/* ' + apiRoutes.length + ' 条）');

const tools = fs.readdirSync(path.join(ROOT, 'tools')).filter((f) => f.endsWith('.js'));
const priv = tools.filter((f) => f.startsWith('_'));
const preview = tools.filter((f) => /^preview-.*\.js$/.test(f));
const v1025 = tools.filter((f) => /^test-v1025-.*\.js$/.test(f));
console.log('tools/*.js = ' + tools.length + ' 个（_* ' + priv.length + ' 个）'
  + ' ｜ preview-* ' + preview.length + ' 个 ｜ test-v1025-* ' + v1025.length + ' 个');

const walk = (d) => {
  let n = 0;
  for (const e of fs.readdirSync(d, { withFileTypes: true })) {
    if (e.name === 'node_modules' || e.name === '.git') continue;
    const p = path.join(d, e.name);
    if (e.isDirectory()) n += walk(p);
    else { try { n += fs.statSync(p).size; } catch (x) {} }
  }
  return n;
};
const total = walk(ROOT);
console.log('项目目录 = ' + (total / 1048576).toFixed(0) + ' MB（' + total + ' 字节，不含 node_modules/.git）');

const df = fs.readdirSync(path.join(ROOT, 'docs', 'versions')).filter((f) => /^v10\.\d+\.md$/.test(f));
console.log('docs/versions = ' + df.length + ' 份');
