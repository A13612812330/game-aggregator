'use strict';
const fs=require('fs'),path=require('path');
const d=JSON.parse(fs.readFileSync(path.join(__dirname,'..','data','saves-youxia.json'),'utf8'));
const kinds={};
for(const it of d.items){ for(const n of ((it.files&&it.files.netdisk)||[])) kinds[n.kind]=(kinds[n.kind]||0)+1; }
const sz=d.items.map(x=>Buffer.byteLength(JSON.stringify(x),'utf8')).sort((a,b)=>a-b);
const q=(p)=>sz[Math.floor(sz.length*p)];
console.log('网盘分布:',JSON.stringify(kinds));
console.log('单条字节 p50='+q(0.5)+' p90='+q(0.9)+' max='+sz[sz.length-1]);
console.log('文件大小中位:', d.stats.sizeFileMedian||'(无该字段)');
console.log('时间跨度:', d.items.map(x=>x.date).filter(Boolean).sort()[0], '→', d.items.map(x=>x.date).filter(Boolean).sort().pop());
