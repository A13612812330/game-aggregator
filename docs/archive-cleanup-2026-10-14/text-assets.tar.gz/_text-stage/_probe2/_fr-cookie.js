/* 验证：过完 CF 挑战后拿到的 cookie，能否让普通 HTTP 请求（node fetch）直接通行。
 * 若能 ⇒ fetcher 只需首次用浏览器过一次，之后全走 HTTP（快且稳）。
 * 不能 ⇒ fetcher 必须全程走浏览器会话。 */
const http = require('http');
const path = require('path');
const fs = require('fs');
const { spawn, execFileSync } = require('child_process');
const puppeteer = require('puppeteer-core');

const CAND = [
  'C:/Users/komo/AppData/Local/Google/Chrome/Application/chrome.exe',
  'C:/Program Files/Google/Chrome/Application/chrome.exe',
];
const PORT = 9334;
const HOME = 'https://fearlessrevolution.com/';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const cdpUp = (port) => new Promise((res) => {
  const r = http.get(`http://127.0.0.1:${port}/json/version`, (x) => { x.resume(); res(x.statusCode === 200); });
  r.on('error', () => res(false)); r.setTimeout(1200, () => { r.destroy(); res(false); });
});
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36';

(async () => {
  const exe = CAND.find((p) => fs.existsSync(p));
  const profile = path.join(__dirname, '..', '.cache', 'chrome-headed');
  fs.mkdirSync(profile, { recursive: true });
  const child = spawn(exe, ['--no-first-run', '--no-default-browser-check',
    `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`, '--window-size=1280,900', 'about:blank'],
    { detached: true, stdio: 'ignore' });
  child.unref();
  let ok = false;
  for (let i = 0; i < 30 && !(ok = await cdpUp(PORT)); i++) await sleep(500);
  if (!ok) { console.log('CDP 未就绪'); return; }

  const b = await puppeteer.connect({ browserURL: `http://127.0.0.1:${PORT}` });
  try {
    const page = await b.newPage();
    const t0 = Date.now();
    await page.goto(HOME, { waitUntil: 'domcontentloaded', timeout: 45000 });
    let title = '';
    for (let i = 0; i < 8; i++) {
      await sleep(3500);
      title = await page.title();
      if (!/moment|稍候|Attention/i.test(title)) break;
    }
    console.log(`过挑战耗时 ${Date.now() - t0}ms · title="${title}"`);

    const cookies = await page.cookies(HOME);
    console.log('页面上可见 cookie:', cookies.map((c) => c.name).join(', ') || '(无)');
    const cdp = await page.createCDPSession();
    const all = (await cdp.send('Network.getAllCookies')).cookies.filter((c) => /fearlessrevolution/.test(c.domain));
    console.log('CDP 全部 cookie:', all.map((c) => `${c.name}${c.httpOnly ? '(httpOnly)' : ''}`).join(', ') || '(无)');
    const jar = all.map((c) => `${c.name}=${c.value}`).join('; ');

    // 用 cookie 走纯 HTTP 试试
    for (const [name, url] of [['首页', HOME], ['搜索页', 'https://fearlessrevolution.com/search/']]) {
      try {
        const r = await fetch(url, {
          headers: { 'User-Agent': UA, Cookie: jar, Referer: HOME, 'Accept-Language': 'en-US,en;q=0.9' },
          redirect: 'follow',
        });
        const t = await r.text();
        const mt = (t.match(/<title>([^<]*)<\/title>/) || [])[1] || '';
        console.log(`  HTTP ${name}: ${r.status}  len=${t.length}  title="${mt.slice(0, 60)}"`);
      } catch (e) { console.log(`  HTTP ${name}: ERR ${String(e.message).slice(0, 80)}`); }
    }
    fs.writeFileSync(path.join(__dirname, 'fr-cookies.json'), JSON.stringify({ ua: UA, jar, at: Date.now() }, null, 1));
    console.log('cookie 已存 _probe2/fr-cookies.json');
  } catch (e) { console.log('ERR', String(e.message).slice(0, 160)); }
  finally {
    try { await b.disconnect(); } catch (e) {}
    try { execFileSync('taskkill', ['/PID', String(child.pid), '/T', '/F'], { stdio: 'ignore' }); } catch (e) {}
  }
})();
