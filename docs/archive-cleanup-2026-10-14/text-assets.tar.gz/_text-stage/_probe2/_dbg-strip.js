/* 调试守卫的剥离逻辑：打印 check-stdio-guard.js 剥离后的 100~118 行 */
'use strict';
const fs = require('fs');
const path = require('path');
const src = fs.readFileSync(path.join(__dirname, '..', 'tools', 'check-stdio-guard.js'), 'utf8');

/* 复刻工具里的实现 */
const STDIO_TOKENS = new Set(['pipe', 'ignore', 'inherit', 'ipc', 'overlapped']);
function strip(s) {
  const out = s.split('');
  const n = s.length;
  let i = 0;
  const blank = (a, b) => { for (let k = a; k < b && k < n; k++) if (out[k] !== '\n') out[k] = ' '; };
  while (i < n) {
    const c = s[i], c2 = s[i + 1];
    if (c === '/' && c2 === '/') { const e = s.indexOf('\n', i); blank(i, e < 0 ? n : e); i = e < 0 ? n : e; continue; }
    if (c === '/' && c2 === '*') { const e = s.indexOf('*/', i + 2); const end = e < 0 ? n : e + 2; blank(i, end); i = end; continue; }
    if (c === '"' || c === "'" || c === '`') {
      let j = i + 1;
      while (j < n) { if (s[j] === '\\') { j += 2; continue; } if (s[j] === c) break; j++; }
      const body = s.slice(i + 1, Math.min(j, n));
      if (!STDIO_TOKENS.has(body)) blank(i + 1, Math.min(j, n));
      i = Math.min(j, n) + 1;
      continue;
    }
    i++;
  }
  return out.join('');
}

const st = strip(src);
const lines = st.split('\n');
for (let k = 99; k < 120; k++) console.log(String(k + 1).padStart(4), JSON.stringify(lines[k] || ''));
