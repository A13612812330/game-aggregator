/* _probe2/_cmp-match.js —— 一次性诊断（不是产品代码，只用于本轮判断「归一化收口」的影响）
 *
 * 目的：**同一份输入、同一套匹配逻辑，只换 `normKey` 实现**，量化命中差异。
 * 为什么不能直接拿 data/saves-youxia.json 对比：那份 item 带了 `game` 字段，
 * 会让 matchYxEntry 走「书名号」分支，而它们原本走的是「前缀」分支 —— 输入结构一变，
 * 对比的就不是同一件事了（第一版就是这么看走眼的）。
 *
 * 用法：node _probe2/_cmp-match.js
 */
'use strict';
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..');
const { keyUsable } = require(path.join(ROOT, 'data/mod-match'));
const { normKey, numMismatchByTitle } = require(path.join(ROOT, 'data/name-normalize'));

/* 收口前的 mod-match 自带字符类（逐字抄自 v10.45 的 data/mod-match.js） */
const OLD_SYMS = /[：:·・,，.。!！?？'"“”‘’()（）\[\]【】《》<>~～\-–—_+*&/／|｜\\]/g;
const normKeyOld = (s) => String(s || '').toLowerCase()
  .replace(/[\s\u3000]+/g, '')
  .replace(OLD_SYMS, '');

function build(nk, all) {
  const byName = new Map();
  const add = (k, it) => { if (keyUsable(k) && !byName.has(k)) byName.set(k, it); };
  for (const it of all) {
    for (const seg of String(it.title || '').split('/')) add(nk(seg), it);
    for (const a of it.aliases || []) add(nk(a), it);
  }
  return byName;
}

const shrink = (title) => {
  const first = String(title || '').trim().split(/\s+/)[0] || '';
  const out = [];
  for (let k = Math.min(14, first.length) - 1; k >= 3; k--) out.push(first.slice(0, k));
  return out;
};

/** 与 fetchers/youxiaSave.js 的 matchYxEntry 逐行对齐，只把 normKey 变成可注入参数 */
function match(item, byName, nk) {
  const rej = { lib: null, how: 'none', key: '' };
  if (item && item.game) {
    const k = nk(item.game);
    const lib = keyUsable(k) ? byName.get(k) : null;
    if (!lib) return rej;
    if (numMismatchByTitle(item.game, lib)) return rej;
    return { lib, how: 'bracket', key: item.game };
  }
  const first = String((item && item.title) || '').trim().split(/\s+/)[0] || '';
  const fk = nk(first);
  if (keyUsable(fk) && byName.has(fk)) {
    const lib = byName.get(fk);
    if (!numMismatchByTitle(item.title, lib)) return { lib, how: 'prefix', key: first };
    return rej;
  }
  for (const c of shrink(item && item.title)) {
    const k = nk(c);
    if (!keyUsable(k) || k.length < 3) continue;
    if (!byName.has(k)) continue;
    const lib = byName.get(k);
    if (numMismatchByTitle(item.title, lib)) return rej;
    return { lib, how: 'prefix', key: c };
  }
  return rej;
}

/* ★ 必须用 `gamesDb.all()` —— 这是 fetch-saves-youxia.js 实际喂给 buildLibIndex 的东西。
   第一版我直接读 data/games.json 的 items，索引键不一样，
   于是「prefix 741 vs 落盘 855」对不上（差 114），白折腾一轮。 */
const gamesDb = require(path.join(ROOT, 'data/gamesDb'));
gamesDb.load();
const all = gamesDb.all();
const raw = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/_yx-list-raw.json'), 'utf8')).items;
console.log('端游库', all.length, '款（gamesDb.all()）');

const idxOld = build(normKeyOld, all);
const idxNew = build(normKey, all);

const cnt = (o) => { const r = { bracket: 0, prefix: 0, none: 0 }; for (const x of o) r[x] = (r[x] || 0) + 1; return r; };
const ro = [], rn = [];
for (const it of raw) {
  ro.push(match(it, idxOld, normKeyOld).how);
  rn.push(match(it, idxNew, normKey).how);
}
console.log('列表', raw.length);
console.log('  收口前(mod-match 字符类):', JSON.stringify(cnt(ro)));
console.log('  收口后(name-normalize)  :', JSON.stringify(cnt(rn)));

const lost = [], gain = [];
for (let i = 0; i < raw.length; i++) {
  if (ro[i] !== 'none' && rn[i] === 'none') lost.push({ t: raw[i].title, g: raw[i].game, old: ro[i], key: match(raw[i], idxOld, normKeyOld).key, lib: (match(raw[i], idxOld, normKeyOld).lib || {}).title });
  if (ro[i] === 'none' && rn[i] !== 'none') gain.push({ t: raw[i].title, g: raw[i].game, neu: rn[i] });
}
console.log('\n收口后**新增**匹配', gain.length);
console.log('收口后**丢失**匹配', lost.length);
console.log('\n=== 丢失样例（前 15）===');
lost.slice(0, 15).forEach((x) => {
  console.log('  ' + String(x.t).slice(0, 48));
  console.log('     旧 how=' + x.old + ' key=「' + x.key + '」 → 库「' + (x.lib || '') + '」');
});
console.log('\n=== 新增样例（前 8）===');
gain.slice(0, 8).forEach((x) => console.log('  ' + String(x.t).slice(0, 52) + '   → ' + x.neu));
