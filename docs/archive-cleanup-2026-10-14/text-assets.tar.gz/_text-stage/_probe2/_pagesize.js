#!/usr/bin/env node
/** _pagesize.js — 四页字节口径实测（KB = 磁盘字节 / 1024；JS/CSS = 标签内部字节） */
'use strict';
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..');
const PAGES = ['index', 'emulator', 'resources', 'unpack'];
let sum = 0, sumJs = 0, sumCss = 0;
for (const p of PAGES) {
  const f = path.join(ROOT, 'public', p + '.html');
  const s = fs.readFileSync(f);
  const txt = s.toString('utf8');
  const inner = (tag) => {
    let n = 0;
    const re = new RegExp('<' + tag + '(?:\\s[^>]*)?>([\\s\\S]*?)<\\/' + tag + '>', 'gi');
    for (const m of txt.matchAll(re)) n += Buffer.byteLength(m[1], 'utf8');
    return n;
  };
  const js = inner('script'), css = inner('style');
  const kb = s.length / 1024;
  const cnt = (tag) => (txt.match(new RegExp('<' + tag + '\\b', 'gi')) || []).length;
  sum += s.length; sumJs += js; sumCss += css;
  console.log(p.padEnd(10) + Math.round(kb) + ' KB 字节（JS ' + Math.round(js / 1024) + ' / CSS ' + Math.round(css / 1024)
    + '）  ' + s.length + ' bytes / ' + txt.length + ' chars  ｜ ' + cnt('script') + ' 个 script / ' + cnt('style') + ' 个 style');
}
console.log('四页合计 ' + Math.round(sum / 1024) + ' KB ≈ ' + (sum / 1048576).toFixed(2) + ' MB（字节 ' + sum.toLocaleString('en-US') + '）');
console.log('其中 JS ' + Math.round(sumJs / 1024) + ' KB / CSS ' + Math.round(sumCss / 1024) + ' KB');
