/* 探针：线上（v10.41 载荷）与本地（v10.53）在 `/api/library/browse` 上的差异。
 * 目的：给 ROADMAP 1.5 的「判版表」找一个 v10.53 专属区分器。
 * 跑法：node _probe2/p-browse-diff.js */
const https = require('https');
const http = require('http');

function get(u) {
  return new Promise((r) => {
    const m = u.startsWith('https') ? https : http;
    m.get(u, { timeout: 15000 }, (res) => {
      let s = '';
      res.on('data', (d) => { s += d; });
      res.on('end', () => r({ code: res.statusCode, body: s }));
    }).on('error', (e) => r({ code: 'ERR', body: e.message }))
      .on('timeout', function () { this.destroy(); r({ code: 'TIMEOUT', body: '' }); });
  });
}
const short = (u) => u.split('/').slice(3).join('/');

(async () => {
  const cases = ['mod=1', 'sv=1', 'tr=1'];
  for (const c of cases) {
    for (const [tag, base] of [['LIVE ', 'https://gamehub-agg-v4.app.workbuddy.host'],
      ['LOCAL', 'http://127.0.0.1:8123']]) {
      const u = base + '/api/library/browse?' + c + '&limit=1';
      const r = await get(u);
      let brief = r.body.slice(0, 140);
      try {
        const j = JSON.parse(r.body);
        const f = (j.items || [])[0] || {};
        brief = 'total=' + j.total + '  首行.res=' + JSON.stringify(f.res) + '  resId=' + JSON.stringify(f.resId);
      } catch (e) { /* 非 JSON 就原样打 */ }
      console.log(tag + ' ' + short(u) + '  → ' + r.code + '  ' + brief);
    }
  }
})();
