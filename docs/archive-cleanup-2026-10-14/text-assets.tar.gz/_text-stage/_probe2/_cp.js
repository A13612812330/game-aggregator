/* _probe2/_cp.js —— 沙箱内的反证「打坏 / 还原」驱动（仅调试用，不属于交付物）
 *
 * 为什么需要它：`tools/_counterproof-v1046.js` 用 `execFileSync` 拉起子套件，
 * 而本沙箱实测**禁止进程内再 spawn**（node 里连 `execFileSync('cmd')` 都是 EBUSY）。
 * 于是把「改坏 / 还原」这一半单独拿出来，由外层 shell 跑套件。
 *
 * ★ CASES 直接 require 正式脚本 —— 两边**不可能漂移**（这是这个薄壳存在的最大理由）。
 *
 * 用法：node _probe2/_cp.js apply <i>   /   node _probe2/_cp.js restore <i>
 */
'use strict';
const fs = require('fs');
const path = require('path');

const { CASES } = require('../tools/_counterproof-v1046.js');

const mode = process.argv[2];
const i = Number(process.argv[3]);
const c = CASES[i];
if (!c) { console.log('no case ' + i); process.exit(2); }

const bak = path.join(__dirname, '_cp_bak_' + i);

if (mode === 'apply') {
  const s = fs.readFileSync(c.file, 'utf8');
  const n = s.split(c.good).length - 1;
  if (n !== 1) { console.log('锚点次数=' + n + '（要求 1）'); process.exit(9); }
  fs.writeFileSync(bak, s, 'utf8');
  fs.writeFileSync(c.file, s.replace(c.good, c.bad), 'utf8');
  console.log('applied#' + i);
} else if (mode === 'restore') {
  fs.copyFileSync(bak, c.file);
  const a = fs.readFileSync(bak, 'utf8');
  const b = fs.readFileSync(c.file, 'utf8');
  console.log(a === b ? 'restored#' + i : 'RESTORE-BAD#' + i);
  if (a !== b) process.exit(3);
} else if (mode === 'expect') {
  console.log(c.expect.join(' | '));
} else {
  console.log('用法：apply|restore|expect <i>');
  process.exit(2);
}
