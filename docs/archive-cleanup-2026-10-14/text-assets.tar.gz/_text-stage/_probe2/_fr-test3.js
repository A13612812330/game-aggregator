/* 有头 Chrome 过 Cloudflare 挑战测试
 * 依据：CF 的 managed challenge 对 headless 特征敏感；真实有头浏览器通常几秒自动放行。
 * 本机约束（见 tools/browser.js 文件头）：Edge 在沙箱里起不来，Chrome 可以；
 * puppeteer.launch 的自有 spawn 链走不通 ⇒ 用 shell 拉起 + connect。 */
const http = require('http');
const path = require('path');
const fs = require('fs');
const { spawn, execFileSync } = require('child_process');
const puppeteer = require('puppeteer-core');

const CAND = [
  'C:/Users/komo/AppData/Local/Google/Chrome/Application/chrome.exe',
  'C:/Program Files/Google/Chrome/Application/chrome.exe',
];
const PORT = 9333;
const URL = process.argv[2] || 'https://fearlessrevolution.com/';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const cdpUp = (port) => new Promise((res) => {
  const r = http.get(`http://127.0.0.1:${port}/json/version`, (x) => { x.resume(); res(x.statusCode === 200); });
  r.on('error', () => res(false)); r.setTimeout(1200, () => { r.destroy(); res(false); });
});

(async () => {
  const exe = CAND.find((p) => fs.existsSync(p));
  if (!exe) { console.log('未找到 Chrome'); return; }
  const profile = path.join(__dirname, '..', '.cache', 'chrome-headed');
  fs.mkdirSync(profile, { recursive: true });
  console.log('拉起有头 Chrome…');
  const child = spawn(exe, [
    '--no-first-run', '--no-default-browser-check',
    `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`,
    '--window-size=1280,900', 'about:blank',
  ], { detached: true, stdio: 'ignore' });
  child.unref();

  let ok = false;
  for (let i = 0; i < 30 && !(ok = await cdpUp(PORT)); i++) await sleep(500);
  if (!ok) { console.log('CDP 未就绪（有头被沙箱拦？）'); try { execFileSync('taskkill', ['/PID', String(child.pid), '/T', '/F'], { stdio: 'ignore' }); } catch (e) {} return; }
  console.log('CDP 就绪');

  const b = await puppeteer.connect({ browserURL: `http://127.0.0.1:${PORT}` });
  const t0 = Date.now();
  try {
    const page = await b.newPage();
    const resp = await page.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 });
    console.log('HTTP', resp && resp.status());
    for (let i = 0; i < 8; i++) {
      await sleep(4000);
      const info = await page.evaluate(() => ({
        t: document.title, u: location.href,
        n: document.body ? document.body.innerText.length : 0,
        h: (document.body ? document.body.innerText : '').slice(0, 240).replace(/\s+/g, ' '),
      }));
      console.log(`  [${Date.now() - t0}ms] "${info.t}" len=${info.n}`);
      if (!/moment|稍候|Attention/i.test(info.t) && info.n > 800) { console.log('  ✔ 通过'); console.log('  ', info.h); break; }
    }
  } catch (e) { console.log('ERR', String(e.message).slice(0, 160)); }
  finally {
    try { await b.disconnect(); } catch (e) {}
    try { execFileSync('taskkill', ['/PID', String(child.pid), '/T', '/F'], { stdio: 'ignore' }); } catch (e) {}
  }
})();
