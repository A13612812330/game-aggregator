/* FR 三次探测：① f=4 普通主题内的附件下载链形式 ② 未登录能否下载 ③ f=5 Trainers 同款
 * 前两次教训：置顶帖(f=21)体积大且会超时 ⇒ 这里限定 f=4 且 t 值较大的普通帖，并降 timeout。 */
const http = require('http');
const path = require('path');
const fs = require('fs');
const { spawn, execFileSync } = require('child_process');
const puppeteer = require('puppeteer-core');

const CAND = ['C:/Users/komo/AppData/Local/Google/Chrome/Application/chrome.exe', 'C:/Program Files/Google/Chrome/Application/chrome.exe'];
const PORT = 9337;
const BASE = 'https://fearlessrevolution.com';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const cdpUp = (port) => new Promise((res) => {
  const r = http.get(`http://127.0.0.1:${port}/json/version`, (x) => { x.resume(); res(x.statusCode === 200); });
  r.on('error', () => res(false)); r.setTimeout(1200, () => { r.destroy(); res(false); });
});
const log = []; const P = (...a) => { const s = a.join(' '); log.push(s); console.log(s); };

(async () => {
  const exe = CAND.find((p) => fs.existsSync(p));
  const profile = path.join(__dirname, '..', '.cache', 'chrome-headed');
  fs.mkdirSync(profile, { recursive: true });
  const child = spawn(exe, ['--no-first-run', '--no-default-browser-check',
    `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`, '--window-size=1280,900', 'about:blank'],
    { detached: true, stdio: 'ignore' });
  child.unref();
  let ok = false;
  for (let i = 0; i < 30 && !(ok = await cdpUp(PORT)); i++) await sleep(500);
  if (!ok) { P('CDP 未就绪'); return; }
  const b = await puppeteer.connect({ browserURL: `http://127.0.0.1:${PORT}` });
  const page = await b.newPage();
  async function go(url, wait = 'domcontentloaded') {
    try { await page.goto(url, { waitUntil: wait, timeout: 35000 }); } catch (e) { P('  (导航异常 ' + String(e.message).slice(0, 50) + ')'); }
    for (let i = 0; i < 8; i++) {
      const t = await page.title().catch(() => '');
      if (!/moment|稍候|Attention/i.test(t)) return t;
      await sleep(3000);
    }
    return await page.title().catch(() => '');
  }
  const sess = () => page.evaluate(() => (document.body.innerText.match(/sid=([a-f0-9]+)/) || [])[1] || '');

  try {
    P('=== f=4 Tables 第 2 页取普通帖 ===');
    P('title:', await go(BASE + '/viewforum.php?f=4&start=50'));
    const cand = await page.evaluate(() => [...document.querySelectorAll('a[href*="viewtopic.php?f=4&t="]')]
      .map((a) => ({ t: a.innerText.trim().replace(/\s+/g, ' '), h: a.getAttribute('href') }))
      .filter((x) => x.t && x.t.length > 3 && /t=\d{4,}/.test(x.h)));
    P('候选帖:', cand.length);
    for (const c of cand.slice(0, 8)) P('  ' + c.t.slice(0, 64) + '  ->  ' + c.h);

    if (cand.length) {
      const url = BASE + '/' + cand[0].h.replace(/^\.\//, '');
      P('');
      P('=== 打开: ' + cand[0].t.slice(0, 60) + ' ===');
      P('title:', await go(url));
      const sid = await sess();
      const det = await page.evaluate(() => {
        const attrs = [];
        document.querySelectorAll('a').forEach((a) => {
          const h = a.getAttribute('href') || '';
          if (/download|attachment|\.ct$|\.zip$|\.rar$|\.exe$|\.7z$/i.test(h)) attrs.push({ t: a.innerText.trim().slice(0, 46), h, cls: String(a.className).slice(0, 24) });
        });
        return { attrs: attrs.slice(0, 20), body: document.body.innerText.replace(/\s+/g, ' ').slice(0, 1400) };
      });
      P('附件候选:', JSON.stringify(det.attrs, null, 1));
      P('正文:', det.body);
      P('sid:', sid);
    }
  } catch (e) { P('ERR', String(e.message).slice(0, 200)); }
  finally {
    fs.writeFileSync(path.join(__dirname, 'fr-explore3.txt'), log.join('\n'), 'utf8');
    try { await b.disconnect(); } catch (e) {}
    try { execFileSync('taskkill', ['/PID', String(child.pid), '/T', '/F'], { stdio: 'ignore' }); } catch (e) {}
    P('\n已写 _probe2/fr-explore3.txt');
  }
})();
