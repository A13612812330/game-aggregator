/* 反证 A：把「单行省略」改回 v10.48 前的「折 2 行」⇒ 新增的样式断言必须变红。
   只改主源不重建 = 派生页不动 = 断言不该全红 ⇒ 这里**连重建一起做**，模拟真实退化路径。 */
const fs = require('fs');
const p = 'public/index.html';
const s = fs.readFileSync(p, 'utf8');
const from = '  .emu-card.grp .gl-i .t{flex:1;min-width:0;font-size:11px;line-height:1.5;color:var(--c-t1);\n'
  + '    white-space:nowrap;overflow:hidden;text-overflow:ellipsis}';
const to = '  .emu-card.grp .gl-i .t{flex:1;min-width:0;font-size:11px;line-height:1.5;color:var(--c-t1);word-break:break-word;\n'
  + '    display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}';
if (!s.includes(from)) { console.log('❌ 未找到锚点 A（断言已失效或样式已被改）'); process.exit(1); }
fs.writeFileSync('_probe2/bak-index.html', s);
fs.writeFileSync(p, s.replace(from, to));
console.log('✅ 反证 A 已注入（主源 .gl-i .t 退回折 2 行）');
