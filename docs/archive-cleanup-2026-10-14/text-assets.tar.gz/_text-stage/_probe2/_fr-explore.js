/* 探明 fearlessrevolution.com（phpBB + Cloudflare）的数据模型
 * 产出（写 _probe2/fr-explore.txt）：
 *   ① 板块结构（viewforum.php?f=N）—— cheat tables / saves 在哪个板
 *   ② 搜索入口与结果 URL
 *   ③ 帖子页里的附件下载链形式
 * 说明：CF 查 TLS 指纹 ⇒ cookie 搬不到 node fetch，全程用浏览器会话。
 */
const http = require('http');
const path = require('path');
const fs = require('fs');
const { spawn, execFileSync } = require('child_process');
const puppeteer = require('puppeteer-core');

const CAND = [
  'C:/Users/komo/AppData/Local/Google/Chrome/Application/chrome.exe',
  'C:/Program Files/Google/Chrome/Application/chrome.exe',
];
const PORT = 9335;
const BASE = 'https://fearlessrevolution.com';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const cdpUp = (port) => new Promise((res) => {
  const r = http.get(`http://127.0.0.1:${port}/json/version`, (x) => { x.resume(); res(x.statusCode === 200); });
  r.on('error', () => res(false)); r.setTimeout(1200, () => { r.destroy(); res(false); });
});
const log = [];
const P = (...a) => { const s = a.join(' '); log.push(s); console.log(s); };

(async () => {
  const exe = CAND.find((p) => fs.existsSync(p));
  const profile = path.join(__dirname, '..', '.cache', 'chrome-headed');
  fs.mkdirSync(profile, { recursive: true });
  const child = spawn(exe, ['--no-first-run', '--no-default-browser-check',
    `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`, '--window-size=1280,900', 'about:blank'],
    { detached: true, stdio: 'ignore' });
  child.unref();
  let ok = false;
  for (let i = 0; i < 30 && !(ok = await cdpUp(PORT)); i++) await sleep(500);
  if (!ok) { P('CDP 未就绪'); return; }

  const b = await puppeteer.connect({ browserURL: `http://127.0.0.1:${PORT}` });
  const page = await b.newPage();

  /** 导航 + 等 CF 放行 */
  async function go(url) {
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 });
    for (let i = 0; i < 10; i++) {
      const t = await page.title();
      if (!/moment|稍候|Attention/i.test(t)) return t;
      await sleep(3000);
    }
    return await page.title();
  }

  try {
    P('=== ① 首页板块 ===');
    P('title:', await go(BASE + '/'));
    const forums = await page.evaluate(() => [...document.querySelectorAll('a[href*="viewforum.php"]')]
      .map((a) => ({ t: a.innerText.trim().replace(/\s+/g, ' '), h: a.getAttribute('href') }))
      .filter((x) => x.t));
    P('板块数:', forums.length);
    for (const f of forums.slice(0, 40)) P(`  ${f.t}  ->  ${f.h}`);

    P('');
    P('=== ② 搜索入口 ===');
    const forms = await page.evaluate(() => [...document.querySelectorAll('form')]
      .map((f) => ({ a: f.getAttribute('action'), m: f.getAttribute('method'), n: [...f.querySelectorAll('input,select')].map((i) => i.name + '=' + i.type).join(',') })));
    for (const f of forms.slice(0, 8)) P(`  form action=${f.a} method=${f.m} :: ${f.n}`);

    P('');
    P('=== ③ 搜索 Elden Ring ===');
    const t = await go(BASE + '/search.php?keywords=Elden+Ring');
    P('title:', t);
    P('url:', await page.evaluate(() => location.href));
    const hits = await page.evaluate(() => [...document.querySelectorAll('a[href*="viewtopic.php"]')]
      .map((a) => ({ t: a.innerText.trim().replace(/\s+/g, ' '), h: a.getAttribute('href') }))
      .filter((x) => x.t && x.t.length > 2).slice(0, 15));
    P('命中链接数(去重前):', hits.length);
    for (const h of hits) P(`  ${h.t.slice(0, 60)}  ->  ${h.h}`);

    P('');
    P('=== ④ 打开首个 topic 看附件 ===');
    if (hits.length) {
      const url = hits[0].h.startsWith('http') ? hits[0].h : BASE + '/' + hits[0].h.replace(/^\.\//, '');
      P('打开:', url);
      P('title:', await go(url));
      const att = await page.evaluate(() => {
        const out = [];
        document.querySelectorAll('a[href*="download"], a[href*="attachment"], a[href*=".ct"], a[href*=".zip"], a[href*=".rar"]')
          .forEach((a) => out.push({ t: a.innerText.trim().slice(0, 40), h: a.getAttribute('href') }));
        return out.slice(0, 20);
      });
      P('附件/下载链接:', JSON.stringify(att, null, 1));
      const body = await page.evaluate(() => document.body.innerText.slice(0, 1200).replace(/\s+/g, ' '));
      P('正文摘录:', body);
    }
  } catch (e) { P('ERR', String(e.message).slice(0, 200)); }
  finally {
    fs.writeFileSync(path.join(__dirname, 'fr-explore.txt'), log.join('\n'), 'utf8');
    try { await b.disconnect(); } catch (e) {}
    try { execFileSync('taskkill', ['/PID', String(child.pid), '/T', '/F'], { stdio: 'ignore' }); } catch (e) {}
    P('\n已写 _probe2/fr-explore.txt');
  }
})();
