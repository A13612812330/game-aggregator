/* FR 二次探测：① 搜索页正文为何 0 命中 ② 板块 f=4(Tables) 的帖子列表结构与分页 ③ topic 内附件形式 */
const http = require('http');
const path = require('path');
const fs = require('fs');
const { spawn, execFileSync } = require('child_process');
const puppeteer = require('puppeteer-core');

const CAND = ['C:/Users/komo/AppData/Local/Google/Chrome/Application/chrome.exe', 'C:/Program Files/Google/Chrome/Application/chrome.exe'];
const PORT = 9336;
const BASE = 'https://fearlessrevolution.com';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const cdpUp = (port) => new Promise((res) => {
  const r = http.get(`http://127.0.0.1:${port}/json/version`, (x) => { x.resume(); res(x.statusCode === 200); });
  r.on('error', () => res(false)); r.setTimeout(1200, () => { r.destroy(); res(false); });
});
const log = []; const P = (...a) => { const s = a.join(' '); log.push(s); console.log(s); };

(async () => {
  const exe = CAND.find((p) => fs.existsSync(p));
  const profile = path.join(__dirname, '..', '.cache', 'chrome-headed');
  fs.mkdirSync(profile, { recursive: true });
  const child = spawn(exe, ['--no-first-run', '--no-default-browser-check',
    `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`, '--window-size=1280,900', 'about:blank'],
    { detached: true, stdio: 'ignore' });
  child.unref();
  let ok = false;
  for (let i = 0; i < 30 && !(ok = await cdpUp(PORT)); i++) await sleep(500);
  if (!ok) { P('CDP 未就绪'); return; }
  const b = await puppeteer.connect({ browserURL: `http://127.0.0.1:${PORT}` });
  const page = await b.newPage();
  async function go(url) {
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 });
    for (let i = 0; i < 10; i++) {
      const t = await page.title();
      if (!/moment|稍候|Attention/i.test(t)) return t;
      await sleep(3000);
    }
    return await page.title();
  }
  try {
    P('=== 搜索页正文 ===');
    await go(BASE + '/search.php?keywords=Elden+Ring');
    P(await page.evaluate(() => document.body.innerText.replace(/\s+/g, ' ').slice(0, 700)));

    P('');
    P('=== viewforum f=4 (Tables) ===');
    P('title:', await go(BASE + '/viewforum.php?f=4'));
    const lst = await page.evaluate(() => {
      const rows = [...document.querySelectorAll('a[href*="viewtopic.php"]')]
        .map((a) => ({ t: a.innerText.trim().replace(/\s+/g, ' '), h: a.getAttribute('href') })).filter((x) => x.t);
      const pager = [...document.querySelectorAll('a[href*="start="], .pagination a, .pagination li')]
        .map((a) => a.innerText.trim()).filter((x) => x).slice(0, 25);
      const cnt = (document.body.innerText.match(/(\d+)\s+(topics|帖子)/i) || [])[0] || '';
      return { n: rows.length, rows: rows.slice(0, 12), pager, cnt };
    });
    P('帖子链接数:', lst.n, '| 计数文本:', lst.cnt);
    P('分页:', JSON.stringify(lst.pager));
    for (const r of lst.rows) P(`  ${r.t.slice(0, 70)}  ->  ${r.h}`);

    P('');
    P('=== 打开首个 topic ===');
    if (lst.rows.length) {
      const h = lst.rows[0].h;
      const url = h.startsWith('http') ? h : BASE + '/' + h.replace(/^\.\//, '');
      P('url:', url);
      P('title:', await go(url));
      const det = await page.evaluate(() => {
        const att = [];
        document.querySelectorAll('a[href*="download"], a[href*="attachment"], a[href*=".ct"], a[href*=".zip"], a[href*=".rar"], a[href*=".exe"]')
          .forEach((a) => att.push({ t: a.innerText.trim().slice(0, 40), h: a.getAttribute('href'), cls: a.className }));
        const title = (document.querySelector('h2, .topic-title, title') || {}).innerText || document.title;
        return { title, att: att.slice(0, 15), body: document.body.innerText.replace(/\s+/g, ' ').slice(0, 900) };
      });
      P('topic:', det.title);
      P('附件/下载:', JSON.stringify(det.att, null, 1));
      P('正文:', det.body);
    }
  } catch (e) { P('ERR', String(e.message).slice(0, 200)); }
  finally {
    fs.writeFileSync(path.join(__dirname, 'fr-explore2.txt'), log.join('\n'), 'utf8');
    try { await b.disconnect(); } catch (e) {}
    try { execFileSync('taskkill', ['/PID', String(child.pid), '/T', '/F'], { stdio: 'ignore' }); } catch (e) {}
    P('\n已写 _probe2/fr-explore2.txt');
  }
})();
